/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LdapSecretBackendLibrarySetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Disable enforcing that service accounts must be checked in by the entity or client token that checked them out.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/ldap_secret_backend_library_set#disable_check_in_enforcement LdapSecretBackendLibrarySet#disable_check_in_enforcement}
    */
    readonly disableCheckInEnforcement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/ldap_secret_backend_library_set#id LdapSecretBackendLibrarySet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The maximum amount of time a check-out last with renewal before Vault automatically checks it back in. Defaults to 24 hours.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/ldap_secret_backend_library_set#max_ttl LdapSecretBackendLibrarySet#max_ttl}
    */
    readonly maxTtl?: number;
    /**
    * The path where the LDAP secrets backend is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/ldap_secret_backend_library_set#mount LdapSecretBackendLibrarySet#mount}
    */
    readonly mount?: string;
    /**
    * The name of the set of service accounts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/ldap_secret_backend_library_set#name LdapSecretBackendLibrarySet#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/ldap_secret_backend_library_set#namespace LdapSecretBackendLibrarySet#namespace}
    */
    readonly namespace?: string;
    /**
    * The names of all the service accounts that can be checked out from this set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/ldap_secret_backend_library_set#service_account_names LdapSecretBackendLibrarySet#service_account_names}
    */
    readonly serviceAccountNames: string[];
    /**
    * The maximum amount of time a single check-out lasts before Vault automatically checks it back in. Defaults to 24 hours.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/ldap_secret_backend_library_set#ttl LdapSecretBackendLibrarySet#ttl}
    */
    readonly ttl?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/ldap_secret_backend_library_set vault_ldap_secret_backend_library_set}
*/
export declare class LdapSecretBackendLibrarySet extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_ldap_secret_backend_library_set";
    /**
    * Generates CDKTN code for importing a LdapSecretBackendLibrarySet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LdapSecretBackendLibrarySet to import
    * @param importFromId The id of the existing LdapSecretBackendLibrarySet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/ldap_secret_backend_library_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LdapSecretBackendLibrarySet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/ldap_secret_backend_library_set vault_ldap_secret_backend_library_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LdapSecretBackendLibrarySetConfig
    */
    constructor(scope: Construct, id: string, config: LdapSecretBackendLibrarySetConfig);
    private _disableCheckInEnforcement?;
    get disableCheckInEnforcement(): boolean | cdktn.IResolvable;
    set disableCheckInEnforcement(value: boolean | cdktn.IResolvable);
    resetDisableCheckInEnforcement(): void;
    get disableCheckInEnforcementInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxTtl?;
    get maxTtl(): number;
    set maxTtl(value: number);
    resetMaxTtl(): void;
    get maxTtlInput(): number | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    resetMount(): void;
    get mountInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _serviceAccountNames?;
    get serviceAccountNames(): string[];
    set serviceAccountNames(value: string[]);
    get serviceAccountNamesInput(): string[] | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

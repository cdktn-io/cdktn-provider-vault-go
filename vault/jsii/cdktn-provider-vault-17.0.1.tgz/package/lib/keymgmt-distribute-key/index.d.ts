/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface KeymgmtDistributeKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies the name of the key to distribute to the given KMS provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/keymgmt_distribute_key#key_name KeymgmtDistributeKey#key_name}
    */
    readonly keyName: string;
    /**
    * Specifies the name of the KMS provider to distribute the given key to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/keymgmt_distribute_key#kms_name KeymgmtDistributeKey#kms_name}
    */
    readonly kmsName: string;
    /**
    * Path of the Key Management secrets engine mount. Must match the `path` of a `vault_mount` resource with `type = "keymgmt"`. Use `vault_mount.keymgmt.path` here.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/keymgmt_distribute_key#mount KeymgmtDistributeKey#mount}
    */
    readonly mount: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/keymgmt_distribute_key#namespace KeymgmtDistributeKey#namespace}
    */
    readonly namespace?: string;
    /**
    * Specifies the protection of the key. The protection defines where cryptographic operations are performed with the key in the KMS provider. The following values are supported: hsm, software. Defaults to `hsm`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/keymgmt_distribute_key#protection KeymgmtDistributeKey#protection}
    */
    readonly protection?: string;
    /**
    * Specifies the purpose of the key. The purpose defines a set of cryptographic capabilities that the key will have in the KMS provider. A key must have at least one of the supported purposes. The following values are supported : encrypt, decrypt, sign, verify, wrap, unwrap.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/keymgmt_distribute_key#purpose KeymgmtDistributeKey#purpose}
    */
    readonly purpose: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/keymgmt_distribute_key vault_keymgmt_distribute_key}
*/
export declare class KeymgmtDistributeKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_keymgmt_distribute_key";
    /**
    * Generates CDKTN code for importing a KeymgmtDistributeKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KeymgmtDistributeKey to import
    * @param importFromId The id of the existing KeymgmtDistributeKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/keymgmt_distribute_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KeymgmtDistributeKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/keymgmt_distribute_key vault_keymgmt_distribute_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KeymgmtDistributeKeyConfig
    */
    constructor(scope: Construct, id: string, config: KeymgmtDistributeKeyConfig);
    private _keyName?;
    get keyName(): string;
    set keyName(value: string);
    get keyNameInput(): string | undefined;
    private _kmsName?;
    get kmsName(): string;
    set kmsName(value: string);
    get kmsNameInput(): string | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _protection?;
    get protection(): string;
    set protection(value: string);
    resetProtection(): void;
    get protectionInput(): string | undefined;
    private _purpose?;
    get purpose(): string[];
    set purpose(value: string[]);
    get purposeInput(): string[] | undefined;
    private _versions;
    get versions(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface KmipSecretRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name of the ca to use, if absent use legacy ca
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#ca KmipSecretRole#ca}
    */
    readonly ca?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#id KmipSecretRole#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#namespace KmipSecretRole#namespace}
    */
    readonly namespace?: string;
    /**
    * Grant permission to use the KMIP Activate operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_activate KmipSecretRole#operation_activate}
    */
    readonly operationActivate?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Add Attribute operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_add_attribute KmipSecretRole#operation_add_attribute}
    */
    readonly operationAddAttribute?: boolean | cdktn.IResolvable;
    /**
    * Grant all permissions to this role. May not be specified with any other operation_* params
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_all KmipSecretRole#operation_all}
    */
    readonly operationAll?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Create operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_create KmipSecretRole#operation_create}
    */
    readonly operationCreate?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Create Key Pair operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_create_key_pair KmipSecretRole#operation_create_key_pair}
    */
    readonly operationCreateKeyPair?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Decrypt operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_decrypt KmipSecretRole#operation_decrypt}
    */
    readonly operationDecrypt?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Delete Attribute operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_delete_attribute KmipSecretRole#operation_delete_attribute}
    */
    readonly operationDeleteAttribute?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Destroy operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_destroy KmipSecretRole#operation_destroy}
    */
    readonly operationDestroy?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Discover Version operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_discover_versions KmipSecretRole#operation_discover_versions}
    */
    readonly operationDiscoverVersions?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Encrypt operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_encrypt KmipSecretRole#operation_encrypt}
    */
    readonly operationEncrypt?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Get operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_get KmipSecretRole#operation_get}
    */
    readonly operationGet?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Get Attribute List operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_get_attribute_list KmipSecretRole#operation_get_attribute_list}
    */
    readonly operationGetAttributeList?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Get Attributes operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_get_attributes KmipSecretRole#operation_get_attributes}
    */
    readonly operationGetAttributes?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Import operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_import KmipSecretRole#operation_import}
    */
    readonly operationImport?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Locate operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_locate KmipSecretRole#operation_locate}
    */
    readonly operationLocate?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP MAC operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_mac KmipSecretRole#operation_mac}
    */
    readonly operationMac?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP MAC Verify operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_mac_verify KmipSecretRole#operation_mac_verify}
    */
    readonly operationMacVerify?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Modify Attribute operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_modify_attribute KmipSecretRole#operation_modify_attribute}
    */
    readonly operationModifyAttribute?: boolean | cdktn.IResolvable;
    /**
    * Remove all permissions from this role. May not be specified with any other operation_* params
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_none KmipSecretRole#operation_none}
    */
    readonly operationNone?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Query operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_query KmipSecretRole#operation_query}
    */
    readonly operationQuery?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Register operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_register KmipSecretRole#operation_register}
    */
    readonly operationRegister?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Rekey operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_rekey KmipSecretRole#operation_rekey}
    */
    readonly operationRekey?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Rekey Key Pair operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_rekey_key_pair KmipSecretRole#operation_rekey_key_pair}
    */
    readonly operationRekeyKeyPair?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Revoke operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_revoke KmipSecretRole#operation_revoke}
    */
    readonly operationRevoke?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP RNG Retrieve operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_rng_retrieve KmipSecretRole#operation_rng_retrieve}
    */
    readonly operationRngRetrieve?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP RNG Seed operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_rng_seed KmipSecretRole#operation_rng_seed}
    */
    readonly operationRngSeed?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Sign operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_sign KmipSecretRole#operation_sign}
    */
    readonly operationSign?: boolean | cdktn.IResolvable;
    /**
    * Grant permission to use the KMIP Signature Verify operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#operation_signature_verify KmipSecretRole#operation_signature_verify}
    */
    readonly operationSignatureVerify?: boolean | cdktn.IResolvable;
    /**
    * Path where KMIP backend is mounted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#path KmipSecretRole#path}
    */
    readonly path: string;
    /**
    * Name of the role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#role KmipSecretRole#role}
    */
    readonly role: string;
    /**
    * Name of the scope
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#scope KmipSecretRole#scope}
    */
    readonly scope: string;
    /**
    * Client certificate key bits, valid values depend on key type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#tls_client_key_bits KmipSecretRole#tls_client_key_bits}
    */
    readonly tlsClientKeyBits?: number;
    /**
    * Client certificate key type, rsa or ec
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#tls_client_key_type KmipSecretRole#tls_client_key_type}
    */
    readonly tlsClientKeyType?: string;
    /**
    * Client certificate TTL in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#tls_client_ttl KmipSecretRole#tls_client_ttl}
    */
    readonly tlsClientTtl?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role vault_kmip_secret_role}
*/
export declare class KmipSecretRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_kmip_secret_role";
    /**
    * Generates CDKTN code for importing a KmipSecretRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KmipSecretRole to import
    * @param importFromId The id of the existing KmipSecretRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KmipSecretRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/kmip_secret_role vault_kmip_secret_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KmipSecretRoleConfig
    */
    constructor(scope: Construct, id: string, config: KmipSecretRoleConfig);
    private _ca?;
    get ca(): string;
    set ca(value: string);
    resetCa(): void;
    get caInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _operationActivate?;
    get operationActivate(): boolean | cdktn.IResolvable;
    set operationActivate(value: boolean | cdktn.IResolvable);
    resetOperationActivate(): void;
    get operationActivateInput(): boolean | cdktn.IResolvable | undefined;
    private _operationAddAttribute?;
    get operationAddAttribute(): boolean | cdktn.IResolvable;
    set operationAddAttribute(value: boolean | cdktn.IResolvable);
    resetOperationAddAttribute(): void;
    get operationAddAttributeInput(): boolean | cdktn.IResolvable | undefined;
    private _operationAll?;
    get operationAll(): boolean | cdktn.IResolvable;
    set operationAll(value: boolean | cdktn.IResolvable);
    resetOperationAll(): void;
    get operationAllInput(): boolean | cdktn.IResolvable | undefined;
    private _operationCreate?;
    get operationCreate(): boolean | cdktn.IResolvable;
    set operationCreate(value: boolean | cdktn.IResolvable);
    resetOperationCreate(): void;
    get operationCreateInput(): boolean | cdktn.IResolvable | undefined;
    private _operationCreateKeyPair?;
    get operationCreateKeyPair(): boolean | cdktn.IResolvable;
    set operationCreateKeyPair(value: boolean | cdktn.IResolvable);
    resetOperationCreateKeyPair(): void;
    get operationCreateKeyPairInput(): boolean | cdktn.IResolvable | undefined;
    private _operationDecrypt?;
    get operationDecrypt(): boolean | cdktn.IResolvable;
    set operationDecrypt(value: boolean | cdktn.IResolvable);
    resetOperationDecrypt(): void;
    get operationDecryptInput(): boolean | cdktn.IResolvable | undefined;
    private _operationDeleteAttribute?;
    get operationDeleteAttribute(): boolean | cdktn.IResolvable;
    set operationDeleteAttribute(value: boolean | cdktn.IResolvable);
    resetOperationDeleteAttribute(): void;
    get operationDeleteAttributeInput(): boolean | cdktn.IResolvable | undefined;
    private _operationDestroy?;
    get operationDestroy(): boolean | cdktn.IResolvable;
    set operationDestroy(value: boolean | cdktn.IResolvable);
    resetOperationDestroy(): void;
    get operationDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _operationDiscoverVersions?;
    get operationDiscoverVersions(): boolean | cdktn.IResolvable;
    set operationDiscoverVersions(value: boolean | cdktn.IResolvable);
    resetOperationDiscoverVersions(): void;
    get operationDiscoverVersionsInput(): boolean | cdktn.IResolvable | undefined;
    private _operationEncrypt?;
    get operationEncrypt(): boolean | cdktn.IResolvable;
    set operationEncrypt(value: boolean | cdktn.IResolvable);
    resetOperationEncrypt(): void;
    get operationEncryptInput(): boolean | cdktn.IResolvable | undefined;
    private _operationGet?;
    get operationGet(): boolean | cdktn.IResolvable;
    set operationGet(value: boolean | cdktn.IResolvable);
    resetOperationGet(): void;
    get operationGetInput(): boolean | cdktn.IResolvable | undefined;
    private _operationGetAttributeList?;
    get operationGetAttributeList(): boolean | cdktn.IResolvable;
    set operationGetAttributeList(value: boolean | cdktn.IResolvable);
    resetOperationGetAttributeList(): void;
    get operationGetAttributeListInput(): boolean | cdktn.IResolvable | undefined;
    private _operationGetAttributes?;
    get operationGetAttributes(): boolean | cdktn.IResolvable;
    set operationGetAttributes(value: boolean | cdktn.IResolvable);
    resetOperationGetAttributes(): void;
    get operationGetAttributesInput(): boolean | cdktn.IResolvable | undefined;
    private _operationImport?;
    get operationImport(): boolean | cdktn.IResolvable;
    set operationImport(value: boolean | cdktn.IResolvable);
    resetOperationImport(): void;
    get operationImportInput(): boolean | cdktn.IResolvable | undefined;
    private _operationLocate?;
    get operationLocate(): boolean | cdktn.IResolvable;
    set operationLocate(value: boolean | cdktn.IResolvable);
    resetOperationLocate(): void;
    get operationLocateInput(): boolean | cdktn.IResolvable | undefined;
    private _operationMac?;
    get operationMac(): boolean | cdktn.IResolvable;
    set operationMac(value: boolean | cdktn.IResolvable);
    resetOperationMac(): void;
    get operationMacInput(): boolean | cdktn.IResolvable | undefined;
    private _operationMacVerify?;
    get operationMacVerify(): boolean | cdktn.IResolvable;
    set operationMacVerify(value: boolean | cdktn.IResolvable);
    resetOperationMacVerify(): void;
    get operationMacVerifyInput(): boolean | cdktn.IResolvable | undefined;
    private _operationModifyAttribute?;
    get operationModifyAttribute(): boolean | cdktn.IResolvable;
    set operationModifyAttribute(value: boolean | cdktn.IResolvable);
    resetOperationModifyAttribute(): void;
    get operationModifyAttributeInput(): boolean | cdktn.IResolvable | undefined;
    private _operationNone?;
    get operationNone(): boolean | cdktn.IResolvable;
    set operationNone(value: boolean | cdktn.IResolvable);
    resetOperationNone(): void;
    get operationNoneInput(): boolean | cdktn.IResolvable | undefined;
    private _operationQuery?;
    get operationQuery(): boolean | cdktn.IResolvable;
    set operationQuery(value: boolean | cdktn.IResolvable);
    resetOperationQuery(): void;
    get operationQueryInput(): boolean | cdktn.IResolvable | undefined;
    private _operationRegister?;
    get operationRegister(): boolean | cdktn.IResolvable;
    set operationRegister(value: boolean | cdktn.IResolvable);
    resetOperationRegister(): void;
    get operationRegisterInput(): boolean | cdktn.IResolvable | undefined;
    private _operationRekey?;
    get operationRekey(): boolean | cdktn.IResolvable;
    set operationRekey(value: boolean | cdktn.IResolvable);
    resetOperationRekey(): void;
    get operationRekeyInput(): boolean | cdktn.IResolvable | undefined;
    private _operationRekeyKeyPair?;
    get operationRekeyKeyPair(): boolean | cdktn.IResolvable;
    set operationRekeyKeyPair(value: boolean | cdktn.IResolvable);
    resetOperationRekeyKeyPair(): void;
    get operationRekeyKeyPairInput(): boolean | cdktn.IResolvable | undefined;
    private _operationRevoke?;
    get operationRevoke(): boolean | cdktn.IResolvable;
    set operationRevoke(value: boolean | cdktn.IResolvable);
    resetOperationRevoke(): void;
    get operationRevokeInput(): boolean | cdktn.IResolvable | undefined;
    private _operationRngRetrieve?;
    get operationRngRetrieve(): boolean | cdktn.IResolvable;
    set operationRngRetrieve(value: boolean | cdktn.IResolvable);
    resetOperationRngRetrieve(): void;
    get operationRngRetrieveInput(): boolean | cdktn.IResolvable | undefined;
    private _operationRngSeed?;
    get operationRngSeed(): boolean | cdktn.IResolvable;
    set operationRngSeed(value: boolean | cdktn.IResolvable);
    resetOperationRngSeed(): void;
    get operationRngSeedInput(): boolean | cdktn.IResolvable | undefined;
    private _operationSign?;
    get operationSign(): boolean | cdktn.IResolvable;
    set operationSign(value: boolean | cdktn.IResolvable);
    resetOperationSign(): void;
    get operationSignInput(): boolean | cdktn.IResolvable | undefined;
    private _operationSignatureVerify?;
    get operationSignatureVerify(): boolean | cdktn.IResolvable;
    set operationSignatureVerify(value: boolean | cdktn.IResolvable);
    resetOperationSignatureVerify(): void;
    get operationSignatureVerifyInput(): boolean | cdktn.IResolvable | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
    private _tlsClientKeyBits?;
    get tlsClientKeyBits(): number;
    set tlsClientKeyBits(value: number);
    resetTlsClientKeyBits(): void;
    get tlsClientKeyBitsInput(): number | undefined;
    private _tlsClientKeyType?;
    get tlsClientKeyType(): string;
    set tlsClientKeyType(value: string);
    resetTlsClientKeyType(): void;
    get tlsClientKeyTypeInput(): string | undefined;
    private _tlsClientTtl?;
    get tlsClientTtl(): number;
    set tlsClientTtl(value: number);
    resetTlsClientTtl(): void;
    get tlsClientTtlInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

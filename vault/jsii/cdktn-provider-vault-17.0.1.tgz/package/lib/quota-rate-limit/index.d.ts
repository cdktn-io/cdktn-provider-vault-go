/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface QuotaRateLimitConfig extends cdktn.TerraformMetaArguments {
    /**
    * If set, when a client reaches a rate limit threshold, the client will be prohibited from any further requests until after the 'block_interval' in seconds has elapsed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_rate_limit#block_interval QuotaRateLimit#block_interval}
    */
    readonly blockInterval?: number;
    /**
    * Attribute used to group requests for rate limiting. Limits are enforced independently for each group. Valid group_by modes are: 1) "ip" that groups requests by their source IP address (group_by defaults to ip if unset); 2) "none" that groups all requests that match the rate limit quota rule together; 3) "entity_then_ip" that groups requests by their entity ID for authenticated requests that carry one, or by their IP for unauthenticated requests (or requests whose authentication is not connected to an entity); and 4) "entity_then_none" which also groups requests by their entity ID when available, but the rest is all grouped together (i.e. unauthenticated or with authentication not connected to an entity).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_rate_limit#group_by QuotaRateLimit#group_by}
    */
    readonly groupBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_rate_limit#id QuotaRateLimit#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * If set to true on a quota where path is set to a namespace, the same quota will be cumulatively applied to all child namespace. The inheritable parameter cannot be set to true if the path does not specify a namespace. Only the quotas associated with the root namespace are inheritable by default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_rate_limit#inheritable QuotaRateLimit#inheritable}
    */
    readonly inheritable?: boolean | cdktn.IResolvable;
    /**
    * The duration in seconds to enforce rate limiting for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_rate_limit#interval QuotaRateLimit#interval}
    */
    readonly interval?: number;
    /**
    * The name of the quota.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_rate_limit#name QuotaRateLimit#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_rate_limit#namespace QuotaRateLimit#namespace}
    */
    readonly namespace?: string;
    /**
    * Path of the mount or namespace to apply the quota. A blank path configures a global rate limit quota.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_rate_limit#path QuotaRateLimit#path}
    */
    readonly path?: string;
    /**
    * The maximum number of requests at any given second to be allowed by the quota rule. The rate must be positive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_rate_limit#rate QuotaRateLimit#rate}
    */
    readonly rate: number;
    /**
    * If set on a quota where path is set to an auth mount with a concept of roles (such as /auth/approle/), this will make the quota restrict login requests to that mount that are made with the specified role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_rate_limit#role QuotaRateLimit#role}
    */
    readonly role?: string;
    /**
    * Only available when using the "entity_then_ip" or "entity_then_none" group_by modes. This is the rate limit applied to the requests that fall under the "ip" or "none" groupings, while the authenticated requests that contain an entity ID are subject to the "rate" field instead. Defaults to the same value as "rate".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_rate_limit#secondary_rate QuotaRateLimit#secondary_rate}
    */
    readonly secondaryRate?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_rate_limit vault_quota_rate_limit}
*/
export declare class QuotaRateLimit extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_quota_rate_limit";
    /**
    * Generates CDKTN code for importing a QuotaRateLimit resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the QuotaRateLimit to import
    * @param importFromId The id of the existing QuotaRateLimit that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_rate_limit#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the QuotaRateLimit to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_rate_limit vault_quota_rate_limit} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options QuotaRateLimitConfig
    */
    constructor(scope: Construct, id: string, config: QuotaRateLimitConfig);
    private _blockInterval?;
    get blockInterval(): number;
    set blockInterval(value: number);
    resetBlockInterval(): void;
    get blockIntervalInput(): number | undefined;
    private _groupBy?;
    get groupBy(): string;
    set groupBy(value: string);
    resetGroupBy(): void;
    get groupByInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inheritable?;
    get inheritable(): boolean | cdktn.IResolvable;
    set inheritable(value: boolean | cdktn.IResolvable);
    resetInheritable(): void;
    get inheritableInput(): boolean | cdktn.IResolvable | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _rate?;
    get rate(): number;
    set rate(value: number);
    get rateInput(): number | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
    private _secondaryRate?;
    get secondaryRate(): number;
    set secondaryRate(value: number);
    resetSecondaryRate(): void;
    get secondaryRateInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

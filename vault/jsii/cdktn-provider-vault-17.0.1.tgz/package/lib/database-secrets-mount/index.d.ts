/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseSecretsMountConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of managed key registry entry names that the mount in question is allowed to access
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_managed_keys DatabaseSecretsMount#allowed_managed_keys}
    */
    readonly allowedManagedKeys?: string[];
    /**
    * List of headers to allow and pass from the request to the plugin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_response_headers DatabaseSecretsMount#allowed_response_headers}
    */
    readonly allowedResponseHeaders?: string[];
    /**
    * Specifies the list of keys that will not be HMAC'd by audit devices in the request data object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#audit_non_hmac_request_keys DatabaseSecretsMount#audit_non_hmac_request_keys}
    */
    readonly auditNonHmacRequestKeys?: string[];
    /**
    * Specifies the list of keys that will not be HMAC'd by audit devices in the response data object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#audit_non_hmac_response_keys DatabaseSecretsMount#audit_non_hmac_response_keys}
    */
    readonly auditNonHmacResponseKeys?: string[];
    /**
    * Default lease duration for tokens and secrets in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#default_lease_ttl_seconds DatabaseSecretsMount#default_lease_ttl_seconds}
    */
    readonly defaultLeaseTtlSeconds?: number;
    /**
    * List of headers to allow and pass from the request to the plugin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#delegated_auth_accessors DatabaseSecretsMount#delegated_auth_accessors}
    */
    readonly delegatedAuthAccessors?: string[];
    /**
    * Human-friendly description of the mount
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#description DatabaseSecretsMount#description}
    */
    readonly description?: string;
    /**
    * Enable the secrets engine to access Vault's external entropy source
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#external_entropy_access DatabaseSecretsMount#external_entropy_access}
    */
    readonly externalEntropyAccess?: boolean | cdktn.IResolvable;
    /**
    * If set to true, disables caching.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#force_no_cache DatabaseSecretsMount#force_no_cache}
    */
    readonly forceNoCache?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#id DatabaseSecretsMount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The key to use for signing plugin workload identity tokens
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#identity_token_key DatabaseSecretsMount#identity_token_key}
    */
    readonly identityTokenKey?: string;
    /**
    * Specifies whether to show this mount in the UI-specific listing endpoint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#listing_visibility DatabaseSecretsMount#listing_visibility}
    */
    readonly listingVisibility?: string;
    /**
    * Local mount flag that can be explicitly set to true to enforce local mount in HA environment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#local DatabaseSecretsMount#local}
    */
    readonly local?: boolean | cdktn.IResolvable;
    /**
    * Maximum possible lease duration for tokens and secrets in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_lease_ttl_seconds DatabaseSecretsMount#max_lease_ttl_seconds}
    */
    readonly maxLeaseTtlSeconds?: number;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#namespace DatabaseSecretsMount#namespace}
    */
    readonly namespace?: string;
    /**
    * Specifies mount type specific options that are passed to the backend
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#options DatabaseSecretsMount#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * List of headers to allow and pass from the request to the plugin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#passthrough_request_headers DatabaseSecretsMount#passthrough_request_headers}
    */
    readonly passthroughRequestHeaders?: string[];
    /**
    * Where the secret backend will be mounted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#path DatabaseSecretsMount#path}
    */
    readonly path: string;
    /**
    * Specifies the semantic version of the plugin to use, e.g. 'v1.0.0'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_version DatabaseSecretsMount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * Enable seal wrapping for the mount, causing values stored by the mount to be wrapped by the seal's encryption capability
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#seal_wrap DatabaseSecretsMount#seal_wrap}
    */
    readonly sealWrap?: boolean | cdktn.IResolvable;
    /**
    * cassandra block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#cassandra DatabaseSecretsMount#cassandra}
    */
    readonly cassandra?: DatabaseSecretsMountCassandra[] | cdktn.IResolvable;
    /**
    * couchbase block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#couchbase DatabaseSecretsMount#couchbase}
    */
    readonly couchbase?: DatabaseSecretsMountCouchbase[] | cdktn.IResolvable;
    /**
    * elasticsearch block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#elasticsearch DatabaseSecretsMount#elasticsearch}
    */
    readonly elasticsearch?: DatabaseSecretsMountElasticsearch[] | cdktn.IResolvable;
    /**
    * hana block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#hana DatabaseSecretsMount#hana}
    */
    readonly hana?: DatabaseSecretsMountHana[] | cdktn.IResolvable;
    /**
    * influxdb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#influxdb DatabaseSecretsMount#influxdb}
    */
    readonly influxdb?: DatabaseSecretsMountInfluxdb[] | cdktn.IResolvable;
    /**
    * mongodb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#mongodb DatabaseSecretsMount#mongodb}
    */
    readonly mongodb?: DatabaseSecretsMountMongodb[] | cdktn.IResolvable;
    /**
    * mongodbatlas block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#mongodbatlas DatabaseSecretsMount#mongodbatlas}
    */
    readonly mongodbatlas?: DatabaseSecretsMountMongodbatlas[] | cdktn.IResolvable;
    /**
    * mssql block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#mssql DatabaseSecretsMount#mssql}
    */
    readonly mssql?: DatabaseSecretsMountMssql[] | cdktn.IResolvable;
    /**
    * mysql block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#mysql DatabaseSecretsMount#mysql}
    */
    readonly mysql?: DatabaseSecretsMountMysql[] | cdktn.IResolvable;
    /**
    * mysql_aurora block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#mysql_aurora DatabaseSecretsMount#mysql_aurora}
    */
    readonly mysqlAurora?: DatabaseSecretsMountMysqlAurora[] | cdktn.IResolvable;
    /**
    * mysql_legacy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#mysql_legacy DatabaseSecretsMount#mysql_legacy}
    */
    readonly mysqlLegacy?: DatabaseSecretsMountMysqlLegacy[] | cdktn.IResolvable;
    /**
    * mysql_rds block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#mysql_rds DatabaseSecretsMount#mysql_rds}
    */
    readonly mysqlRds?: DatabaseSecretsMountMysqlRds[] | cdktn.IResolvable;
    /**
    * oracle block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#oracle DatabaseSecretsMount#oracle}
    */
    readonly oracle?: DatabaseSecretsMountOracle[] | cdktn.IResolvable;
    /**
    * postgresql block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#postgresql DatabaseSecretsMount#postgresql}
    */
    readonly postgresql?: DatabaseSecretsMountPostgresql[] | cdktn.IResolvable;
    /**
    * redis block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#redis DatabaseSecretsMount#redis}
    */
    readonly redis?: DatabaseSecretsMountRedis[] | cdktn.IResolvable;
    /**
    * redis_elasticache block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#redis_elasticache DatabaseSecretsMount#redis_elasticache}
    */
    readonly redisElasticache?: DatabaseSecretsMountRedisElasticache[] | cdktn.IResolvable;
    /**
    * redshift block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#redshift DatabaseSecretsMount#redshift}
    */
    readonly redshift?: DatabaseSecretsMountRedshift[] | cdktn.IResolvable;
    /**
    * snowflake block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#snowflake DatabaseSecretsMount#snowflake}
    */
    readonly snowflake?: DatabaseSecretsMountSnowflake[] | cdktn.IResolvable;
}
export interface DatabaseSecretsMountCassandra {
    /**
    * A list of roles that are allowed to use this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_roles DatabaseSecretsMount#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * The number of seconds to use as a connection timeout.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#connect_timeout DatabaseSecretsMount#connect_timeout}
    */
    readonly connectTimeout?: number;
    /**
    * Cassandra consistency level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#consistency DatabaseSecretsMount#consistency}
    */
    readonly consistency?: string;
    /**
    * A map of sensitive data to pass to the endpoint. Useful for templated connection strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#data DatabaseSecretsMount#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_automated_rotation DatabaseSecretsMount#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * Cassandra hosts to connect to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#hosts DatabaseSecretsMount#hosts}
    */
    readonly hosts?: string[];
    /**
    * Whether to skip verification of the server certificate when using TLS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#insecure_tls DatabaseSecretsMount#insecure_tls}
    */
    readonly insecureTls?: boolean | cdktn.IResolvable;
    /**
    * Cassandra local datacenter name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#local_datacenter DatabaseSecretsMount#local_datacenter}
    */
    readonly localDatacenter?: string;
    /**
    * Name of the database connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#name DatabaseSecretsMount#name}
    */
    readonly name: string;
    /**
    * The password to use when authenticating with Cassandra.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password DatabaseSecretsMount#password}
    */
    readonly password?: string;
    /**
    * Optional name of the password policy to use for generated passwords.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_policy DatabaseSecretsMount#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * Concatenated PEM blocks containing a certificate and private key; a certificate, private key, and issuing CA certificate; or just a CA certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#pem_bundle DatabaseSecretsMount#pem_bundle}
    */
    readonly pemBundle?: string;
    /**
    * Specifies JSON containing a certificate and private key; a certificate, private key, and issuing CA certificate; or just a CA certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#pem_json DatabaseSecretsMount#pem_json}
    */
    readonly pemJson?: string;
    /**
    * Specifies the name of the plugin to use for this connection. Must be prefixed with the name of one of the supported database engine types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_name DatabaseSecretsMount#plugin_name}
    */
    readonly pluginName?: string;
    /**
    * Optional plugin version to use for this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_version DatabaseSecretsMount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * The transport port to use to connect to Cassandra.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#port DatabaseSecretsMount#port}
    */
    readonly port?: number;
    /**
    * The CQL protocol version to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#protocol_version DatabaseSecretsMount#protocol_version}
    */
    readonly protocolVersion?: number;
    /**
    * A list of database statements to be executed to rotate the root user's credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#root_rotation_statements DatabaseSecretsMount#root_rotation_statements}
    */
    readonly rootRotationStatements?: string[];
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_period DatabaseSecretsMount#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_schedule DatabaseSecretsMount#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_window DatabaseSecretsMount#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * Skip rotation of static role credentials on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#skip_static_role_import_rotation DatabaseSecretsMount#skip_static_role_import_rotation}
    */
    readonly skipStaticRoleImportRotation?: boolean | cdktn.IResolvable;
    /**
    * Skip permissions checks when a connection to Cassandra is first created. These checks ensure that Vault is able to create roles, but can be resource intensive in clusters with many roles.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#skip_verification DatabaseSecretsMount#skip_verification}
    */
    readonly skipVerification?: boolean | cdktn.IResolvable;
    /**
    * Enable TCP keepalive for Cassandra connections.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#socket_keep_alive DatabaseSecretsMount#socket_keep_alive}
    */
    readonly socketKeepAlive?: string;
    /**
    * Whether to use TLS when connecting to Cassandra.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#tls DatabaseSecretsMount#tls}
    */
    readonly tls?: boolean | cdktn.IResolvable;
    /**
    * SNI host for TLS connections.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#tls_server_name DatabaseSecretsMount#tls_server_name}
    */
    readonly tlsServerName?: string;
    /**
    * The username to use when authenticating with Cassandra.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username DatabaseSecretsMount#username}
    */
    readonly username?: string;
    /**
    * Template for dynamic Cassandra usernames.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username_template DatabaseSecretsMount#username_template}
    */
    readonly usernameTemplate?: string;
    /**
    * Specifies if the connection is verified during initial configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#verify_connection DatabaseSecretsMount#verify_connection}
    */
    readonly verifyConnection?: boolean | cdktn.IResolvable;
}
export declare function databaseSecretsMountCassandraToTerraform(struct?: DatabaseSecretsMountCassandra | cdktn.IResolvable): any;
export declare function databaseSecretsMountCassandraToHclTerraform(struct?: DatabaseSecretsMountCassandra | cdktn.IResolvable): any;
export declare class DatabaseSecretsMountCassandraOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseSecretsMountCassandra | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSecretsMountCassandra | cdktn.IResolvable | undefined);
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _connectTimeout?;
    get connectTimeout(): number;
    set connectTimeout(value: number);
    resetConnectTimeout(): void;
    get connectTimeoutInput(): number | undefined;
    private _consistency?;
    get consistency(): string;
    set consistency(value: string);
    resetConsistency(): void;
    get consistencyInput(): string | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _hosts?;
    get hosts(): string[];
    set hosts(value: string[]);
    resetHosts(): void;
    get hostsInput(): string[] | undefined;
    private _insecureTls?;
    get insecureTls(): boolean | cdktn.IResolvable;
    set insecureTls(value: boolean | cdktn.IResolvable);
    resetInsecureTls(): void;
    get insecureTlsInput(): boolean | cdktn.IResolvable | undefined;
    private _localDatacenter?;
    get localDatacenter(): string;
    set localDatacenter(value: string);
    resetLocalDatacenter(): void;
    get localDatacenterInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _pemBundle?;
    get pemBundle(): string;
    set pemBundle(value: string);
    resetPemBundle(): void;
    get pemBundleInput(): string | undefined;
    private _pemJson?;
    get pemJson(): string;
    set pemJson(value: string);
    resetPemJson(): void;
    get pemJsonInput(): string | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    resetPluginName(): void;
    get pluginNameInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _protocolVersion?;
    get protocolVersion(): number;
    set protocolVersion(value: number);
    resetProtocolVersion(): void;
    get protocolVersionInput(): number | undefined;
    private _rootRotationStatements?;
    get rootRotationStatements(): string[];
    set rootRotationStatements(value: string[]);
    resetRootRotationStatements(): void;
    get rootRotationStatementsInput(): string[] | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _skipStaticRoleImportRotation?;
    get skipStaticRoleImportRotation(): boolean | cdktn.IResolvable;
    set skipStaticRoleImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipStaticRoleImportRotation(): void;
    get skipStaticRoleImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _skipVerification?;
    get skipVerification(): boolean | cdktn.IResolvable;
    set skipVerification(value: boolean | cdktn.IResolvable);
    resetSkipVerification(): void;
    get skipVerificationInput(): boolean | cdktn.IResolvable | undefined;
    private _socketKeepAlive?;
    get socketKeepAlive(): string;
    set socketKeepAlive(value: string);
    resetSocketKeepAlive(): void;
    get socketKeepAliveInput(): string | undefined;
    private _tls?;
    get tls(): boolean | cdktn.IResolvable;
    set tls(value: boolean | cdktn.IResolvable);
    resetTls(): void;
    get tlsInput(): boolean | cdktn.IResolvable | undefined;
    private _tlsServerName?;
    get tlsServerName(): string;
    set tlsServerName(value: string);
    resetTlsServerName(): void;
    get tlsServerNameInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _usernameTemplate?;
    get usernameTemplate(): string;
    set usernameTemplate(value: string);
    resetUsernameTemplate(): void;
    get usernameTemplateInput(): string | undefined;
    private _verifyConnection?;
    get verifyConnection(): boolean | cdktn.IResolvable;
    set verifyConnection(value: boolean | cdktn.IResolvable);
    resetVerifyConnection(): void;
    get verifyConnectionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DatabaseSecretsMountCassandraList extends cdktn.ComplexList {
    internalValue?: DatabaseSecretsMountCassandra[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseSecretsMountCassandraOutputReference;
}
export interface DatabaseSecretsMountCouchbase {
    /**
    * A list of roles that are allowed to use this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_roles DatabaseSecretsMount#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * Required if `tls` is `true`. Specifies the certificate authority of the Couchbase server, as a PEM certificate that has been base64 encoded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#base64_pem DatabaseSecretsMount#base64_pem}
    */
    readonly base64Pem?: string;
    /**
    * Required for Couchbase versions prior to 6.5.0. This is only used to verify vault's connection to the server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#bucket_name DatabaseSecretsMount#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * A map of sensitive data to pass to the endpoint. Useful for templated connection strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#data DatabaseSecretsMount#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_automated_rotation DatabaseSecretsMount#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * A set of Couchbase URIs to connect to. Must use `couchbases://` scheme if `tls` is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#hosts DatabaseSecretsMount#hosts}
    */
    readonly hosts: string[];
    /**
    *  Specifies whether to skip verification of the server certificate when using TLS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#insecure_tls DatabaseSecretsMount#insecure_tls}
    */
    readonly insecureTls?: boolean | cdktn.IResolvable;
    /**
    * Name of the database connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#name DatabaseSecretsMount#name}
    */
    readonly name: string;
    /**
    * Specifies the password corresponding to the given username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password DatabaseSecretsMount#password}
    */
    readonly password: string;
    /**
    * Optional name of the password policy to use for generated passwords.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_policy DatabaseSecretsMount#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * Specifies the name of the plugin to use for this connection. Must be prefixed with the name of one of the supported database engine types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_name DatabaseSecretsMount#plugin_name}
    */
    readonly pluginName?: string;
    /**
    * Optional plugin version to use for this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_version DatabaseSecretsMount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * A list of database statements to be executed to rotate the root user's credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#root_rotation_statements DatabaseSecretsMount#root_rotation_statements}
    */
    readonly rootRotationStatements?: string[];
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_period DatabaseSecretsMount#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_schedule DatabaseSecretsMount#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_window DatabaseSecretsMount#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * Skip rotation of static role credentials on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#skip_static_role_import_rotation DatabaseSecretsMount#skip_static_role_import_rotation}
    */
    readonly skipStaticRoleImportRotation?: boolean | cdktn.IResolvable;
    /**
    * Specifies whether to use TLS when connecting to Couchbase.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#tls DatabaseSecretsMount#tls}
    */
    readonly tls?: boolean | cdktn.IResolvable;
    /**
    * Specifies the username for Vault to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username DatabaseSecretsMount#username}
    */
    readonly username: string;
    /**
    * Template describing how dynamic usernames are generated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username_template DatabaseSecretsMount#username_template}
    */
    readonly usernameTemplate?: string;
    /**
    * Specifies if the connection is verified during initial configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#verify_connection DatabaseSecretsMount#verify_connection}
    */
    readonly verifyConnection?: boolean | cdktn.IResolvable;
}
export declare function databaseSecretsMountCouchbaseToTerraform(struct?: DatabaseSecretsMountCouchbase | cdktn.IResolvable): any;
export declare function databaseSecretsMountCouchbaseToHclTerraform(struct?: DatabaseSecretsMountCouchbase | cdktn.IResolvable): any;
export declare class DatabaseSecretsMountCouchbaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseSecretsMountCouchbase | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSecretsMountCouchbase | cdktn.IResolvable | undefined);
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _base64Pem?;
    get base64Pem(): string;
    set base64Pem(value: string);
    resetBase64Pem(): void;
    get base64PemInput(): string | undefined;
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _hosts?;
    get hosts(): string[];
    set hosts(value: string[]);
    get hostsInput(): string[] | undefined;
    private _insecureTls?;
    get insecureTls(): boolean | cdktn.IResolvable;
    set insecureTls(value: boolean | cdktn.IResolvable);
    resetInsecureTls(): void;
    get insecureTlsInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    resetPluginName(): void;
    get pluginNameInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _rootRotationStatements?;
    get rootRotationStatements(): string[];
    set rootRotationStatements(value: string[]);
    resetRootRotationStatements(): void;
    get rootRotationStatementsInput(): string[] | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _skipStaticRoleImportRotation?;
    get skipStaticRoleImportRotation(): boolean | cdktn.IResolvable;
    set skipStaticRoleImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipStaticRoleImportRotation(): void;
    get skipStaticRoleImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _tls?;
    get tls(): boolean | cdktn.IResolvable;
    set tls(value: boolean | cdktn.IResolvable);
    resetTls(): void;
    get tlsInput(): boolean | cdktn.IResolvable | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    private _usernameTemplate?;
    get usernameTemplate(): string;
    set usernameTemplate(value: string);
    resetUsernameTemplate(): void;
    get usernameTemplateInput(): string | undefined;
    private _verifyConnection?;
    get verifyConnection(): boolean | cdktn.IResolvable;
    set verifyConnection(value: boolean | cdktn.IResolvable);
    resetVerifyConnection(): void;
    get verifyConnectionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DatabaseSecretsMountCouchbaseList extends cdktn.ComplexList {
    internalValue?: DatabaseSecretsMountCouchbase[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseSecretsMountCouchbaseOutputReference;
}
export interface DatabaseSecretsMountElasticsearch {
    /**
    * A list of roles that are allowed to use this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_roles DatabaseSecretsMount#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * The path to a PEM-encoded CA cert file to use to verify the Elasticsearch server's identity
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#ca_cert DatabaseSecretsMount#ca_cert}
    */
    readonly caCert?: string;
    /**
    * The path to a directory of PEM-encoded CA cert files to use to verify the Elasticsearch server's identity
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#ca_path DatabaseSecretsMount#ca_path}
    */
    readonly caPath?: string;
    /**
    * The path to the certificate for the Elasticsearch client to present for communication
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#client_cert DatabaseSecretsMount#client_cert}
    */
    readonly clientCert?: string;
    /**
    * The path to the key for the Elasticsearch client to use for communication
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#client_key DatabaseSecretsMount#client_key}
    */
    readonly clientKey?: string;
    /**
    * A map of sensitive data to pass to the endpoint. Useful for templated connection strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#data DatabaseSecretsMount#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_automated_rotation DatabaseSecretsMount#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * Whether to disable certificate verification
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#insecure DatabaseSecretsMount#insecure}
    */
    readonly insecure?: boolean | cdktn.IResolvable;
    /**
    * Name of the database connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#name DatabaseSecretsMount#name}
    */
    readonly name: string;
    /**
    * The password to be used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password DatabaseSecretsMount#password}
    */
    readonly password: string;
    /**
    * Optional name of the password policy to use for generated passwords.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_policy DatabaseSecretsMount#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * Specifies the name of the plugin to use for this connection. Must be prefixed with the name of one of the supported database engine types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_name DatabaseSecretsMount#plugin_name}
    */
    readonly pluginName?: string;
    /**
    * Optional plugin version to use for this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_version DatabaseSecretsMount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * A list of database statements to be executed to rotate the root user's credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#root_rotation_statements DatabaseSecretsMount#root_rotation_statements}
    */
    readonly rootRotationStatements?: string[];
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_period DatabaseSecretsMount#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_schedule DatabaseSecretsMount#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_window DatabaseSecretsMount#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * Skip rotation of static role credentials on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#skip_static_role_import_rotation DatabaseSecretsMount#skip_static_role_import_rotation}
    */
    readonly skipStaticRoleImportRotation?: boolean | cdktn.IResolvable;
    /**
    * This, if set, is used to set the SNI host when connecting via TLS
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#tls_server_name DatabaseSecretsMount#tls_server_name}
    */
    readonly tlsServerName?: string;
    /**
    * The URL for Elasticsearch's API
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#url DatabaseSecretsMount#url}
    */
    readonly url: string;
    /**
    * The username to be used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username DatabaseSecretsMount#username}
    */
    readonly username: string;
    /**
    * Template describing how dynamic usernames are generated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username_template DatabaseSecretsMount#username_template}
    */
    readonly usernameTemplate?: string;
    /**
    * Specifies if the connection is verified during initial configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#verify_connection DatabaseSecretsMount#verify_connection}
    */
    readonly verifyConnection?: boolean | cdktn.IResolvable;
}
export declare function databaseSecretsMountElasticsearchToTerraform(struct?: DatabaseSecretsMountElasticsearch | cdktn.IResolvable): any;
export declare function databaseSecretsMountElasticsearchToHclTerraform(struct?: DatabaseSecretsMountElasticsearch | cdktn.IResolvable): any;
export declare class DatabaseSecretsMountElasticsearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseSecretsMountElasticsearch | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSecretsMountElasticsearch | cdktn.IResolvable | undefined);
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _caCert?;
    get caCert(): string;
    set caCert(value: string);
    resetCaCert(): void;
    get caCertInput(): string | undefined;
    private _caPath?;
    get caPath(): string;
    set caPath(value: string);
    resetCaPath(): void;
    get caPathInput(): string | undefined;
    private _clientCert?;
    get clientCert(): string;
    set clientCert(value: string);
    resetClientCert(): void;
    get clientCertInput(): string | undefined;
    private _clientKey?;
    get clientKey(): string;
    set clientKey(value: string);
    resetClientKey(): void;
    get clientKeyInput(): string | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _insecure?;
    get insecure(): boolean | cdktn.IResolvable;
    set insecure(value: boolean | cdktn.IResolvable);
    resetInsecure(): void;
    get insecureInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    resetPluginName(): void;
    get pluginNameInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _rootRotationStatements?;
    get rootRotationStatements(): string[];
    set rootRotationStatements(value: string[]);
    resetRootRotationStatements(): void;
    get rootRotationStatementsInput(): string[] | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _skipStaticRoleImportRotation?;
    get skipStaticRoleImportRotation(): boolean | cdktn.IResolvable;
    set skipStaticRoleImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipStaticRoleImportRotation(): void;
    get skipStaticRoleImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _tlsServerName?;
    get tlsServerName(): string;
    set tlsServerName(value: string);
    resetTlsServerName(): void;
    get tlsServerNameInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    private _usernameTemplate?;
    get usernameTemplate(): string;
    set usernameTemplate(value: string);
    resetUsernameTemplate(): void;
    get usernameTemplateInput(): string | undefined;
    private _verifyConnection?;
    get verifyConnection(): boolean | cdktn.IResolvable;
    set verifyConnection(value: boolean | cdktn.IResolvable);
    resetVerifyConnection(): void;
    get verifyConnectionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DatabaseSecretsMountElasticsearchList extends cdktn.ComplexList {
    internalValue?: DatabaseSecretsMountElasticsearch[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseSecretsMountElasticsearchOutputReference;
}
export interface DatabaseSecretsMountHana {
    /**
    * A list of roles that are allowed to use this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_roles DatabaseSecretsMount#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * Connection string to use to connect to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#connection_url DatabaseSecretsMount#connection_url}
    */
    readonly connectionUrl?: string;
    /**
    * A map of sensitive data to pass to the endpoint. Useful for templated connection strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#data DatabaseSecretsMount#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_automated_rotation DatabaseSecretsMount#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * Disable special character escaping in username and password
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_escaping DatabaseSecretsMount#disable_escaping}
    */
    readonly disableEscaping?: boolean | cdktn.IResolvable;
    /**
    * Maximum number of seconds a connection may be reused.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_connection_lifetime DatabaseSecretsMount#max_connection_lifetime}
    */
    readonly maxConnectionLifetime?: number;
    /**
    * Maximum number of idle connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_idle_connections DatabaseSecretsMount#max_idle_connections}
    */
    readonly maxIdleConnections?: number;
    /**
    * Maximum number of open connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_open_connections DatabaseSecretsMount#max_open_connections}
    */
    readonly maxOpenConnections?: number;
    /**
    * Name of the database connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#name DatabaseSecretsMount#name}
    */
    readonly name: string;
    /**
    * The root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password DatabaseSecretsMount#password}
    */
    readonly password?: string;
    /**
    * Optional name of the password policy to use for generated passwords.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_policy DatabaseSecretsMount#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * Write-only field for the root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo DatabaseSecretsMount#password_wo}
    */
    readonly passwordWo?: string;
    /**
    * Version counter for root credential password write-only field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo_version DatabaseSecretsMount#password_wo_version}
    */
    readonly passwordWoVersion?: number;
    /**
    * Specifies the name of the plugin to use for this connection. Must be prefixed with the name of one of the supported database engine types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_name DatabaseSecretsMount#plugin_name}
    */
    readonly pluginName?: string;
    /**
    * Optional plugin version to use for this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_version DatabaseSecretsMount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * A list of database statements to be executed to rotate the root user's credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#root_rotation_statements DatabaseSecretsMount#root_rotation_statements}
    */
    readonly rootRotationStatements?: string[];
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_period DatabaseSecretsMount#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_schedule DatabaseSecretsMount#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_window DatabaseSecretsMount#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * Skip rotation of static role credentials on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#skip_static_role_import_rotation DatabaseSecretsMount#skip_static_role_import_rotation}
    */
    readonly skipStaticRoleImportRotation?: boolean | cdktn.IResolvable;
    /**
    * The root credential username used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username DatabaseSecretsMount#username}
    */
    readonly username?: string;
    /**
    * Username generation template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username_template DatabaseSecretsMount#username_template}
    */
    readonly usernameTemplate?: string;
    /**
    * Specifies if the connection is verified during initial configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#verify_connection DatabaseSecretsMount#verify_connection}
    */
    readonly verifyConnection?: boolean | cdktn.IResolvable;
}
export declare function databaseSecretsMountHanaToTerraform(struct?: DatabaseSecretsMountHana | cdktn.IResolvable): any;
export declare function databaseSecretsMountHanaToHclTerraform(struct?: DatabaseSecretsMountHana | cdktn.IResolvable): any;
export declare class DatabaseSecretsMountHanaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseSecretsMountHana | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSecretsMountHana | cdktn.IResolvable | undefined);
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _connectionUrl?;
    get connectionUrl(): string;
    set connectionUrl(value: string);
    resetConnectionUrl(): void;
    get connectionUrlInput(): string | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _disableEscaping?;
    get disableEscaping(): boolean | cdktn.IResolvable;
    set disableEscaping(value: boolean | cdktn.IResolvable);
    resetDisableEscaping(): void;
    get disableEscapingInput(): boolean | cdktn.IResolvable | undefined;
    private _maxConnectionLifetime?;
    get maxConnectionLifetime(): number;
    set maxConnectionLifetime(value: number);
    resetMaxConnectionLifetime(): void;
    get maxConnectionLifetimeInput(): number | undefined;
    private _maxIdleConnections?;
    get maxIdleConnections(): number;
    set maxIdleConnections(value: number);
    resetMaxIdleConnections(): void;
    get maxIdleConnectionsInput(): number | undefined;
    private _maxOpenConnections?;
    get maxOpenConnections(): number;
    set maxOpenConnections(value: number);
    resetMaxOpenConnections(): void;
    get maxOpenConnectionsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _passwordWo?;
    get passwordWo(): string;
    set passwordWo(value: string);
    resetPasswordWo(): void;
    get passwordWoInput(): string | undefined;
    private _passwordWoVersion?;
    get passwordWoVersion(): number;
    set passwordWoVersion(value: number);
    resetPasswordWoVersion(): void;
    get passwordWoVersionInput(): number | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    resetPluginName(): void;
    get pluginNameInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _rootRotationStatements?;
    get rootRotationStatements(): string[];
    set rootRotationStatements(value: string[]);
    resetRootRotationStatements(): void;
    get rootRotationStatementsInput(): string[] | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _skipStaticRoleImportRotation?;
    get skipStaticRoleImportRotation(): boolean | cdktn.IResolvable;
    set skipStaticRoleImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipStaticRoleImportRotation(): void;
    get skipStaticRoleImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _usernameTemplate?;
    get usernameTemplate(): string;
    set usernameTemplate(value: string);
    resetUsernameTemplate(): void;
    get usernameTemplateInput(): string | undefined;
    private _verifyConnection?;
    get verifyConnection(): boolean | cdktn.IResolvable;
    set verifyConnection(value: boolean | cdktn.IResolvable);
    resetVerifyConnection(): void;
    get verifyConnectionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DatabaseSecretsMountHanaList extends cdktn.ComplexList {
    internalValue?: DatabaseSecretsMountHana[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseSecretsMountHanaOutputReference;
}
export interface DatabaseSecretsMountInfluxdb {
    /**
    * A list of roles that are allowed to use this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_roles DatabaseSecretsMount#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * The number of seconds to use as a connection timeout.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#connect_timeout DatabaseSecretsMount#connect_timeout}
    */
    readonly connectTimeout?: number;
    /**
    * A map of sensitive data to pass to the endpoint. Useful for templated connection strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#data DatabaseSecretsMount#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_automated_rotation DatabaseSecretsMount#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * Influxdb host to connect to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#host DatabaseSecretsMount#host}
    */
    readonly host: string;
    /**
    * Whether to skip verification of the server certificate when using TLS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#insecure_tls DatabaseSecretsMount#insecure_tls}
    */
    readonly insecureTls?: boolean | cdktn.IResolvable;
    /**
    * Name of the database connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#name DatabaseSecretsMount#name}
    */
    readonly name: string;
    /**
    * Specifies the password corresponding to the given username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password DatabaseSecretsMount#password}
    */
    readonly password: string;
    /**
    * Optional name of the password policy to use for generated passwords.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_policy DatabaseSecretsMount#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * Concatenated PEM blocks containing a certificate and private key; a certificate, private key, and issuing CA certificate; or just a CA certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#pem_bundle DatabaseSecretsMount#pem_bundle}
    */
    readonly pemBundle?: string;
    /**
    * Specifies JSON containing a certificate and private key; a certificate, private key, and issuing CA certificate; or just a CA certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#pem_json DatabaseSecretsMount#pem_json}
    */
    readonly pemJson?: string;
    /**
    * Specifies the name of the plugin to use for this connection. Must be prefixed with the name of one of the supported database engine types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_name DatabaseSecretsMount#plugin_name}
    */
    readonly pluginName?: string;
    /**
    * Optional plugin version to use for this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_version DatabaseSecretsMount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * The transport port to use to connect to Influxdb.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#port DatabaseSecretsMount#port}
    */
    readonly port?: number;
    /**
    * A list of database statements to be executed to rotate the root user's credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#root_rotation_statements DatabaseSecretsMount#root_rotation_statements}
    */
    readonly rootRotationStatements?: string[];
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_period DatabaseSecretsMount#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_schedule DatabaseSecretsMount#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_window DatabaseSecretsMount#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * Skip rotation of static role credentials on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#skip_static_role_import_rotation DatabaseSecretsMount#skip_static_role_import_rotation}
    */
    readonly skipStaticRoleImportRotation?: boolean | cdktn.IResolvable;
    /**
    * Whether to use TLS when connecting to Influxdb.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#tls DatabaseSecretsMount#tls}
    */
    readonly tls?: boolean | cdktn.IResolvable;
    /**
    * Specifies the username to use for superuser access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username DatabaseSecretsMount#username}
    */
    readonly username: string;
    /**
    * Template describing how dynamic usernames are generated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username_template DatabaseSecretsMount#username_template}
    */
    readonly usernameTemplate?: string;
    /**
    * Specifies if the connection is verified during initial configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#verify_connection DatabaseSecretsMount#verify_connection}
    */
    readonly verifyConnection?: boolean | cdktn.IResolvable;
}
export declare function databaseSecretsMountInfluxdbToTerraform(struct?: DatabaseSecretsMountInfluxdb | cdktn.IResolvable): any;
export declare function databaseSecretsMountInfluxdbToHclTerraform(struct?: DatabaseSecretsMountInfluxdb | cdktn.IResolvable): any;
export declare class DatabaseSecretsMountInfluxdbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseSecretsMountInfluxdb | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSecretsMountInfluxdb | cdktn.IResolvable | undefined);
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _connectTimeout?;
    get connectTimeout(): number;
    set connectTimeout(value: number);
    resetConnectTimeout(): void;
    get connectTimeoutInput(): number | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _host?;
    get host(): string;
    set host(value: string);
    get hostInput(): string | undefined;
    private _insecureTls?;
    get insecureTls(): boolean | cdktn.IResolvable;
    set insecureTls(value: boolean | cdktn.IResolvable);
    resetInsecureTls(): void;
    get insecureTlsInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _pemBundle?;
    get pemBundle(): string;
    set pemBundle(value: string);
    resetPemBundle(): void;
    get pemBundleInput(): string | undefined;
    private _pemJson?;
    get pemJson(): string;
    set pemJson(value: string);
    resetPemJson(): void;
    get pemJsonInput(): string | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    resetPluginName(): void;
    get pluginNameInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _rootRotationStatements?;
    get rootRotationStatements(): string[];
    set rootRotationStatements(value: string[]);
    resetRootRotationStatements(): void;
    get rootRotationStatementsInput(): string[] | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _skipStaticRoleImportRotation?;
    get skipStaticRoleImportRotation(): boolean | cdktn.IResolvable;
    set skipStaticRoleImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipStaticRoleImportRotation(): void;
    get skipStaticRoleImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _tls?;
    get tls(): boolean | cdktn.IResolvable;
    set tls(value: boolean | cdktn.IResolvable);
    resetTls(): void;
    get tlsInput(): boolean | cdktn.IResolvable | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    private _usernameTemplate?;
    get usernameTemplate(): string;
    set usernameTemplate(value: string);
    resetUsernameTemplate(): void;
    get usernameTemplateInput(): string | undefined;
    private _verifyConnection?;
    get verifyConnection(): boolean | cdktn.IResolvable;
    set verifyConnection(value: boolean | cdktn.IResolvable);
    resetVerifyConnection(): void;
    get verifyConnectionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DatabaseSecretsMountInfluxdbList extends cdktn.ComplexList {
    internalValue?: DatabaseSecretsMountInfluxdb[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseSecretsMountInfluxdbOutputReference;
}
export interface DatabaseSecretsMountMongodb {
    /**
    * A list of roles that are allowed to use this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_roles DatabaseSecretsMount#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * Connection string to use to connect to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#connection_url DatabaseSecretsMount#connection_url}
    */
    readonly connectionUrl?: string;
    /**
    * A map of sensitive data to pass to the endpoint. Useful for templated connection strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#data DatabaseSecretsMount#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_automated_rotation DatabaseSecretsMount#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * Maximum number of seconds a connection may be reused.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_connection_lifetime DatabaseSecretsMount#max_connection_lifetime}
    */
    readonly maxConnectionLifetime?: number;
    /**
    * Maximum number of idle connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_idle_connections DatabaseSecretsMount#max_idle_connections}
    */
    readonly maxIdleConnections?: number;
    /**
    * Maximum number of open connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_open_connections DatabaseSecretsMount#max_open_connections}
    */
    readonly maxOpenConnections?: number;
    /**
    * Name of the database connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#name DatabaseSecretsMount#name}
    */
    readonly name: string;
    /**
    * The root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password DatabaseSecretsMount#password}
    */
    readonly password?: string;
    /**
    * Optional name of the password policy to use for generated passwords.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_policy DatabaseSecretsMount#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * Write-only field for the root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo DatabaseSecretsMount#password_wo}
    */
    readonly passwordWo?: string;
    /**
    * Version counter for root credential password write-only field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo_version DatabaseSecretsMount#password_wo_version}
    */
    readonly passwordWoVersion?: number;
    /**
    * Specifies the name of the plugin to use for this connection. Must be prefixed with the name of one of the supported database engine types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_name DatabaseSecretsMount#plugin_name}
    */
    readonly pluginName?: string;
    /**
    * Optional plugin version to use for this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_version DatabaseSecretsMount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * A list of database statements to be executed to rotate the root user's credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#root_rotation_statements DatabaseSecretsMount#root_rotation_statements}
    */
    readonly rootRotationStatements?: string[];
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_period DatabaseSecretsMount#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_schedule DatabaseSecretsMount#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_window DatabaseSecretsMount#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * Skip rotation of static role credentials on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#skip_static_role_import_rotation DatabaseSecretsMount#skip_static_role_import_rotation}
    */
    readonly skipStaticRoleImportRotation?: boolean | cdktn.IResolvable;
    /**
    * The x509 CA file for validating the certificate presented by the MongoDB server. Must be PEM encoded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#tls_ca DatabaseSecretsMount#tls_ca}
    */
    readonly tlsCa?: string;
    /**
    * The x509 certificate and private key bundle for connecting to the database. Must be PEM encoded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#tls_certificate_key DatabaseSecretsMount#tls_certificate_key}
    */
    readonly tlsCertificateKey?: string;
    /**
    * The root credential username used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username DatabaseSecretsMount#username}
    */
    readonly username?: string;
    /**
    * Username generation template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username_template DatabaseSecretsMount#username_template}
    */
    readonly usernameTemplate?: string;
    /**
    * Specifies if the connection is verified during initial configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#verify_connection DatabaseSecretsMount#verify_connection}
    */
    readonly verifyConnection?: boolean | cdktn.IResolvable;
    /**
    * Specifies the MongoDB write concern for Vault management operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#write_concern DatabaseSecretsMount#write_concern}
    */
    readonly writeConcern?: string;
}
export declare function databaseSecretsMountMongodbToTerraform(struct?: DatabaseSecretsMountMongodb | cdktn.IResolvable): any;
export declare function databaseSecretsMountMongodbToHclTerraform(struct?: DatabaseSecretsMountMongodb | cdktn.IResolvable): any;
export declare class DatabaseSecretsMountMongodbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseSecretsMountMongodb | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSecretsMountMongodb | cdktn.IResolvable | undefined);
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _connectionUrl?;
    get connectionUrl(): string;
    set connectionUrl(value: string);
    resetConnectionUrl(): void;
    get connectionUrlInput(): string | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _maxConnectionLifetime?;
    get maxConnectionLifetime(): number;
    set maxConnectionLifetime(value: number);
    resetMaxConnectionLifetime(): void;
    get maxConnectionLifetimeInput(): number | undefined;
    private _maxIdleConnections?;
    get maxIdleConnections(): number;
    set maxIdleConnections(value: number);
    resetMaxIdleConnections(): void;
    get maxIdleConnectionsInput(): number | undefined;
    private _maxOpenConnections?;
    get maxOpenConnections(): number;
    set maxOpenConnections(value: number);
    resetMaxOpenConnections(): void;
    get maxOpenConnectionsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _passwordWo?;
    get passwordWo(): string;
    set passwordWo(value: string);
    resetPasswordWo(): void;
    get passwordWoInput(): string | undefined;
    private _passwordWoVersion?;
    get passwordWoVersion(): number;
    set passwordWoVersion(value: number);
    resetPasswordWoVersion(): void;
    get passwordWoVersionInput(): number | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    resetPluginName(): void;
    get pluginNameInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _rootRotationStatements?;
    get rootRotationStatements(): string[];
    set rootRotationStatements(value: string[]);
    resetRootRotationStatements(): void;
    get rootRotationStatementsInput(): string[] | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _skipStaticRoleImportRotation?;
    get skipStaticRoleImportRotation(): boolean | cdktn.IResolvable;
    set skipStaticRoleImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipStaticRoleImportRotation(): void;
    get skipStaticRoleImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _tlsCa?;
    get tlsCa(): string;
    set tlsCa(value: string);
    resetTlsCa(): void;
    get tlsCaInput(): string | undefined;
    private _tlsCertificateKey?;
    get tlsCertificateKey(): string;
    set tlsCertificateKey(value: string);
    resetTlsCertificateKey(): void;
    get tlsCertificateKeyInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _usernameTemplate?;
    get usernameTemplate(): string;
    set usernameTemplate(value: string);
    resetUsernameTemplate(): void;
    get usernameTemplateInput(): string | undefined;
    private _verifyConnection?;
    get verifyConnection(): boolean | cdktn.IResolvable;
    set verifyConnection(value: boolean | cdktn.IResolvable);
    resetVerifyConnection(): void;
    get verifyConnectionInput(): boolean | cdktn.IResolvable | undefined;
    private _writeConcern?;
    get writeConcern(): string;
    set writeConcern(value: string);
    resetWriteConcern(): void;
    get writeConcernInput(): string | undefined;
}
export declare class DatabaseSecretsMountMongodbList extends cdktn.ComplexList {
    internalValue?: DatabaseSecretsMountMongodb[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseSecretsMountMongodbOutputReference;
}
export interface DatabaseSecretsMountMongodbatlas {
    /**
    * A list of roles that are allowed to use this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_roles DatabaseSecretsMount#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * A map of sensitive data to pass to the endpoint. Useful for templated connection strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#data DatabaseSecretsMount#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_automated_rotation DatabaseSecretsMount#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * Name of the database connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#name DatabaseSecretsMount#name}
    */
    readonly name: string;
    /**
    * Optional name of the password policy to use for generated passwords.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_policy DatabaseSecretsMount#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * Specifies the name of the plugin to use for this connection. Must be prefixed with the name of one of the supported database engine types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_name DatabaseSecretsMount#plugin_name}
    */
    readonly pluginName?: string;
    /**
    * Optional plugin version to use for this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_version DatabaseSecretsMount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * The Private Programmatic API Key used to connect with MongoDB Atlas API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#private_key DatabaseSecretsMount#private_key}
    */
    readonly privateKey: string;
    /**
    * The Project ID the Database User should be created within.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#project_id DatabaseSecretsMount#project_id}
    */
    readonly projectId: string;
    /**
    * The Public Programmatic API Key used to authenticate with the MongoDB Atlas API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#public_key DatabaseSecretsMount#public_key}
    */
    readonly publicKey: string;
    /**
    * A list of database statements to be executed to rotate the root user's credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#root_rotation_statements DatabaseSecretsMount#root_rotation_statements}
    */
    readonly rootRotationStatements?: string[];
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_period DatabaseSecretsMount#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_schedule DatabaseSecretsMount#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_window DatabaseSecretsMount#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * Skip rotation of static role credentials on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#skip_static_role_import_rotation DatabaseSecretsMount#skip_static_role_import_rotation}
    */
    readonly skipStaticRoleImportRotation?: boolean | cdktn.IResolvable;
    /**
    * Template describing how dynamic usernames are generated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username_template DatabaseSecretsMount#username_template}
    */
    readonly usernameTemplate?: string;
    /**
    * Specifies if the connection is verified during initial configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#verify_connection DatabaseSecretsMount#verify_connection}
    */
    readonly verifyConnection?: boolean | cdktn.IResolvable;
}
export declare function databaseSecretsMountMongodbatlasToTerraform(struct?: DatabaseSecretsMountMongodbatlas | cdktn.IResolvable): any;
export declare function databaseSecretsMountMongodbatlasToHclTerraform(struct?: DatabaseSecretsMountMongodbatlas | cdktn.IResolvable): any;
export declare class DatabaseSecretsMountMongodbatlasOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseSecretsMountMongodbatlas | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSecretsMountMongodbatlas | cdktn.IResolvable | undefined);
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    resetPluginName(): void;
    get pluginNameInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    get privateKeyInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _publicKey?;
    get publicKey(): string;
    set publicKey(value: string);
    get publicKeyInput(): string | undefined;
    private _rootRotationStatements?;
    get rootRotationStatements(): string[];
    set rootRotationStatements(value: string[]);
    resetRootRotationStatements(): void;
    get rootRotationStatementsInput(): string[] | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _skipStaticRoleImportRotation?;
    get skipStaticRoleImportRotation(): boolean | cdktn.IResolvable;
    set skipStaticRoleImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipStaticRoleImportRotation(): void;
    get skipStaticRoleImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _usernameTemplate?;
    get usernameTemplate(): string;
    set usernameTemplate(value: string);
    resetUsernameTemplate(): void;
    get usernameTemplateInput(): string | undefined;
    private _verifyConnection?;
    get verifyConnection(): boolean | cdktn.IResolvable;
    set verifyConnection(value: boolean | cdktn.IResolvable);
    resetVerifyConnection(): void;
    get verifyConnectionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DatabaseSecretsMountMongodbatlasList extends cdktn.ComplexList {
    internalValue?: DatabaseSecretsMountMongodbatlas[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseSecretsMountMongodbatlasOutputReference;
}
export interface DatabaseSecretsMountMssql {
    /**
    * A list of roles that are allowed to use this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_roles DatabaseSecretsMount#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * Connection string to use to connect to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#connection_url DatabaseSecretsMount#connection_url}
    */
    readonly connectionUrl?: string;
    /**
    * Set to true when the target is a Contained Database, e.g. AzureSQL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#contained_db DatabaseSecretsMount#contained_db}
    */
    readonly containedDb?: boolean | cdktn.IResolvable;
    /**
    * A map of sensitive data to pass to the endpoint. Useful for templated connection strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#data DatabaseSecretsMount#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_automated_rotation DatabaseSecretsMount#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * Disable special character escaping in username and password
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_escaping DatabaseSecretsMount#disable_escaping}
    */
    readonly disableEscaping?: boolean | cdktn.IResolvable;
    /**
    * Maximum number of seconds a connection may be reused.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_connection_lifetime DatabaseSecretsMount#max_connection_lifetime}
    */
    readonly maxConnectionLifetime?: number;
    /**
    * Maximum number of idle connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_idle_connections DatabaseSecretsMount#max_idle_connections}
    */
    readonly maxIdleConnections?: number;
    /**
    * Maximum number of open connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_open_connections DatabaseSecretsMount#max_open_connections}
    */
    readonly maxOpenConnections?: number;
    /**
    * Name of the database connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#name DatabaseSecretsMount#name}
    */
    readonly name: string;
    /**
    * The root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password DatabaseSecretsMount#password}
    */
    readonly password?: string;
    /**
    * Optional name of the password policy to use for generated passwords.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_policy DatabaseSecretsMount#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * Write-only field for the root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo DatabaseSecretsMount#password_wo}
    */
    readonly passwordWo?: string;
    /**
    * Version counter for root credential password write-only field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo_version DatabaseSecretsMount#password_wo_version}
    */
    readonly passwordWoVersion?: number;
    /**
    * Specifies the name of the plugin to use for this connection. Must be prefixed with the name of one of the supported database engine types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_name DatabaseSecretsMount#plugin_name}
    */
    readonly pluginName?: string;
    /**
    * Optional plugin version to use for this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_version DatabaseSecretsMount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * A list of database statements to be executed to rotate the root user's credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#root_rotation_statements DatabaseSecretsMount#root_rotation_statements}
    */
    readonly rootRotationStatements?: string[];
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_period DatabaseSecretsMount#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_schedule DatabaseSecretsMount#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_window DatabaseSecretsMount#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * Skip rotation of static role credentials on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#skip_static_role_import_rotation DatabaseSecretsMount#skip_static_role_import_rotation}
    */
    readonly skipStaticRoleImportRotation?: boolean | cdktn.IResolvable;
    /**
    * The root credential username used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username DatabaseSecretsMount#username}
    */
    readonly username?: string;
    /**
    * Username generation template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username_template DatabaseSecretsMount#username_template}
    */
    readonly usernameTemplate?: string;
    /**
    * Specifies if the connection is verified during initial configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#verify_connection DatabaseSecretsMount#verify_connection}
    */
    readonly verifyConnection?: boolean | cdktn.IResolvable;
}
export declare function databaseSecretsMountMssqlToTerraform(struct?: DatabaseSecretsMountMssql | cdktn.IResolvable): any;
export declare function databaseSecretsMountMssqlToHclTerraform(struct?: DatabaseSecretsMountMssql | cdktn.IResolvable): any;
export declare class DatabaseSecretsMountMssqlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseSecretsMountMssql | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSecretsMountMssql | cdktn.IResolvable | undefined);
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _connectionUrl?;
    get connectionUrl(): string;
    set connectionUrl(value: string);
    resetConnectionUrl(): void;
    get connectionUrlInput(): string | undefined;
    private _containedDb?;
    get containedDb(): boolean | cdktn.IResolvable;
    set containedDb(value: boolean | cdktn.IResolvable);
    resetContainedDb(): void;
    get containedDbInput(): boolean | cdktn.IResolvable | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _disableEscaping?;
    get disableEscaping(): boolean | cdktn.IResolvable;
    set disableEscaping(value: boolean | cdktn.IResolvable);
    resetDisableEscaping(): void;
    get disableEscapingInput(): boolean | cdktn.IResolvable | undefined;
    private _maxConnectionLifetime?;
    get maxConnectionLifetime(): number;
    set maxConnectionLifetime(value: number);
    resetMaxConnectionLifetime(): void;
    get maxConnectionLifetimeInput(): number | undefined;
    private _maxIdleConnections?;
    get maxIdleConnections(): number;
    set maxIdleConnections(value: number);
    resetMaxIdleConnections(): void;
    get maxIdleConnectionsInput(): number | undefined;
    private _maxOpenConnections?;
    get maxOpenConnections(): number;
    set maxOpenConnections(value: number);
    resetMaxOpenConnections(): void;
    get maxOpenConnectionsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _passwordWo?;
    get passwordWo(): string;
    set passwordWo(value: string);
    resetPasswordWo(): void;
    get passwordWoInput(): string | undefined;
    private _passwordWoVersion?;
    get passwordWoVersion(): number;
    set passwordWoVersion(value: number);
    resetPasswordWoVersion(): void;
    get passwordWoVersionInput(): number | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    resetPluginName(): void;
    get pluginNameInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _rootRotationStatements?;
    get rootRotationStatements(): string[];
    set rootRotationStatements(value: string[]);
    resetRootRotationStatements(): void;
    get rootRotationStatementsInput(): string[] | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _skipStaticRoleImportRotation?;
    get skipStaticRoleImportRotation(): boolean | cdktn.IResolvable;
    set skipStaticRoleImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipStaticRoleImportRotation(): void;
    get skipStaticRoleImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _usernameTemplate?;
    get usernameTemplate(): string;
    set usernameTemplate(value: string);
    resetUsernameTemplate(): void;
    get usernameTemplateInput(): string | undefined;
    private _verifyConnection?;
    get verifyConnection(): boolean | cdktn.IResolvable;
    set verifyConnection(value: boolean | cdktn.IResolvable);
    resetVerifyConnection(): void;
    get verifyConnectionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DatabaseSecretsMountMssqlList extends cdktn.ComplexList {
    internalValue?: DatabaseSecretsMountMssql[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseSecretsMountMssqlOutputReference;
}
export interface DatabaseSecretsMountMysql {
    /**
    * A list of roles that are allowed to use this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_roles DatabaseSecretsMount#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * Specify alternative authorization type. (Only 'gcp_iam' is valid currently)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#auth_type DatabaseSecretsMount#auth_type}
    */
    readonly authType?: string;
    /**
    * Connection string to use to connect to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#connection_url DatabaseSecretsMount#connection_url}
    */
    readonly connectionUrl?: string;
    /**
    * A map of sensitive data to pass to the endpoint. Useful for templated connection strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#data DatabaseSecretsMount#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_automated_rotation DatabaseSecretsMount#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * Maximum number of seconds a connection may be reused.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_connection_lifetime DatabaseSecretsMount#max_connection_lifetime}
    */
    readonly maxConnectionLifetime?: number;
    /**
    * Maximum number of idle connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_idle_connections DatabaseSecretsMount#max_idle_connections}
    */
    readonly maxIdleConnections?: number;
    /**
    * Maximum number of open connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_open_connections DatabaseSecretsMount#max_open_connections}
    */
    readonly maxOpenConnections?: number;
    /**
    * Name of the database connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#name DatabaseSecretsMount#name}
    */
    readonly name: string;
    /**
    * The root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password DatabaseSecretsMount#password}
    */
    readonly password?: string;
    /**
    * Optional name of the password policy to use for generated passwords.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_policy DatabaseSecretsMount#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * Write-only field for the root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo DatabaseSecretsMount#password_wo}
    */
    readonly passwordWo?: string;
    /**
    * Version counter for root credential password write-only field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo_version DatabaseSecretsMount#password_wo_version}
    */
    readonly passwordWoVersion?: number;
    /**
    * Specifies the name of the plugin to use for this connection. Must be prefixed with the name of one of the supported database engine types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_name DatabaseSecretsMount#plugin_name}
    */
    readonly pluginName?: string;
    /**
    * Optional plugin version to use for this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_version DatabaseSecretsMount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * A list of database statements to be executed to rotate the root user's credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#root_rotation_statements DatabaseSecretsMount#root_rotation_statements}
    */
    readonly rootRotationStatements?: string[];
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_period DatabaseSecretsMount#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_schedule DatabaseSecretsMount#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_window DatabaseSecretsMount#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * A JSON encoded credential for use with IAM authorization
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#service_account_json DatabaseSecretsMount#service_account_json}
    */
    readonly serviceAccountJson?: string;
    /**
    * Skip rotation of static role credentials on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#skip_static_role_import_rotation DatabaseSecretsMount#skip_static_role_import_rotation}
    */
    readonly skipStaticRoleImportRotation?: boolean | cdktn.IResolvable;
    /**
    * x509 CA file for validating the certificate presented by the MySQL server. Must be PEM encoded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#tls_ca DatabaseSecretsMount#tls_ca}
    */
    readonly tlsCa?: string;
    /**
    * x509 certificate for connecting to the database. This must be a PEM encoded version of the private key and the certificate combined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#tls_certificate_key DatabaseSecretsMount#tls_certificate_key}
    */
    readonly tlsCertificateKey?: string;
    /**
    * The root credential username used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username DatabaseSecretsMount#username}
    */
    readonly username?: string;
    /**
    * Username generation template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username_template DatabaseSecretsMount#username_template}
    */
    readonly usernameTemplate?: string;
    /**
    * Specifies if the connection is verified during initial configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#verify_connection DatabaseSecretsMount#verify_connection}
    */
    readonly verifyConnection?: boolean | cdktn.IResolvable;
}
export declare function databaseSecretsMountMysqlToTerraform(struct?: DatabaseSecretsMountMysql | cdktn.IResolvable): any;
export declare function databaseSecretsMountMysqlToHclTerraform(struct?: DatabaseSecretsMountMysql | cdktn.IResolvable): any;
export declare class DatabaseSecretsMountMysqlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseSecretsMountMysql | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSecretsMountMysql | cdktn.IResolvable | undefined);
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _authType?;
    get authType(): string;
    set authType(value: string);
    resetAuthType(): void;
    get authTypeInput(): string | undefined;
    private _connectionUrl?;
    get connectionUrl(): string;
    set connectionUrl(value: string);
    resetConnectionUrl(): void;
    get connectionUrlInput(): string | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _maxConnectionLifetime?;
    get maxConnectionLifetime(): number;
    set maxConnectionLifetime(value: number);
    resetMaxConnectionLifetime(): void;
    get maxConnectionLifetimeInput(): number | undefined;
    private _maxIdleConnections?;
    get maxIdleConnections(): number;
    set maxIdleConnections(value: number);
    resetMaxIdleConnections(): void;
    get maxIdleConnectionsInput(): number | undefined;
    private _maxOpenConnections?;
    get maxOpenConnections(): number;
    set maxOpenConnections(value: number);
    resetMaxOpenConnections(): void;
    get maxOpenConnectionsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _passwordWo?;
    get passwordWo(): string;
    set passwordWo(value: string);
    resetPasswordWo(): void;
    get passwordWoInput(): string | undefined;
    private _passwordWoVersion?;
    get passwordWoVersion(): number;
    set passwordWoVersion(value: number);
    resetPasswordWoVersion(): void;
    get passwordWoVersionInput(): number | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    resetPluginName(): void;
    get pluginNameInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _rootRotationStatements?;
    get rootRotationStatements(): string[];
    set rootRotationStatements(value: string[]);
    resetRootRotationStatements(): void;
    get rootRotationStatementsInput(): string[] | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _serviceAccountJson?;
    get serviceAccountJson(): string;
    set serviceAccountJson(value: string);
    resetServiceAccountJson(): void;
    get serviceAccountJsonInput(): string | undefined;
    private _skipStaticRoleImportRotation?;
    get skipStaticRoleImportRotation(): boolean | cdktn.IResolvable;
    set skipStaticRoleImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipStaticRoleImportRotation(): void;
    get skipStaticRoleImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _tlsCa?;
    get tlsCa(): string;
    set tlsCa(value: string);
    resetTlsCa(): void;
    get tlsCaInput(): string | undefined;
    private _tlsCertificateKey?;
    get tlsCertificateKey(): string;
    set tlsCertificateKey(value: string);
    resetTlsCertificateKey(): void;
    get tlsCertificateKeyInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _usernameTemplate?;
    get usernameTemplate(): string;
    set usernameTemplate(value: string);
    resetUsernameTemplate(): void;
    get usernameTemplateInput(): string | undefined;
    private _verifyConnection?;
    get verifyConnection(): boolean | cdktn.IResolvable;
    set verifyConnection(value: boolean | cdktn.IResolvable);
    resetVerifyConnection(): void;
    get verifyConnectionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DatabaseSecretsMountMysqlList extends cdktn.ComplexList {
    internalValue?: DatabaseSecretsMountMysql[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseSecretsMountMysqlOutputReference;
}
export interface DatabaseSecretsMountMysqlAurora {
    /**
    * A list of roles that are allowed to use this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_roles DatabaseSecretsMount#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * Specify alternative authorization type. (Only 'gcp_iam' is valid currently)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#auth_type DatabaseSecretsMount#auth_type}
    */
    readonly authType?: string;
    /**
    * Connection string to use to connect to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#connection_url DatabaseSecretsMount#connection_url}
    */
    readonly connectionUrl?: string;
    /**
    * A map of sensitive data to pass to the endpoint. Useful for templated connection strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#data DatabaseSecretsMount#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_automated_rotation DatabaseSecretsMount#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * Maximum number of seconds a connection may be reused.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_connection_lifetime DatabaseSecretsMount#max_connection_lifetime}
    */
    readonly maxConnectionLifetime?: number;
    /**
    * Maximum number of idle connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_idle_connections DatabaseSecretsMount#max_idle_connections}
    */
    readonly maxIdleConnections?: number;
    /**
    * Maximum number of open connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_open_connections DatabaseSecretsMount#max_open_connections}
    */
    readonly maxOpenConnections?: number;
    /**
    * Name of the database connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#name DatabaseSecretsMount#name}
    */
    readonly name: string;
    /**
    * The root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password DatabaseSecretsMount#password}
    */
    readonly password?: string;
    /**
    * Optional name of the password policy to use for generated passwords.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_policy DatabaseSecretsMount#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * Write-only field for the root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo DatabaseSecretsMount#password_wo}
    */
    readonly passwordWo?: string;
    /**
    * Version counter for root credential password write-only field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo_version DatabaseSecretsMount#password_wo_version}
    */
    readonly passwordWoVersion?: number;
    /**
    * Specifies the name of the plugin to use for this connection. Must be prefixed with the name of one of the supported database engine types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_name DatabaseSecretsMount#plugin_name}
    */
    readonly pluginName?: string;
    /**
    * Optional plugin version to use for this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_version DatabaseSecretsMount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * A list of database statements to be executed to rotate the root user's credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#root_rotation_statements DatabaseSecretsMount#root_rotation_statements}
    */
    readonly rootRotationStatements?: string[];
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_period DatabaseSecretsMount#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_schedule DatabaseSecretsMount#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_window DatabaseSecretsMount#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * A JSON encoded credential for use with IAM authorization
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#service_account_json DatabaseSecretsMount#service_account_json}
    */
    readonly serviceAccountJson?: string;
    /**
    * Skip rotation of static role credentials on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#skip_static_role_import_rotation DatabaseSecretsMount#skip_static_role_import_rotation}
    */
    readonly skipStaticRoleImportRotation?: boolean | cdktn.IResolvable;
    /**
    * x509 CA file for validating the certificate presented by the MySQL server. Must be PEM encoded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#tls_ca DatabaseSecretsMount#tls_ca}
    */
    readonly tlsCa?: string;
    /**
    * x509 certificate for connecting to the database. This must be a PEM encoded version of the private key and the certificate combined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#tls_certificate_key DatabaseSecretsMount#tls_certificate_key}
    */
    readonly tlsCertificateKey?: string;
    /**
    * The root credential username used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username DatabaseSecretsMount#username}
    */
    readonly username?: string;
    /**
    * Username generation template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username_template DatabaseSecretsMount#username_template}
    */
    readonly usernameTemplate?: string;
    /**
    * Specifies if the connection is verified during initial configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#verify_connection DatabaseSecretsMount#verify_connection}
    */
    readonly verifyConnection?: boolean | cdktn.IResolvable;
}
export declare function databaseSecretsMountMysqlAuroraToTerraform(struct?: DatabaseSecretsMountMysqlAurora | cdktn.IResolvable): any;
export declare function databaseSecretsMountMysqlAuroraToHclTerraform(struct?: DatabaseSecretsMountMysqlAurora | cdktn.IResolvable): any;
export declare class DatabaseSecretsMountMysqlAuroraOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseSecretsMountMysqlAurora | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSecretsMountMysqlAurora | cdktn.IResolvable | undefined);
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _authType?;
    get authType(): string;
    set authType(value: string);
    resetAuthType(): void;
    get authTypeInput(): string | undefined;
    private _connectionUrl?;
    get connectionUrl(): string;
    set connectionUrl(value: string);
    resetConnectionUrl(): void;
    get connectionUrlInput(): string | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _maxConnectionLifetime?;
    get maxConnectionLifetime(): number;
    set maxConnectionLifetime(value: number);
    resetMaxConnectionLifetime(): void;
    get maxConnectionLifetimeInput(): number | undefined;
    private _maxIdleConnections?;
    get maxIdleConnections(): number;
    set maxIdleConnections(value: number);
    resetMaxIdleConnections(): void;
    get maxIdleConnectionsInput(): number | undefined;
    private _maxOpenConnections?;
    get maxOpenConnections(): number;
    set maxOpenConnections(value: number);
    resetMaxOpenConnections(): void;
    get maxOpenConnectionsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _passwordWo?;
    get passwordWo(): string;
    set passwordWo(value: string);
    resetPasswordWo(): void;
    get passwordWoInput(): string | undefined;
    private _passwordWoVersion?;
    get passwordWoVersion(): number;
    set passwordWoVersion(value: number);
    resetPasswordWoVersion(): void;
    get passwordWoVersionInput(): number | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    resetPluginName(): void;
    get pluginNameInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _rootRotationStatements?;
    get rootRotationStatements(): string[];
    set rootRotationStatements(value: string[]);
    resetRootRotationStatements(): void;
    get rootRotationStatementsInput(): string[] | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _serviceAccountJson?;
    get serviceAccountJson(): string;
    set serviceAccountJson(value: string);
    resetServiceAccountJson(): void;
    get serviceAccountJsonInput(): string | undefined;
    private _skipStaticRoleImportRotation?;
    get skipStaticRoleImportRotation(): boolean | cdktn.IResolvable;
    set skipStaticRoleImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipStaticRoleImportRotation(): void;
    get skipStaticRoleImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _tlsCa?;
    get tlsCa(): string;
    set tlsCa(value: string);
    resetTlsCa(): void;
    get tlsCaInput(): string | undefined;
    private _tlsCertificateKey?;
    get tlsCertificateKey(): string;
    set tlsCertificateKey(value: string);
    resetTlsCertificateKey(): void;
    get tlsCertificateKeyInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _usernameTemplate?;
    get usernameTemplate(): string;
    set usernameTemplate(value: string);
    resetUsernameTemplate(): void;
    get usernameTemplateInput(): string | undefined;
    private _verifyConnection?;
    get verifyConnection(): boolean | cdktn.IResolvable;
    set verifyConnection(value: boolean | cdktn.IResolvable);
    resetVerifyConnection(): void;
    get verifyConnectionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DatabaseSecretsMountMysqlAuroraList extends cdktn.ComplexList {
    internalValue?: DatabaseSecretsMountMysqlAurora[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseSecretsMountMysqlAuroraOutputReference;
}
export interface DatabaseSecretsMountMysqlLegacy {
    /**
    * A list of roles that are allowed to use this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_roles DatabaseSecretsMount#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * Specify alternative authorization type. (Only 'gcp_iam' is valid currently)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#auth_type DatabaseSecretsMount#auth_type}
    */
    readonly authType?: string;
    /**
    * Connection string to use to connect to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#connection_url DatabaseSecretsMount#connection_url}
    */
    readonly connectionUrl?: string;
    /**
    * A map of sensitive data to pass to the endpoint. Useful for templated connection strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#data DatabaseSecretsMount#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_automated_rotation DatabaseSecretsMount#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * Maximum number of seconds a connection may be reused.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_connection_lifetime DatabaseSecretsMount#max_connection_lifetime}
    */
    readonly maxConnectionLifetime?: number;
    /**
    * Maximum number of idle connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_idle_connections DatabaseSecretsMount#max_idle_connections}
    */
    readonly maxIdleConnections?: number;
    /**
    * Maximum number of open connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_open_connections DatabaseSecretsMount#max_open_connections}
    */
    readonly maxOpenConnections?: number;
    /**
    * Name of the database connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#name DatabaseSecretsMount#name}
    */
    readonly name: string;
    /**
    * The root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password DatabaseSecretsMount#password}
    */
    readonly password?: string;
    /**
    * Optional name of the password policy to use for generated passwords.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_policy DatabaseSecretsMount#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * Write-only field for the root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo DatabaseSecretsMount#password_wo}
    */
    readonly passwordWo?: string;
    /**
    * Version counter for root credential password write-only field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo_version DatabaseSecretsMount#password_wo_version}
    */
    readonly passwordWoVersion?: number;
    /**
    * Specifies the name of the plugin to use for this connection. Must be prefixed with the name of one of the supported database engine types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_name DatabaseSecretsMount#plugin_name}
    */
    readonly pluginName?: string;
    /**
    * Optional plugin version to use for this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_version DatabaseSecretsMount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * A list of database statements to be executed to rotate the root user's credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#root_rotation_statements DatabaseSecretsMount#root_rotation_statements}
    */
    readonly rootRotationStatements?: string[];
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_period DatabaseSecretsMount#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_schedule DatabaseSecretsMount#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_window DatabaseSecretsMount#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * A JSON encoded credential for use with IAM authorization
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#service_account_json DatabaseSecretsMount#service_account_json}
    */
    readonly serviceAccountJson?: string;
    /**
    * Skip rotation of static role credentials on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#skip_static_role_import_rotation DatabaseSecretsMount#skip_static_role_import_rotation}
    */
    readonly skipStaticRoleImportRotation?: boolean | cdktn.IResolvable;
    /**
    * x509 CA file for validating the certificate presented by the MySQL server. Must be PEM encoded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#tls_ca DatabaseSecretsMount#tls_ca}
    */
    readonly tlsCa?: string;
    /**
    * x509 certificate for connecting to the database. This must be a PEM encoded version of the private key and the certificate combined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#tls_certificate_key DatabaseSecretsMount#tls_certificate_key}
    */
    readonly tlsCertificateKey?: string;
    /**
    * The root credential username used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username DatabaseSecretsMount#username}
    */
    readonly username?: string;
    /**
    * Username generation template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username_template DatabaseSecretsMount#username_template}
    */
    readonly usernameTemplate?: string;
    /**
    * Specifies if the connection is verified during initial configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#verify_connection DatabaseSecretsMount#verify_connection}
    */
    readonly verifyConnection?: boolean | cdktn.IResolvable;
}
export declare function databaseSecretsMountMysqlLegacyToTerraform(struct?: DatabaseSecretsMountMysqlLegacy | cdktn.IResolvable): any;
export declare function databaseSecretsMountMysqlLegacyToHclTerraform(struct?: DatabaseSecretsMountMysqlLegacy | cdktn.IResolvable): any;
export declare class DatabaseSecretsMountMysqlLegacyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseSecretsMountMysqlLegacy | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSecretsMountMysqlLegacy | cdktn.IResolvable | undefined);
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _authType?;
    get authType(): string;
    set authType(value: string);
    resetAuthType(): void;
    get authTypeInput(): string | undefined;
    private _connectionUrl?;
    get connectionUrl(): string;
    set connectionUrl(value: string);
    resetConnectionUrl(): void;
    get connectionUrlInput(): string | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _maxConnectionLifetime?;
    get maxConnectionLifetime(): number;
    set maxConnectionLifetime(value: number);
    resetMaxConnectionLifetime(): void;
    get maxConnectionLifetimeInput(): number | undefined;
    private _maxIdleConnections?;
    get maxIdleConnections(): number;
    set maxIdleConnections(value: number);
    resetMaxIdleConnections(): void;
    get maxIdleConnectionsInput(): number | undefined;
    private _maxOpenConnections?;
    get maxOpenConnections(): number;
    set maxOpenConnections(value: number);
    resetMaxOpenConnections(): void;
    get maxOpenConnectionsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _passwordWo?;
    get passwordWo(): string;
    set passwordWo(value: string);
    resetPasswordWo(): void;
    get passwordWoInput(): string | undefined;
    private _passwordWoVersion?;
    get passwordWoVersion(): number;
    set passwordWoVersion(value: number);
    resetPasswordWoVersion(): void;
    get passwordWoVersionInput(): number | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    resetPluginName(): void;
    get pluginNameInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _rootRotationStatements?;
    get rootRotationStatements(): string[];
    set rootRotationStatements(value: string[]);
    resetRootRotationStatements(): void;
    get rootRotationStatementsInput(): string[] | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _serviceAccountJson?;
    get serviceAccountJson(): string;
    set serviceAccountJson(value: string);
    resetServiceAccountJson(): void;
    get serviceAccountJsonInput(): string | undefined;
    private _skipStaticRoleImportRotation?;
    get skipStaticRoleImportRotation(): boolean | cdktn.IResolvable;
    set skipStaticRoleImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipStaticRoleImportRotation(): void;
    get skipStaticRoleImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _tlsCa?;
    get tlsCa(): string;
    set tlsCa(value: string);
    resetTlsCa(): void;
    get tlsCaInput(): string | undefined;
    private _tlsCertificateKey?;
    get tlsCertificateKey(): string;
    set tlsCertificateKey(value: string);
    resetTlsCertificateKey(): void;
    get tlsCertificateKeyInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _usernameTemplate?;
    get usernameTemplate(): string;
    set usernameTemplate(value: string);
    resetUsernameTemplate(): void;
    get usernameTemplateInput(): string | undefined;
    private _verifyConnection?;
    get verifyConnection(): boolean | cdktn.IResolvable;
    set verifyConnection(value: boolean | cdktn.IResolvable);
    resetVerifyConnection(): void;
    get verifyConnectionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DatabaseSecretsMountMysqlLegacyList extends cdktn.ComplexList {
    internalValue?: DatabaseSecretsMountMysqlLegacy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseSecretsMountMysqlLegacyOutputReference;
}
export interface DatabaseSecretsMountMysqlRds {
    /**
    * A list of roles that are allowed to use this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_roles DatabaseSecretsMount#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * Specify alternative authorization type. (Only 'gcp_iam' is valid currently)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#auth_type DatabaseSecretsMount#auth_type}
    */
    readonly authType?: string;
    /**
    * Connection string to use to connect to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#connection_url DatabaseSecretsMount#connection_url}
    */
    readonly connectionUrl?: string;
    /**
    * A map of sensitive data to pass to the endpoint. Useful for templated connection strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#data DatabaseSecretsMount#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_automated_rotation DatabaseSecretsMount#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * Maximum number of seconds a connection may be reused.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_connection_lifetime DatabaseSecretsMount#max_connection_lifetime}
    */
    readonly maxConnectionLifetime?: number;
    /**
    * Maximum number of idle connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_idle_connections DatabaseSecretsMount#max_idle_connections}
    */
    readonly maxIdleConnections?: number;
    /**
    * Maximum number of open connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_open_connections DatabaseSecretsMount#max_open_connections}
    */
    readonly maxOpenConnections?: number;
    /**
    * Name of the database connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#name DatabaseSecretsMount#name}
    */
    readonly name: string;
    /**
    * The root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password DatabaseSecretsMount#password}
    */
    readonly password?: string;
    /**
    * Optional name of the password policy to use for generated passwords.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_policy DatabaseSecretsMount#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * Write-only field for the root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo DatabaseSecretsMount#password_wo}
    */
    readonly passwordWo?: string;
    /**
    * Version counter for root credential password write-only field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo_version DatabaseSecretsMount#password_wo_version}
    */
    readonly passwordWoVersion?: number;
    /**
    * Specifies the name of the plugin to use for this connection. Must be prefixed with the name of one of the supported database engine types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_name DatabaseSecretsMount#plugin_name}
    */
    readonly pluginName?: string;
    /**
    * Optional plugin version to use for this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_version DatabaseSecretsMount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * A list of database statements to be executed to rotate the root user's credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#root_rotation_statements DatabaseSecretsMount#root_rotation_statements}
    */
    readonly rootRotationStatements?: string[];
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_period DatabaseSecretsMount#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_schedule DatabaseSecretsMount#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_window DatabaseSecretsMount#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * A JSON encoded credential for use with IAM authorization
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#service_account_json DatabaseSecretsMount#service_account_json}
    */
    readonly serviceAccountJson?: string;
    /**
    * Skip rotation of static role credentials on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#skip_static_role_import_rotation DatabaseSecretsMount#skip_static_role_import_rotation}
    */
    readonly skipStaticRoleImportRotation?: boolean | cdktn.IResolvable;
    /**
    * x509 CA file for validating the certificate presented by the MySQL server. Must be PEM encoded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#tls_ca DatabaseSecretsMount#tls_ca}
    */
    readonly tlsCa?: string;
    /**
    * x509 certificate for connecting to the database. This must be a PEM encoded version of the private key and the certificate combined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#tls_certificate_key DatabaseSecretsMount#tls_certificate_key}
    */
    readonly tlsCertificateKey?: string;
    /**
    * The root credential username used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username DatabaseSecretsMount#username}
    */
    readonly username?: string;
    /**
    * Username generation template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username_template DatabaseSecretsMount#username_template}
    */
    readonly usernameTemplate?: string;
    /**
    * Specifies if the connection is verified during initial configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#verify_connection DatabaseSecretsMount#verify_connection}
    */
    readonly verifyConnection?: boolean | cdktn.IResolvable;
}
export declare function databaseSecretsMountMysqlRdsToTerraform(struct?: DatabaseSecretsMountMysqlRds | cdktn.IResolvable): any;
export declare function databaseSecretsMountMysqlRdsToHclTerraform(struct?: DatabaseSecretsMountMysqlRds | cdktn.IResolvable): any;
export declare class DatabaseSecretsMountMysqlRdsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseSecretsMountMysqlRds | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSecretsMountMysqlRds | cdktn.IResolvable | undefined);
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _authType?;
    get authType(): string;
    set authType(value: string);
    resetAuthType(): void;
    get authTypeInput(): string | undefined;
    private _connectionUrl?;
    get connectionUrl(): string;
    set connectionUrl(value: string);
    resetConnectionUrl(): void;
    get connectionUrlInput(): string | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _maxConnectionLifetime?;
    get maxConnectionLifetime(): number;
    set maxConnectionLifetime(value: number);
    resetMaxConnectionLifetime(): void;
    get maxConnectionLifetimeInput(): number | undefined;
    private _maxIdleConnections?;
    get maxIdleConnections(): number;
    set maxIdleConnections(value: number);
    resetMaxIdleConnections(): void;
    get maxIdleConnectionsInput(): number | undefined;
    private _maxOpenConnections?;
    get maxOpenConnections(): number;
    set maxOpenConnections(value: number);
    resetMaxOpenConnections(): void;
    get maxOpenConnectionsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _passwordWo?;
    get passwordWo(): string;
    set passwordWo(value: string);
    resetPasswordWo(): void;
    get passwordWoInput(): string | undefined;
    private _passwordWoVersion?;
    get passwordWoVersion(): number;
    set passwordWoVersion(value: number);
    resetPasswordWoVersion(): void;
    get passwordWoVersionInput(): number | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    resetPluginName(): void;
    get pluginNameInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _rootRotationStatements?;
    get rootRotationStatements(): string[];
    set rootRotationStatements(value: string[]);
    resetRootRotationStatements(): void;
    get rootRotationStatementsInput(): string[] | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _serviceAccountJson?;
    get serviceAccountJson(): string;
    set serviceAccountJson(value: string);
    resetServiceAccountJson(): void;
    get serviceAccountJsonInput(): string | undefined;
    private _skipStaticRoleImportRotation?;
    get skipStaticRoleImportRotation(): boolean | cdktn.IResolvable;
    set skipStaticRoleImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipStaticRoleImportRotation(): void;
    get skipStaticRoleImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _tlsCa?;
    get tlsCa(): string;
    set tlsCa(value: string);
    resetTlsCa(): void;
    get tlsCaInput(): string | undefined;
    private _tlsCertificateKey?;
    get tlsCertificateKey(): string;
    set tlsCertificateKey(value: string);
    resetTlsCertificateKey(): void;
    get tlsCertificateKeyInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _usernameTemplate?;
    get usernameTemplate(): string;
    set usernameTemplate(value: string);
    resetUsernameTemplate(): void;
    get usernameTemplateInput(): string | undefined;
    private _verifyConnection?;
    get verifyConnection(): boolean | cdktn.IResolvable;
    set verifyConnection(value: boolean | cdktn.IResolvable);
    resetVerifyConnection(): void;
    get verifyConnectionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DatabaseSecretsMountMysqlRdsList extends cdktn.ComplexList {
    internalValue?: DatabaseSecretsMountMysqlRds[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseSecretsMountMysqlRdsOutputReference;
}
export interface DatabaseSecretsMountOracle {
    /**
    * A list of roles that are allowed to use this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_roles DatabaseSecretsMount#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * Connection string to use to connect to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#connection_url DatabaseSecretsMount#connection_url}
    */
    readonly connectionUrl?: string;
    /**
    * A map of sensitive data to pass to the endpoint. Useful for templated connection strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#data DatabaseSecretsMount#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_automated_rotation DatabaseSecretsMount#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * Set to true to disconnect any open sessions prior to running the revocation statements.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disconnect_sessions DatabaseSecretsMount#disconnect_sessions}
    */
    readonly disconnectSessions?: boolean | cdktn.IResolvable;
    /**
    * Maximum number of seconds a connection may be reused.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_connection_lifetime DatabaseSecretsMount#max_connection_lifetime}
    */
    readonly maxConnectionLifetime?: number;
    /**
    * Maximum number of idle connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_idle_connections DatabaseSecretsMount#max_idle_connections}
    */
    readonly maxIdleConnections?: number;
    /**
    * Maximum number of open connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_open_connections DatabaseSecretsMount#max_open_connections}
    */
    readonly maxOpenConnections?: number;
    /**
    * Name of the database connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#name DatabaseSecretsMount#name}
    */
    readonly name: string;
    /**
    * The root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password DatabaseSecretsMount#password}
    */
    readonly password?: string;
    /**
    * Optional name of the password policy to use for generated passwords.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_policy DatabaseSecretsMount#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * Write-only field for the root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo DatabaseSecretsMount#password_wo}
    */
    readonly passwordWo?: string;
    /**
    * Version counter for root credential password write-only field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo_version DatabaseSecretsMount#password_wo_version}
    */
    readonly passwordWoVersion?: number;
    /**
    * Specifies the name of the plugin to use for this connection. Must be prefixed with the name of one of the supported database engine types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_name DatabaseSecretsMount#plugin_name}
    */
    readonly pluginName?: string;
    /**
    * Optional plugin version to use for this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_version DatabaseSecretsMount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * A list of database statements to be executed to rotate the root user's credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#root_rotation_statements DatabaseSecretsMount#root_rotation_statements}
    */
    readonly rootRotationStatements?: string[];
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_period DatabaseSecretsMount#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_schedule DatabaseSecretsMount#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_window DatabaseSecretsMount#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * If set, allows onboarding static roles with a rootless connection configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#self_managed DatabaseSecretsMount#self_managed}
    */
    readonly selfManaged?: boolean | cdktn.IResolvable;
    /**
    * Skip rotation of static role credentials on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#skip_static_role_import_rotation DatabaseSecretsMount#skip_static_role_import_rotation}
    */
    readonly skipStaticRoleImportRotation?: boolean | cdktn.IResolvable;
    /**
    * Set to true in order to split statements after semi-colons.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#split_statements DatabaseSecretsMount#split_statements}
    */
    readonly splitStatements?: boolean | cdktn.IResolvable;
    /**
    * The root credential username used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username DatabaseSecretsMount#username}
    */
    readonly username?: string;
    /**
    * Username generation template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username_template DatabaseSecretsMount#username_template}
    */
    readonly usernameTemplate?: string;
    /**
    * Specifies if the connection is verified during initial configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#verify_connection DatabaseSecretsMount#verify_connection}
    */
    readonly verifyConnection?: boolean | cdktn.IResolvable;
}
export declare function databaseSecretsMountOracleToTerraform(struct?: DatabaseSecretsMountOracle | cdktn.IResolvable): any;
export declare function databaseSecretsMountOracleToHclTerraform(struct?: DatabaseSecretsMountOracle | cdktn.IResolvable): any;
export declare class DatabaseSecretsMountOracleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseSecretsMountOracle | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSecretsMountOracle | cdktn.IResolvable | undefined);
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _connectionUrl?;
    get connectionUrl(): string;
    set connectionUrl(value: string);
    resetConnectionUrl(): void;
    get connectionUrlInput(): string | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _disconnectSessions?;
    get disconnectSessions(): boolean | cdktn.IResolvable;
    set disconnectSessions(value: boolean | cdktn.IResolvable);
    resetDisconnectSessions(): void;
    get disconnectSessionsInput(): boolean | cdktn.IResolvable | undefined;
    private _maxConnectionLifetime?;
    get maxConnectionLifetime(): number;
    set maxConnectionLifetime(value: number);
    resetMaxConnectionLifetime(): void;
    get maxConnectionLifetimeInput(): number | undefined;
    private _maxIdleConnections?;
    get maxIdleConnections(): number;
    set maxIdleConnections(value: number);
    resetMaxIdleConnections(): void;
    get maxIdleConnectionsInput(): number | undefined;
    private _maxOpenConnections?;
    get maxOpenConnections(): number;
    set maxOpenConnections(value: number);
    resetMaxOpenConnections(): void;
    get maxOpenConnectionsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _passwordWo?;
    get passwordWo(): string;
    set passwordWo(value: string);
    resetPasswordWo(): void;
    get passwordWoInput(): string | undefined;
    private _passwordWoVersion?;
    get passwordWoVersion(): number;
    set passwordWoVersion(value: number);
    resetPasswordWoVersion(): void;
    get passwordWoVersionInput(): number | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    resetPluginName(): void;
    get pluginNameInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _rootRotationStatements?;
    get rootRotationStatements(): string[];
    set rootRotationStatements(value: string[]);
    resetRootRotationStatements(): void;
    get rootRotationStatementsInput(): string[] | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _selfManaged?;
    get selfManaged(): boolean | cdktn.IResolvable;
    set selfManaged(value: boolean | cdktn.IResolvable);
    resetSelfManaged(): void;
    get selfManagedInput(): boolean | cdktn.IResolvable | undefined;
    private _skipStaticRoleImportRotation?;
    get skipStaticRoleImportRotation(): boolean | cdktn.IResolvable;
    set skipStaticRoleImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipStaticRoleImportRotation(): void;
    get skipStaticRoleImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _splitStatements?;
    get splitStatements(): boolean | cdktn.IResolvable;
    set splitStatements(value: boolean | cdktn.IResolvable);
    resetSplitStatements(): void;
    get splitStatementsInput(): boolean | cdktn.IResolvable | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _usernameTemplate?;
    get usernameTemplate(): string;
    set usernameTemplate(value: string);
    resetUsernameTemplate(): void;
    get usernameTemplateInput(): string | undefined;
    private _verifyConnection?;
    get verifyConnection(): boolean | cdktn.IResolvable;
    set verifyConnection(value: boolean | cdktn.IResolvable);
    resetVerifyConnection(): void;
    get verifyConnectionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DatabaseSecretsMountOracleList extends cdktn.ComplexList {
    internalValue?: DatabaseSecretsMountOracle[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseSecretsMountOracleOutputReference;
}
export interface DatabaseSecretsMountPostgresql {
    /**
    * A list of roles that are allowed to use this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_roles DatabaseSecretsMount#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * Specify alternative authorization type. (Only 'gcp_iam' is valid currently)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#auth_type DatabaseSecretsMount#auth_type}
    */
    readonly authType?: string;
    /**
    * Connection string to use to connect to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#connection_url DatabaseSecretsMount#connection_url}
    */
    readonly connectionUrl?: string;
    /**
    * A map of sensitive data to pass to the endpoint. Useful for templated connection strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#data DatabaseSecretsMount#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_automated_rotation DatabaseSecretsMount#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * Disable special character escaping in username and password
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_escaping DatabaseSecretsMount#disable_escaping}
    */
    readonly disableEscaping?: boolean | cdktn.IResolvable;
    /**
    * Maximum number of seconds a connection may be reused.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_connection_lifetime DatabaseSecretsMount#max_connection_lifetime}
    */
    readonly maxConnectionLifetime?: number;
    /**
    * Maximum number of idle connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_idle_connections DatabaseSecretsMount#max_idle_connections}
    */
    readonly maxIdleConnections?: number;
    /**
    * Maximum number of open connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_open_connections DatabaseSecretsMount#max_open_connections}
    */
    readonly maxOpenConnections?: number;
    /**
    * Name of the database connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#name DatabaseSecretsMount#name}
    */
    readonly name: string;
    /**
    * The root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password DatabaseSecretsMount#password}
    */
    readonly password?: string;
    /**
    * When set to `scram-sha-256`, passwords will be hashed by Vault before being sent to PostgreSQL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_authentication DatabaseSecretsMount#password_authentication}
    */
    readonly passwordAuthentication?: string;
    /**
    * Optional name of the password policy to use for generated passwords.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_policy DatabaseSecretsMount#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * Write-only field for the root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo DatabaseSecretsMount#password_wo}
    */
    readonly passwordWo?: string;
    /**
    * Version counter for root credential password write-only field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo_version DatabaseSecretsMount#password_wo_version}
    */
    readonly passwordWoVersion?: number;
    /**
    * Specifies the name of the plugin to use for this connection. Must be prefixed with the name of one of the supported database engine types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_name DatabaseSecretsMount#plugin_name}
    */
    readonly pluginName?: string;
    /**
    * Optional plugin version to use for this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_version DatabaseSecretsMount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * The secret key used for the x509 client certificate. Must be PEM encoded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#private_key DatabaseSecretsMount#private_key}
    */
    readonly privateKey?: string;
    /**
    * A list of database statements to be executed to rotate the root user's credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#root_rotation_statements DatabaseSecretsMount#root_rotation_statements}
    */
    readonly rootRotationStatements?: string[];
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_period DatabaseSecretsMount#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_schedule DatabaseSecretsMount#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_window DatabaseSecretsMount#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * If set, allows onboarding static roles with a rootless connection configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#self_managed DatabaseSecretsMount#self_managed}
    */
    readonly selfManaged?: boolean | cdktn.IResolvable;
    /**
    * A JSON encoded credential for use with IAM authorization
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#service_account_json DatabaseSecretsMount#service_account_json}
    */
    readonly serviceAccountJson?: string;
    /**
    * Skip rotation of static role credentials on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#skip_static_role_import_rotation DatabaseSecretsMount#skip_static_role_import_rotation}
    */
    readonly skipStaticRoleImportRotation?: boolean | cdktn.IResolvable;
    /**
    * The x509 CA file for validating the certificate presented by the PostgreSQL server. Must be PEM encoded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#tls_ca DatabaseSecretsMount#tls_ca}
    */
    readonly tlsCa?: string;
    /**
    * The x509 client certificate for connecting to the database. Must be PEM encoded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#tls_certificate DatabaseSecretsMount#tls_certificate}
    */
    readonly tlsCertificate?: string;
    /**
    * The root credential username used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username DatabaseSecretsMount#username}
    */
    readonly username?: string;
    /**
    * Username generation template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username_template DatabaseSecretsMount#username_template}
    */
    readonly usernameTemplate?: string;
    /**
    * Specifies if the connection is verified during initial configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#verify_connection DatabaseSecretsMount#verify_connection}
    */
    readonly verifyConnection?: boolean | cdktn.IResolvable;
}
export declare function databaseSecretsMountPostgresqlToTerraform(struct?: DatabaseSecretsMountPostgresql | cdktn.IResolvable): any;
export declare function databaseSecretsMountPostgresqlToHclTerraform(struct?: DatabaseSecretsMountPostgresql | cdktn.IResolvable): any;
export declare class DatabaseSecretsMountPostgresqlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseSecretsMountPostgresql | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSecretsMountPostgresql | cdktn.IResolvable | undefined);
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _authType?;
    get authType(): string;
    set authType(value: string);
    resetAuthType(): void;
    get authTypeInput(): string | undefined;
    private _connectionUrl?;
    get connectionUrl(): string;
    set connectionUrl(value: string);
    resetConnectionUrl(): void;
    get connectionUrlInput(): string | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _disableEscaping?;
    get disableEscaping(): boolean | cdktn.IResolvable;
    set disableEscaping(value: boolean | cdktn.IResolvable);
    resetDisableEscaping(): void;
    get disableEscapingInput(): boolean | cdktn.IResolvable | undefined;
    private _maxConnectionLifetime?;
    get maxConnectionLifetime(): number;
    set maxConnectionLifetime(value: number);
    resetMaxConnectionLifetime(): void;
    get maxConnectionLifetimeInput(): number | undefined;
    private _maxIdleConnections?;
    get maxIdleConnections(): number;
    set maxIdleConnections(value: number);
    resetMaxIdleConnections(): void;
    get maxIdleConnectionsInput(): number | undefined;
    private _maxOpenConnections?;
    get maxOpenConnections(): number;
    set maxOpenConnections(value: number);
    resetMaxOpenConnections(): void;
    get maxOpenConnectionsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _passwordAuthentication?;
    get passwordAuthentication(): string;
    set passwordAuthentication(value: string);
    resetPasswordAuthentication(): void;
    get passwordAuthenticationInput(): string | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _passwordWo?;
    get passwordWo(): string;
    set passwordWo(value: string);
    resetPasswordWo(): void;
    get passwordWoInput(): string | undefined;
    private _passwordWoVersion?;
    get passwordWoVersion(): number;
    set passwordWoVersion(value: number);
    resetPasswordWoVersion(): void;
    get passwordWoVersionInput(): number | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    resetPluginName(): void;
    get pluginNameInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    resetPrivateKey(): void;
    get privateKeyInput(): string | undefined;
    private _rootRotationStatements?;
    get rootRotationStatements(): string[];
    set rootRotationStatements(value: string[]);
    resetRootRotationStatements(): void;
    get rootRotationStatementsInput(): string[] | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _selfManaged?;
    get selfManaged(): boolean | cdktn.IResolvable;
    set selfManaged(value: boolean | cdktn.IResolvable);
    resetSelfManaged(): void;
    get selfManagedInput(): boolean | cdktn.IResolvable | undefined;
    private _serviceAccountJson?;
    get serviceAccountJson(): string;
    set serviceAccountJson(value: string);
    resetServiceAccountJson(): void;
    get serviceAccountJsonInput(): string | undefined;
    private _skipStaticRoleImportRotation?;
    get skipStaticRoleImportRotation(): boolean | cdktn.IResolvable;
    set skipStaticRoleImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipStaticRoleImportRotation(): void;
    get skipStaticRoleImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _tlsCa?;
    get tlsCa(): string;
    set tlsCa(value: string);
    resetTlsCa(): void;
    get tlsCaInput(): string | undefined;
    private _tlsCertificate?;
    get tlsCertificate(): string;
    set tlsCertificate(value: string);
    resetTlsCertificate(): void;
    get tlsCertificateInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _usernameTemplate?;
    get usernameTemplate(): string;
    set usernameTemplate(value: string);
    resetUsernameTemplate(): void;
    get usernameTemplateInput(): string | undefined;
    private _verifyConnection?;
    get verifyConnection(): boolean | cdktn.IResolvable;
    set verifyConnection(value: boolean | cdktn.IResolvable);
    resetVerifyConnection(): void;
    get verifyConnectionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DatabaseSecretsMountPostgresqlList extends cdktn.ComplexList {
    internalValue?: DatabaseSecretsMountPostgresql[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseSecretsMountPostgresqlOutputReference;
}
export interface DatabaseSecretsMountRedis {
    /**
    * A list of roles that are allowed to use this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_roles DatabaseSecretsMount#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * The contents of a PEM-encoded CA cert file to use to verify the Redis server's identity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#ca_cert DatabaseSecretsMount#ca_cert}
    */
    readonly caCert?: string;
    /**
    * A map of sensitive data to pass to the endpoint. Useful for templated connection strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#data DatabaseSecretsMount#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_automated_rotation DatabaseSecretsMount#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * Specifies the host to connect to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#host DatabaseSecretsMount#host}
    */
    readonly host: string;
    /**
    * Specifies whether to skip verification of the server certificate when using TLS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#insecure_tls DatabaseSecretsMount#insecure_tls}
    */
    readonly insecureTls?: boolean | cdktn.IResolvable;
    /**
    * Name of the database connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#name DatabaseSecretsMount#name}
    */
    readonly name: string;
    /**
    * Specifies the password corresponding to the given username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password DatabaseSecretsMount#password}
    */
    readonly password: string;
    /**
    * Optional name of the password policy to use for generated passwords.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_policy DatabaseSecretsMount#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * Specifies the name of the plugin to use for this connection. Must be prefixed with the name of one of the supported database engine types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_name DatabaseSecretsMount#plugin_name}
    */
    readonly pluginName?: string;
    /**
    * Optional plugin version to use for this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_version DatabaseSecretsMount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * The transport port to use to connect to Redis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#port DatabaseSecretsMount#port}
    */
    readonly port?: number;
    /**
    * A list of database statements to be executed to rotate the root user's credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#root_rotation_statements DatabaseSecretsMount#root_rotation_statements}
    */
    readonly rootRotationStatements?: string[];
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_period DatabaseSecretsMount#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_schedule DatabaseSecretsMount#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_window DatabaseSecretsMount#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * Skip rotation of static role credentials on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#skip_static_role_import_rotation DatabaseSecretsMount#skip_static_role_import_rotation}
    */
    readonly skipStaticRoleImportRotation?: boolean | cdktn.IResolvable;
    /**
    * Specifies whether to use TLS when connecting to Redis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#tls DatabaseSecretsMount#tls}
    */
    readonly tls?: boolean | cdktn.IResolvable;
    /**
    * Specifies the username for Vault to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username DatabaseSecretsMount#username}
    */
    readonly username: string;
    /**
    * Specifies if the connection is verified during initial configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#verify_connection DatabaseSecretsMount#verify_connection}
    */
    readonly verifyConnection?: boolean | cdktn.IResolvable;
}
export declare function databaseSecretsMountRedisToTerraform(struct?: DatabaseSecretsMountRedis | cdktn.IResolvable): any;
export declare function databaseSecretsMountRedisToHclTerraform(struct?: DatabaseSecretsMountRedis | cdktn.IResolvable): any;
export declare class DatabaseSecretsMountRedisOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseSecretsMountRedis | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSecretsMountRedis | cdktn.IResolvable | undefined);
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _caCert?;
    get caCert(): string;
    set caCert(value: string);
    resetCaCert(): void;
    get caCertInput(): string | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _host?;
    get host(): string;
    set host(value: string);
    get hostInput(): string | undefined;
    private _insecureTls?;
    get insecureTls(): boolean | cdktn.IResolvable;
    set insecureTls(value: boolean | cdktn.IResolvable);
    resetInsecureTls(): void;
    get insecureTlsInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    resetPluginName(): void;
    get pluginNameInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _rootRotationStatements?;
    get rootRotationStatements(): string[];
    set rootRotationStatements(value: string[]);
    resetRootRotationStatements(): void;
    get rootRotationStatementsInput(): string[] | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _skipStaticRoleImportRotation?;
    get skipStaticRoleImportRotation(): boolean | cdktn.IResolvable;
    set skipStaticRoleImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipStaticRoleImportRotation(): void;
    get skipStaticRoleImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _tls?;
    get tls(): boolean | cdktn.IResolvable;
    set tls(value: boolean | cdktn.IResolvable);
    resetTls(): void;
    get tlsInput(): boolean | cdktn.IResolvable | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    private _verifyConnection?;
    get verifyConnection(): boolean | cdktn.IResolvable;
    set verifyConnection(value: boolean | cdktn.IResolvable);
    resetVerifyConnection(): void;
    get verifyConnectionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DatabaseSecretsMountRedisList extends cdktn.ComplexList {
    internalValue?: DatabaseSecretsMountRedis[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseSecretsMountRedisOutputReference;
}
export interface DatabaseSecretsMountRedisElasticache {
    /**
    * A list of roles that are allowed to use this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_roles DatabaseSecretsMount#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * A map of sensitive data to pass to the endpoint. Useful for templated connection strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#data DatabaseSecretsMount#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_automated_rotation DatabaseSecretsMount#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * Name of the database connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#name DatabaseSecretsMount#name}
    */
    readonly name: string;
    /**
    * The AWS secret key id to use to talk to ElastiCache. If omitted the credentials chain provider is used instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password DatabaseSecretsMount#password}
    */
    readonly password?: string;
    /**
    * Optional name of the password policy to use for generated passwords.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_policy DatabaseSecretsMount#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * Specifies the name of the plugin to use for this connection. Must be prefixed with the name of one of the supported database engine types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_name DatabaseSecretsMount#plugin_name}
    */
    readonly pluginName?: string;
    /**
    * Optional plugin version to use for this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_version DatabaseSecretsMount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * The AWS region where the ElastiCache cluster is hosted. If omitted the plugin tries to infer the region from the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#region DatabaseSecretsMount#region}
    */
    readonly region?: string;
    /**
    * A list of database statements to be executed to rotate the root user's credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#root_rotation_statements DatabaseSecretsMount#root_rotation_statements}
    */
    readonly rootRotationStatements?: string[];
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_period DatabaseSecretsMount#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_schedule DatabaseSecretsMount#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_window DatabaseSecretsMount#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * Skip rotation of static role credentials on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#skip_static_role_import_rotation DatabaseSecretsMount#skip_static_role_import_rotation}
    */
    readonly skipStaticRoleImportRotation?: boolean | cdktn.IResolvable;
    /**
    * The configuration endpoint for the ElastiCache cluster to connect to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#url DatabaseSecretsMount#url}
    */
    readonly url: string;
    /**
    * The AWS access key id to use to talk to ElastiCache. If omitted the credentials chain provider is used instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username DatabaseSecretsMount#username}
    */
    readonly username?: string;
    /**
    * Specifies if the connection is verified during initial configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#verify_connection DatabaseSecretsMount#verify_connection}
    */
    readonly verifyConnection?: boolean | cdktn.IResolvable;
}
export declare function databaseSecretsMountRedisElasticacheToTerraform(struct?: DatabaseSecretsMountRedisElasticache | cdktn.IResolvable): any;
export declare function databaseSecretsMountRedisElasticacheToHclTerraform(struct?: DatabaseSecretsMountRedisElasticache | cdktn.IResolvable): any;
export declare class DatabaseSecretsMountRedisElasticacheOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseSecretsMountRedisElasticache | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSecretsMountRedisElasticache | cdktn.IResolvable | undefined);
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    resetPluginName(): void;
    get pluginNameInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rootRotationStatements?;
    get rootRotationStatements(): string[];
    set rootRotationStatements(value: string[]);
    resetRootRotationStatements(): void;
    get rootRotationStatementsInput(): string[] | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _skipStaticRoleImportRotation?;
    get skipStaticRoleImportRotation(): boolean | cdktn.IResolvable;
    set skipStaticRoleImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipStaticRoleImportRotation(): void;
    get skipStaticRoleImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _verifyConnection?;
    get verifyConnection(): boolean | cdktn.IResolvable;
    set verifyConnection(value: boolean | cdktn.IResolvable);
    resetVerifyConnection(): void;
    get verifyConnectionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DatabaseSecretsMountRedisElasticacheList extends cdktn.ComplexList {
    internalValue?: DatabaseSecretsMountRedisElasticache[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseSecretsMountRedisElasticacheOutputReference;
}
export interface DatabaseSecretsMountRedshift {
    /**
    * A list of roles that are allowed to use this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_roles DatabaseSecretsMount#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * Connection string to use to connect to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#connection_url DatabaseSecretsMount#connection_url}
    */
    readonly connectionUrl?: string;
    /**
    * A map of sensitive data to pass to the endpoint. Useful for templated connection strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#data DatabaseSecretsMount#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_automated_rotation DatabaseSecretsMount#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * Disable special character escaping in username and password
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_escaping DatabaseSecretsMount#disable_escaping}
    */
    readonly disableEscaping?: boolean | cdktn.IResolvable;
    /**
    * Maximum number of seconds a connection may be reused.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_connection_lifetime DatabaseSecretsMount#max_connection_lifetime}
    */
    readonly maxConnectionLifetime?: number;
    /**
    * Maximum number of idle connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_idle_connections DatabaseSecretsMount#max_idle_connections}
    */
    readonly maxIdleConnections?: number;
    /**
    * Maximum number of open connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_open_connections DatabaseSecretsMount#max_open_connections}
    */
    readonly maxOpenConnections?: number;
    /**
    * Name of the database connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#name DatabaseSecretsMount#name}
    */
    readonly name: string;
    /**
    * The root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password DatabaseSecretsMount#password}
    */
    readonly password?: string;
    /**
    * Optional name of the password policy to use for generated passwords.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_policy DatabaseSecretsMount#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * Write-only field for the root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo DatabaseSecretsMount#password_wo}
    */
    readonly passwordWo?: string;
    /**
    * Version counter for root credential password write-only field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo_version DatabaseSecretsMount#password_wo_version}
    */
    readonly passwordWoVersion?: number;
    /**
    * Specifies the name of the plugin to use for this connection. Must be prefixed with the name of one of the supported database engine types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_name DatabaseSecretsMount#plugin_name}
    */
    readonly pluginName?: string;
    /**
    * Optional plugin version to use for this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_version DatabaseSecretsMount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * A list of database statements to be executed to rotate the root user's credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#root_rotation_statements DatabaseSecretsMount#root_rotation_statements}
    */
    readonly rootRotationStatements?: string[];
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_period DatabaseSecretsMount#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_schedule DatabaseSecretsMount#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_window DatabaseSecretsMount#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * Skip rotation of static role credentials on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#skip_static_role_import_rotation DatabaseSecretsMount#skip_static_role_import_rotation}
    */
    readonly skipStaticRoleImportRotation?: boolean | cdktn.IResolvable;
    /**
    * The root credential username used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username DatabaseSecretsMount#username}
    */
    readonly username?: string;
    /**
    * Username generation template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username_template DatabaseSecretsMount#username_template}
    */
    readonly usernameTemplate?: string;
    /**
    * Specifies if the connection is verified during initial configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#verify_connection DatabaseSecretsMount#verify_connection}
    */
    readonly verifyConnection?: boolean | cdktn.IResolvable;
}
export declare function databaseSecretsMountRedshiftToTerraform(struct?: DatabaseSecretsMountRedshift | cdktn.IResolvable): any;
export declare function databaseSecretsMountRedshiftToHclTerraform(struct?: DatabaseSecretsMountRedshift | cdktn.IResolvable): any;
export declare class DatabaseSecretsMountRedshiftOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseSecretsMountRedshift | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSecretsMountRedshift | cdktn.IResolvable | undefined);
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _connectionUrl?;
    get connectionUrl(): string;
    set connectionUrl(value: string);
    resetConnectionUrl(): void;
    get connectionUrlInput(): string | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _disableEscaping?;
    get disableEscaping(): boolean | cdktn.IResolvable;
    set disableEscaping(value: boolean | cdktn.IResolvable);
    resetDisableEscaping(): void;
    get disableEscapingInput(): boolean | cdktn.IResolvable | undefined;
    private _maxConnectionLifetime?;
    get maxConnectionLifetime(): number;
    set maxConnectionLifetime(value: number);
    resetMaxConnectionLifetime(): void;
    get maxConnectionLifetimeInput(): number | undefined;
    private _maxIdleConnections?;
    get maxIdleConnections(): number;
    set maxIdleConnections(value: number);
    resetMaxIdleConnections(): void;
    get maxIdleConnectionsInput(): number | undefined;
    private _maxOpenConnections?;
    get maxOpenConnections(): number;
    set maxOpenConnections(value: number);
    resetMaxOpenConnections(): void;
    get maxOpenConnectionsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _passwordWo?;
    get passwordWo(): string;
    set passwordWo(value: string);
    resetPasswordWo(): void;
    get passwordWoInput(): string | undefined;
    private _passwordWoVersion?;
    get passwordWoVersion(): number;
    set passwordWoVersion(value: number);
    resetPasswordWoVersion(): void;
    get passwordWoVersionInput(): number | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    resetPluginName(): void;
    get pluginNameInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _rootRotationStatements?;
    get rootRotationStatements(): string[];
    set rootRotationStatements(value: string[]);
    resetRootRotationStatements(): void;
    get rootRotationStatementsInput(): string[] | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _skipStaticRoleImportRotation?;
    get skipStaticRoleImportRotation(): boolean | cdktn.IResolvable;
    set skipStaticRoleImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipStaticRoleImportRotation(): void;
    get skipStaticRoleImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _usernameTemplate?;
    get usernameTemplate(): string;
    set usernameTemplate(value: string);
    resetUsernameTemplate(): void;
    get usernameTemplateInput(): string | undefined;
    private _verifyConnection?;
    get verifyConnection(): boolean | cdktn.IResolvable;
    set verifyConnection(value: boolean | cdktn.IResolvable);
    resetVerifyConnection(): void;
    get verifyConnectionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DatabaseSecretsMountRedshiftList extends cdktn.ComplexList {
    internalValue?: DatabaseSecretsMountRedshift[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseSecretsMountRedshiftOutputReference;
}
export interface DatabaseSecretsMountSnowflake {
    /**
    * A list of roles that are allowed to use this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#allowed_roles DatabaseSecretsMount#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * Connection string to use to connect to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#connection_url DatabaseSecretsMount#connection_url}
    */
    readonly connectionUrl?: string;
    /**
    * A map of sensitive data to pass to the endpoint. Useful for templated connection strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#data DatabaseSecretsMount#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#disable_automated_rotation DatabaseSecretsMount#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * Maximum number of seconds a connection may be reused.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_connection_lifetime DatabaseSecretsMount#max_connection_lifetime}
    */
    readonly maxConnectionLifetime?: number;
    /**
    * Maximum number of idle connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_idle_connections DatabaseSecretsMount#max_idle_connections}
    */
    readonly maxIdleConnections?: number;
    /**
    * Maximum number of open connections to the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#max_open_connections DatabaseSecretsMount#max_open_connections}
    */
    readonly maxOpenConnections?: number;
    /**
    * Name of the database connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#name DatabaseSecretsMount#name}
    */
    readonly name: string;
    /**
    * The root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password DatabaseSecretsMount#password}
    */
    readonly password?: string;
    /**
    * Optional name of the password policy to use for generated passwords.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_policy DatabaseSecretsMount#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * Write-only field for the root credential password used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo DatabaseSecretsMount#password_wo}
    */
    readonly passwordWo?: string;
    /**
    * Version counter for root credential password write-only field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#password_wo_version DatabaseSecretsMount#password_wo_version}
    */
    readonly passwordWoVersion?: number;
    /**
    * Specifies the name of the plugin to use for this connection. Must be prefixed with the name of one of the supported database engine types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_name DatabaseSecretsMount#plugin_name}
    */
    readonly pluginName?: string;
    /**
    * Optional plugin version to use for this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#plugin_version DatabaseSecretsMount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * The private key configured for the admin user in Snowflake.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#private_key_wo DatabaseSecretsMount#private_key_wo}
    */
    readonly privateKeyWo?: string;
    /**
    * Version counter for the private key key-pair credentials write-only field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#private_key_wo_version DatabaseSecretsMount#private_key_wo_version}
    */
    readonly privateKeyWoVersion?: number;
    /**
    * A list of database statements to be executed to rotate the root user's credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#root_rotation_statements DatabaseSecretsMount#root_rotation_statements}
    */
    readonly rootRotationStatements?: string[];
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_period DatabaseSecretsMount#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_schedule DatabaseSecretsMount#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#rotation_window DatabaseSecretsMount#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * Skip rotation of static role credentials on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#skip_static_role_import_rotation DatabaseSecretsMount#skip_static_role_import_rotation}
    */
    readonly skipStaticRoleImportRotation?: boolean | cdktn.IResolvable;
    /**
    * The root credential username used in the connection URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username DatabaseSecretsMount#username}
    */
    readonly username?: string;
    /**
    * Username generation template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#username_template DatabaseSecretsMount#username_template}
    */
    readonly usernameTemplate?: string;
    /**
    * Specifies if the connection is verified during initial configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#verify_connection DatabaseSecretsMount#verify_connection}
    */
    readonly verifyConnection?: boolean | cdktn.IResolvable;
}
export declare function databaseSecretsMountSnowflakeToTerraform(struct?: DatabaseSecretsMountSnowflake | cdktn.IResolvable): any;
export declare function databaseSecretsMountSnowflakeToHclTerraform(struct?: DatabaseSecretsMountSnowflake | cdktn.IResolvable): any;
export declare class DatabaseSecretsMountSnowflakeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseSecretsMountSnowflake | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSecretsMountSnowflake | cdktn.IResolvable | undefined);
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _connectionUrl?;
    get connectionUrl(): string;
    set connectionUrl(value: string);
    resetConnectionUrl(): void;
    get connectionUrlInput(): string | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _maxConnectionLifetime?;
    get maxConnectionLifetime(): number;
    set maxConnectionLifetime(value: number);
    resetMaxConnectionLifetime(): void;
    get maxConnectionLifetimeInput(): number | undefined;
    private _maxIdleConnections?;
    get maxIdleConnections(): number;
    set maxIdleConnections(value: number);
    resetMaxIdleConnections(): void;
    get maxIdleConnectionsInput(): number | undefined;
    private _maxOpenConnections?;
    get maxOpenConnections(): number;
    set maxOpenConnections(value: number);
    resetMaxOpenConnections(): void;
    get maxOpenConnectionsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _passwordWo?;
    get passwordWo(): string;
    set passwordWo(value: string);
    resetPasswordWo(): void;
    get passwordWoInput(): string | undefined;
    private _passwordWoVersion?;
    get passwordWoVersion(): number;
    set passwordWoVersion(value: number);
    resetPasswordWoVersion(): void;
    get passwordWoVersionInput(): number | undefined;
    private _pluginName?;
    get pluginName(): string;
    set pluginName(value: string);
    resetPluginName(): void;
    get pluginNameInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _privateKeyWo?;
    get privateKeyWo(): string;
    set privateKeyWo(value: string);
    resetPrivateKeyWo(): void;
    get privateKeyWoInput(): string | undefined;
    private _privateKeyWoVersion?;
    get privateKeyWoVersion(): number;
    set privateKeyWoVersion(value: number);
    resetPrivateKeyWoVersion(): void;
    get privateKeyWoVersionInput(): number | undefined;
    private _rootRotationStatements?;
    get rootRotationStatements(): string[];
    set rootRotationStatements(value: string[]);
    resetRootRotationStatements(): void;
    get rootRotationStatementsInput(): string[] | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _skipStaticRoleImportRotation?;
    get skipStaticRoleImportRotation(): boolean | cdktn.IResolvable;
    set skipStaticRoleImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipStaticRoleImportRotation(): void;
    get skipStaticRoleImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _usernameTemplate?;
    get usernameTemplate(): string;
    set usernameTemplate(value: string);
    resetUsernameTemplate(): void;
    get usernameTemplateInput(): string | undefined;
    private _verifyConnection?;
    get verifyConnection(): boolean | cdktn.IResolvable;
    set verifyConnection(value: boolean | cdktn.IResolvable);
    resetVerifyConnection(): void;
    get verifyConnectionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DatabaseSecretsMountSnowflakeList extends cdktn.ComplexList {
    internalValue?: DatabaseSecretsMountSnowflake[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseSecretsMountSnowflakeOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount vault_database_secrets_mount}
*/
export declare class DatabaseSecretsMount extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_database_secrets_mount";
    /**
    * Generates CDKTN code for importing a DatabaseSecretsMount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseSecretsMount to import
    * @param importFromId The id of the existing DatabaseSecretsMount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseSecretsMount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/database_secrets_mount vault_database_secrets_mount} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseSecretsMountConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseSecretsMountConfig);
    get accessor(): string;
    private _allowedManagedKeys?;
    get allowedManagedKeys(): string[];
    set allowedManagedKeys(value: string[]);
    resetAllowedManagedKeys(): void;
    get allowedManagedKeysInput(): string[] | undefined;
    private _allowedResponseHeaders?;
    get allowedResponseHeaders(): string[];
    set allowedResponseHeaders(value: string[]);
    resetAllowedResponseHeaders(): void;
    get allowedResponseHeadersInput(): string[] | undefined;
    private _auditNonHmacRequestKeys?;
    get auditNonHmacRequestKeys(): string[];
    set auditNonHmacRequestKeys(value: string[]);
    resetAuditNonHmacRequestKeys(): void;
    get auditNonHmacRequestKeysInput(): string[] | undefined;
    private _auditNonHmacResponseKeys?;
    get auditNonHmacResponseKeys(): string[];
    set auditNonHmacResponseKeys(value: string[]);
    resetAuditNonHmacResponseKeys(): void;
    get auditNonHmacResponseKeysInput(): string[] | undefined;
    private _defaultLeaseTtlSeconds?;
    get defaultLeaseTtlSeconds(): number;
    set defaultLeaseTtlSeconds(value: number);
    resetDefaultLeaseTtlSeconds(): void;
    get defaultLeaseTtlSecondsInput(): number | undefined;
    private _delegatedAuthAccessors?;
    get delegatedAuthAccessors(): string[];
    set delegatedAuthAccessors(value: string[]);
    resetDelegatedAuthAccessors(): void;
    get delegatedAuthAccessorsInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get engineCount(): number;
    private _externalEntropyAccess?;
    get externalEntropyAccess(): boolean | cdktn.IResolvable;
    set externalEntropyAccess(value: boolean | cdktn.IResolvable);
    resetExternalEntropyAccess(): void;
    get externalEntropyAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _forceNoCache?;
    get forceNoCache(): boolean | cdktn.IResolvable;
    set forceNoCache(value: boolean | cdktn.IResolvable);
    resetForceNoCache(): void;
    get forceNoCacheInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityTokenKey?;
    get identityTokenKey(): string;
    set identityTokenKey(value: string);
    resetIdentityTokenKey(): void;
    get identityTokenKeyInput(): string | undefined;
    private _listingVisibility?;
    get listingVisibility(): string;
    set listingVisibility(value: string);
    resetListingVisibility(): void;
    get listingVisibilityInput(): string | undefined;
    private _local?;
    get local(): boolean | cdktn.IResolvable;
    set local(value: boolean | cdktn.IResolvable);
    resetLocal(): void;
    get localInput(): boolean | cdktn.IResolvable | undefined;
    private _maxLeaseTtlSeconds?;
    get maxLeaseTtlSeconds(): number;
    set maxLeaseTtlSeconds(value: number);
    resetMaxLeaseTtlSeconds(): void;
    get maxLeaseTtlSecondsInput(): number | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _passthroughRequestHeaders?;
    get passthroughRequestHeaders(): string[];
    set passthroughRequestHeaders(value: string[]);
    resetPassthroughRequestHeaders(): void;
    get passthroughRequestHeadersInput(): string[] | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _sealWrap?;
    get sealWrap(): boolean | cdktn.IResolvable;
    set sealWrap(value: boolean | cdktn.IResolvable);
    resetSealWrap(): void;
    get sealWrapInput(): boolean | cdktn.IResolvable | undefined;
    private _cassandra;
    get cassandra(): DatabaseSecretsMountCassandraList;
    putCassandra(value: DatabaseSecretsMountCassandra[] | cdktn.IResolvable): void;
    resetCassandra(): void;
    get cassandraInput(): cdktn.IResolvable | DatabaseSecretsMountCassandra[] | undefined;
    private _couchbase;
    get couchbase(): DatabaseSecretsMountCouchbaseList;
    putCouchbase(value: DatabaseSecretsMountCouchbase[] | cdktn.IResolvable): void;
    resetCouchbase(): void;
    get couchbaseInput(): cdktn.IResolvable | DatabaseSecretsMountCouchbase[] | undefined;
    private _elasticsearch;
    get elasticsearch(): DatabaseSecretsMountElasticsearchList;
    putElasticsearch(value: DatabaseSecretsMountElasticsearch[] | cdktn.IResolvable): void;
    resetElasticsearch(): void;
    get elasticsearchInput(): cdktn.IResolvable | DatabaseSecretsMountElasticsearch[] | undefined;
    private _hana;
    get hana(): DatabaseSecretsMountHanaList;
    putHana(value: DatabaseSecretsMountHana[] | cdktn.IResolvable): void;
    resetHana(): void;
    get hanaInput(): cdktn.IResolvable | DatabaseSecretsMountHana[] | undefined;
    private _influxdb;
    get influxdb(): DatabaseSecretsMountInfluxdbList;
    putInfluxdb(value: DatabaseSecretsMountInfluxdb[] | cdktn.IResolvable): void;
    resetInfluxdb(): void;
    get influxdbInput(): cdktn.IResolvable | DatabaseSecretsMountInfluxdb[] | undefined;
    private _mongodb;
    get mongodb(): DatabaseSecretsMountMongodbList;
    putMongodb(value: DatabaseSecretsMountMongodb[] | cdktn.IResolvable): void;
    resetMongodb(): void;
    get mongodbInput(): cdktn.IResolvable | DatabaseSecretsMountMongodb[] | undefined;
    private _mongodbatlas;
    get mongodbatlas(): DatabaseSecretsMountMongodbatlasList;
    putMongodbatlas(value: DatabaseSecretsMountMongodbatlas[] | cdktn.IResolvable): void;
    resetMongodbatlas(): void;
    get mongodbatlasInput(): cdktn.IResolvable | DatabaseSecretsMountMongodbatlas[] | undefined;
    private _mssql;
    get mssql(): DatabaseSecretsMountMssqlList;
    putMssql(value: DatabaseSecretsMountMssql[] | cdktn.IResolvable): void;
    resetMssql(): void;
    get mssqlInput(): cdktn.IResolvable | DatabaseSecretsMountMssql[] | undefined;
    private _mysql;
    get mysql(): DatabaseSecretsMountMysqlList;
    putMysql(value: DatabaseSecretsMountMysql[] | cdktn.IResolvable): void;
    resetMysql(): void;
    get mysqlInput(): cdktn.IResolvable | DatabaseSecretsMountMysql[] | undefined;
    private _mysqlAurora;
    get mysqlAurora(): DatabaseSecretsMountMysqlAuroraList;
    putMysqlAurora(value: DatabaseSecretsMountMysqlAurora[] | cdktn.IResolvable): void;
    resetMysqlAurora(): void;
    get mysqlAuroraInput(): cdktn.IResolvable | DatabaseSecretsMountMysqlAurora[] | undefined;
    private _mysqlLegacy;
    get mysqlLegacy(): DatabaseSecretsMountMysqlLegacyList;
    putMysqlLegacy(value: DatabaseSecretsMountMysqlLegacy[] | cdktn.IResolvable): void;
    resetMysqlLegacy(): void;
    get mysqlLegacyInput(): cdktn.IResolvable | DatabaseSecretsMountMysqlLegacy[] | undefined;
    private _mysqlRds;
    get mysqlRds(): DatabaseSecretsMountMysqlRdsList;
    putMysqlRds(value: DatabaseSecretsMountMysqlRds[] | cdktn.IResolvable): void;
    resetMysqlRds(): void;
    get mysqlRdsInput(): cdktn.IResolvable | DatabaseSecretsMountMysqlRds[] | undefined;
    private _oracle;
    get oracle(): DatabaseSecretsMountOracleList;
    putOracle(value: DatabaseSecretsMountOracle[] | cdktn.IResolvable): void;
    resetOracle(): void;
    get oracleInput(): cdktn.IResolvable | DatabaseSecretsMountOracle[] | undefined;
    private _postgresql;
    get postgresql(): DatabaseSecretsMountPostgresqlList;
    putPostgresql(value: DatabaseSecretsMountPostgresql[] | cdktn.IResolvable): void;
    resetPostgresql(): void;
    get postgresqlInput(): cdktn.IResolvable | DatabaseSecretsMountPostgresql[] | undefined;
    private _redis;
    get redis(): DatabaseSecretsMountRedisList;
    putRedis(value: DatabaseSecretsMountRedis[] | cdktn.IResolvable): void;
    resetRedis(): void;
    get redisInput(): cdktn.IResolvable | DatabaseSecretsMountRedis[] | undefined;
    private _redisElasticache;
    get redisElasticache(): DatabaseSecretsMountRedisElasticacheList;
    putRedisElasticache(value: DatabaseSecretsMountRedisElasticache[] | cdktn.IResolvable): void;
    resetRedisElasticache(): void;
    get redisElasticacheInput(): cdktn.IResolvable | DatabaseSecretsMountRedisElasticache[] | undefined;
    private _redshift;
    get redshift(): DatabaseSecretsMountRedshiftList;
    putRedshift(value: DatabaseSecretsMountRedshift[] | cdktn.IResolvable): void;
    resetRedshift(): void;
    get redshiftInput(): cdktn.IResolvable | DatabaseSecretsMountRedshift[] | undefined;
    private _snowflake;
    get snowflake(): DatabaseSecretsMountSnowflakeList;
    putSnowflake(value: DatabaseSecretsMountSnowflake[] | cdktn.IResolvable): void;
    resetSnowflake(): void;
    get snowflakeInput(): cdktn.IResolvable | DatabaseSecretsMountSnowflake[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AzureSecretBackendStaticRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Application object ID for an existing service principal that is managed by the static role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_static_role#application_object_id AzureSecretBackendStaticRole#application_object_id}
    */
    readonly applicationObjectId: string;
    /**
    * The path where the Azure secrets backend is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_static_role#backend AzureSecretBackendStaticRole#backend}
    */
    readonly backend: string;
    /**
    * The plaintext secret value of the credential you want to import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_static_role#client_secret AzureSecretBackendStaticRole#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * If true, the initial creation of credentials will be deferred until first static-creds read.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_static_role#defer_initial_creds AzureSecretBackendStaticRole#defer_initial_creds}
    */
    readonly deferInitialCreds?: boolean | cdktn.IResolvable;
    /**
    * A future expiration time for the imported credential, in RFC3339 format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_static_role#expiration AzureSecretBackendStaticRole#expiration}
    */
    readonly expiration?: string;
    /**
    * A map of string key/value pairs that will be stored as metadata on the secret.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_static_role#metadata AzureSecretBackendStaticRole#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_static_role#namespace AzureSecretBackendStaticRole#namespace}
    */
    readonly namespace?: string;
    /**
    * Name of the static role to create.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_static_role#role AzureSecretBackendStaticRole#role}
    */
    readonly role: string;
    /**
    * The secret ID of the Azure password credential you want to import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_static_role#secret_id AzureSecretBackendStaticRole#secret_id}
    */
    readonly secretId?: string;
    /**
    * If true, skip rotation of the client secret on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_static_role#skip_import_rotation AzureSecretBackendStaticRole#skip_import_rotation}
    */
    readonly skipImportRotation?: boolean | cdktn.IResolvable;
    /**
    * Timespan of 1 month or more during which the role credentials are valid.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_static_role#ttl AzureSecretBackendStaticRole#ttl}
    */
    readonly ttl?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_static_role vault_azure_secret_backend_static_role}
*/
export declare class AzureSecretBackendStaticRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_azure_secret_backend_static_role";
    /**
    * Generates CDKTN code for importing a AzureSecretBackendStaticRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AzureSecretBackendStaticRole to import
    * @param importFromId The id of the existing AzureSecretBackendStaticRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_static_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AzureSecretBackendStaticRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_static_role vault_azure_secret_backend_static_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AzureSecretBackendStaticRoleConfig
    */
    constructor(scope: Construct, id: string, config: AzureSecretBackendStaticRoleConfig);
    private _applicationObjectId?;
    get applicationObjectId(): string;
    set applicationObjectId(value: string);
    get applicationObjectIdInput(): string | undefined;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _deferInitialCreds?;
    get deferInitialCreds(): boolean | cdktn.IResolvable;
    set deferInitialCreds(value: boolean | cdktn.IResolvable);
    resetDeferInitialCreds(): void;
    get deferInitialCredsInput(): boolean | cdktn.IResolvable | undefined;
    private _expiration?;
    get expiration(): string;
    set expiration(value: string);
    resetExpiration(): void;
    get expirationInput(): string | undefined;
    get id(): string;
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _secretId?;
    get secretId(): string;
    set secretId(value: string);
    resetSecretId(): void;
    get secretIdInput(): string | undefined;
    private _skipImportRotation?;
    get skipImportRotation(): boolean | cdktn.IResolvable;
    set skipImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipImportRotation(): void;
    get skipImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultPolicyDocumentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/policy_document#id DataVaultPolicyDocument#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/policy_document#namespace DataVaultPolicyDocument#namespace}
    */
    readonly namespace?: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/policy_document#rule DataVaultPolicyDocument#rule}
    */
    readonly rule?: DataVaultPolicyDocumentRule[] | cdktn.IResolvable;
}
export interface DataVaultPolicyDocumentRuleAllowedParameter {
    /**
    * Name of permitted key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/policy_document#key DataVaultPolicyDocument#key}
    */
    readonly key: string;
    /**
    * A list of values what are permitted by policy rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/policy_document#value DataVaultPolicyDocument#value}
    */
    readonly value: string[];
}
export declare function dataVaultPolicyDocumentRuleAllowedParameterToTerraform(struct?: DataVaultPolicyDocumentRuleAllowedParameter | cdktn.IResolvable): any;
export declare function dataVaultPolicyDocumentRuleAllowedParameterToHclTerraform(struct?: DataVaultPolicyDocumentRuleAllowedParameter | cdktn.IResolvable): any;
export declare class DataVaultPolicyDocumentRuleAllowedParameterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataVaultPolicyDocumentRuleAllowedParameter | cdktn.IResolvable | undefined;
    set internalValue(value: DataVaultPolicyDocumentRuleAllowedParameter | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string[];
    set value(value: string[]);
    get valueInput(): string[] | undefined;
}
export declare class DataVaultPolicyDocumentRuleAllowedParameterList extends cdktn.ComplexList {
    internalValue?: DataVaultPolicyDocumentRuleAllowedParameter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataVaultPolicyDocumentRuleAllowedParameterOutputReference;
}
export interface DataVaultPolicyDocumentRuleDeniedParameter {
    /**
    * Name of denied key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/policy_document#key DataVaultPolicyDocument#key}
    */
    readonly key: string;
    /**
    * A list of values what are denied by policy rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/policy_document#value DataVaultPolicyDocument#value}
    */
    readonly value: string[];
}
export declare function dataVaultPolicyDocumentRuleDeniedParameterToTerraform(struct?: DataVaultPolicyDocumentRuleDeniedParameter | cdktn.IResolvable): any;
export declare function dataVaultPolicyDocumentRuleDeniedParameterToHclTerraform(struct?: DataVaultPolicyDocumentRuleDeniedParameter | cdktn.IResolvable): any;
export declare class DataVaultPolicyDocumentRuleDeniedParameterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataVaultPolicyDocumentRuleDeniedParameter | cdktn.IResolvable | undefined;
    set internalValue(value: DataVaultPolicyDocumentRuleDeniedParameter | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string[];
    set value(value: string[]);
    get valueInput(): string[] | undefined;
}
export declare class DataVaultPolicyDocumentRuleDeniedParameterList extends cdktn.ComplexList {
    internalValue?: DataVaultPolicyDocumentRuleDeniedParameter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataVaultPolicyDocumentRuleDeniedParameterOutputReference;
}
export interface DataVaultPolicyDocumentRule {
    /**
    * A list of capabilities to apply to the specified path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/policy_document#capabilities DataVaultPolicyDocument#capabilities}
    */
    readonly capabilities: string[];
    /**
    * Description of the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/policy_document#description DataVaultPolicyDocument#description}
    */
    readonly description?: string;
    /**
    * The maximum allowed TTL that clients can specify for a wrapped response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/policy_document#max_wrapping_ttl DataVaultPolicyDocument#max_wrapping_ttl}
    */
    readonly maxWrappingTtl?: string;
    /**
    * The minimum allowed TTL that clients can specify for a wrapped response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/policy_document#min_wrapping_ttl DataVaultPolicyDocument#min_wrapping_ttl}
    */
    readonly minWrappingTtl?: string;
    /**
    * A path in Vault that this rule applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/policy_document#path DataVaultPolicyDocument#path}
    */
    readonly path: string;
    /**
    * A list of parameters that must be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/policy_document#required_parameters DataVaultPolicyDocument#required_parameters}
    */
    readonly requiredParameters?: string[];
    /**
    * A list of event types to subscribe to when using `subscribe` capability
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/policy_document#subscribe_event_types DataVaultPolicyDocument#subscribe_event_types}
    */
    readonly subscribeEventTypes?: string[];
    /**
    * allowed_parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/policy_document#allowed_parameter DataVaultPolicyDocument#allowed_parameter}
    */
    readonly allowedParameter?: DataVaultPolicyDocumentRuleAllowedParameter[] | cdktn.IResolvable;
    /**
    * denied_parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/policy_document#denied_parameter DataVaultPolicyDocument#denied_parameter}
    */
    readonly deniedParameter?: DataVaultPolicyDocumentRuleDeniedParameter[] | cdktn.IResolvable;
}
export declare function dataVaultPolicyDocumentRuleToTerraform(struct?: DataVaultPolicyDocumentRule | cdktn.IResolvable): any;
export declare function dataVaultPolicyDocumentRuleToHclTerraform(struct?: DataVaultPolicyDocumentRule | cdktn.IResolvable): any;
export declare class DataVaultPolicyDocumentRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataVaultPolicyDocumentRule | cdktn.IResolvable | undefined;
    set internalValue(value: DataVaultPolicyDocumentRule | cdktn.IResolvable | undefined);
    private _capabilities?;
    get capabilities(): string[];
    set capabilities(value: string[]);
    get capabilitiesInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _maxWrappingTtl?;
    get maxWrappingTtl(): string;
    set maxWrappingTtl(value: string);
    resetMaxWrappingTtl(): void;
    get maxWrappingTtlInput(): string | undefined;
    private _minWrappingTtl?;
    get minWrappingTtl(): string;
    set minWrappingTtl(value: string);
    resetMinWrappingTtl(): void;
    get minWrappingTtlInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _requiredParameters?;
    get requiredParameters(): string[];
    set requiredParameters(value: string[]);
    resetRequiredParameters(): void;
    get requiredParametersInput(): string[] | undefined;
    private _subscribeEventTypes?;
    get subscribeEventTypes(): string[];
    set subscribeEventTypes(value: string[]);
    resetSubscribeEventTypes(): void;
    get subscribeEventTypesInput(): string[] | undefined;
    private _allowedParameter;
    get allowedParameter(): DataVaultPolicyDocumentRuleAllowedParameterList;
    putAllowedParameter(value: DataVaultPolicyDocumentRuleAllowedParameter[] | cdktn.IResolvable): void;
    resetAllowedParameter(): void;
    get allowedParameterInput(): cdktn.IResolvable | DataVaultPolicyDocumentRuleAllowedParameter[] | undefined;
    private _deniedParameter;
    get deniedParameter(): DataVaultPolicyDocumentRuleDeniedParameterList;
    putDeniedParameter(value: DataVaultPolicyDocumentRuleDeniedParameter[] | cdktn.IResolvable): void;
    resetDeniedParameter(): void;
    get deniedParameterInput(): cdktn.IResolvable | DataVaultPolicyDocumentRuleDeniedParameter[] | undefined;
}
export declare class DataVaultPolicyDocumentRuleList extends cdktn.ComplexList {
    internalValue?: DataVaultPolicyDocumentRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataVaultPolicyDocumentRuleOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/policy_document vault_policy_document}
*/
export declare class DataVaultPolicyDocument extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_policy_document";
    /**
    * Generates CDKTN code for importing a DataVaultPolicyDocument resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultPolicyDocument to import
    * @param importFromId The id of the existing DataVaultPolicyDocument that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/policy_document#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultPolicyDocument to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/policy_document vault_policy_document} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultPolicyDocumentConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataVaultPolicyDocumentConfig);
    get hcl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _rule;
    get rule(): DataVaultPolicyDocumentRuleList;
    putRule(value: DataVaultPolicyDocumentRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | DataVaultPolicyDocumentRule[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultPkiSecretBackendIssuerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Full path where PKI backend is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/pki_secret_backend_issuer#backend DataVaultPkiSecretBackendIssuer#backend}
    */
    readonly backend: string;
    /**
    * This determines whether this issuer is able to issue certificates where the chain of trust (including the issued certificate) contain critical extensions not processed by Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/pki_secret_backend_issuer#disable_critical_extension_checks DataVaultPkiSecretBackendIssuer#disable_critical_extension_checks}
    */
    readonly disableCriticalExtensionChecks?: boolean | cdktn.IResolvable;
    /**
    * This determines whether this issuer is able to issue certificates where the chain of trust (including the final issued certificate) contains a link in which the subject of the issuing certificate does not match the named issuer of the certificate it signed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/pki_secret_backend_issuer#disable_name_checks DataVaultPkiSecretBackendIssuer#disable_name_checks}
    */
    readonly disableNameChecks?: boolean | cdktn.IResolvable;
    /**
    * This determines whether this issuer is able to issue certificates where the chain of trust (including the final issued certificate) violates the name constraints critical extension of one of the issuer certificates in the chain
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/pki_secret_backend_issuer#disable_name_constraint_checks DataVaultPkiSecretBackendIssuer#disable_name_constraint_checks}
    */
    readonly disableNameConstraintChecks?: boolean | cdktn.IResolvable;
    /**
    * This determines whether this issuer is able to issue certificates where the chain of trust (including the final issued certificate) is longer than allowed by a certificate authority in that chain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/pki_secret_backend_issuer#disable_path_length_checks DataVaultPkiSecretBackendIssuer#disable_path_length_checks}
    */
    readonly disablePathLengthChecks?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/pki_secret_backend_issuer#id DataVaultPkiSecretBackendIssuer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Reference to an existing issuer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/pki_secret_backend_issuer#issuer_ref DataVaultPkiSecretBackendIssuer#issuer_ref}
    */
    readonly issuerRef: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/pki_secret_backend_issuer#namespace DataVaultPkiSecretBackendIssuer#namespace}
    */
    readonly namespace?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/pki_secret_backend_issuer vault_pki_secret_backend_issuer}
*/
export declare class DataVaultPkiSecretBackendIssuer extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_pki_secret_backend_issuer";
    /**
    * Generates CDKTN code for importing a DataVaultPkiSecretBackendIssuer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultPkiSecretBackendIssuer to import
    * @param importFromId The id of the existing DataVaultPkiSecretBackendIssuer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/pki_secret_backend_issuer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultPkiSecretBackendIssuer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/data-sources/pki_secret_backend_issuer vault_pki_secret_backend_issuer} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultPkiSecretBackendIssuerConfig
    */
    constructor(scope: Construct, id: string, config: DataVaultPkiSecretBackendIssuerConfig);
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    get caChain(): string[];
    get certificate(): string;
    private _disableCriticalExtensionChecks?;
    get disableCriticalExtensionChecks(): boolean | cdktn.IResolvable;
    set disableCriticalExtensionChecks(value: boolean | cdktn.IResolvable);
    resetDisableCriticalExtensionChecks(): void;
    get disableCriticalExtensionChecksInput(): boolean | cdktn.IResolvable | undefined;
    private _disableNameChecks?;
    get disableNameChecks(): boolean | cdktn.IResolvable;
    set disableNameChecks(value: boolean | cdktn.IResolvable);
    resetDisableNameChecks(): void;
    get disableNameChecksInput(): boolean | cdktn.IResolvable | undefined;
    private _disableNameConstraintChecks?;
    get disableNameConstraintChecks(): boolean | cdktn.IResolvable;
    set disableNameConstraintChecks(value: boolean | cdktn.IResolvable);
    resetDisableNameConstraintChecks(): void;
    get disableNameConstraintChecksInput(): boolean | cdktn.IResolvable | undefined;
    private _disablePathLengthChecks?;
    get disablePathLengthChecks(): boolean | cdktn.IResolvable;
    set disablePathLengthChecks(value: boolean | cdktn.IResolvable);
    resetDisablePathLengthChecks(): void;
    get disablePathLengthChecksInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get issuerId(): string;
    get issuerName(): string;
    private _issuerRef?;
    get issuerRef(): string;
    set issuerRef(value: string);
    get issuerRefInput(): string | undefined;
    get keyId(): string;
    get leafNotAfterBehavior(): string;
    get manualChain(): string[];
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get usage(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

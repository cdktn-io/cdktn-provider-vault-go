/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PkiSecretBackendRootSignIntermediateConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of alternative names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#alt_names PkiSecretBackendRootSignIntermediate#alt_names}
    */
    readonly altNames?: string[];
    /**
    * The PKI secret backend the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#backend PkiSecretBackendRootSignIntermediate#backend}
    */
    readonly backend: string;
    /**
    * CN of intermediate to create.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#common_name PkiSecretBackendRootSignIntermediate#common_name}
    */
    readonly commonName: string;
    /**
    * The country.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#country PkiSecretBackendRootSignIntermediate#country}
    */
    readonly country?: string;
    /**
    * The CSR.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#csr PkiSecretBackendRootSignIntermediate#csr}
    */
    readonly csr: string;
    /**
    * Flag to exclude CN from SANs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#exclude_cn_from_sans PkiSecretBackendRootSignIntermediate#exclude_cn_from_sans}
    */
    readonly excludeCnFromSans?: boolean | cdktn.IResolvable;
    /**
    * List of domains for which certificates are not allowed to be issued.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#excluded_dns_domains PkiSecretBackendRootSignIntermediate#excluded_dns_domains}
    */
    readonly excludedDnsDomains?: string[];
    /**
    * List of email addresses for which certificates are not allowed to be issued.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#excluded_email_addresses PkiSecretBackendRootSignIntermediate#excluded_email_addresses}
    */
    readonly excludedEmailAddresses?: string[];
    /**
    * List of IP ranges for which certificates are NOT allowed to be issued.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#excluded_ip_ranges PkiSecretBackendRootSignIntermediate#excluded_ip_ranges}
    */
    readonly excludedIpRanges?: string[];
    /**
    * List of URI domains for which certificates are not allowed to be issued.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#excluded_uri_domains PkiSecretBackendRootSignIntermediate#excluded_uri_domains}
    */
    readonly excludedUriDomains?: string[];
    /**
    * The format of data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#format PkiSecretBackendRootSignIntermediate#format}
    */
    readonly format?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#id PkiSecretBackendRootSignIntermediate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * List of alternative IPs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#ip_sans PkiSecretBackendRootSignIntermediate#ip_sans}
    */
    readonly ipSans?: string[];
    /**
    * Specifies the default issuer of this request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#issuer_ref PkiSecretBackendRootSignIntermediate#issuer_ref}
    */
    readonly issuerRef?: string;
    /**
    * Specify the key usages to be added to the existing set of key usages ("CRL", "CertSign") on the generated certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#key_usage PkiSecretBackendRootSignIntermediate#key_usage}
    */
    readonly keyUsage?: string[];
    /**
    * The locality.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#locality PkiSecretBackendRootSignIntermediate#locality}
    */
    readonly locality?: string;
    /**
    * The maximum path length to encode in the generated certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#max_path_length PkiSecretBackendRootSignIntermediate#max_path_length}
    */
    readonly maxPathLength?: number;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#namespace PkiSecretBackendRootSignIntermediate#namespace}
    */
    readonly namespace?: string;
    /**
    * Set the Not After field of the certificate with specified date value. The value format should be given in UTC format YYYY-MM-ddTHH:MM:SSZ. Supports the Y10K end date for IEEE 802.1AR-2018 standard devices, 9999-12-31T23:59:59Z.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#not_after PkiSecretBackendRootSignIntermediate#not_after}
    */
    readonly notAfter?: string;
    /**
    * Specifies the duration by which to backdate the NotBefore property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#not_before_duration PkiSecretBackendRootSignIntermediate#not_before_duration}
    */
    readonly notBeforeDuration?: string;
    /**
    * The organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#organization PkiSecretBackendRootSignIntermediate#organization}
    */
    readonly organization?: string;
    /**
    * List of other SANs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#other_sans PkiSecretBackendRootSignIntermediate#other_sans}
    */
    readonly otherSans?: string[];
    /**
    * The organization unit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#ou PkiSecretBackendRootSignIntermediate#ou}
    */
    readonly ou?: string;
    /**
    * List of domains for which certificates are allowed to be issued.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#permitted_dns_domains PkiSecretBackendRootSignIntermediate#permitted_dns_domains}
    */
    readonly permittedDnsDomains?: string[];
    /**
    * List of email addresses for which certificates are allowed to be issued.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#permitted_email_addresses PkiSecretBackendRootSignIntermediate#permitted_email_addresses}
    */
    readonly permittedEmailAddresses?: string[];
    /**
    * List of IP ranges for which certificates are allowed to be issued.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#permitted_ip_ranges PkiSecretBackendRootSignIntermediate#permitted_ip_ranges}
    */
    readonly permittedIpRanges?: string[];
    /**
    * List of URI domains for which certificates are allowed to be issued.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#permitted_uri_domains PkiSecretBackendRootSignIntermediate#permitted_uri_domains}
    */
    readonly permittedUriDomains?: string[];
    /**
    * The postal code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#postal_code PkiSecretBackendRootSignIntermediate#postal_code}
    */
    readonly postalCode?: string;
    /**
    * The province.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#province PkiSecretBackendRootSignIntermediate#province}
    */
    readonly province?: string;
    /**
    * Revoke the certificate upon resource destruction.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#revoke PkiSecretBackendRootSignIntermediate#revoke}
    */
    readonly revoke?: boolean | cdktn.IResolvable;
    /**
    * The number of bits to use in the signature algorithm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#signature_bits PkiSecretBackendRootSignIntermediate#signature_bits}
    */
    readonly signatureBits?: number;
    /**
    * Value for the Subject Key Identifier field
    *   (RFC 5280 Section 4.2.1.2). Specified as a string in hex format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#skid PkiSecretBackendRootSignIntermediate#skid}
    */
    readonly skid?: string;
    /**
    * The street address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#street_address PkiSecretBackendRootSignIntermediate#street_address}
    */
    readonly streetAddress?: string;
    /**
    * Time to live.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#ttl PkiSecretBackendRootSignIntermediate#ttl}
    */
    readonly ttl?: string;
    /**
    * List of alternative URIs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#uri_sans PkiSecretBackendRootSignIntermediate#uri_sans}
    */
    readonly uriSans?: string[];
    /**
    * Preserve CSR values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#use_csr_values PkiSecretBackendRootSignIntermediate#use_csr_values}
    */
    readonly useCsrValues?: boolean | cdktn.IResolvable;
    /**
    * Specifies whether or not to use PSS signatures
    *   over PKCS#1v1.5 signatures when a RSA-type issuer is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#use_pss PkiSecretBackendRootSignIntermediate#use_pss}
    */
    readonly usePss?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate vault_pki_secret_backend_root_sign_intermediate}
*/
export declare class PkiSecretBackendRootSignIntermediate extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_pki_secret_backend_root_sign_intermediate";
    /**
    * Generates CDKTN code for importing a PkiSecretBackendRootSignIntermediate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PkiSecretBackendRootSignIntermediate to import
    * @param importFromId The id of the existing PkiSecretBackendRootSignIntermediate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PkiSecretBackendRootSignIntermediate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_root_sign_intermediate vault_pki_secret_backend_root_sign_intermediate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PkiSecretBackendRootSignIntermediateConfig
    */
    constructor(scope: Construct, id: string, config: PkiSecretBackendRootSignIntermediateConfig);
    private _altNames?;
    get altNames(): string[];
    set altNames(value: string[]);
    resetAltNames(): void;
    get altNamesInput(): string[] | undefined;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    get caChain(): string[];
    get certificate(): string;
    get certificateBundle(): string;
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    get commonNameInput(): string | undefined;
    private _country?;
    get country(): string;
    set country(value: string);
    resetCountry(): void;
    get countryInput(): string | undefined;
    private _csr?;
    get csr(): string;
    set csr(value: string);
    get csrInput(): string | undefined;
    private _excludeCnFromSans?;
    get excludeCnFromSans(): boolean | cdktn.IResolvable;
    set excludeCnFromSans(value: boolean | cdktn.IResolvable);
    resetExcludeCnFromSans(): void;
    get excludeCnFromSansInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedDnsDomains?;
    get excludedDnsDomains(): string[];
    set excludedDnsDomains(value: string[]);
    resetExcludedDnsDomains(): void;
    get excludedDnsDomainsInput(): string[] | undefined;
    private _excludedEmailAddresses?;
    get excludedEmailAddresses(): string[];
    set excludedEmailAddresses(value: string[]);
    resetExcludedEmailAddresses(): void;
    get excludedEmailAddressesInput(): string[] | undefined;
    private _excludedIpRanges?;
    get excludedIpRanges(): string[];
    set excludedIpRanges(value: string[]);
    resetExcludedIpRanges(): void;
    get excludedIpRangesInput(): string[] | undefined;
    private _excludedUriDomains?;
    get excludedUriDomains(): string[];
    set excludedUriDomains(value: string[]);
    resetExcludedUriDomains(): void;
    get excludedUriDomainsInput(): string[] | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipSans?;
    get ipSans(): string[];
    set ipSans(value: string[]);
    resetIpSans(): void;
    get ipSansInput(): string[] | undefined;
    private _issuerRef?;
    get issuerRef(): string;
    set issuerRef(value: string);
    resetIssuerRef(): void;
    get issuerRefInput(): string | undefined;
    get issuingCa(): string;
    private _keyUsage?;
    get keyUsage(): string[];
    set keyUsage(value: string[]);
    resetKeyUsage(): void;
    get keyUsageInput(): string[] | undefined;
    private _locality?;
    get locality(): string;
    set locality(value: string);
    resetLocality(): void;
    get localityInput(): string | undefined;
    private _maxPathLength?;
    get maxPathLength(): number;
    set maxPathLength(value: number);
    resetMaxPathLength(): void;
    get maxPathLengthInput(): number | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _notAfter?;
    get notAfter(): string;
    set notAfter(value: string);
    resetNotAfter(): void;
    get notAfterInput(): string | undefined;
    private _notBeforeDuration?;
    get notBeforeDuration(): string;
    set notBeforeDuration(value: string);
    resetNotBeforeDuration(): void;
    get notBeforeDurationInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _otherSans?;
    get otherSans(): string[];
    set otherSans(value: string[]);
    resetOtherSans(): void;
    get otherSansInput(): string[] | undefined;
    private _ou?;
    get ou(): string;
    set ou(value: string);
    resetOu(): void;
    get ouInput(): string | undefined;
    private _permittedDnsDomains?;
    get permittedDnsDomains(): string[];
    set permittedDnsDomains(value: string[]);
    resetPermittedDnsDomains(): void;
    get permittedDnsDomainsInput(): string[] | undefined;
    private _permittedEmailAddresses?;
    get permittedEmailAddresses(): string[];
    set permittedEmailAddresses(value: string[]);
    resetPermittedEmailAddresses(): void;
    get permittedEmailAddressesInput(): string[] | undefined;
    private _permittedIpRanges?;
    get permittedIpRanges(): string[];
    set permittedIpRanges(value: string[]);
    resetPermittedIpRanges(): void;
    get permittedIpRangesInput(): string[] | undefined;
    private _permittedUriDomains?;
    get permittedUriDomains(): string[];
    set permittedUriDomains(value: string[]);
    resetPermittedUriDomains(): void;
    get permittedUriDomainsInput(): string[] | undefined;
    private _postalCode?;
    get postalCode(): string;
    set postalCode(value: string);
    resetPostalCode(): void;
    get postalCodeInput(): string | undefined;
    private _province?;
    get province(): string;
    set province(value: string);
    resetProvince(): void;
    get provinceInput(): string | undefined;
    private _revoke?;
    get revoke(): boolean | cdktn.IResolvable;
    set revoke(value: boolean | cdktn.IResolvable);
    resetRevoke(): void;
    get revokeInput(): boolean | cdktn.IResolvable | undefined;
    get serialNumber(): string;
    private _signatureBits?;
    get signatureBits(): number;
    set signatureBits(value: number);
    resetSignatureBits(): void;
    get signatureBitsInput(): number | undefined;
    private _skid?;
    get skid(): string;
    set skid(value: string);
    resetSkid(): void;
    get skidInput(): string | undefined;
    private _streetAddress?;
    get streetAddress(): string;
    set streetAddress(value: string);
    resetStreetAddress(): void;
    get streetAddressInput(): string | undefined;
    private _ttl?;
    get ttl(): string;
    set ttl(value: string);
    resetTtl(): void;
    get ttlInput(): string | undefined;
    private _uriSans?;
    get uriSans(): string[];
    set uriSans(value: string[]);
    resetUriSans(): void;
    get uriSansInput(): string[] | undefined;
    private _useCsrValues?;
    get useCsrValues(): boolean | cdktn.IResolvable;
    set useCsrValues(value: boolean | cdktn.IResolvable);
    resetUseCsrValues(): void;
    get useCsrValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _usePss?;
    get usePss(): boolean | cdktn.IResolvable;
    set usePss(value: boolean | cdktn.IResolvable);
    resetUsePss(): void;
    get usePssInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

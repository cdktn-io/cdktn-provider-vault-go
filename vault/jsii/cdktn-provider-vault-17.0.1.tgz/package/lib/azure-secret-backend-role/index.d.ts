/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AzureSecretBackendRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Application Object ID for an existing service principal that will be used instead of creating dynamic service principals.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#application_object_id AzureSecretBackendRole#application_object_id}
    */
    readonly applicationObjectId?: string;
    /**
    * Unique name of the auth backend to configure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#backend AzureSecretBackendRole#backend}
    */
    readonly backend?: string;
    /**
    * Human-friendly description of the mount for the backend.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#description AzureSecretBackendRole#description}
    */
    readonly description?: string;
    /**
    * Specifies the explicit maximum lifetime of the lease and service principal.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#explicit_max_ttl AzureSecretBackendRole#explicit_max_ttl}
    */
    readonly explicitMaxTtl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#id AzureSecretBackendRole#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the maximum TTL for service principals generated using this role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#max_ttl AzureSecretBackendRole#max_ttl}
    */
    readonly maxTtl?: string;
    /**
    * A map of string key/value pairs that will be stored as metadata on the secret.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#metadata AzureSecretBackendRole#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#namespace AzureSecretBackendRole#namespace}
    */
    readonly namespace?: string;
    /**
    * Indicates whether the applications and service principals created by Vault will be permanently deleted when the corresponding leases expire.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#permanently_delete AzureSecretBackendRole#permanently_delete}
    */
    readonly permanentlyDelete?: boolean | cdktn.IResolvable;
    /**
    * If true, persists the created service principal and application for the lifetime of the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#persist_app AzureSecretBackendRole#persist_app}
    */
    readonly persistApp?: boolean | cdktn.IResolvable;
    /**
    * Name of the role to create
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#role AzureSecretBackendRole#role}
    */
    readonly role: string;
    /**
    * Specifies the security principal types that are allowed to sign in to the application. Valid values are: AzureADMyOrg, AzureADMultipleOrgs, AzureADandPersonalMicrosoftAccount, PersonalMicrosoftAccount
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#sign_in_audience AzureSecretBackendRole#sign_in_audience}
    */
    readonly signInAudience?: string;
    /**
    * Comma-separated strings of Azure tags to attach to an application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#tags AzureSecretBackendRole#tags}
    */
    readonly tags?: string[];
    /**
    * Specifies the default TTL for service principals generated using this role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#ttl AzureSecretBackendRole#ttl}
    */
    readonly ttl?: string;
    /**
    * azure_groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#azure_groups AzureSecretBackendRole#azure_groups}
    */
    readonly azureGroups?: AzureSecretBackendRoleAzureGroups[] | cdktn.IResolvable;
    /**
    * azure_roles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#azure_roles AzureSecretBackendRole#azure_roles}
    */
    readonly azureRoles?: AzureSecretBackendRoleAzureRoles[] | cdktn.IResolvable;
}
export interface AzureSecretBackendRoleAzureGroups {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#group_name AzureSecretBackendRole#group_name}
    */
    readonly groupName: string;
}
export declare function azureSecretBackendRoleAzureGroupsToTerraform(struct?: AzureSecretBackendRoleAzureGroups | cdktn.IResolvable): any;
export declare function azureSecretBackendRoleAzureGroupsToHclTerraform(struct?: AzureSecretBackendRoleAzureGroups | cdktn.IResolvable): any;
export declare class AzureSecretBackendRoleAzureGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AzureSecretBackendRoleAzureGroups | cdktn.IResolvable | undefined;
    set internalValue(value: AzureSecretBackendRoleAzureGroups | cdktn.IResolvable | undefined);
    private _groupName?;
    get groupName(): string;
    set groupName(value: string);
    get groupNameInput(): string | undefined;
    get objectId(): string;
}
export declare class AzureSecretBackendRoleAzureGroupsList extends cdktn.ComplexList {
    internalValue?: AzureSecretBackendRoleAzureGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AzureSecretBackendRoleAzureGroupsOutputReference;
}
export interface AzureSecretBackendRoleAzureRoles {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#role_id AzureSecretBackendRole#role_id}
    */
    readonly roleId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#role_name AzureSecretBackendRole#role_name}
    */
    readonly roleName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#scope AzureSecretBackendRole#scope}
    */
    readonly scope: string;
}
export declare function azureSecretBackendRoleAzureRolesToTerraform(struct?: AzureSecretBackendRoleAzureRoles | cdktn.IResolvable): any;
export declare function azureSecretBackendRoleAzureRolesToHclTerraform(struct?: AzureSecretBackendRoleAzureRoles | cdktn.IResolvable): any;
export declare class AzureSecretBackendRoleAzureRolesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AzureSecretBackendRoleAzureRoles | cdktn.IResolvable | undefined;
    set internalValue(value: AzureSecretBackendRoleAzureRoles | cdktn.IResolvable | undefined);
    private _roleId?;
    get roleId(): string;
    set roleId(value: string);
    resetRoleId(): void;
    get roleIdInput(): string | undefined;
    private _roleName?;
    get roleName(): string;
    set roleName(value: string);
    resetRoleName(): void;
    get roleNameInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export declare class AzureSecretBackendRoleAzureRolesList extends cdktn.ComplexList {
    internalValue?: AzureSecretBackendRoleAzureRoles[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AzureSecretBackendRoleAzureRolesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role vault_azure_secret_backend_role}
*/
export declare class AzureSecretBackendRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_azure_secret_backend_role";
    /**
    * Generates CDKTN code for importing a AzureSecretBackendRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AzureSecretBackendRole to import
    * @param importFromId The id of the existing AzureSecretBackendRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AzureSecretBackendRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/azure_secret_backend_role vault_azure_secret_backend_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AzureSecretBackendRoleConfig
    */
    constructor(scope: Construct, id: string, config: AzureSecretBackendRoleConfig);
    private _applicationObjectId?;
    get applicationObjectId(): string;
    set applicationObjectId(value: string);
    resetApplicationObjectId(): void;
    get applicationObjectIdInput(): string | undefined;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    resetBackend(): void;
    get backendInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _explicitMaxTtl?;
    get explicitMaxTtl(): string;
    set explicitMaxTtl(value: string);
    resetExplicitMaxTtl(): void;
    get explicitMaxTtlInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxTtl?;
    get maxTtl(): string;
    set maxTtl(value: string);
    resetMaxTtl(): void;
    get maxTtlInput(): string | undefined;
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _permanentlyDelete?;
    get permanentlyDelete(): boolean | cdktn.IResolvable;
    set permanentlyDelete(value: boolean | cdktn.IResolvable);
    resetPermanentlyDelete(): void;
    get permanentlyDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _persistApp?;
    get persistApp(): boolean | cdktn.IResolvable;
    set persistApp(value: boolean | cdktn.IResolvable);
    resetPersistApp(): void;
    get persistAppInput(): boolean | cdktn.IResolvable | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _signInAudience?;
    get signInAudience(): string;
    set signInAudience(value: string);
    resetSignInAudience(): void;
    get signInAudienceInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _ttl?;
    get ttl(): string;
    set ttl(value: string);
    resetTtl(): void;
    get ttlInput(): string | undefined;
    private _azureGroups;
    get azureGroups(): AzureSecretBackendRoleAzureGroupsList;
    putAzureGroups(value: AzureSecretBackendRoleAzureGroups[] | cdktn.IResolvable): void;
    resetAzureGroups(): void;
    get azureGroupsInput(): cdktn.IResolvable | AzureSecretBackendRoleAzureGroups[] | undefined;
    private _azureRoles;
    get azureRoles(): AzureSecretBackendRoleAzureRolesList;
    putAzureRoles(value: AzureSecretBackendRoleAzureRoles[] | cdktn.IResolvable): void;
    resetAzureRoles(): void;
    get azureRolesInput(): cdktn.IResolvable | AzureSecretBackendRoleAzureRoles[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PkiSecretBackendSignConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of alternative names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#alt_names PkiSecretBackendSign#alt_names}
    */
    readonly altNames?: string[];
    /**
    * If enabled, a new certificate will be generated if the expiration is within min_seconds_remaining
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#auto_renew PkiSecretBackendSign#auto_renew}
    */
    readonly autoRenew?: boolean | cdktn.IResolvable;
    /**
    * The PKI secret backend the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#backend PkiSecretBackendSign#backend}
    */
    readonly backend: string;
    /**
    * A base 64 encoded value or an empty string to associate with the certificate's serial number. The role's no_store_metadata must be set to false, otherwise an error is returned when specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#cert_metadata PkiSecretBackendSign#cert_metadata}
    */
    readonly certMetadata?: string;
    /**
    * CN of intermediate to create.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#common_name PkiSecretBackendSign#common_name}
    */
    readonly commonName: string;
    /**
    * The CSR.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#csr PkiSecretBackendSign#csr}
    */
    readonly csr: string;
    /**
    * Flag to exclude CN from SANs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#exclude_cn_from_sans PkiSecretBackendSign#exclude_cn_from_sans}
    */
    readonly excludeCnFromSans?: boolean | cdktn.IResolvable;
    /**
    * The format of data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#format PkiSecretBackendSign#format}
    */
    readonly format?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#id PkiSecretBackendSign#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * List of alternative IPs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#ip_sans PkiSecretBackendSign#ip_sans}
    */
    readonly ipSans?: string[];
    /**
    * Specifies the default issuer of this request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#issuer_ref PkiSecretBackendSign#issuer_ref}
    */
    readonly issuerRef?: string;
    /**
    * Generate a new certificate when the expiration is within this number of seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#min_seconds_remaining PkiSecretBackendSign#min_seconds_remaining}
    */
    readonly minSecondsRemaining?: number;
    /**
    * Name of the role to create the certificate against.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#name PkiSecretBackendSign#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#namespace PkiSecretBackendSign#namespace}
    */
    readonly namespace?: string;
    /**
    * Set the Not After field of the certificate with specified date value. The value format should be given in UTC format YYYY-MM-ddTHH:MM:SSZ. Supports the Y10K end date for IEEE 802.1AR-2018 standard devices, 9999-12-31T23:59:59Z.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#not_after PkiSecretBackendSign#not_after}
    */
    readonly notAfter?: string;
    /**
    * List of other SANs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#other_sans PkiSecretBackendSign#other_sans}
    */
    readonly otherSans?: string[];
    /**
    * If true, the returned ca_chain field will not include any self-signed CA certificates. Useful if end-users already have the root CA in their trust store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#remove_roots_from_chain PkiSecretBackendSign#remove_roots_from_chain}
    */
    readonly removeRootsFromChain?: boolean | cdktn.IResolvable;
    /**
    * Time to live.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#ttl PkiSecretBackendSign#ttl}
    */
    readonly ttl?: string;
    /**
    * List of alternative URIs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#uri_sans PkiSecretBackendSign#uri_sans}
    */
    readonly uriSans?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign vault_pki_secret_backend_sign}
*/
export declare class PkiSecretBackendSign extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_pki_secret_backend_sign";
    /**
    * Generates CDKTN code for importing a PkiSecretBackendSign resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PkiSecretBackendSign to import
    * @param importFromId The id of the existing PkiSecretBackendSign that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PkiSecretBackendSign to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_sign vault_pki_secret_backend_sign} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PkiSecretBackendSignConfig
    */
    constructor(scope: Construct, id: string, config: PkiSecretBackendSignConfig);
    private _altNames?;
    get altNames(): string[];
    set altNames(value: string[]);
    resetAltNames(): void;
    get altNamesInput(): string[] | undefined;
    private _autoRenew?;
    get autoRenew(): boolean | cdktn.IResolvable;
    set autoRenew(value: boolean | cdktn.IResolvable);
    resetAutoRenew(): void;
    get autoRenewInput(): boolean | cdktn.IResolvable | undefined;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    get caChain(): string[];
    private _certMetadata?;
    get certMetadata(): string;
    set certMetadata(value: string);
    resetCertMetadata(): void;
    get certMetadataInput(): string | undefined;
    get certificate(): string;
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    get commonNameInput(): string | undefined;
    private _csr?;
    get csr(): string;
    set csr(value: string);
    get csrInput(): string | undefined;
    private _excludeCnFromSans?;
    get excludeCnFromSans(): boolean | cdktn.IResolvable;
    set excludeCnFromSans(value: boolean | cdktn.IResolvable);
    resetExcludeCnFromSans(): void;
    get excludeCnFromSansInput(): boolean | cdktn.IResolvable | undefined;
    get expiration(): number;
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipSans?;
    get ipSans(): string[];
    set ipSans(value: string[]);
    resetIpSans(): void;
    get ipSansInput(): string[] | undefined;
    private _issuerRef?;
    get issuerRef(): string;
    set issuerRef(value: string);
    resetIssuerRef(): void;
    get issuerRefInput(): string | undefined;
    get issuingCa(): string;
    private _minSecondsRemaining?;
    get minSecondsRemaining(): number;
    set minSecondsRemaining(value: number);
    resetMinSecondsRemaining(): void;
    get minSecondsRemainingInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _notAfter?;
    get notAfter(): string;
    set notAfter(value: string);
    resetNotAfter(): void;
    get notAfterInput(): string | undefined;
    private _otherSans?;
    get otherSans(): string[];
    set otherSans(value: string[]);
    resetOtherSans(): void;
    get otherSansInput(): string[] | undefined;
    private _removeRootsFromChain?;
    get removeRootsFromChain(): boolean | cdktn.IResolvable;
    set removeRootsFromChain(value: boolean | cdktn.IResolvable);
    resetRemoveRootsFromChain(): void;
    get removeRootsFromChainInput(): boolean | cdktn.IResolvable | undefined;
    get renewPending(): cdktn.IResolvable;
    get serialNumber(): string;
    private _ttl?;
    get ttl(): string;
    set ttl(value: string);
    resetTtl(): void;
    get ttlInput(): string | undefined;
    private _uriSans?;
    get uriSans(): string[];
    set uriSans(value: string[]);
    resetUriSans(): void;
    get uriSansInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

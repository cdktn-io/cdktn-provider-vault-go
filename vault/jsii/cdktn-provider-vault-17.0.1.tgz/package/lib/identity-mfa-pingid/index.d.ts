/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IdentityMfaPingidConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_mfa_pingid#id IdentityMfaPingid#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_mfa_pingid#namespace IdentityMfaPingid#namespace}
    */
    readonly namespace?: string;
    /**
    * A base64-encoded third-party settings contents as retrieved from PingID's configuration page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_mfa_pingid#settings_file_base64 IdentityMfaPingid#settings_file_base64}
    */
    readonly settingsFileBase64: string;
    /**
    * A template string for mapping Identity names to MFA methods.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_mfa_pingid#username_format IdentityMfaPingid#username_format}
    */
    readonly usernameFormat?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_mfa_pingid vault_identity_mfa_pingid}
*/
export declare class IdentityMfaPingid extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_identity_mfa_pingid";
    /**
    * Generates CDKTN code for importing a IdentityMfaPingid resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IdentityMfaPingid to import
    * @param importFromId The id of the existing IdentityMfaPingid that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_mfa_pingid#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IdentityMfaPingid to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_mfa_pingid vault_identity_mfa_pingid} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IdentityMfaPingidConfig
    */
    constructor(scope: Construct, id: string, config: IdentityMfaPingidConfig);
    get adminUrl(): string;
    get authenticatorUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get idpUrl(): string;
    get methodId(): string;
    get mountAccessor(): string;
    get name(): string;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get namespaceId(): string;
    get namespacePath(): string;
    get orgAlias(): string;
    private _settingsFileBase64?;
    get settingsFileBase64(): string;
    set settingsFileBase64(value: string);
    get settingsFileBase64Input(): string | undefined;
    get type(): string;
    get useSignature(): cdktn.IResolvable;
    private _usernameFormat?;
    get usernameFormat(): string;
    set usernameFormat(value: string);
    resetUsernameFormat(): void;
    get usernameFormatInput(): string | undefined;
    get uuid(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApproleAuthBackendLoginConfig extends cdktn.TerraformMetaArguments {
    /**
    * Unique name of the auth backend to configure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/approle_auth_backend_login#backend ApproleAuthBackendLogin#backend}
    */
    readonly backend?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/approle_auth_backend_login#id ApproleAuthBackendLogin#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/approle_auth_backend_login#namespace ApproleAuthBackendLogin#namespace}
    */
    readonly namespace?: string;
    /**
    * The RoleID to log in with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/approle_auth_backend_login#role_id ApproleAuthBackendLogin#role_id}
    */
    readonly roleId: string;
    /**
    * The SecretID to log in with. Required unless `bind_secret_id` is set to false on the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/approle_auth_backend_login#secret_id ApproleAuthBackendLogin#secret_id}
    */
    readonly secretId?: string;
    /**
    * The SecretID to log in with. Write-only attribute that can accept ephemeral values. Required unless `bind_secret_id` is set to false on the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/approle_auth_backend_login#secret_id_wo ApproleAuthBackendLogin#secret_id_wo}
    */
    readonly secretIdWo?: string;
    /**
    * Version counter for the write-only secret_id field. Increment this to trigger re-authentication with a new SecretID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/approle_auth_backend_login#secret_id_wo_version ApproleAuthBackendLogin#secret_id_wo_version}
    */
    readonly secretIdWoVersion?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/approle_auth_backend_login vault_approle_auth_backend_login}
*/
export declare class ApproleAuthBackendLogin extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_approle_auth_backend_login";
    /**
    * Generates CDKTN code for importing a ApproleAuthBackendLogin resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApproleAuthBackendLogin to import
    * @param importFromId The id of the existing ApproleAuthBackendLogin that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/approle_auth_backend_login#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApproleAuthBackendLogin to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/approle_auth_backend_login vault_approle_auth_backend_login} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApproleAuthBackendLoginConfig
    */
    constructor(scope: Construct, id: string, config: ApproleAuthBackendLoginConfig);
    get accessor(): string;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    resetBackend(): void;
    get backendInput(): string | undefined;
    get clientToken(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get leaseDuration(): number;
    get leaseStarted(): string;
    private _metadata;
    get metadata(): cdktn.StringMap;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get policies(): string[];
    get renewable(): cdktn.IResolvable;
    private _roleId?;
    get roleId(): string;
    set roleId(value: string);
    get roleIdInput(): string | undefined;
    private _secretId?;
    get secretId(): string;
    set secretId(value: string);
    resetSecretId(): void;
    get secretIdInput(): string | undefined;
    private _secretIdWo?;
    get secretIdWo(): string;
    set secretIdWo(value: string);
    resetSecretIdWo(): void;
    get secretIdWoInput(): string | undefined;
    private _secretIdWoVersion?;
    get secretIdWoVersion(): number;
    set secretIdWoVersion(value: number);
    resetSecretIdWoVersion(): void;
    get secretIdWoVersionInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

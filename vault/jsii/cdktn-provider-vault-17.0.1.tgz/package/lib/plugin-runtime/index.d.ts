/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PluginRuntimeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies the parent cgroup to set for each container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/plugin_runtime#cgroup_parent PluginRuntime#cgroup_parent}
    */
    readonly cgroupParent?: string;
    /**
    * Specifies CPU limit to set per container in billionths of a CPU.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/plugin_runtime#cpu_nanos PluginRuntime#cpu_nanos}
    */
    readonly cpuNanos?: number;
    /**
    * Specifies memory limit to set per container in bytes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/plugin_runtime#memory_bytes PluginRuntime#memory_bytes}
    */
    readonly memoryBytes?: number;
    /**
    * The name of the plugin runtime.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/plugin_runtime#name PluginRuntime#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/plugin_runtime#namespace PluginRuntime#namespace}
    */
    readonly namespace?: string;
    /**
    * Specifies OCI-compliant container runtime to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/plugin_runtime#oci_runtime PluginRuntime#oci_runtime}
    */
    readonly ociRuntime?: string;
    /**
    * Whether the container runtime is running as a non-privileged user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/plugin_runtime#rootless PluginRuntime#rootless}
    */
    readonly rootless?: boolean | cdktn.IResolvable;
    /**
    * Specifies the plugin runtime type. Currently only `container` is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/plugin_runtime#type PluginRuntime#type}
    */
    readonly type: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/plugin_runtime vault_plugin_runtime}
*/
export declare class PluginRuntime extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_plugin_runtime";
    /**
    * Generates CDKTN code for importing a PluginRuntime resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PluginRuntime to import
    * @param importFromId The id of the existing PluginRuntime that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/plugin_runtime#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PluginRuntime to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/plugin_runtime vault_plugin_runtime} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PluginRuntimeConfig
    */
    constructor(scope: Construct, id: string, config: PluginRuntimeConfig);
    private _cgroupParent?;
    get cgroupParent(): string;
    set cgroupParent(value: string);
    resetCgroupParent(): void;
    get cgroupParentInput(): string | undefined;
    private _cpuNanos?;
    get cpuNanos(): number;
    set cpuNanos(value: number);
    resetCpuNanos(): void;
    get cpuNanosInput(): number | undefined;
    get id(): string;
    private _memoryBytes?;
    get memoryBytes(): number;
    set memoryBytes(value: number);
    resetMemoryBytes(): void;
    get memoryBytesInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _ociRuntime?;
    get ociRuntime(): string;
    set ociRuntime(value: string);
    resetOciRuntime(): void;
    get ociRuntimeInput(): string | undefined;
    private _rootless?;
    get rootless(): boolean | cdktn.IResolvable;
    set rootless(value: boolean | cdktn.IResolvable);
    resetRootless(): void;
    get rootlessInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

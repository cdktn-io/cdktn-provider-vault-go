/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IdentityEntityPoliciesConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the entity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_entity_policies#entity_id IdentityEntityPolicies#entity_id}
    */
    readonly entityId: string;
    /**
    * Should the resource manage policies exclusively
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_entity_policies#exclusive IdentityEntityPolicies#exclusive}
    */
    readonly exclusive?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_entity_policies#id IdentityEntityPolicies#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_entity_policies#namespace IdentityEntityPolicies#namespace}
    */
    readonly namespace?: string;
    /**
    * Policies to be tied to the entity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_entity_policies#policies IdentityEntityPolicies#policies}
    */
    readonly policies: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_entity_policies vault_identity_entity_policies}
*/
export declare class IdentityEntityPolicies extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_identity_entity_policies";
    /**
    * Generates CDKTN code for importing a IdentityEntityPolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IdentityEntityPolicies to import
    * @param importFromId The id of the existing IdentityEntityPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_entity_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IdentityEntityPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_entity_policies vault_identity_entity_policies} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IdentityEntityPoliciesConfig
    */
    constructor(scope: Construct, id: string, config: IdentityEntityPoliciesConfig);
    private _entityId?;
    get entityId(): string;
    set entityId(value: string);
    get entityIdInput(): string | undefined;
    get entityName(): string;
    private _exclusive?;
    get exclusive(): boolean | cdktn.IResolvable;
    set exclusive(value: boolean | cdktn.IResolvable);
    resetExclusive(): void;
    get exclusiveInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _policies?;
    get policies(): string[];
    set policies(value: string[]);
    get policiesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

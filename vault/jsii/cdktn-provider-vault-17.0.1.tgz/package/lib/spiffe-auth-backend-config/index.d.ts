/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SpiffeAuthBackendConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * A list of audience values allowed to match claims in JWT-SVIDs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/spiffe_auth_backend_config#audience SpiffeAuthBackendConfig#audience}
    */
    readonly audience?: string[];
    /**
    * When profile is 'https_spiffe_bundle', the bootstrapping bundle in SPIFFE format; when profile is 'static', either a bundle in SPIFFE format or PEM-encoded CA certificate(s)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/spiffe_auth_backend_config#bundle SpiffeAuthBackendConfig#bundle}
    */
    readonly bundle?: string;
    /**
    * Don't attempt to fetch a bundle immediately; only applies when profile != static
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/spiffe_auth_backend_config#defer_bundle_fetch SpiffeAuthBackendConfig#defer_bundle_fetch}
    */
    readonly deferBundleFetch?: boolean | cdktn.IResolvable;
    /**
    * PEM-encoded CA certificate(s) to validate the server reached by 'endpoint_url', if set this will override the default TLS trust store
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/spiffe_auth_backend_config#endpoint_root_ca_truststore_pem SpiffeAuthBackendConfig#endpoint_root_ca_truststore_pem}
    */
    readonly endpointRootCaTruststorePem?: string;
    /**
    * The server's SPIFFE ID to validate when profile is 'https_spiffe_bundle'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/spiffe_auth_backend_config#endpoint_spiffe_id SpiffeAuthBackendConfig#endpoint_spiffe_id}
    */
    readonly endpointSpiffeId?: string;
    /**
    * The URI to be used when profile is 'https_web_bundle' or 'https_spiffe_bundle'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/spiffe_auth_backend_config#endpoint_url SpiffeAuthBackendConfig#endpoint_url}
    */
    readonly endpointUrl?: string;
    /**
    * Mount path for the SPIFFE auth engine in Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/spiffe_auth_backend_config#mount SpiffeAuthBackendConfig#mount}
    */
    readonly mount: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/spiffe_auth_backend_config#namespace SpiffeAuthBackendConfig#namespace}
    */
    readonly namespace?: string;
    /**
    * The mechanism to fetch or embed the trust bundle to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/spiffe_auth_backend_config#profile SpiffeAuthBackendConfig#profile}
    */
    readonly profile: string;
    /**
    * The SPIFFE trust domain for this backend.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/spiffe_auth_backend_config#trust_domain SpiffeAuthBackendConfig#trust_domain}
    */
    readonly trustDomain: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/spiffe_auth_backend_config vault_spiffe_auth_backend_config}
*/
export declare class SpiffeAuthBackendConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_spiffe_auth_backend_config";
    /**
    * Generates CDKTN code for importing a SpiffeAuthBackendConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SpiffeAuthBackendConfig to import
    * @param importFromId The id of the existing SpiffeAuthBackendConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/spiffe_auth_backend_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SpiffeAuthBackendConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/spiffe_auth_backend_config vault_spiffe_auth_backend_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SpiffeAuthBackendConfigConfig
    */
    constructor(scope: Construct, id: string, config: SpiffeAuthBackendConfigConfig);
    private _audience?;
    get audience(): string[];
    set audience(value: string[]);
    resetAudience(): void;
    get audienceInput(): string[] | undefined;
    private _bundle?;
    get bundle(): string;
    set bundle(value: string);
    resetBundle(): void;
    get bundleInput(): string | undefined;
    private _deferBundleFetch?;
    get deferBundleFetch(): boolean | cdktn.IResolvable;
    set deferBundleFetch(value: boolean | cdktn.IResolvable);
    resetDeferBundleFetch(): void;
    get deferBundleFetchInput(): boolean | cdktn.IResolvable | undefined;
    private _endpointRootCaTruststorePem?;
    get endpointRootCaTruststorePem(): string;
    set endpointRootCaTruststorePem(value: string);
    resetEndpointRootCaTruststorePem(): void;
    get endpointRootCaTruststorePemInput(): string | undefined;
    private _endpointSpiffeId?;
    get endpointSpiffeId(): string;
    set endpointSpiffeId(value: string);
    resetEndpointSpiffeId(): void;
    get endpointSpiffeIdInput(): string | undefined;
    private _endpointUrl?;
    get endpointUrl(): string;
    set endpointUrl(value: string);
    resetEndpointUrl(): void;
    get endpointUrlInput(): string | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _profile?;
    get profile(): string;
    set profile(value: string);
    get profileInput(): string | undefined;
    private _trustDomain?;
    get trustDomain(): string;
    set trustDomain(value: string);
    get trustDomainInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

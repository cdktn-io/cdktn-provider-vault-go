/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TransformTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * The alphabet to use for this template. This is only used during FPE transformations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/transform_template#alphabet TransformTemplate#alphabet}
    */
    readonly alphabet?: string;
    /**
    * The map of regular expression templates used to customize decoded outputs.
    * Only applicable to FPE transformations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/transform_template#decode_formats TransformTemplate#decode_formats}
    */
    readonly decodeFormats?: {
        [key: string]: string;
    };
    /**
    * The regular expression template used for encoding values.
    * Only applicable to FPE transformations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/transform_template#encode_format TransformTemplate#encode_format}
    */
    readonly encodeFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/transform_template#id TransformTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/transform_template#name TransformTemplate#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/transform_template#namespace TransformTemplate#namespace}
    */
    readonly namespace?: string;
    /**
    * The mount path for a back-end, for example, the path given in "$ vault auth enable -path=my-aws aws".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/transform_template#path TransformTemplate#path}
    */
    readonly path: string;
    /**
    * The pattern used for matching. Currently, only regular expression pattern is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/transform_template#pattern TransformTemplate#pattern}
    */
    readonly pattern?: string;
    /**
    * The pattern type to use for match detection. Currently, only regex is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/transform_template#type TransformTemplate#type}
    */
    readonly type?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/transform_template vault_transform_template}
*/
export declare class TransformTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_transform_template";
    /**
    * Generates CDKTN code for importing a TransformTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TransformTemplate to import
    * @param importFromId The id of the existing TransformTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/transform_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TransformTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/transform_template vault_transform_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TransformTemplateConfig
    */
    constructor(scope: Construct, id: string, config: TransformTemplateConfig);
    private _alphabet?;
    get alphabet(): string;
    set alphabet(value: string);
    resetAlphabet(): void;
    get alphabetInput(): string | undefined;
    private _decodeFormats?;
    get decodeFormats(): {
        [key: string]: string;
    };
    set decodeFormats(value: {
        [key: string]: string;
    });
    resetDecodeFormats(): void;
    get decodeFormatsInput(): {
        [key: string]: string;
    } | undefined;
    private _encodeFormat?;
    get encodeFormat(): string;
    set encodeFormat(value: string);
    resetEncodeFormat(): void;
    get encodeFormatInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    resetPattern(): void;
    get patternInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

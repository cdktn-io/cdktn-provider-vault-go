/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SecretsSyncGithubAppsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The GitHub application ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_github_apps#app_id SecretsSyncGithubApps#app_id}
    */
    readonly appId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_github_apps#id SecretsSyncGithubApps#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The user-defined name of the GitHub App configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_github_apps#name SecretsSyncGithubApps#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_github_apps#namespace SecretsSyncGithubApps#namespace}
    */
    readonly namespace?: string;
    /**
    * The content of a PEM formatted private key generated on GitHub for the app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_github_apps#private_key SecretsSyncGithubApps#private_key}
    */
    readonly privateKey: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_github_apps vault_secrets_sync_github_apps}
*/
export declare class SecretsSyncGithubApps extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_secrets_sync_github_apps";
    /**
    * Generates CDKTN code for importing a SecretsSyncGithubApps resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecretsSyncGithubApps to import
    * @param importFromId The id of the existing SecretsSyncGithubApps that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_github_apps#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecretsSyncGithubApps to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_github_apps vault_secrets_sync_github_apps} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecretsSyncGithubAppsConfig
    */
    constructor(scope: Construct, id: string, config: SecretsSyncGithubAppsConfig);
    private _appId?;
    get appId(): number;
    set appId(value: number);
    get appIdInput(): number | undefined;
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    get privateKeyInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

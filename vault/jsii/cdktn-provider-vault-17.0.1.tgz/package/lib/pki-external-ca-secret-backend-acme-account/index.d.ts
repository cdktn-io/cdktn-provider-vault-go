/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PkiExternalCaSecretBackendAcmeAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * ACME Directory URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_external_ca_secret_backend_acme_account#directory_url PkiExternalCaSecretBackendAcmeAccount#directory_url}
    */
    readonly directoryUrl: string;
    /**
    * An url base64 encoded external binding token to create the initial account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_external_ca_secret_backend_acme_account#eab_key PkiExternalCaSecretBackendAcmeAccount#eab_key}
    */
    readonly eabKey?: string;
    /**
    * The external binding key ID to create the initial account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_external_ca_secret_backend_acme_account#eab_kid PkiExternalCaSecretBackendAcmeAccount#eab_kid}
    */
    readonly eabKid?: string;
    /**
    * Email addresses for the ACME account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_external_ca_secret_backend_acme_account#email_contacts PkiExternalCaSecretBackendAcmeAccount#email_contacts}
    */
    readonly emailContacts: string[];
    /**
    * Key type to generate for the account key. Valid values are `ec-256`, `ec-384`, `ec-521`, `rsa-2048`, `rsa-4096`, `rsa-8192`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_external_ca_secret_backend_acme_account#key_type PkiExternalCaSecretBackendAcmeAccount#key_type}
    */
    readonly keyType?: string;
    /**
    * The path where the PKI secret backend is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_external_ca_secret_backend_acme_account#mount PkiExternalCaSecretBackendAcmeAccount#mount}
    */
    readonly mount: string;
    /**
    * Name of the ACME account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_external_ca_secret_backend_acme_account#name PkiExternalCaSecretBackendAcmeAccount#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_external_ca_secret_backend_acme_account#namespace PkiExternalCaSecretBackendAcmeAccount#namespace}
    */
    readonly namespace?: string;
    /**
    * Trusted CA certificates for the ACME server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_external_ca_secret_backend_acme_account#trusted_ca PkiExternalCaSecretBackendAcmeAccount#trusted_ca}
    */
    readonly trustedCa?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_external_ca_secret_backend_acme_account vault_pki_external_ca_secret_backend_acme_account}
*/
export declare class PkiExternalCaSecretBackendAcmeAccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_pki_external_ca_secret_backend_acme_account";
    /**
    * Generates CDKTN code for importing a PkiExternalCaSecretBackendAcmeAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PkiExternalCaSecretBackendAcmeAccount to import
    * @param importFromId The id of the existing PkiExternalCaSecretBackendAcmeAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_external_ca_secret_backend_acme_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PkiExternalCaSecretBackendAcmeAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_external_ca_secret_backend_acme_account vault_pki_external_ca_secret_backend_acme_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PkiExternalCaSecretBackendAcmeAccountConfig
    */
    constructor(scope: Construct, id: string, config: PkiExternalCaSecretBackendAcmeAccountConfig);
    get activeKeyVersion(): number;
    private _directoryUrl?;
    get directoryUrl(): string;
    set directoryUrl(value: string);
    get directoryUrlInput(): string | undefined;
    private _eabKey?;
    get eabKey(): string;
    set eabKey(value: string);
    resetEabKey(): void;
    get eabKeyInput(): string | undefined;
    private _eabKid?;
    get eabKid(): string;
    set eabKid(value: string);
    resetEabKid(): void;
    get eabKidInput(): string | undefined;
    private _emailContacts?;
    get emailContacts(): string[];
    set emailContacts(value: string[]);
    get emailContactsInput(): string[] | undefined;
    private _keyType?;
    get keyType(): string;
    set keyType(value: string);
    resetKeyType(): void;
    get keyTypeInput(): string | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _trustedCa?;
    get trustedCa(): string;
    set trustedCa(value: string);
    resetTrustedCa(): void;
    get trustedCaInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CfAuthBackendConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * CF's full API address, used for verifying that a given `CF_INSTANCE_CERT` shows an application ID, space ID, and organization ID that presently exist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/cf_auth_backend_config#cf_api_addr CfAuthBackendConfig#cf_api_addr}
    */
    readonly cfApiAddr: string;
    /**
    * The certificate(s) presented by the CF API. Configures Vault to trust these certificates when making API calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/cf_auth_backend_config#cf_api_trusted_certificates CfAuthBackendConfig#cf_api_trusted_certificates}
    */
    readonly cfApiTrustedCertificates?: string[];
    /**
    * The password for authenticating to the CF API. This attribute is write-only and is never stored in Terraform state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/cf_auth_backend_config#cf_password_wo CfAuthBackendConfig#cf_password_wo}
    */
    readonly cfPasswordWo: string;
    /**
    * Version counter for 'cf_password_wo'. Increment this value to trigger an update when only the write-only password changes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/cf_auth_backend_config#cf_password_wo_version CfAuthBackendConfig#cf_password_wo_version}
    */
    readonly cfPasswordWoVersion: number;
    /**
    * The timeout for the CF API in seconds. Defaults to `0` (no timeout). Removing this field from config resets the value to `0` in Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/cf_auth_backend_config#cf_timeout CfAuthBackendConfig#cf_timeout}
    */
    readonly cfTimeout?: number;
    /**
    * The username for authenticating to the CF API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/cf_auth_backend_config#cf_username CfAuthBackendConfig#cf_username}
    */
    readonly cfUsername: string;
    /**
    * The root CA certificate(s) to be used for verifying that the `CF_INSTANCE_CERT` presented for logging in was issued by the proper authority.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/cf_auth_backend_config#identity_ca_certificates CfAuthBackendConfig#identity_ca_certificates}
    */
    readonly identityCaCertificates: string[];
    /**
    * The maximum number of seconds in the future when a signature could have been created. Defaults to `60`. This field is `Computed`: if removed from config, Vault retains the previously set value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/cf_auth_backend_config#login_max_seconds_not_after CfAuthBackendConfig#login_max_seconds_not_after}
    */
    readonly loginMaxSecondsNotAfter?: number;
    /**
    * The maximum number of seconds in the past when a signature could have been created. Defaults to `300`. This field is `Computed`: if removed from config, Vault retains the previously set value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/cf_auth_backend_config#login_max_seconds_not_before CfAuthBackendConfig#login_max_seconds_not_before}
    */
    readonly loginMaxSecondsNotBefore?: number;
    /**
    * Mount path for the CF auth engine in Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/cf_auth_backend_config#mount CfAuthBackendConfig#mount}
    */
    readonly mount: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/cf_auth_backend_config#namespace CfAuthBackendConfig#namespace}
    */
    readonly namespace?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/cf_auth_backend_config vault_cf_auth_backend_config}
*/
export declare class CfAuthBackendConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_cf_auth_backend_config";
    /**
    * Generates CDKTN code for importing a CfAuthBackendConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CfAuthBackendConfig to import
    * @param importFromId The id of the existing CfAuthBackendConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/cf_auth_backend_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CfAuthBackendConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/cf_auth_backend_config vault_cf_auth_backend_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CfAuthBackendConfigConfig
    */
    constructor(scope: Construct, id: string, config: CfAuthBackendConfigConfig);
    private _cfApiAddr?;
    get cfApiAddr(): string;
    set cfApiAddr(value: string);
    get cfApiAddrInput(): string | undefined;
    private _cfApiTrustedCertificates?;
    get cfApiTrustedCertificates(): string[];
    set cfApiTrustedCertificates(value: string[]);
    resetCfApiTrustedCertificates(): void;
    get cfApiTrustedCertificatesInput(): string[] | undefined;
    private _cfPasswordWo?;
    get cfPasswordWo(): string;
    set cfPasswordWo(value: string);
    get cfPasswordWoInput(): string | undefined;
    private _cfPasswordWoVersion?;
    get cfPasswordWoVersion(): number;
    set cfPasswordWoVersion(value: number);
    get cfPasswordWoVersionInput(): number | undefined;
    private _cfTimeout?;
    get cfTimeout(): number;
    set cfTimeout(value: number);
    resetCfTimeout(): void;
    get cfTimeoutInput(): number | undefined;
    private _cfUsername?;
    get cfUsername(): string;
    set cfUsername(value: string);
    get cfUsernameInput(): string | undefined;
    private _identityCaCertificates?;
    get identityCaCertificates(): string[];
    set identityCaCertificates(value: string[]);
    get identityCaCertificatesInput(): string[] | undefined;
    private _loginMaxSecondsNotAfter?;
    get loginMaxSecondsNotAfter(): number;
    set loginMaxSecondsNotAfter(value: number);
    resetLoginMaxSecondsNotAfter(): void;
    get loginMaxSecondsNotAfterInput(): number | undefined;
    private _loginMaxSecondsNotBefore?;
    get loginMaxSecondsNotBefore(): number;
    set loginMaxSecondsNotBefore(value: number);
    resetLoginMaxSecondsNotBefore(): void;
    get loginMaxSecondsNotBeforeInput(): number | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

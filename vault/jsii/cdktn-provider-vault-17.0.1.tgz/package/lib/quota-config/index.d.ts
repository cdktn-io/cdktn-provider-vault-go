/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface QuotaConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Absolute paths exempt from all rate limit quotas, qualified from the root of the namespace hierarchy. This field is effectively root-managed; administrative namespaces can read returned values but cannot reliably manage them. Order is not significant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_config#absolute_rate_limit_exempt_paths QuotaConfig#absolute_rate_limit_exempt_paths}
    */
    readonly absoluteRateLimitExemptPaths?: string[];
    /**
    * Enables audit logging for requests rejected by rate limit quotas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_config#enable_rate_limit_audit_logging QuotaConfig#enable_rate_limit_audit_logging}
    */
    readonly enableRateLimitAuditLogging?: boolean | cdktn.IResolvable;
    /**
    * Enables rate limit response headers on HTTP responses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_config#enable_rate_limit_response_headers QuotaConfig#enable_rate_limit_response_headers}
    */
    readonly enableRateLimitResponseHeaders?: boolean | cdktn.IResolvable;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_config#namespace QuotaConfig#namespace}
    */
    readonly namespace?: string;
    /**
    * Paths exempt from rate limit quotas relative to the current namespace context. This endpoint is only callable from the root or an administrative namespace, and exemption updates are effectively root-managed. Order is not significant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_config#rate_limit_exempt_paths QuotaConfig#rate_limit_exempt_paths}
    */
    readonly rateLimitExemptPaths?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_config vault_quota_config}
*/
export declare class QuotaConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_quota_config";
    /**
    * Generates CDKTN code for importing a QuotaConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the QuotaConfig to import
    * @param importFromId The id of the existing QuotaConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the QuotaConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/quota_config vault_quota_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options QuotaConfigConfig = {}
    */
    constructor(scope: Construct, id: string, config?: QuotaConfigConfig);
    private _absoluteRateLimitExemptPaths?;
    get absoluteRateLimitExemptPaths(): string[];
    set absoluteRateLimitExemptPaths(value: string[]);
    resetAbsoluteRateLimitExemptPaths(): void;
    get absoluteRateLimitExemptPathsInput(): string[] | undefined;
    private _enableRateLimitAuditLogging?;
    get enableRateLimitAuditLogging(): boolean | cdktn.IResolvable;
    set enableRateLimitAuditLogging(value: boolean | cdktn.IResolvable);
    resetEnableRateLimitAuditLogging(): void;
    get enableRateLimitAuditLoggingInput(): boolean | cdktn.IResolvable | undefined;
    private _enableRateLimitResponseHeaders?;
    get enableRateLimitResponseHeaders(): boolean | cdktn.IResolvable;
    set enableRateLimitResponseHeaders(value: boolean | cdktn.IResolvable);
    resetEnableRateLimitResponseHeaders(): void;
    get enableRateLimitResponseHeadersInput(): boolean | cdktn.IResolvable | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _rateLimitExemptPaths?;
    get rateLimitExemptPaths(): string[];
    set rateLimitExemptPaths(value: string[]);
    resetRateLimitExemptPaths(): void;
    get rateLimitExemptPathsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

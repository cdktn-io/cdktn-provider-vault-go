/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PkiSecretBackendCrlConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Enables or disables periodic rebuilding of the CRL upon expiry.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_crl_config#auto_rebuild PkiSecretBackendCrlConfig#auto_rebuild}
    */
    readonly autoRebuild?: boolean | cdktn.IResolvable;
    /**
    * Grace period before CRL expiry to attempt rebuild of CRL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_crl_config#auto_rebuild_grace_period PkiSecretBackendCrlConfig#auto_rebuild_grace_period}
    */
    readonly autoRebuildGracePeriod?: string;
    /**
    * The path of the PKI secret backend the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_crl_config#backend PkiSecretBackendCrlConfig#backend}
    */
    readonly backend: string;
    /**
    * Enable cross-cluster revocation request queues.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_crl_config#cross_cluster_revocation PkiSecretBackendCrlConfig#cross_cluster_revocation}
    */
    readonly crossClusterRevocation?: boolean | cdktn.IResolvable;
    /**
    * Interval to check for new revocations on, to regenerate the delta CRL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_crl_config#delta_rebuild_interval PkiSecretBackendCrlConfig#delta_rebuild_interval}
    */
    readonly deltaRebuildInterval?: string;
    /**
    * Disables or enables CRL building
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_crl_config#disable PkiSecretBackendCrlConfig#disable}
    */
    readonly disable?: boolean | cdktn.IResolvable;
    /**
    * Enables or disables building of delta CRLs with up-to-date revocation information, augmenting the last complete CRL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_crl_config#enable_delta PkiSecretBackendCrlConfig#enable_delta}
    */
    readonly enableDelta?: boolean | cdktn.IResolvable;
    /**
    * Specifies the time until expiration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_crl_config#expiry PkiSecretBackendCrlConfig#expiry}
    */
    readonly expiry?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_crl_config#id PkiSecretBackendCrlConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The maximum number of entries a CRL can contain. This option exists to prevent accidental runaway issuance/revocation from overloading Vault. If set to -1, the limit is disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_crl_config#max_crl_entries PkiSecretBackendCrlConfig#max_crl_entries}
    */
    readonly maxCrlEntries?: number;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_crl_config#namespace PkiSecretBackendCrlConfig#namespace}
    */
    readonly namespace?: string;
    /**
    * Disables or enables the OCSP responder in Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_crl_config#ocsp_disable PkiSecretBackendCrlConfig#ocsp_disable}
    */
    readonly ocspDisable?: boolean | cdktn.IResolvable;
    /**
    * The amount of time an OCSP response can be cached for, useful for OCSP stapling refresh durations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_crl_config#ocsp_expiry PkiSecretBackendCrlConfig#ocsp_expiry}
    */
    readonly ocspExpiry?: string;
    /**
    * Enables unified CRL and OCSP building.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_crl_config#unified_crl PkiSecretBackendCrlConfig#unified_crl}
    */
    readonly unifiedCrl?: boolean | cdktn.IResolvable;
    /**
    * Enables serving the unified CRL and OCSP on the existing, previously cluster-local paths.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_crl_config#unified_crl_on_existing_paths PkiSecretBackendCrlConfig#unified_crl_on_existing_paths}
    */
    readonly unifiedCrlOnExistingPaths?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_crl_config vault_pki_secret_backend_crl_config}
*/
export declare class PkiSecretBackendCrlConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_pki_secret_backend_crl_config";
    /**
    * Generates CDKTN code for importing a PkiSecretBackendCrlConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PkiSecretBackendCrlConfig to import
    * @param importFromId The id of the existing PkiSecretBackendCrlConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_crl_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PkiSecretBackendCrlConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/pki_secret_backend_crl_config vault_pki_secret_backend_crl_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PkiSecretBackendCrlConfigConfig
    */
    constructor(scope: Construct, id: string, config: PkiSecretBackendCrlConfigConfig);
    private _autoRebuild?;
    get autoRebuild(): boolean | cdktn.IResolvable;
    set autoRebuild(value: boolean | cdktn.IResolvable);
    resetAutoRebuild(): void;
    get autoRebuildInput(): boolean | cdktn.IResolvable | undefined;
    private _autoRebuildGracePeriod?;
    get autoRebuildGracePeriod(): string;
    set autoRebuildGracePeriod(value: string);
    resetAutoRebuildGracePeriod(): void;
    get autoRebuildGracePeriodInput(): string | undefined;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    private _crossClusterRevocation?;
    get crossClusterRevocation(): boolean | cdktn.IResolvable;
    set crossClusterRevocation(value: boolean | cdktn.IResolvable);
    resetCrossClusterRevocation(): void;
    get crossClusterRevocationInput(): boolean | cdktn.IResolvable | undefined;
    private _deltaRebuildInterval?;
    get deltaRebuildInterval(): string;
    set deltaRebuildInterval(value: string);
    resetDeltaRebuildInterval(): void;
    get deltaRebuildIntervalInput(): string | undefined;
    private _disable?;
    get disable(): boolean | cdktn.IResolvable;
    set disable(value: boolean | cdktn.IResolvable);
    resetDisable(): void;
    get disableInput(): boolean | cdktn.IResolvable | undefined;
    private _enableDelta?;
    get enableDelta(): boolean | cdktn.IResolvable;
    set enableDelta(value: boolean | cdktn.IResolvable);
    resetEnableDelta(): void;
    get enableDeltaInput(): boolean | cdktn.IResolvable | undefined;
    private _expiry?;
    get expiry(): string;
    set expiry(value: string);
    resetExpiry(): void;
    get expiryInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxCrlEntries?;
    get maxCrlEntries(): number;
    set maxCrlEntries(value: number);
    resetMaxCrlEntries(): void;
    get maxCrlEntriesInput(): number | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _ocspDisable?;
    get ocspDisable(): boolean | cdktn.IResolvable;
    set ocspDisable(value: boolean | cdktn.IResolvable);
    resetOcspDisable(): void;
    get ocspDisableInput(): boolean | cdktn.IResolvable | undefined;
    private _ocspExpiry?;
    get ocspExpiry(): string;
    set ocspExpiry(value: string);
    resetOcspExpiry(): void;
    get ocspExpiryInput(): string | undefined;
    private _unifiedCrl?;
    get unifiedCrl(): boolean | cdktn.IResolvable;
    set unifiedCrl(value: boolean | cdktn.IResolvable);
    resetUnifiedCrl(): void;
    get unifiedCrlInput(): boolean | cdktn.IResolvable | undefined;
    private _unifiedCrlOnExistingPaths?;
    get unifiedCrlOnExistingPaths(): boolean | cdktn.IResolvable;
    set unifiedCrlOnExistingPaths(value: boolean | cdktn.IResolvable);
    resetUnifiedCrlOnExistingPaths(): void;
    get unifiedCrlOnExistingPathsInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

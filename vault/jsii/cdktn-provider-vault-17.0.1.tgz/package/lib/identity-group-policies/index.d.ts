/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IdentityGroupPoliciesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Should the resource manage policies exclusively? Beware of race conditions when disabling exclusive management
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_group_policies#exclusive IdentityGroupPolicies#exclusive}
    */
    readonly exclusive?: boolean | cdktn.IResolvable;
    /**
    * ID of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_group_policies#group_id IdentityGroupPolicies#group_id}
    */
    readonly groupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_group_policies#id IdentityGroupPolicies#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_group_policies#namespace IdentityGroupPolicies#namespace}
    */
    readonly namespace?: string;
    /**
    * Policies to be tied to the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_group_policies#policies IdentityGroupPolicies#policies}
    */
    readonly policies: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_group_policies vault_identity_group_policies}
*/
export declare class IdentityGroupPolicies extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_identity_group_policies";
    /**
    * Generates CDKTN code for importing a IdentityGroupPolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IdentityGroupPolicies to import
    * @param importFromId The id of the existing IdentityGroupPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_group_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IdentityGroupPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/identity_group_policies vault_identity_group_policies} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IdentityGroupPoliciesConfig
    */
    constructor(scope: Construct, id: string, config: IdentityGroupPoliciesConfig);
    private _exclusive?;
    get exclusive(): boolean | cdktn.IResolvable;
    set exclusive(value: boolean | cdktn.IResolvable);
    resetExclusive(): void;
    get exclusiveInput(): boolean | cdktn.IResolvable | undefined;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    get groupIdInput(): string | undefined;
    get groupName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _policies?;
    get policies(): string[];
    set policies(value: string[]);
    get policiesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

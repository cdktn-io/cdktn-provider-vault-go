/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MountConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of managed key registry entry names that the mount in question is allowed to access
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#allowed_managed_keys Mount#allowed_managed_keys}
    */
    readonly allowedManagedKeys?: string[];
    /**
    * List of headers to allow and pass from the request to the plugin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#allowed_response_headers Mount#allowed_response_headers}
    */
    readonly allowedResponseHeaders?: string[];
    /**
    * Specifies the list of keys that will not be HMAC'd by audit devices in the request data object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#audit_non_hmac_request_keys Mount#audit_non_hmac_request_keys}
    */
    readonly auditNonHmacRequestKeys?: string[];
    /**
    * Specifies the list of keys that will not be HMAC'd by audit devices in the response data object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#audit_non_hmac_response_keys Mount#audit_non_hmac_response_keys}
    */
    readonly auditNonHmacResponseKeys?: string[];
    /**
    * Default lease duration for tokens and secrets in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#default_lease_ttl_seconds Mount#default_lease_ttl_seconds}
    */
    readonly defaultLeaseTtlSeconds?: number;
    /**
    * List of headers to allow and pass from the request to the plugin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#delegated_auth_accessors Mount#delegated_auth_accessors}
    */
    readonly delegatedAuthAccessors?: string[];
    /**
    * Human-friendly description of the mount
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#description Mount#description}
    */
    readonly description?: string;
    /**
    * Enable the secrets engine to access Vault's external entropy source
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#external_entropy_access Mount#external_entropy_access}
    */
    readonly externalEntropyAccess?: boolean | cdktn.IResolvable;
    /**
    * If set to true, disables caching.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#force_no_cache Mount#force_no_cache}
    */
    readonly forceNoCache?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#id Mount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The key to use for signing plugin workload identity tokens
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#identity_token_key Mount#identity_token_key}
    */
    readonly identityTokenKey?: string;
    /**
    * Specifies whether to show this mount in the UI-specific listing endpoint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#listing_visibility Mount#listing_visibility}
    */
    readonly listingVisibility?: string;
    /**
    * Local mount flag that can be explicitly set to true to enforce local mount in HA environment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#local Mount#local}
    */
    readonly local?: boolean | cdktn.IResolvable;
    /**
    * Maximum possible lease duration for tokens and secrets in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#max_lease_ttl_seconds Mount#max_lease_ttl_seconds}
    */
    readonly maxLeaseTtlSeconds?: number;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#namespace Mount#namespace}
    */
    readonly namespace?: string;
    /**
    * Specifies mount type specific options that are passed to the backend
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#options Mount#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * List of headers to allow and pass from the request to the plugin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#passthrough_request_headers Mount#passthrough_request_headers}
    */
    readonly passthroughRequestHeaders?: string[];
    /**
    * Where the secret backend will be mounted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#path Mount#path}
    */
    readonly path: string;
    /**
    * Specifies the semantic version of the plugin to use, e.g. 'v1.0.0'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#plugin_version Mount#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * Enable seal wrapping for the mount, causing values stored by the mount to be wrapped by the seal's encryption capability
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#seal_wrap Mount#seal_wrap}
    */
    readonly sealWrap?: boolean | cdktn.IResolvable;
    /**
    * Type of the backend, such as 'aws'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#type Mount#type}
    */
    readonly type: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount vault_mount}
*/
export declare class Mount extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_mount";
    /**
    * Generates CDKTN code for importing a Mount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Mount to import
    * @param importFromId The id of the existing Mount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Mount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/mount vault_mount} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MountConfig
    */
    constructor(scope: Construct, id: string, config: MountConfig);
    get accessor(): string;
    private _allowedManagedKeys?;
    get allowedManagedKeys(): string[];
    set allowedManagedKeys(value: string[]);
    resetAllowedManagedKeys(): void;
    get allowedManagedKeysInput(): string[] | undefined;
    private _allowedResponseHeaders?;
    get allowedResponseHeaders(): string[];
    set allowedResponseHeaders(value: string[]);
    resetAllowedResponseHeaders(): void;
    get allowedResponseHeadersInput(): string[] | undefined;
    private _auditNonHmacRequestKeys?;
    get auditNonHmacRequestKeys(): string[];
    set auditNonHmacRequestKeys(value: string[]);
    resetAuditNonHmacRequestKeys(): void;
    get auditNonHmacRequestKeysInput(): string[] | undefined;
    private _auditNonHmacResponseKeys?;
    get auditNonHmacResponseKeys(): string[];
    set auditNonHmacResponseKeys(value: string[]);
    resetAuditNonHmacResponseKeys(): void;
    get auditNonHmacResponseKeysInput(): string[] | undefined;
    private _defaultLeaseTtlSeconds?;
    get defaultLeaseTtlSeconds(): number;
    set defaultLeaseTtlSeconds(value: number);
    resetDefaultLeaseTtlSeconds(): void;
    get defaultLeaseTtlSecondsInput(): number | undefined;
    private _delegatedAuthAccessors?;
    get delegatedAuthAccessors(): string[];
    set delegatedAuthAccessors(value: string[]);
    resetDelegatedAuthAccessors(): void;
    get delegatedAuthAccessorsInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _externalEntropyAccess?;
    get externalEntropyAccess(): boolean | cdktn.IResolvable;
    set externalEntropyAccess(value: boolean | cdktn.IResolvable);
    resetExternalEntropyAccess(): void;
    get externalEntropyAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _forceNoCache?;
    get forceNoCache(): boolean | cdktn.IResolvable;
    set forceNoCache(value: boolean | cdktn.IResolvable);
    resetForceNoCache(): void;
    get forceNoCacheInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityTokenKey?;
    get identityTokenKey(): string;
    set identityTokenKey(value: string);
    resetIdentityTokenKey(): void;
    get identityTokenKeyInput(): string | undefined;
    private _listingVisibility?;
    get listingVisibility(): string;
    set listingVisibility(value: string);
    resetListingVisibility(): void;
    get listingVisibilityInput(): string | undefined;
    private _local?;
    get local(): boolean | cdktn.IResolvable;
    set local(value: boolean | cdktn.IResolvable);
    resetLocal(): void;
    get localInput(): boolean | cdktn.IResolvable | undefined;
    private _maxLeaseTtlSeconds?;
    get maxLeaseTtlSeconds(): number;
    set maxLeaseTtlSeconds(value: number);
    resetMaxLeaseTtlSeconds(): void;
    get maxLeaseTtlSecondsInput(): number | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _passthroughRequestHeaders?;
    get passthroughRequestHeaders(): string[];
    set passthroughRequestHeaders(value: string[]);
    resetPassthroughRequestHeaders(): void;
    get passthroughRequestHeadersInput(): string[] | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _sealWrap?;
    get sealWrap(): boolean | cdktn.IResolvable;
    set sealWrap(value: boolean | cdktn.IResolvable);
    resetSealWrap(): void;
    get sealWrapInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

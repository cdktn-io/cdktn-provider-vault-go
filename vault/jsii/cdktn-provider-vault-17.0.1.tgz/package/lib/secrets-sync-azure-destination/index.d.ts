/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SecretsSyncAzureDestinationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Set of allowed IPv4 addresses in CIDR notation (e.g., 192.168.1.1/32) for outbound connections from Vault to the destination. If not set, all IPv4 addresses are allowed. Requires Vault 1.19+.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#allowed_ipv4_addresses SecretsSyncAzureDestination#allowed_ipv4_addresses}
    */
    readonly allowedIpv4Addresses?: string[];
    /**
    * Set of allowed IPv6 addresses in CIDR notation (e.g., 2001:db8::1/128) for outbound connections from Vault to the destination. If not set, all IPv6 addresses are allowed. Requires Vault 1.19+.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#allowed_ipv6_addresses SecretsSyncAzureDestination#allowed_ipv6_addresses}
    */
    readonly allowedIpv6Addresses?: string[];
    /**
    * Set of allowed ports for outbound connections from Vault to the destination. If not set, all ports are allowed. Requires Vault 1.19+.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#allowed_ports SecretsSyncAzureDestination#allowed_ports}
    */
    readonly allowedPorts?: number[];
    /**
    * Client ID of an Azure app registration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#client_id SecretsSyncAzureDestination#client_id}
    */
    readonly clientId?: string;
    /**
    * Client Secret of an Azure app registration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#client_secret SecretsSyncAzureDestination#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * Specifies a cloud for the client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#cloud SecretsSyncAzureDestination#cloud}
    */
    readonly cloud?: string;
    /**
    * Custom tags to set on the secret managed at the destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#custom_tags SecretsSyncAzureDestination#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
    /**
    * If set to true, disables strict networking enforcement for this destination. When disabled, Vault will not enforce allowed IP addresses and ports. Requires Vault 1.19+.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#disable_strict_networking SecretsSyncAzureDestination#disable_strict_networking}
    */
    readonly disableStrictNetworking?: boolean | cdktn.IResolvable;
    /**
    * Determines what level of information is synced as a distinct resource at the destination. Can be 'secret-path' or 'secret-key'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#granularity SecretsSyncAzureDestination#granularity}
    */
    readonly granularity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#id SecretsSyncAzureDestination#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The audience claim value for identity tokens. This is a write-only field and will not be read back from Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#identity_token_audience_wo SecretsSyncAzureDestination#identity_token_audience_wo}
    */
    readonly identityTokenAudienceWo?: string;
    /**
    * A version counter for the write-only identity_token_audience_wo field. Incrementing this value will trigger an update.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#identity_token_audience_wo_version SecretsSyncAzureDestination#identity_token_audience_wo_version}
    */
    readonly identityTokenAudienceWoVersion?: number;
    /**
    * The key to use for signing identity tokens. This is a write-only field and will not be read back from Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#identity_token_key_wo SecretsSyncAzureDestination#identity_token_key_wo}
    */
    readonly identityTokenKeyWo?: string;
    /**
    * A version counter for the write-only identity_token_key_wo field. Incrementing this value will trigger an update.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#identity_token_key_wo_version SecretsSyncAzureDestination#identity_token_key_wo_version}
    */
    readonly identityTokenKeyWoVersion?: number;
    /**
    * The TTL of generated tokens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#identity_token_ttl SecretsSyncAzureDestination#identity_token_ttl}
    */
    readonly identityTokenTtl?: number;
    /**
    * URI of an existing Azure Key Vault instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#key_vault_uri SecretsSyncAzureDestination#key_vault_uri}
    */
    readonly keyVaultUri?: string;
    /**
    * Unique name of the Azure destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#name SecretsSyncAzureDestination#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#namespace SecretsSyncAzureDestination#namespace}
    */
    readonly namespace?: string;
    /**
    * Template describing how to generate external secret names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#secret_name_template SecretsSyncAzureDestination#secret_name_template}
    */
    readonly secretNameTemplate?: string;
    /**
    * ID of the target Azure tenant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#tenant_id SecretsSyncAzureDestination#tenant_id}
    */
    readonly tenantId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination vault_secrets_sync_azure_destination}
*/
export declare class SecretsSyncAzureDestination extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_secrets_sync_azure_destination";
    /**
    * Generates CDKTN code for importing a SecretsSyncAzureDestination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecretsSyncAzureDestination to import
    * @param importFromId The id of the existing SecretsSyncAzureDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecretsSyncAzureDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.9.0/docs/resources/secrets_sync_azure_destination vault_secrets_sync_azure_destination} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecretsSyncAzureDestinationConfig
    */
    constructor(scope: Construct, id: string, config: SecretsSyncAzureDestinationConfig);
    private _allowedIpv4Addresses?;
    get allowedIpv4Addresses(): string[];
    set allowedIpv4Addresses(value: string[]);
    resetAllowedIpv4Addresses(): void;
    get allowedIpv4AddressesInput(): string[] | undefined;
    private _allowedIpv6Addresses?;
    get allowedIpv6Addresses(): string[];
    set allowedIpv6Addresses(value: string[]);
    resetAllowedIpv6Addresses(): void;
    get allowedIpv6AddressesInput(): string[] | undefined;
    private _allowedPorts?;
    get allowedPorts(): number[];
    set allowedPorts(value: number[]);
    resetAllowedPorts(): void;
    get allowedPortsInput(): number[] | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _cloud?;
    get cloud(): string;
    set cloud(value: string);
    resetCloud(): void;
    get cloudInput(): string | undefined;
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _disableStrictNetworking?;
    get disableStrictNetworking(): boolean | cdktn.IResolvable;
    set disableStrictNetworking(value: boolean | cdktn.IResolvable);
    resetDisableStrictNetworking(): void;
    get disableStrictNetworkingInput(): boolean | cdktn.IResolvable | undefined;
    private _granularity?;
    get granularity(): string;
    set granularity(value: string);
    resetGranularity(): void;
    get granularityInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityTokenAudienceWo?;
    get identityTokenAudienceWo(): string;
    set identityTokenAudienceWo(value: string);
    resetIdentityTokenAudienceWo(): void;
    get identityTokenAudienceWoInput(): string | undefined;
    private _identityTokenAudienceWoVersion?;
    get identityTokenAudienceWoVersion(): number;
    set identityTokenAudienceWoVersion(value: number);
    resetIdentityTokenAudienceWoVersion(): void;
    get identityTokenAudienceWoVersionInput(): number | undefined;
    private _identityTokenKeyWo?;
    get identityTokenKeyWo(): string;
    set identityTokenKeyWo(value: string);
    resetIdentityTokenKeyWo(): void;
    get identityTokenKeyWoInput(): string | undefined;
    private _identityTokenKeyWoVersion?;
    get identityTokenKeyWoVersion(): number;
    set identityTokenKeyWoVersion(value: number);
    resetIdentityTokenKeyWoVersion(): void;
    get identityTokenKeyWoVersionInput(): number | undefined;
    private _identityTokenTtl?;
    get identityTokenTtl(): number;
    set identityTokenTtl(value: number);
    resetIdentityTokenTtl(): void;
    get identityTokenTtlInput(): number | undefined;
    private _keyVaultUri?;
    get keyVaultUri(): string;
    set keyVaultUri(value: string);
    resetKeyVaultUri(): void;
    get keyVaultUriInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _secretNameTemplate?;
    get secretNameTemplate(): string;
    set secretNameTemplate(value: string);
    resetSecretNameTemplate(): void;
    get secretNameTemplateInput(): string | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    resetTenantId(): void;
    get tenantIdInput(): string | undefined;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

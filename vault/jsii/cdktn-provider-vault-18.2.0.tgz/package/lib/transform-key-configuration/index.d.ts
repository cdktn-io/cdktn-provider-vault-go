/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TransformKeyConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Amount of time the key should live before being automatically rotated. A value of 0 disables automatic rotation for the key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/transform_key_configuration#auto_rotate_period TransformKeyConfiguration#auto_rotate_period}
    */
    readonly autoRotatePeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/transform_key_configuration#id TransformKeyConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Minimum key version that vault uses to decode values for the transform
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/transform_key_configuration#min_decryption_version TransformKeyConfiguration#min_decryption_version}
    */
    readonly minDecryptionVersion?: number;
    /**
    * The name of the transform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/transform_key_configuration#name TransformKeyConfiguration#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/transform_key_configuration#namespace TransformKeyConfiguration#namespace}
    */
    readonly namespace?: string;
    /**
    * The mount path for the transform backend, for example the path given in "$ vault secrets enable -path=transform transform".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/transform_key_configuration#path TransformKeyConfiguration#path}
    */
    readonly path: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/transform_key_configuration vault_transform_key_configuration}
*/
export declare class TransformKeyConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_transform_key_configuration";
    /**
    * Generates CDKTN code for importing a TransformKeyConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TransformKeyConfiguration to import
    * @param importFromId The id of the existing TransformKeyConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/transform_key_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TransformKeyConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/transform_key_configuration vault_transform_key_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TransformKeyConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: TransformKeyConfigurationConfig);
    private _autoRotatePeriod?;
    get autoRotatePeriod(): number;
    set autoRotatePeriod(value: number);
    resetAutoRotatePeriod(): void;
    get autoRotatePeriodInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get latestVersion(): number;
    get minAvailableVersion(): number;
    private _minDecryptionVersion?;
    get minDecryptionVersion(): number;
    set minDecryptionVersion(value: number);
    resetMinDecryptionVersion(): void;
    get minDecryptionVersionInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GcpkmsSecretBackendKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Algorithm to use for the key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/gcpkms_secret_backend_key#algorithm GcpkmsSecretBackendKey#algorithm}
    */
    readonly algorithm?: string;
    /**
    * Name of the crypto key to use in GCP KMS. If the crypto key does not exist,Vault will try to create it. This defaults to the Vault key name if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/gcpkms_secret_backend_key#crypto_key GcpkmsSecretBackendKey#crypto_key}
    */
    readonly cryptoKey?: string;
    /**
    * Name of the key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/gcpkms_secret_backend_key#key_name GcpkmsSecretBackendKey#key_name}
    */
    readonly keyName: string;
    /**
    * GCP KMS key ring resource ID (e.g., 'projects/my-project/locations/us-central1/keyRings/my-ring'). Required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/gcpkms_secret_backend_key#key_ring GcpkmsSecretBackendKey#key_ring}
    */
    readonly keyRing: string;
    /**
    * Labels to apply to the key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/gcpkms_secret_backend_key#labels GcpkmsSecretBackendKey#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Path where the GCP KMS secrets engine is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/gcpkms_secret_backend_key#mount GcpkmsSecretBackendKey#mount}
    */
    readonly mount: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/gcpkms_secret_backend_key#namespace GcpkmsSecretBackendKey#namespace}
    */
    readonly namespace?: string;
    /**
    * Protection level of the key. Valid values: SOFTWARE, HSM. Defaults to SOFTWARE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/gcpkms_secret_backend_key#protection_level GcpkmsSecretBackendKey#protection_level}
    */
    readonly protectionLevel?: string;
    /**
    * Purpose of the key. Valid values: encrypt_decrypt, asymmetric_sign, asymmetric_decrypt.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/gcpkms_secret_backend_key#purpose GcpkmsSecretBackendKey#purpose}
    */
    readonly purpose?: string;
    /**
    * Rotation period for the key as a duration string (e.g., '72h', '2592000s' for 30 days). Can be updated after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/gcpkms_secret_backend_key#rotation_period GcpkmsSecretBackendKey#rotation_period}
    */
    readonly rotationPeriod?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/gcpkms_secret_backend_key vault_gcpkms_secret_backend_key}
*/
export declare class GcpkmsSecretBackendKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_gcpkms_secret_backend_key";
    /**
    * Generates CDKTN code for importing a GcpkmsSecretBackendKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GcpkmsSecretBackendKey to import
    * @param importFromId The id of the existing GcpkmsSecretBackendKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/gcpkms_secret_backend_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GcpkmsSecretBackendKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.12.0/docs/resources/gcpkms_secret_backend_key vault_gcpkms_secret_backend_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GcpkmsSecretBackendKeyConfig
    */
    constructor(scope: Construct, id: string, config: GcpkmsSecretBackendKeyConfig);
    private _algorithm?;
    get algorithm(): string;
    set algorithm(value: string);
    resetAlgorithm(): void;
    get algorithmInput(): string | undefined;
    private _cryptoKey?;
    get cryptoKey(): string;
    set cryptoKey(value: string);
    resetCryptoKey(): void;
    get cryptoKeyInput(): string | undefined;
    private _keyName?;
    get keyName(): string;
    set keyName(value: string);
    get keyNameInput(): string | undefined;
    private _keyRing?;
    get keyRing(): string;
    set keyRing(value: string);
    get keyRingInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get nextRotationTimeSeconds(): number;
    get primaryVersion(): number;
    private _protectionLevel?;
    get protectionLevel(): string;
    set protectionLevel(value: string);
    resetProtectionLevel(): void;
    get protectionLevelInput(): string | undefined;
    private _purpose?;
    get purpose(): string;
    set purpose(value: string);
    resetPurpose(): void;
    get purposeInput(): string | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): string;
    set rotationPeriod(value: string);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): string | undefined;
    get rotationScheduleSeconds(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SecretsSyncConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Disables the syncing process between Vault and external destinations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_config#disabled SecretsSyncConfig#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_config#id SecretsSyncConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_config#namespace SecretsSyncConfig#namespace}
    */
    readonly namespace?: string;
    /**
    * Maximum number of pending sync operations allowed on the queue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_config#queue_capacity SecretsSyncConfig#queue_capacity}
    */
    readonly queueCapacity?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_config vault_secrets_sync_config}
*/
export declare class SecretsSyncConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_secrets_sync_config";
    /**
    * Generates CDKTN code for importing a SecretsSyncConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecretsSyncConfig to import
    * @param importFromId The id of the existing SecretsSyncConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecretsSyncConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_config vault_secrets_sync_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecretsSyncConfigConfig = {}
    */
    constructor(scope: Construct, id: string, config?: SecretsSyncConfigConfig);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _queueCapacity?;
    get queueCapacity(): number;
    set queueCapacity(value: number);
    resetQueueCapacity(): void;
    get queueCapacityInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

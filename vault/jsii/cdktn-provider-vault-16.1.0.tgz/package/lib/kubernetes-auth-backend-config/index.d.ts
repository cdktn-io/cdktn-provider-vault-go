/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface KubernetesAuthBackendConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Unique name of the kubernetes backend to configure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_auth_backend_config#backend KubernetesAuthBackendConfig#backend}
    */
    readonly backend?: string;
    /**
    * Optional disable JWT issuer validation. Allows to skip ISS validation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_auth_backend_config#disable_iss_validation KubernetesAuthBackendConfig#disable_iss_validation}
    */
    readonly disableIssValidation?: boolean | cdktn.IResolvable;
    /**
    * Optional disable defaulting to the local CA cert and service account JWT when running in a Kubernetes pod.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_auth_backend_config#disable_local_ca_jwt KubernetesAuthBackendConfig#disable_local_ca_jwt}
    */
    readonly disableLocalCaJwt?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_auth_backend_config#id KubernetesAuthBackendConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Optional JWT issuer. If no issuer is specified, kubernetes.io/serviceaccount will be used as the default issuer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_auth_backend_config#issuer KubernetesAuthBackendConfig#issuer}
    */
    readonly issuer?: string;
    /**
    * PEM encoded CA cert for use by the TLS client used to talk with the Kubernetes API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_auth_backend_config#kubernetes_ca_cert KubernetesAuthBackendConfig#kubernetes_ca_cert}
    */
    readonly kubernetesCaCert?: string;
    /**
    * Host must be a host string, a host:port pair, or a URL to the base of the Kubernetes API server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_auth_backend_config#kubernetes_host KubernetesAuthBackendConfig#kubernetes_host}
    */
    readonly kubernetesHost: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_auth_backend_config#namespace KubernetesAuthBackendConfig#namespace}
    */
    readonly namespace?: string;
    /**
    * Optional list of PEM-formatted public keys or certificates used to verify the signatures of Kubernetes service account JWTs. If a certificate is given, its public key will be extracted. Not every installation of Kubernetes exposes these keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_auth_backend_config#pem_keys KubernetesAuthBackendConfig#pem_keys}
    */
    readonly pemKeys?: string[];
    /**
    * A service account JWT (or other token) used as a bearer token to access the TokenReview API to validate other JWTs during login. If not set the JWT used for login will be used to access the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_auth_backend_config#token_reviewer_jwt KubernetesAuthBackendConfig#token_reviewer_jwt}
    */
    readonly tokenReviewerJwt?: string;
    /**
    * A write-only service account JWT (or other token) used as a bearer token to access the TokenReview API to validate other JWTs during login. If not set the JWT used for login will be used to access the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_auth_backend_config#token_reviewer_jwt_wo KubernetesAuthBackendConfig#token_reviewer_jwt_wo}
    */
    readonly tokenReviewerJwtWo?: string;
    /**
    * The version of token_reviewer_jwt_wo to use during write operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_auth_backend_config#token_reviewer_jwt_wo_version KubernetesAuthBackendConfig#token_reviewer_jwt_wo_version}
    */
    readonly tokenReviewerJwtWoVersion?: number;
    /**
    * Use annotations from the client token's associated service account as alias metadata for the Vault entity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_auth_backend_config#use_annotations_as_alias_metadata KubernetesAuthBackendConfig#use_annotations_as_alias_metadata}
    */
    readonly useAnnotationsAsAliasMetadata?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_auth_backend_config vault_kubernetes_auth_backend_config}
*/
export declare class KubernetesAuthBackendConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_kubernetes_auth_backend_config";
    /**
    * Generates CDKTN code for importing a KubernetesAuthBackendConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KubernetesAuthBackendConfig to import
    * @param importFromId The id of the existing KubernetesAuthBackendConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_auth_backend_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KubernetesAuthBackendConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_auth_backend_config vault_kubernetes_auth_backend_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KubernetesAuthBackendConfigConfig
    */
    constructor(scope: Construct, id: string, config: KubernetesAuthBackendConfigConfig);
    private _backend?;
    get backend(): string;
    set backend(value: string);
    resetBackend(): void;
    get backendInput(): string | undefined;
    private _disableIssValidation?;
    get disableIssValidation(): boolean | cdktn.IResolvable;
    set disableIssValidation(value: boolean | cdktn.IResolvable);
    resetDisableIssValidation(): void;
    get disableIssValidationInput(): boolean | cdktn.IResolvable | undefined;
    private _disableLocalCaJwt?;
    get disableLocalCaJwt(): boolean | cdktn.IResolvable;
    set disableLocalCaJwt(value: boolean | cdktn.IResolvable);
    resetDisableLocalCaJwt(): void;
    get disableLocalCaJwtInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _issuer?;
    get issuer(): string;
    set issuer(value: string);
    resetIssuer(): void;
    get issuerInput(): string | undefined;
    private _kubernetesCaCert?;
    get kubernetesCaCert(): string;
    set kubernetesCaCert(value: string);
    resetKubernetesCaCert(): void;
    get kubernetesCaCertInput(): string | undefined;
    private _kubernetesHost?;
    get kubernetesHost(): string;
    set kubernetesHost(value: string);
    get kubernetesHostInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _pemKeys?;
    get pemKeys(): string[];
    set pemKeys(value: string[]);
    resetPemKeys(): void;
    get pemKeysInput(): string[] | undefined;
    private _tokenReviewerJwt?;
    get tokenReviewerJwt(): string;
    set tokenReviewerJwt(value: string);
    resetTokenReviewerJwt(): void;
    get tokenReviewerJwtInput(): string | undefined;
    private _tokenReviewerJwtWo?;
    get tokenReviewerJwtWo(): string;
    set tokenReviewerJwtWo(value: string);
    resetTokenReviewerJwtWo(): void;
    get tokenReviewerJwtWoInput(): string | undefined;
    private _tokenReviewerJwtWoVersion?;
    get tokenReviewerJwtWoVersion(): number;
    set tokenReviewerJwtWoVersion(value: number);
    resetTokenReviewerJwtWoVersion(): void;
    get tokenReviewerJwtWoVersionInput(): number | undefined;
    private _useAnnotationsAsAliasMetadata?;
    get useAnnotationsAsAliasMetadata(): boolean | cdktn.IResolvable;
    set useAnnotationsAsAliasMetadata(value: boolean | cdktn.IResolvable);
    resetUseAnnotationsAsAliasMetadata(): void;
    get useAnnotationsAsAliasMetadataInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

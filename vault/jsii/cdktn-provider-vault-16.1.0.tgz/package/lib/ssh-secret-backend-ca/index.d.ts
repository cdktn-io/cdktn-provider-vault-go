/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SshSecretBackendCaConfig extends cdktn.TerraformMetaArguments {
    /**
    * The path of the SSH Secret Backend where the CA should be configured
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ssh_secret_backend_ca#backend SshSecretBackendCa#backend}
    */
    readonly backend?: string;
    /**
    * Whether Vault should generate the signing key pair internally.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ssh_secret_backend_ca#generate_signing_key SshSecretBackendCa#generate_signing_key}
    */
    readonly generateSigningKey?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ssh_secret_backend_ca#id SshSecretBackendCa#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the desired key bits for the generated SSH CA key when `generate_signing_key` is set to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ssh_secret_backend_ca#key_bits SshSecretBackendCa#key_bits}
    */
    readonly keyBits?: number;
    /**
    * Specifies the desired key type for the generated SSH CA key when `generate_signing_key` is set to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ssh_secret_backend_ca#key_type SshSecretBackendCa#key_type}
    */
    readonly keyType?: string;
    /**
    * The id of the managed key to use. When using a managed key, this field or managed_key_name is required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ssh_secret_backend_ca#managed_key_id SshSecretBackendCa#managed_key_id}
    */
    readonly managedKeyId?: string;
    /**
    * The name of the managed key to use. When using a managed key, this field or managed_key_id is required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ssh_secret_backend_ca#managed_key_name SshSecretBackendCa#managed_key_name}
    */
    readonly managedKeyName?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ssh_secret_backend_ca#namespace SshSecretBackendCa#namespace}
    */
    readonly namespace?: string;
    /**
    * Private key part the SSH CA key pair; required if generate_signing_key is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ssh_secret_backend_ca#private_key SshSecretBackendCa#private_key}
    */
    readonly privateKey?: string;
    /**
    * Public key part the SSH CA key pair; required if generate_signing_key is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ssh_secret_backend_ca#public_key SshSecretBackendCa#public_key}
    */
    readonly publicKey?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ssh_secret_backend_ca vault_ssh_secret_backend_ca}
*/
export declare class SshSecretBackendCa extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_ssh_secret_backend_ca";
    /**
    * Generates CDKTN code for importing a SshSecretBackendCa resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SshSecretBackendCa to import
    * @param importFromId The id of the existing SshSecretBackendCa that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ssh_secret_backend_ca#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SshSecretBackendCa to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ssh_secret_backend_ca vault_ssh_secret_backend_ca} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SshSecretBackendCaConfig = {}
    */
    constructor(scope: Construct, id: string, config?: SshSecretBackendCaConfig);
    private _backend?;
    get backend(): string;
    set backend(value: string);
    resetBackend(): void;
    get backendInput(): string | undefined;
    private _generateSigningKey?;
    get generateSigningKey(): boolean | cdktn.IResolvable;
    set generateSigningKey(value: boolean | cdktn.IResolvable);
    resetGenerateSigningKey(): void;
    get generateSigningKeyInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyBits?;
    get keyBits(): number;
    set keyBits(value: number);
    resetKeyBits(): void;
    get keyBitsInput(): number | undefined;
    private _keyType?;
    get keyType(): string;
    set keyType(value: string);
    resetKeyType(): void;
    get keyTypeInput(): string | undefined;
    private _managedKeyId?;
    get managedKeyId(): string;
    set managedKeyId(value: string);
    resetManagedKeyId(): void;
    get managedKeyIdInput(): string | undefined;
    private _managedKeyName?;
    get managedKeyName(): string;
    set managedKeyName(value: string);
    resetManagedKeyName(): void;
    get managedKeyNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    resetPrivateKey(): void;
    get privateKeyInput(): string | undefined;
    private _publicKey?;
    get publicKey(): string;
    set publicKey(value: string);
    resetPublicKey(): void;
    get publicKeyInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

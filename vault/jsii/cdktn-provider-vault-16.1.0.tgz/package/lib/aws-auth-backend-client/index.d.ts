/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAuthBackendClientConfig extends cdktn.TerraformMetaArguments {
    /**
    * AWS Access key with permissions to query AWS APIs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#access_key AwsAuthBackendClient#access_key}
    */
    readonly accessKey?: string;
    /**
    * List of additional headers that are allowed to be in STS request headers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#allowed_sts_header_values AwsAuthBackendClient#allowed_sts_header_values}
    */
    readonly allowedStsHeaderValues?: string[];
    /**
    * Unique name of the auth backend to configure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#backend AwsAuthBackendClient#backend}
    */
    readonly backend?: string;
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#disable_automated_rotation AwsAuthBackendClient#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * URL to override the default generated endpoint for making AWS EC2 API calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#ec2_endpoint AwsAuthBackendClient#ec2_endpoint}
    */
    readonly ec2Endpoint?: string;
    /**
    * URL to override the default generated endpoint for making AWS IAM API calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#iam_endpoint AwsAuthBackendClient#iam_endpoint}
    */
    readonly iamEndpoint?: string;
    /**
    * The value to require in the X-Vault-AWS-IAM-Server-ID header as part of GetCallerIdentity requests that are used in the iam auth method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#iam_server_id_header_value AwsAuthBackendClient#iam_server_id_header_value}
    */
    readonly iamServerIdHeaderValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#id AwsAuthBackendClient#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The audience claim value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#identity_token_audience AwsAuthBackendClient#identity_token_audience}
    */
    readonly identityTokenAudience?: string;
    /**
    * The TTL of generated identity tokens in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#identity_token_ttl AwsAuthBackendClient#identity_token_ttl}
    */
    readonly identityTokenTtl?: number;
    /**
    * Number of max retries the client should use for recoverable errors.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#max_retries AwsAuthBackendClient#max_retries}
    */
    readonly maxRetries?: number;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#namespace AwsAuthBackendClient#namespace}
    */
    readonly namespace?: string;
    /**
    * Role ARN to assume for plugin identity token federation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#role_arn AwsAuthBackendClient#role_arn}
    */
    readonly roleArn?: string;
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#rotation_period AwsAuthBackendClient#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#rotation_schedule AwsAuthBackendClient#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#rotation_window AwsAuthBackendClient#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * AWS Secret key with permissions to query AWS APIs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#secret_key AwsAuthBackendClient#secret_key}
    */
    readonly secretKey?: string;
    /**
    * Write-only AWS Secret key with permissions to query AWS APIs. This field is recommended over secret_key for enhanced security.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#secret_key_wo AwsAuthBackendClient#secret_key_wo}
    */
    readonly secretKeyWo?: string;
    /**
    * Version counter for write-only secret_key field. Increment this value to force update of the secret.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#secret_key_wo_version AwsAuthBackendClient#secret_key_wo_version}
    */
    readonly secretKeyWoVersion?: number;
    /**
    * URL to override the default generated endpoint for making AWS STS API calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#sts_endpoint AwsAuthBackendClient#sts_endpoint}
    */
    readonly stsEndpoint?: string;
    /**
    * Region to override the default region for making AWS STS API calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#sts_region AwsAuthBackendClient#sts_region}
    */
    readonly stsRegion?: string;
    /**
    * If set, will override sts_region and use the region from the client request's header
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#use_sts_region_from_client AwsAuthBackendClient#use_sts_region_from_client}
    */
    readonly useStsRegionFromClient?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client vault_aws_auth_backend_client}
*/
export declare class AwsAuthBackendClient extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_aws_auth_backend_client";
    /**
    * Generates CDKTN code for importing a AwsAuthBackendClient resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAuthBackendClient to import
    * @param importFromId The id of the existing AwsAuthBackendClient that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAuthBackendClient to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_client vault_aws_auth_backend_client} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAuthBackendClientConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsAuthBackendClientConfig);
    private _accessKey?;
    get accessKey(): string;
    set accessKey(value: string);
    resetAccessKey(): void;
    get accessKeyInput(): string | undefined;
    private _allowedStsHeaderValues?;
    get allowedStsHeaderValues(): string[];
    set allowedStsHeaderValues(value: string[]);
    resetAllowedStsHeaderValues(): void;
    get allowedStsHeaderValuesInput(): string[] | undefined;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    resetBackend(): void;
    get backendInput(): string | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _ec2Endpoint?;
    get ec2Endpoint(): string;
    set ec2Endpoint(value: string);
    resetEc2Endpoint(): void;
    get ec2EndpointInput(): string | undefined;
    private _iamEndpoint?;
    get iamEndpoint(): string;
    set iamEndpoint(value: string);
    resetIamEndpoint(): void;
    get iamEndpointInput(): string | undefined;
    private _iamServerIdHeaderValue?;
    get iamServerIdHeaderValue(): string;
    set iamServerIdHeaderValue(value: string);
    resetIamServerIdHeaderValue(): void;
    get iamServerIdHeaderValueInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityTokenAudience?;
    get identityTokenAudience(): string;
    set identityTokenAudience(value: string);
    resetIdentityTokenAudience(): void;
    get identityTokenAudienceInput(): string | undefined;
    private _identityTokenTtl?;
    get identityTokenTtl(): number;
    set identityTokenTtl(value: number);
    resetIdentityTokenTtl(): void;
    get identityTokenTtlInput(): number | undefined;
    private _maxRetries?;
    get maxRetries(): number;
    set maxRetries(value: number);
    resetMaxRetries(): void;
    get maxRetriesInput(): number | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _secretKey?;
    get secretKey(): string;
    set secretKey(value: string);
    resetSecretKey(): void;
    get secretKeyInput(): string | undefined;
    private _secretKeyWo?;
    get secretKeyWo(): string;
    set secretKeyWo(value: string);
    resetSecretKeyWo(): void;
    get secretKeyWoInput(): string | undefined;
    private _secretKeyWoVersion?;
    get secretKeyWoVersion(): number;
    set secretKeyWoVersion(value: number);
    resetSecretKeyWoVersion(): void;
    get secretKeyWoVersionInput(): number | undefined;
    private _stsEndpoint?;
    get stsEndpoint(): string;
    set stsEndpoint(value: string);
    resetStsEndpoint(): void;
    get stsEndpointInput(): string | undefined;
    private _stsRegion?;
    get stsRegion(): string;
    set stsRegion(value: string);
    resetStsRegion(): void;
    get stsRegionInput(): string | undefined;
    private _useStsRegionFromClient?;
    get useStsRegionFromClient(): boolean | cdktn.IResolvable;
    set useStsRegionFromClient(value: boolean | cdktn.IResolvable);
    resetUseStsRegionFromClient(): void;
    get useStsRegionFromClientInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IdentityOidcClientConfig extends cdktn.TerraformMetaArguments {
    /**
    * The time-to-live for access tokens obtained by the client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/identity_oidc_client#access_token_ttl IdentityOidcClient#access_token_ttl}
    */
    readonly accessTokenTtl?: number;
    /**
    * A list of assignment resources associated with the client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/identity_oidc_client#assignments IdentityOidcClient#assignments}
    */
    readonly assignments?: string[];
    /**
    * The client type based on its ability to maintain confidentiality of credentials.Defaults to 'confidential'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/identity_oidc_client#client_type IdentityOidcClient#client_type}
    */
    readonly clientType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/identity_oidc_client#id IdentityOidcClient#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The time-to-live for ID tokens obtained by the client. The value should be less than the verification_ttl on the key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/identity_oidc_client#id_token_ttl IdentityOidcClient#id_token_ttl}
    */
    readonly idTokenTtl?: number;
    /**
    * A reference to a named key resource in Vault. This cannot be modified after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/identity_oidc_client#key IdentityOidcClient#key}
    */
    readonly key?: string;
    /**
    * The name of the client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/identity_oidc_client#name IdentityOidcClient#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/identity_oidc_client#namespace IdentityOidcClient#namespace}
    */
    readonly namespace?: string;
    /**
    * Redirection URI values used by the client. One of these values must exactly match the redirect_uri parameter value used in each authentication request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/identity_oidc_client#redirect_uris IdentityOidcClient#redirect_uris}
    */
    readonly redirectUris?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/identity_oidc_client vault_identity_oidc_client}
*/
export declare class IdentityOidcClient extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_identity_oidc_client";
    /**
    * Generates CDKTN code for importing a IdentityOidcClient resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IdentityOidcClient to import
    * @param importFromId The id of the existing IdentityOidcClient that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/identity_oidc_client#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IdentityOidcClient to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/identity_oidc_client vault_identity_oidc_client} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IdentityOidcClientConfig
    */
    constructor(scope: Construct, id: string, config: IdentityOidcClientConfig);
    private _accessTokenTtl?;
    get accessTokenTtl(): number;
    set accessTokenTtl(value: number);
    resetAccessTokenTtl(): void;
    get accessTokenTtlInput(): number | undefined;
    private _assignments?;
    get assignments(): string[];
    set assignments(value: string[]);
    resetAssignments(): void;
    get assignmentsInput(): string[] | undefined;
    get clientId(): string;
    get clientSecret(): string;
    private _clientType?;
    get clientType(): string;
    set clientType(value: string);
    resetClientType(): void;
    get clientTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _idTokenTtl?;
    get idTokenTtl(): number;
    set idTokenTtl(value: number);
    resetIdTokenTtl(): void;
    get idTokenTtlInput(): number | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _redirectUris?;
    get redirectUris(): string[];
    set redirectUris(value: string[]);
    resetRedirectUris(): void;
    get redirectUrisInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultPkiSecretBackendConfigScepConfig extends cdktn.TerraformMetaArguments {
    /**
    * Path where PKI engine is mounted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/pki_secret_backend_config_scep#backend DataVaultPkiSecretBackendConfigScep#backend}
    */
    readonly backend: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/pki_secret_backend_config_scep#id DataVaultPkiSecretBackendConfigScep#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The level of logging verbosity, affects only SCEP logs on this mount
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/pki_secret_backend_config_scep#log_level DataVaultPkiSecretBackendConfigScep#log_level}
    */
    readonly logLevel?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/pki_secret_backend_config_scep#namespace DataVaultPkiSecretBackendConfigScep#namespace}
    */
    readonly namespace?: string;
}
export interface DataVaultPkiSecretBackendConfigScepAuthenticators {
}
export declare function dataVaultPkiSecretBackendConfigScepAuthenticatorsToTerraform(struct?: DataVaultPkiSecretBackendConfigScepAuthenticators): any;
export declare function dataVaultPkiSecretBackendConfigScepAuthenticatorsToHclTerraform(struct?: DataVaultPkiSecretBackendConfigScepAuthenticators): any;
export declare class DataVaultPkiSecretBackendConfigScepAuthenticatorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataVaultPkiSecretBackendConfigScepAuthenticators | undefined;
    set internalValue(value: DataVaultPkiSecretBackendConfigScepAuthenticators | undefined);
    private _cert;
    get cert(): cdktn.StringMap;
    private _scep;
    get scep(): cdktn.StringMap;
}
export declare class DataVaultPkiSecretBackendConfigScepAuthenticatorsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataVaultPkiSecretBackendConfigScepAuthenticatorsOutputReference;
}
export interface DataVaultPkiSecretBackendConfigScepExternalValidation {
}
export declare function dataVaultPkiSecretBackendConfigScepExternalValidationToTerraform(struct?: DataVaultPkiSecretBackendConfigScepExternalValidation): any;
export declare function dataVaultPkiSecretBackendConfigScepExternalValidationToHclTerraform(struct?: DataVaultPkiSecretBackendConfigScepExternalValidation): any;
export declare class DataVaultPkiSecretBackendConfigScepExternalValidationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataVaultPkiSecretBackendConfigScepExternalValidation | undefined;
    set internalValue(value: DataVaultPkiSecretBackendConfigScepExternalValidation | undefined);
    private _intune;
    get intune(): cdktn.StringMap;
}
export declare class DataVaultPkiSecretBackendConfigScepExternalValidationList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataVaultPkiSecretBackendConfigScepExternalValidationOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/pki_secret_backend_config_scep vault_pki_secret_backend_config_scep}
*/
export declare class DataVaultPkiSecretBackendConfigScep extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_pki_secret_backend_config_scep";
    /**
    * Generates CDKTN code for importing a DataVaultPkiSecretBackendConfigScep resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultPkiSecretBackendConfigScep to import
    * @param importFromId The id of the existing DataVaultPkiSecretBackendConfigScep that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/pki_secret_backend_config_scep#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultPkiSecretBackendConfigScep to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/pki_secret_backend_config_scep vault_pki_secret_backend_config_scep} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultPkiSecretBackendConfigScepConfig
    */
    constructor(scope: Construct, id: string, config: DataVaultPkiSecretBackendConfigScepConfig);
    get allowedDigestAlgorithms(): string[];
    get allowedEncryptionAlgorithms(): string[];
    private _authenticators;
    get authenticators(): DataVaultPkiSecretBackendConfigScepAuthenticatorsList;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    get defaultPathPolicy(): string;
    get enabled(): cdktn.IResolvable;
    private _externalValidation;
    get externalValidation(): DataVaultPkiSecretBackendConfigScepExternalValidationList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdated(): string;
    private _logLevel?;
    get logLevel(): string;
    set logLevel(value: string);
    resetLogLevel(): void;
    get logLevelInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get restrictCaChainToIssuer(): cdktn.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

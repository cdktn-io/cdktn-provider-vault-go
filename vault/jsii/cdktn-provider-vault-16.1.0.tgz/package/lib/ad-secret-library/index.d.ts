/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AdSecretLibraryConfig extends cdktn.TerraformMetaArguments {
    /**
    * The mount path for the AD backend.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ad_secret_library#backend AdSecretLibrary#backend}
    */
    readonly backend: string;
    /**
    * Disable enforcing that service accounts must be checked in by the entity or client token that checked them out.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ad_secret_library#disable_check_in_enforcement AdSecretLibrary#disable_check_in_enforcement}
    */
    readonly disableCheckInEnforcement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ad_secret_library#id AdSecretLibrary#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The maximum amount of time, in seconds, a check-out last with renewal before Vault automatically checks it back in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ad_secret_library#max_ttl AdSecretLibrary#max_ttl}
    */
    readonly maxTtl?: number;
    /**
    * The name of the set of service accounts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ad_secret_library#name AdSecretLibrary#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ad_secret_library#namespace AdSecretLibrary#namespace}
    */
    readonly namespace?: string;
    /**
    * The names of all the service accounts that can be checked out from this set. These service accounts must already exist in Active Directory.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ad_secret_library#service_account_names AdSecretLibrary#service_account_names}
    */
    readonly serviceAccountNames: string[];
    /**
    * The amount of time, in seconds, a single check-out lasts before Vault automatically checks it back in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ad_secret_library#ttl AdSecretLibrary#ttl}
    */
    readonly ttl?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ad_secret_library vault_ad_secret_library}
*/
export declare class AdSecretLibrary extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_ad_secret_library";
    /**
    * Generates CDKTN code for importing a AdSecretLibrary resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AdSecretLibrary to import
    * @param importFromId The id of the existing AdSecretLibrary that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ad_secret_library#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AdSecretLibrary to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/ad_secret_library vault_ad_secret_library} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AdSecretLibraryConfig
    */
    constructor(scope: Construct, id: string, config: AdSecretLibraryConfig);
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    private _disableCheckInEnforcement?;
    get disableCheckInEnforcement(): boolean | cdktn.IResolvable;
    set disableCheckInEnforcement(value: boolean | cdktn.IResolvable);
    resetDisableCheckInEnforcement(): void;
    get disableCheckInEnforcementInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxTtl?;
    get maxTtl(): number;
    set maxTtl(value: number);
    resetMaxTtl(): void;
    get maxTtlInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _serviceAccountNames?;
    get serviceAccountNames(): string[];
    set serviceAccountNames(value: string[]);
    get serviceAccountNamesInput(): string[] | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

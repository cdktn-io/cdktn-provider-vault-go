/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SecretsSyncVercelDestinationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Vercel API access token with the permissions to manage environment variables.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_vercel_destination#access_token SecretsSyncVercelDestination#access_token}
    */
    readonly accessToken: string;
    /**
    * Set of allowed IPv4 addresses in CIDR notation (e.g., 192.168.1.1/32) for outbound connections from Vault to the destination. If not set, all IPv4 addresses are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_vercel_destination#allowed_ipv4_addresses SecretsSyncVercelDestination#allowed_ipv4_addresses}
    */
    readonly allowedIpv4Addresses?: string[];
    /**
    * Set of allowed IPv6 addresses in CIDR notation (e.g., 2001:db8::1/128) for outbound connections from Vault to the destination. If not set, all IPv6 addresses are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_vercel_destination#allowed_ipv6_addresses SecretsSyncVercelDestination#allowed_ipv6_addresses}
    */
    readonly allowedIpv6Addresses?: string[];
    /**
    * Set of allowed ports for outbound connections from Vault to the destination. If not set, all ports are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_vercel_destination#allowed_ports SecretsSyncVercelDestination#allowed_ports}
    */
    readonly allowedPorts?: number[];
    /**
    * Deployment environments where the environment variables are available. Accepts 'development', 'preview' & 'production'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_vercel_destination#deployment_environments SecretsSyncVercelDestination#deployment_environments}
    */
    readonly deploymentEnvironments: string[];
    /**
    * If set to true, disables strict networking enforcement for this destination. When disabled, Vault will not enforce allowed IP addresses and ports.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_vercel_destination#disable_strict_networking SecretsSyncVercelDestination#disable_strict_networking}
    */
    readonly disableStrictNetworking?: boolean | cdktn.IResolvable;
    /**
    * Determines what level of information is synced as a distinct resource at the destination. Can be 'secret-path' or 'secret-key'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_vercel_destination#granularity SecretsSyncVercelDestination#granularity}
    */
    readonly granularity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_vercel_destination#id SecretsSyncVercelDestination#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Unique name of the Vercel destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_vercel_destination#name SecretsSyncVercelDestination#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_vercel_destination#namespace SecretsSyncVercelDestination#namespace}
    */
    readonly namespace?: string;
    /**
    * Project ID where to manage environment variables.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_vercel_destination#project_id SecretsSyncVercelDestination#project_id}
    */
    readonly projectId: string;
    /**
    * Template describing how to generate external secret names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_vercel_destination#secret_name_template SecretsSyncVercelDestination#secret_name_template}
    */
    readonly secretNameTemplate?: string;
    /**
    * Team ID the project belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_vercel_destination#team_id SecretsSyncVercelDestination#team_id}
    */
    readonly teamId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_vercel_destination vault_secrets_sync_vercel_destination}
*/
export declare class SecretsSyncVercelDestination extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_secrets_sync_vercel_destination";
    /**
    * Generates CDKTN code for importing a SecretsSyncVercelDestination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecretsSyncVercelDestination to import
    * @param importFromId The id of the existing SecretsSyncVercelDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_vercel_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecretsSyncVercelDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/secrets_sync_vercel_destination vault_secrets_sync_vercel_destination} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecretsSyncVercelDestinationConfig
    */
    constructor(scope: Construct, id: string, config: SecretsSyncVercelDestinationConfig);
    private _accessToken?;
    get accessToken(): string;
    set accessToken(value: string);
    get accessTokenInput(): string | undefined;
    private _allowedIpv4Addresses?;
    get allowedIpv4Addresses(): string[];
    set allowedIpv4Addresses(value: string[]);
    resetAllowedIpv4Addresses(): void;
    get allowedIpv4AddressesInput(): string[] | undefined;
    private _allowedIpv6Addresses?;
    get allowedIpv6Addresses(): string[];
    set allowedIpv6Addresses(value: string[]);
    resetAllowedIpv6Addresses(): void;
    get allowedIpv6AddressesInput(): string[] | undefined;
    private _allowedPorts?;
    get allowedPorts(): number[];
    set allowedPorts(value: number[]);
    resetAllowedPorts(): void;
    get allowedPortsInput(): number[] | undefined;
    private _deploymentEnvironments?;
    get deploymentEnvironments(): string[];
    set deploymentEnvironments(value: string[]);
    get deploymentEnvironmentsInput(): string[] | undefined;
    private _disableStrictNetworking?;
    get disableStrictNetworking(): boolean | cdktn.IResolvable;
    set disableStrictNetworking(value: boolean | cdktn.IResolvable);
    resetDisableStrictNetworking(): void;
    get disableStrictNetworkingInput(): boolean | cdktn.IResolvable | undefined;
    private _granularity?;
    get granularity(): string;
    set granularity(value: string);
    resetGranularity(): void;
    get granularityInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _secretNameTemplate?;
    get secretNameTemplate(): string;
    set secretNameTemplate(value: string);
    resetSecretNameTemplate(): void;
    get secretNameTemplateInput(): string | undefined;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    resetTeamId(): void;
    get teamIdInput(): string | undefined;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

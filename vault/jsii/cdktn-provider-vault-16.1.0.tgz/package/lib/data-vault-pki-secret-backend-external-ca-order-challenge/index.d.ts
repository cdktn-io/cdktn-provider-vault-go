/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultPkiSecretBackendExternalCaOrderChallengeConfig extends cdktn.TerraformMetaArguments {
    /**
    * The type of ACME challenge to retrieve. Valid values are `http-01`, `dns-01`, `tls-alpn-01`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/pki_secret_backend_external_ca_order_challenge#challenge_type DataVaultPkiSecretBackendExternalCaOrderChallenge#challenge_type}
    */
    readonly challengeType: string;
    /**
    * The identifier (domain name) for which to retrieve the challenge.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/pki_secret_backend_external_ca_order_challenge#identifier DataVaultPkiSecretBackendExternalCaOrderChallenge#identifier}
    */
    readonly identifier: string;
    /**
    * The path where the PKI External CA secret backend is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/pki_secret_backend_external_ca_order_challenge#mount DataVaultPkiSecretBackendExternalCaOrderChallenge#mount}
    */
    readonly mount: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/pki_secret_backend_external_ca_order_challenge#namespace DataVaultPkiSecretBackendExternalCaOrderChallenge#namespace}
    */
    readonly namespace?: string;
    /**
    * The unique identifier for the ACME order.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/pki_secret_backend_external_ca_order_challenge#order_id DataVaultPkiSecretBackendExternalCaOrderChallenge#order_id}
    */
    readonly orderId: string;
    /**
    * Name of the role associated with the order.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/pki_secret_backend_external_ca_order_challenge#role_name DataVaultPkiSecretBackendExternalCaOrderChallenge#role_name}
    */
    readonly roleName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/pki_secret_backend_external_ca_order_challenge vault_pki_secret_backend_external_ca_order_challenge}
*/
export declare class DataVaultPkiSecretBackendExternalCaOrderChallenge extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_pki_secret_backend_external_ca_order_challenge";
    /**
    * Generates CDKTN code for importing a DataVaultPkiSecretBackendExternalCaOrderChallenge resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultPkiSecretBackendExternalCaOrderChallenge to import
    * @param importFromId The id of the existing DataVaultPkiSecretBackendExternalCaOrderChallenge that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/pki_secret_backend_external_ca_order_challenge#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultPkiSecretBackendExternalCaOrderChallenge to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/pki_secret_backend_external_ca_order_challenge vault_pki_secret_backend_external_ca_order_challenge} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultPkiSecretBackendExternalCaOrderChallengeConfig
    */
    constructor(scope: Construct, id: string, config: DataVaultPkiSecretBackendExternalCaOrderChallengeConfig);
    private _challengeType?;
    get challengeType(): string;
    set challengeType(value: string);
    get challengeTypeInput(): string | undefined;
    get expires(): string;
    get id(): string;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    get keyAuthorization(): string;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _orderId?;
    get orderId(): string;
    set orderId(value: string);
    get orderIdInput(): string | undefined;
    private _roleName?;
    get roleName(): string;
    set roleName(value: string);
    get roleNameInput(): string | undefined;
    get status(): string;
    get token(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

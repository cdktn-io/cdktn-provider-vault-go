/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PkiSecretBackendExternalCaOrderConfig extends cdktn.TerraformMetaArguments {
    /**
    * PEM-encoded Certificate Signing Request containing identifiers. Required if `identifiers` is not provided. Mutually exclusive with `identifiers`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_order#csr PkiSecretBackendExternalCaOrder#csr}
    */
    readonly csr?: string;
    /**
    * List of identifiers (domain names) for the certificate order. Required if `csr` is not provided. Mutually exclusive with `csr`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_order#identifiers PkiSecretBackendExternalCaOrder#identifiers}
    */
    readonly identifiers?: string[];
    /**
    * The path where the PKI External CA secret backend is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_order#mount PkiSecretBackendExternalCaOrder#mount}
    */
    readonly mount: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_order#namespace PkiSecretBackendExternalCaOrder#namespace}
    */
    readonly namespace?: string;
    /**
    * Name of the role to create the order for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_order#role_name PkiSecretBackendExternalCaOrder#role_name}
    */
    readonly roleName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_order vault_pki_secret_backend_external_ca_order}
*/
export declare class PkiSecretBackendExternalCaOrder extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_pki_secret_backend_external_ca_order";
    /**
    * Generates CDKTN code for importing a PkiSecretBackendExternalCaOrder resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PkiSecretBackendExternalCaOrder to import
    * @param importFromId The id of the existing PkiSecretBackendExternalCaOrder that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_order#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PkiSecretBackendExternalCaOrder to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_order vault_pki_secret_backend_external_ca_order} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PkiSecretBackendExternalCaOrderConfig
    */
    constructor(scope: Construct, id: string, config: PkiSecretBackendExternalCaOrderConfig);
    private _challenges;
    get challenges(): cdktn.StringMap;
    get creationDate(): string;
    private _csr?;
    get csr(): string;
    set csr(value: string);
    resetCsr(): void;
    get csrInput(): string | undefined;
    get expires(): string;
    private _identifiers?;
    get identifiers(): string[];
    set identifiers(value: string[]);
    resetIdentifiers(): void;
    get identifiersInput(): string[] | undefined;
    get lastError(): string;
    get lastUpdate(): string;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get nextWorkDate(): string;
    get orderId(): string;
    get orderStatus(): string;
    private _roleName?;
    get roleName(): string;
    set roleName(value: string);
    get roleNameInput(): string | undefined;
    get serialNumber(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PkiSecretBackendExternalCaRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ACME account to use when validating certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_role#acme_account_name PkiSecretBackendExternalCaRole#acme_account_name}
    */
    readonly acmeAccountName: string;
    /**
    * The list of challenge types that are allowed to be used. Valid values are: `http-01`, `dns-01`, `tls-alpn-01`. Defaults to all challenge types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_role#allowed_challenge_types PkiSecretBackendExternalCaRole#allowed_challenge_types}
    */
    readonly allowedChallengeTypes?: string[];
    /**
    * A list of keyword options that influence how values within allowed_domains are interpreted against the requested set of identifiers from the client. Valid values are: `bare_domains`, `subdomains`, `wildcards`, `globs`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_role#allowed_domain_options PkiSecretBackendExternalCaRole#allowed_domain_options}
    */
    readonly allowedDomainOptions?: string[];
    /**
    * A list of domains the role will accept certificates for. May contain templates, as with ACL Path Templating.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_role#allowed_domains PkiSecretBackendExternalCaRole#allowed_domains}
    */
    readonly allowedDomains?: string[];
    /**
    * The key type and size/parameters to use when generating a new key if running in the identifier workflow. Valid values are: `ec-256`, `ec-384`, `ec-521`, `rsa-2048`, `rsa-4096`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_role#csr_generate_key_type PkiSecretBackendExternalCaRole#csr_generate_key_type}
    */
    readonly csrGenerateKeyType?: string;
    /**
    * The technique used to populate a CSR from the provided identifiers in the identifier workflow. Valid values are: `cn_first`, `sans_only`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_role#csr_identifier_population PkiSecretBackendExternalCaRole#csr_identifier_population}
    */
    readonly csrIdentifierPopulation?: string;
    /**
    * Force deletion even when active orders exist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_role#force PkiSecretBackendExternalCaRole#force}
    */
    readonly force?: boolean | cdktn.IResolvable;
    /**
    * The path where the PKI External CA secret backend is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_role#mount PkiSecretBackendExternalCaRole#mount}
    */
    readonly mount: string;
    /**
    * Name of the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_role#name PkiSecretBackendExternalCaRole#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_role#namespace PkiSecretBackendExternalCaRole#namespace}
    */
    readonly namespace?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_role vault_pki_secret_backend_external_ca_role}
*/
export declare class PkiSecretBackendExternalCaRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_pki_secret_backend_external_ca_role";
    /**
    * Generates CDKTN code for importing a PkiSecretBackendExternalCaRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PkiSecretBackendExternalCaRole to import
    * @param importFromId The id of the existing PkiSecretBackendExternalCaRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PkiSecretBackendExternalCaRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_external_ca_role vault_pki_secret_backend_external_ca_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PkiSecretBackendExternalCaRoleConfig
    */
    constructor(scope: Construct, id: string, config: PkiSecretBackendExternalCaRoleConfig);
    private _acmeAccountName?;
    get acmeAccountName(): string;
    set acmeAccountName(value: string);
    get acmeAccountNameInput(): string | undefined;
    private _allowedChallengeTypes?;
    get allowedChallengeTypes(): string[];
    set allowedChallengeTypes(value: string[]);
    resetAllowedChallengeTypes(): void;
    get allowedChallengeTypesInput(): string[] | undefined;
    private _allowedDomainOptions?;
    get allowedDomainOptions(): string[];
    set allowedDomainOptions(value: string[]);
    resetAllowedDomainOptions(): void;
    get allowedDomainOptionsInput(): string[] | undefined;
    private _allowedDomains?;
    get allowedDomains(): string[];
    set allowedDomains(value: string[]);
    resetAllowedDomains(): void;
    get allowedDomainsInput(): string[] | undefined;
    get creationDate(): string;
    private _csrGenerateKeyType?;
    get csrGenerateKeyType(): string;
    set csrGenerateKeyType(value: string);
    resetCsrGenerateKeyType(): void;
    get csrGenerateKeyTypeInput(): string | undefined;
    private _csrIdentifierPopulation?;
    get csrIdentifierPopulation(): string;
    set csrIdentifierPopulation(value: string);
    resetCsrIdentifierPopulation(): void;
    get csrIdentifierPopulationInput(): string | undefined;
    private _force?;
    get force(): boolean | cdktn.IResolvable;
    set force(value: boolean | cdktn.IResolvable);
    resetForce(): void;
    get forceInput(): boolean | cdktn.IResolvable | undefined;
    get lastUpdateDate(): string;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultTransitCmacConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a list of items for processing. When this parameter is set, any supplied 'input' or 'context' parameters will be ignored. Responses are returned in the 'batch_results' array component of the 'data' element of the response. Any batch output will preserve the order of the batch input. If the input data value of an item is invalid, the corresponding item in the 'batch_results' will have the key 'error' with a value describing the error.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/transit_cmac#batch_input DataVaultTransitCmac#batch_input}
    */
    readonly batchInput?: {
        [key: string]: string;
    }[] | cdktn.IResolvable;
    /**
    * The results returned from Vault if using batch_input
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/transit_cmac#batch_results DataVaultTransitCmac#batch_results}
    */
    readonly batchResults?: {
        [key: string]: string;
    }[] | cdktn.IResolvable;
    /**
    * The CMAC returned from Vault if using input
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/transit_cmac#cmac DataVaultTransitCmac#cmac}
    */
    readonly cmac?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/transit_cmac#id DataVaultTransitCmac#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the base64 encoded input data. One of input or batch_input must be supplied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/transit_cmac#input DataVaultTransitCmac#input}
    */
    readonly input?: string;
    /**
    * The version of the key to use
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/transit_cmac#key_version DataVaultTransitCmac#key_version}
    */
    readonly keyVersion?: number;
    /**
    * Specifies the MAC length to use (POST body parameter). The mac_length cannot be larger than the cipher's block size.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/transit_cmac#mac_length DataVaultTransitCmac#mac_length}
    */
    readonly macLength?: number;
    /**
    * Name of the CMAC key to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/transit_cmac#name DataVaultTransitCmac#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/transit_cmac#namespace DataVaultTransitCmac#namespace}
    */
    readonly namespace?: string;
    /**
    * The Transit secret backend the key belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/transit_cmac#path DataVaultTransitCmac#path}
    */
    readonly path: string;
    /**
    * Specifies the MAC length to use (URL parameter). If provided, this value overrides mac_length. The url_mac_length cannot be larger than the cipher's block size.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/transit_cmac#url_mac_length DataVaultTransitCmac#url_mac_length}
    */
    readonly urlMacLength?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/transit_cmac vault_transit_cmac}
*/
export declare class DataVaultTransitCmac extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_transit_cmac";
    /**
    * Generates CDKTN code for importing a DataVaultTransitCmac resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultTransitCmac to import
    * @param importFromId The id of the existing DataVaultTransitCmac that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/transit_cmac#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultTransitCmac to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/data-sources/transit_cmac vault_transit_cmac} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultTransitCmacConfig
    */
    constructor(scope: Construct, id: string, config: DataVaultTransitCmacConfig);
    private _batchInput?;
    get batchInput(): {
        [key: string]: string;
    }[] | cdktn.IResolvable;
    set batchInput(value: {
        [key: string]: string;
    }[] | cdktn.IResolvable);
    resetBatchInput(): void;
    get batchInputInput(): cdktn.IResolvable | {
        [key: string]: string;
    }[] | undefined;
    private _batchResults?;
    get batchResults(): {
        [key: string]: string;
    }[] | cdktn.IResolvable;
    set batchResults(value: {
        [key: string]: string;
    }[] | cdktn.IResolvable);
    resetBatchResults(): void;
    get batchResultsInput(): cdktn.IResolvable | {
        [key: string]: string;
    }[] | undefined;
    private _cmac?;
    get cmac(): string;
    set cmac(value: string);
    resetCmac(): void;
    get cmacInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _input?;
    get input(): string;
    set input(value: string);
    resetInput(): void;
    get inputInput(): string | undefined;
    private _keyVersion?;
    get keyVersion(): number;
    set keyVersion(value: number);
    resetKeyVersion(): void;
    get keyVersionInput(): number | undefined;
    private _macLength?;
    get macLength(): number;
    set macLength(value: number);
    resetMacLength(): void;
    get macLengthInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _urlMacLength?;
    get urlMacLength(): number;
    set urlMacLength(value: number);
    resetUrlMacLength(): void;
    get urlMacLengthInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

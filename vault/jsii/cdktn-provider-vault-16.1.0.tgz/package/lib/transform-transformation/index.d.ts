/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TransformTransformationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The set of roles allowed to perform this transformation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transform_transformation#allowed_roles TransformTransformation#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * If true, this transform can be deleted. Otherwise deletion is blocked while this value remains false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transform_transformation#deletion_allowed TransformTransformation#deletion_allowed}
    */
    readonly deletionAllowed?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transform_transformation#id TransformTransformation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The character used to replace data when in masking mode
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transform_transformation#masking_character TransformTransformation#masking_character}
    */
    readonly maskingCharacter?: string;
    /**
    * The name of the transformation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transform_transformation#name TransformTransformation#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transform_transformation#namespace TransformTransformation#namespace}
    */
    readonly namespace?: string;
    /**
    * The mount path for a back-end, for example, the path given in "$ vault auth enable -path=my-aws aws".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transform_transformation#path TransformTransformation#path}
    */
    readonly path: string;
    /**
    * The name of the template to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transform_transformation#template TransformTransformation#template}
    */
    readonly template?: string;
    /**
    * Templates configured for transformation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transform_transformation#templates TransformTransformation#templates}
    */
    readonly templates?: string[];
    /**
    * The source of where the tweak value comes from. Only valid when in FPE mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transform_transformation#tweak_source TransformTransformation#tweak_source}
    */
    readonly tweakSource?: string;
    /**
    * The type of transformation to perform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transform_transformation#type TransformTransformation#type}
    */
    readonly type?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transform_transformation vault_transform_transformation}
*/
export declare class TransformTransformation extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_transform_transformation";
    /**
    * Generates CDKTN code for importing a TransformTransformation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TransformTransformation to import
    * @param importFromId The id of the existing TransformTransformation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transform_transformation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TransformTransformation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transform_transformation vault_transform_transformation} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TransformTransformationConfig
    */
    constructor(scope: Construct, id: string, config: TransformTransformationConfig);
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _deletionAllowed?;
    get deletionAllowed(): boolean | cdktn.IResolvable;
    set deletionAllowed(value: boolean | cdktn.IResolvable);
    resetDeletionAllowed(): void;
    get deletionAllowedInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maskingCharacter?;
    get maskingCharacter(): string;
    set maskingCharacter(value: string);
    resetMaskingCharacter(): void;
    get maskingCharacterInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _template?;
    get template(): string;
    set template(value: string);
    resetTemplate(): void;
    get templateInput(): string | undefined;
    private _templates?;
    get templates(): string[];
    set templates(value: string[]);
    resetTemplates(): void;
    get templatesInput(): string[] | undefined;
    private _tweakSource?;
    get tweakSource(): string;
    set tweakSource(value: string);
    resetTweakSource(): void;
    get tweakSourceInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

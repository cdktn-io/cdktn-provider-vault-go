/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAuthBackendLoginConfig extends cdktn.TerraformMetaArguments {
    /**
    * AWS Auth Backend to read the token from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_login#backend AwsAuthBackendLogin#backend}
    */
    readonly backend?: string;
    /**
    * The HTTP method used in the signed request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_login#iam_http_request_method AwsAuthBackendLogin#iam_http_request_method}
    */
    readonly iamHttpRequestMethod?: string;
    /**
    * The Base64-encoded body of the signed request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_login#iam_request_body AwsAuthBackendLogin#iam_request_body}
    */
    readonly iamRequestBody?: string;
    /**
    * The Base64-encoded, JSON serialized representation of the sts:GetCallerIdentity HTTP request headers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_login#iam_request_headers AwsAuthBackendLogin#iam_request_headers}
    */
    readonly iamRequestHeaders?: string;
    /**
    * The Base64-encoded HTTP URL used in the signed request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_login#iam_request_url AwsAuthBackendLogin#iam_request_url}
    */
    readonly iamRequestUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_login#id AwsAuthBackendLogin#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Base64-encoded EC2 instance identity document to authenticate with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_login#identity AwsAuthBackendLogin#identity}
    */
    readonly identity?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_login#namespace AwsAuthBackendLogin#namespace}
    */
    readonly namespace?: string;
    /**
    * The nonce to be used for subsequent login requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_login#nonce AwsAuthBackendLogin#nonce}
    */
    readonly nonce?: string;
    /**
    * PKCS7 signature of the identity document to authenticate with, with all newline characters removed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_login#pkcs7 AwsAuthBackendLogin#pkcs7}
    */
    readonly pkcs7?: string;
    /**
    * AWS Auth Role to read the token from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_login#role AwsAuthBackendLogin#role}
    */
    readonly role?: string;
    /**
    * Base64-encoded SHA256 RSA signature of the instance identtiy document to authenticate with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_login#signature AwsAuthBackendLogin#signature}
    */
    readonly signature?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_login vault_aws_auth_backend_login}
*/
export declare class AwsAuthBackendLogin extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_aws_auth_backend_login";
    /**
    * Generates CDKTN code for importing a AwsAuthBackendLogin resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAuthBackendLogin to import
    * @param importFromId The id of the existing AwsAuthBackendLogin that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_login#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAuthBackendLogin to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/aws_auth_backend_login vault_aws_auth_backend_login} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAuthBackendLoginConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsAuthBackendLoginConfig);
    get accessor(): string;
    get authType(): string;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    resetBackend(): void;
    get backendInput(): string | undefined;
    get clientToken(): string;
    private _iamHttpRequestMethod?;
    get iamHttpRequestMethod(): string;
    set iamHttpRequestMethod(value: string);
    resetIamHttpRequestMethod(): void;
    get iamHttpRequestMethodInput(): string | undefined;
    private _iamRequestBody?;
    get iamRequestBody(): string;
    set iamRequestBody(value: string);
    resetIamRequestBody(): void;
    get iamRequestBodyInput(): string | undefined;
    private _iamRequestHeaders?;
    get iamRequestHeaders(): string;
    set iamRequestHeaders(value: string);
    resetIamRequestHeaders(): void;
    get iamRequestHeadersInput(): string | undefined;
    private _iamRequestUrl?;
    get iamRequestUrl(): string;
    set iamRequestUrl(value: string);
    resetIamRequestUrl(): void;
    get iamRequestUrlInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identity?;
    get identity(): string;
    set identity(value: string);
    resetIdentity(): void;
    get identityInput(): string | undefined;
    get leaseDuration(): number;
    get leaseStartTime(): string;
    private _metadata;
    get metadata(): cdktn.StringMap;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _nonce?;
    get nonce(): string;
    set nonce(value: string);
    resetNonce(): void;
    get nonceInput(): string | undefined;
    private _pkcs7?;
    get pkcs7(): string;
    set pkcs7(value: string);
    resetPkcs7(): void;
    get pkcs7Input(): string | undefined;
    get policies(): string[];
    get renewable(): cdktn.IResolvable;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
    private _signature?;
    get signature(): string;
    set signature(value: string);
    resetSignature(): void;
    get signatureInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

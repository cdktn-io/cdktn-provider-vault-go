/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PkiSecretBackendConfigEstConfig extends cdktn.TerraformMetaArguments {
    /**
    * Fields parsed from the CSR that appear in the audit and can be used by sentinel policies
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_config_est#audit_fields PkiSecretBackendConfigEst#audit_fields}
    */
    readonly auditFields?: string[];
    /**
    * The PKI secret backend the resource belongs to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_config_est#backend PkiSecretBackendConfigEst#backend}
    */
    readonly backend: string;
    /**
    * If set, this mount will register the default `.well-known/est` URL path. Only a single mount can enable this across a Vault cluster
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_config_est#default_mount PkiSecretBackendConfigEst#default_mount}
    */
    readonly defaultMount?: boolean | cdktn.IResolvable;
    /**
    * Required to be set if default_mount is enabled. Specifies the behavior for requests using the default EST label. Can be sign-verbatim or a role given by role:<role_name>
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_config_est#default_path_policy PkiSecretBackendConfigEst#default_path_policy}
    */
    readonly defaultPathPolicy?: string;
    /**
    * If set, parse out fields from the provided CSR making them available for Sentinel policies
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_config_est#enable_sentinel_parsing PkiSecretBackendConfigEst#enable_sentinel_parsing}
    */
    readonly enableSentinelParsing?: boolean | cdktn.IResolvable;
    /**
    * Specifies whether EST is enabled
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_config_est#enabled PkiSecretBackendConfigEst#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_config_est#id PkiSecretBackendConfigEst#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Configures a pairing of an EST label with the redirected behavior for requests hitting that role. The path policy can be sign-verbatim or a role given by role:<role_name>. Labels must be unique across Vault cluster, and will register .well-known/est/<label> URL paths
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_config_est#label_to_path_policy PkiSecretBackendConfigEst#label_to_path_policy}
    */
    readonly labelToPathPolicy?: {
        [key: string]: string;
    };
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_config_est#namespace PkiSecretBackendConfigEst#namespace}
    */
    readonly namespace?: string;
    /**
    * authenticators block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_config_est#authenticators PkiSecretBackendConfigEst#authenticators}
    */
    readonly authenticators?: PkiSecretBackendConfigEstAuthenticators;
}
export interface PkiSecretBackendConfigEstAuthenticators {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_config_est#cert PkiSecretBackendConfigEst#cert}
    */
    readonly cert?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_config_est#userpass PkiSecretBackendConfigEst#userpass}
    */
    readonly userpass?: {
        [key: string]: string;
    };
}
export declare function pkiSecretBackendConfigEstAuthenticatorsToTerraform(struct?: PkiSecretBackendConfigEstAuthenticatorsOutputReference | PkiSecretBackendConfigEstAuthenticators): any;
export declare function pkiSecretBackendConfigEstAuthenticatorsToHclTerraform(struct?: PkiSecretBackendConfigEstAuthenticatorsOutputReference | PkiSecretBackendConfigEstAuthenticators): any;
export declare class PkiSecretBackendConfigEstAuthenticatorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PkiSecretBackendConfigEstAuthenticators | undefined;
    set internalValue(value: PkiSecretBackendConfigEstAuthenticators | undefined);
    private _cert?;
    get cert(): {
        [key: string]: string;
    };
    set cert(value: {
        [key: string]: string;
    });
    resetCert(): void;
    get certInput(): {
        [key: string]: string;
    } | undefined;
    private _userpass?;
    get userpass(): {
        [key: string]: string;
    };
    set userpass(value: {
        [key: string]: string;
    });
    resetUserpass(): void;
    get userpassInput(): {
        [key: string]: string;
    } | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_config_est vault_pki_secret_backend_config_est}
*/
export declare class PkiSecretBackendConfigEst extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_pki_secret_backend_config_est";
    /**
    * Generates CDKTN code for importing a PkiSecretBackendConfigEst resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PkiSecretBackendConfigEst to import
    * @param importFromId The id of the existing PkiSecretBackendConfigEst that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_config_est#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PkiSecretBackendConfigEst to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_config_est vault_pki_secret_backend_config_est} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PkiSecretBackendConfigEstConfig
    */
    constructor(scope: Construct, id: string, config: PkiSecretBackendConfigEstConfig);
    private _auditFields?;
    get auditFields(): string[];
    set auditFields(value: string[]);
    resetAuditFields(): void;
    get auditFieldsInput(): string[] | undefined;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    private _defaultMount?;
    get defaultMount(): boolean | cdktn.IResolvable;
    set defaultMount(value: boolean | cdktn.IResolvable);
    resetDefaultMount(): void;
    get defaultMountInput(): boolean | cdktn.IResolvable | undefined;
    private _defaultPathPolicy?;
    get defaultPathPolicy(): string;
    set defaultPathPolicy(value: string);
    resetDefaultPathPolicy(): void;
    get defaultPathPolicyInput(): string | undefined;
    private _enableSentinelParsing?;
    get enableSentinelParsing(): boolean | cdktn.IResolvable;
    set enableSentinelParsing(value: boolean | cdktn.IResolvable);
    resetEnableSentinelParsing(): void;
    get enableSentinelParsingInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labelToPathPolicy?;
    get labelToPathPolicy(): {
        [key: string]: string;
    };
    set labelToPathPolicy(value: {
        [key: string]: string;
    });
    resetLabelToPathPolicy(): void;
    get labelToPathPolicyInput(): {
        [key: string]: string;
    } | undefined;
    get lastUpdated(): string;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _authenticators;
    get authenticators(): PkiSecretBackendConfigEstAuthenticatorsOutputReference;
    putAuthenticators(value: PkiSecretBackendConfigEstAuthenticators): void;
    resetAuthenticators(): void;
    get authenticatorsInput(): PkiSecretBackendConfigEstAuthenticators | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PkiSecretBackendCertConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of alternative names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#alt_names PkiSecretBackendCert#alt_names}
    */
    readonly altNames?: string[];
    /**
    * If enabled, a new certificate will be generated if the expiration is within min_seconds_remaining
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#auto_renew PkiSecretBackendCert#auto_renew}
    */
    readonly autoRenew?: boolean | cdktn.IResolvable;
    /**
    * The PKI secret backend the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#backend PkiSecretBackendCert#backend}
    */
    readonly backend: string;
    /**
    * A base 64 encoded value or an empty string to associate with the certificate's serial number. The role's no_store_metadata must be set to false, otherwise an error is returned when specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#cert_metadata PkiSecretBackendCert#cert_metadata}
    */
    readonly certMetadata?: string;
    /**
    * CN of the certificate to create.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#common_name PkiSecretBackendCert#common_name}
    */
    readonly commonName: string;
    /**
    * Flag to exclude CN from SANs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#exclude_cn_from_sans PkiSecretBackendCert#exclude_cn_from_sans}
    */
    readonly excludeCnFromSans?: boolean | cdktn.IResolvable;
    /**
    * The format of data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#format PkiSecretBackendCert#format}
    */
    readonly format?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#id PkiSecretBackendCert#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * List of alternative IPs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#ip_sans PkiSecretBackendCert#ip_sans}
    */
    readonly ipSans?: string[];
    /**
    * Specifies the default issuer of this request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#issuer_ref PkiSecretBackendCert#issuer_ref}
    */
    readonly issuerRef?: string;
    /**
    * Generate a new certificate when the expiration is within this number of seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#min_seconds_remaining PkiSecretBackendCert#min_seconds_remaining}
    */
    readonly minSecondsRemaining?: number;
    /**
    * Name of the role to create the certificate against.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#name PkiSecretBackendCert#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#namespace PkiSecretBackendCert#namespace}
    */
    readonly namespace?: string;
    /**
    * Set the Not After field of the certificate with specified date value. The value format should be given in UTC format YYYY-MM-ddTHH:MM:SSZ. Supports the Y10K end date for IEEE 802.1AR-2018 standard devices, 9999-12-31T23:59:59Z.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#not_after PkiSecretBackendCert#not_after}
    */
    readonly notAfter?: string;
    /**
    * List of other SANs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#other_sans PkiSecretBackendCert#other_sans}
    */
    readonly otherSans?: string[];
    /**
    * The private key format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#private_key_format PkiSecretBackendCert#private_key_format}
    */
    readonly privateKeyFormat?: string;
    /**
    * If true, the returned ca_chain field will not include any self-signed CA certificates. Useful if end-users already have the root CA in their trust store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#remove_roots_from_chain PkiSecretBackendCert#remove_roots_from_chain}
    */
    readonly removeRootsFromChain?: boolean | cdktn.IResolvable;
    /**
    * Revoke the certificate upon resource destruction.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#revoke PkiSecretBackendCert#revoke}
    */
    readonly revoke?: boolean | cdktn.IResolvable;
    /**
    * Revoke the certificate with private key method upon resource destruction.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#revoke_with_key PkiSecretBackendCert#revoke_with_key}
    */
    readonly revokeWithKey?: boolean | cdktn.IResolvable;
    /**
    * Time to live.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#ttl PkiSecretBackendCert#ttl}
    */
    readonly ttl?: string;
    /**
    * List of alternative URIs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#uri_sans PkiSecretBackendCert#uri_sans}
    */
    readonly uriSans?: string[];
    /**
    * List of Subject User IDs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#user_ids PkiSecretBackendCert#user_ids}
    */
    readonly userIds?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert vault_pki_secret_backend_cert}
*/
export declare class PkiSecretBackendCert extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_pki_secret_backend_cert";
    /**
    * Generates CDKTN code for importing a PkiSecretBackendCert resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PkiSecretBackendCert to import
    * @param importFromId The id of the existing PkiSecretBackendCert that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PkiSecretBackendCert to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/pki_secret_backend_cert vault_pki_secret_backend_cert} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PkiSecretBackendCertConfig
    */
    constructor(scope: Construct, id: string, config: PkiSecretBackendCertConfig);
    private _altNames?;
    get altNames(): string[];
    set altNames(value: string[]);
    resetAltNames(): void;
    get altNamesInput(): string[] | undefined;
    private _autoRenew?;
    get autoRenew(): boolean | cdktn.IResolvable;
    set autoRenew(value: boolean | cdktn.IResolvable);
    resetAutoRenew(): void;
    get autoRenewInput(): boolean | cdktn.IResolvable | undefined;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    get caChain(): string;
    private _certMetadata?;
    get certMetadata(): string;
    set certMetadata(value: string);
    resetCertMetadata(): void;
    get certMetadataInput(): string | undefined;
    get certificate(): string;
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    get commonNameInput(): string | undefined;
    private _excludeCnFromSans?;
    get excludeCnFromSans(): boolean | cdktn.IResolvable;
    set excludeCnFromSans(value: boolean | cdktn.IResolvable);
    resetExcludeCnFromSans(): void;
    get excludeCnFromSansInput(): boolean | cdktn.IResolvable | undefined;
    get expiration(): number;
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipSans?;
    get ipSans(): string[];
    set ipSans(value: string[]);
    resetIpSans(): void;
    get ipSansInput(): string[] | undefined;
    private _issuerRef?;
    get issuerRef(): string;
    set issuerRef(value: string);
    resetIssuerRef(): void;
    get issuerRefInput(): string | undefined;
    get issuingCa(): string;
    private _minSecondsRemaining?;
    get minSecondsRemaining(): number;
    set minSecondsRemaining(value: number);
    resetMinSecondsRemaining(): void;
    get minSecondsRemainingInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _notAfter?;
    get notAfter(): string;
    set notAfter(value: string);
    resetNotAfter(): void;
    get notAfterInput(): string | undefined;
    private _otherSans?;
    get otherSans(): string[];
    set otherSans(value: string[]);
    resetOtherSans(): void;
    get otherSansInput(): string[] | undefined;
    get privateKey(): string;
    private _privateKeyFormat?;
    get privateKeyFormat(): string;
    set privateKeyFormat(value: string);
    resetPrivateKeyFormat(): void;
    get privateKeyFormatInput(): string | undefined;
    get privateKeyType(): string;
    private _removeRootsFromChain?;
    get removeRootsFromChain(): boolean | cdktn.IResolvable;
    set removeRootsFromChain(value: boolean | cdktn.IResolvable);
    resetRemoveRootsFromChain(): void;
    get removeRootsFromChainInput(): boolean | cdktn.IResolvable | undefined;
    get renewPending(): cdktn.IResolvable;
    private _revoke?;
    get revoke(): boolean | cdktn.IResolvable;
    set revoke(value: boolean | cdktn.IResolvable);
    resetRevoke(): void;
    get revokeInput(): boolean | cdktn.IResolvable | undefined;
    private _revokeWithKey?;
    get revokeWithKey(): boolean | cdktn.IResolvable;
    set revokeWithKey(value: boolean | cdktn.IResolvable);
    resetRevokeWithKey(): void;
    get revokeWithKeyInput(): boolean | cdktn.IResolvable | undefined;
    get serialNumber(): string;
    private _ttl?;
    get ttl(): string;
    set ttl(value: string);
    resetTtl(): void;
    get ttlInput(): string | undefined;
    private _uriSans?;
    get uriSans(): string[];
    set uriSans(value: string[]);
    resetUriSans(): void;
    get uriSansInput(): string[] | undefined;
    private _userIds?;
    get userIds(): string[];
    set userIds(value: string[]);
    resetUserIds(): void;
    get userIdsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConfigUiHeaderConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the custom header. Cannot start with `X-Vault-`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/config_ui_header#name ConfigUiHeader#name}
    */
    readonly name: string;
    /**
    * Set of values for the header. At least one value is required. Duplicates are automatically ignored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/config_ui_header#values ConfigUiHeader#values}
    */
    readonly values: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/config_ui_header vault_config_ui_header}
*/
export declare class ConfigUiHeader extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_config_ui_header";
    /**
    * Generates CDKTN code for importing a ConfigUiHeader resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConfigUiHeader to import
    * @param importFromId The id of the existing ConfigUiHeader that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/config_ui_header#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConfigUiHeader to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/config_ui_header vault_config_ui_header} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConfigUiHeaderConfig
    */
    constructor(scope: Construct, id: string, config: ConfigUiHeaderConfig);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

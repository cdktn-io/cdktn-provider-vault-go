/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PkiSecretBackendConfigAcmeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies whether the ExtKeyUsage field from a role is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_acme#allow_role_ext_key_usage PkiSecretBackendConfigAcme#allow_role_ext_key_usage}
    */
    readonly allowRoleExtKeyUsage?: boolean | cdktn.IResolvable;
    /**
    * Specifies which issuers are allowed for use with ACME.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_acme#allowed_issuers PkiSecretBackendConfigAcme#allowed_issuers}
    */
    readonly allowedIssuers?: string[];
    /**
    * Specifies which roles are allowed for use with ACME.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_acme#allowed_roles PkiSecretBackendConfigAcme#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * Full path where PKI backend is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_acme#backend PkiSecretBackendConfigAcme#backend}
    */
    readonly backend: string;
    /**
    * Specifies the excluded IP ranges for ACME challenge workers to connect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_acme#challenge_excluded_ip_ranges PkiSecretBackendConfigAcme#challenge_excluded_ip_ranges}
    */
    readonly challengeExcludedIpRanges?: string[];
    /**
    * Specifies the permitted IP ranges for ACME challenge workers to connect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_acme#challenge_permitted_ip_ranges PkiSecretBackendConfigAcme#challenge_permitted_ip_ranges}
    */
    readonly challengePermittedIpRanges?: string[];
    /**
    * Specifies the policy to be used for non-role-qualified ACME requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_acme#default_directory_policy PkiSecretBackendConfigAcme#default_directory_policy}
    */
    readonly defaultDirectoryPolicy?: string;
    /**
    * DNS resolver to use for domain resolution on this mount. Must be in the format <host>:<port>, with both parts mandatory.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_acme#dns_resolver PkiSecretBackendConfigAcme#dns_resolver}
    */
    readonly dnsResolver?: string;
    /**
    * Specifies the policy to use for external account binding behaviour.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_acme#eab_policy PkiSecretBackendConfigAcme#eab_policy}
    */
    readonly eabPolicy?: string;
    /**
    * Specifies whether ACME is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_acme#enabled PkiSecretBackendConfigAcme#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_acme#id PkiSecretBackendConfigAcme#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the maximum TTL in seconds for certificates issued by ACME.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_acme#max_ttl PkiSecretBackendConfigAcme#max_ttl}
    */
    readonly maxTtl?: number;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_acme#namespace PkiSecretBackendConfigAcme#namespace}
    */
    readonly namespace?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_acme vault_pki_secret_backend_config_acme}
*/
export declare class PkiSecretBackendConfigAcme extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_pki_secret_backend_config_acme";
    /**
    * Generates CDKTN code for importing a PkiSecretBackendConfigAcme resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PkiSecretBackendConfigAcme to import
    * @param importFromId The id of the existing PkiSecretBackendConfigAcme that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_acme#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PkiSecretBackendConfigAcme to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_acme vault_pki_secret_backend_config_acme} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PkiSecretBackendConfigAcmeConfig
    */
    constructor(scope: Construct, id: string, config: PkiSecretBackendConfigAcmeConfig);
    private _allowRoleExtKeyUsage?;
    get allowRoleExtKeyUsage(): boolean | cdktn.IResolvable;
    set allowRoleExtKeyUsage(value: boolean | cdktn.IResolvable);
    resetAllowRoleExtKeyUsage(): void;
    get allowRoleExtKeyUsageInput(): boolean | cdktn.IResolvable | undefined;
    private _allowedIssuers?;
    get allowedIssuers(): string[];
    set allowedIssuers(value: string[]);
    resetAllowedIssuers(): void;
    get allowedIssuersInput(): string[] | undefined;
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    private _challengeExcludedIpRanges?;
    get challengeExcludedIpRanges(): string[];
    set challengeExcludedIpRanges(value: string[]);
    resetChallengeExcludedIpRanges(): void;
    get challengeExcludedIpRangesInput(): string[] | undefined;
    private _challengePermittedIpRanges?;
    get challengePermittedIpRanges(): string[];
    set challengePermittedIpRanges(value: string[]);
    resetChallengePermittedIpRanges(): void;
    get challengePermittedIpRangesInput(): string[] | undefined;
    private _defaultDirectoryPolicy?;
    get defaultDirectoryPolicy(): string;
    set defaultDirectoryPolicy(value: string);
    resetDefaultDirectoryPolicy(): void;
    get defaultDirectoryPolicyInput(): string | undefined;
    private _dnsResolver?;
    get dnsResolver(): string;
    set dnsResolver(value: string);
    resetDnsResolver(): void;
    get dnsResolverInput(): string | undefined;
    private _eabPolicy?;
    get eabPolicy(): string;
    set eabPolicy(value: string);
    resetEabPolicy(): void;
    get eabPolicyInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxTtl?;
    get maxTtl(): number;
    set maxTtl(value: number);
    resetMaxTtl(): void;
    get maxTtlInput(): number | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultActivationFlagsConfig extends cdktn.TerraformMetaArguments {
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/activation_flags vault_activation_flags}
*/
export declare class DataVaultActivationFlags extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_activation_flags";
    /**
    * Generates CDKTN code for importing a DataVaultActivationFlags resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultActivationFlags to import
    * @param importFromId The id of the existing DataVaultActivationFlags that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/activation_flags#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultActivationFlags to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/activation_flags vault_activation_flags} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultActivationFlagsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataVaultActivationFlagsConfig);
    get activatedFlags(): string[];
    get id(): string;
    get unactivatedFlags(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

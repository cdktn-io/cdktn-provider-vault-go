/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AlicloudSecretBackendRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The maximum allowed lifetime of credentials issued using this role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/alicloud_secret_backend_role#max_ttl AlicloudSecretBackendRole#max_ttl}
    */
    readonly maxTtl?: number;
    /**
    * Path of the AliCloud Secret Backend the role belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/alicloud_secret_backend_role#mount AlicloudSecretBackendRole#mount}
    */
    readonly mount: string;
    /**
    * Name of the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/alicloud_secret_backend_role#name AlicloudSecretBackendRole#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/alicloud_secret_backend_role#namespace AlicloudSecretBackendRole#namespace}
    */
    readonly namespace?: string;
    /**
    * ARN of the RAM role to assume. If provided, inline_policies and remote_policies should be blank. The trusted principal of the role must be configured to allow assumption by the access key and secret configured in the backend.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/alicloud_secret_backend_role#role_arn AlicloudSecretBackendRole#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Duration in seconds after which the issued credentials should expire. Defaults to 0, in which case the value will fallback to the system/mount defaults.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/alicloud_secret_backend_role#ttl AlicloudSecretBackendRole#ttl}
    */
    readonly ttl?: number;
    /**
    * inline_policies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/alicloud_secret_backend_role#inline_policies AlicloudSecretBackendRole#inline_policies}
    */
    readonly inlinePolicies?: AlicloudSecretBackendRoleInlinePolicies[] | cdktn.IResolvable;
    /**
    * remote_policies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/alicloud_secret_backend_role#remote_policies AlicloudSecretBackendRole#remote_policies}
    */
    readonly remotePolicies?: AlicloudSecretBackendRoleRemotePolicies[] | cdktn.IResolvable;
}
export interface AlicloudSecretBackendRoleInlinePolicies {
    /**
    * JSON-encoded inline policy document.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/alicloud_secret_backend_role#policy_document AlicloudSecretBackendRole#policy_document}
    */
    readonly policyDocument: string;
}
export declare function alicloudSecretBackendRoleInlinePoliciesToTerraform(struct?: AlicloudSecretBackendRoleInlinePolicies | cdktn.IResolvable): any;
export declare function alicloudSecretBackendRoleInlinePoliciesToHclTerraform(struct?: AlicloudSecretBackendRoleInlinePolicies | cdktn.IResolvable): any;
export declare class AlicloudSecretBackendRoleInlinePoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlicloudSecretBackendRoleInlinePolicies | cdktn.IResolvable | undefined;
    set internalValue(value: AlicloudSecretBackendRoleInlinePolicies | cdktn.IResolvable | undefined);
    private _policyDocument?;
    get policyDocument(): string;
    set policyDocument(value: string);
    get policyDocumentInput(): string | undefined;
}
export declare class AlicloudSecretBackendRoleInlinePoliciesList extends cdktn.ComplexList {
    internalValue?: AlicloudSecretBackendRoleInlinePolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlicloudSecretBackendRoleInlinePoliciesOutputReference;
}
export interface AlicloudSecretBackendRoleRemotePolicies {
    /**
    * Name of the remote policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/alicloud_secret_backend_role#name AlicloudSecretBackendRole#name}
    */
    readonly name: string;
    /**
    * Type of the remote policy (System or Custom).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/alicloud_secret_backend_role#type AlicloudSecretBackendRole#type}
    */
    readonly type: string;
}
export declare function alicloudSecretBackendRoleRemotePoliciesToTerraform(struct?: AlicloudSecretBackendRoleRemotePolicies | cdktn.IResolvable): any;
export declare function alicloudSecretBackendRoleRemotePoliciesToHclTerraform(struct?: AlicloudSecretBackendRoleRemotePolicies | cdktn.IResolvable): any;
export declare class AlicloudSecretBackendRoleRemotePoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlicloudSecretBackendRoleRemotePolicies | cdktn.IResolvable | undefined;
    set internalValue(value: AlicloudSecretBackendRoleRemotePolicies | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class AlicloudSecretBackendRoleRemotePoliciesList extends cdktn.ComplexList {
    internalValue?: AlicloudSecretBackendRoleRemotePolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlicloudSecretBackendRoleRemotePoliciesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/alicloud_secret_backend_role vault_alicloud_secret_backend_role}
*/
export declare class AlicloudSecretBackendRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_alicloud_secret_backend_role";
    /**
    * Generates CDKTN code for importing a AlicloudSecretBackendRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlicloudSecretBackendRole to import
    * @param importFromId The id of the existing AlicloudSecretBackendRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/alicloud_secret_backend_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlicloudSecretBackendRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/alicloud_secret_backend_role vault_alicloud_secret_backend_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlicloudSecretBackendRoleConfig
    */
    constructor(scope: Construct, id: string, config: AlicloudSecretBackendRoleConfig);
    private _maxTtl?;
    get maxTtl(): number;
    set maxTtl(value: number);
    resetMaxTtl(): void;
    get maxTtlInput(): number | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
    private _inlinePolicies;
    get inlinePolicies(): AlicloudSecretBackendRoleInlinePoliciesList;
    putInlinePolicies(value: AlicloudSecretBackendRoleInlinePolicies[] | cdktn.IResolvable): void;
    resetInlinePolicies(): void;
    get inlinePoliciesInput(): cdktn.IResolvable | AlicloudSecretBackendRoleInlinePolicies[] | undefined;
    private _remotePolicies;
    get remotePolicies(): AlicloudSecretBackendRoleRemotePoliciesList;
    putRemotePolicies(value: AlicloudSecretBackendRoleRemotePolicies[] | cdktn.IResolvable): void;
    resetRemotePolicies(): void;
    get remotePoliciesInput(): cdktn.IResolvable | AlicloudSecretBackendRoleRemotePolicies[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

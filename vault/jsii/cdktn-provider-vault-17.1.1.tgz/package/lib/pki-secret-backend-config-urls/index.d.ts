/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PkiSecretBackendConfigUrlsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The path of the PKI secret backend the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_urls#backend PkiSecretBackendConfigUrls#backend}
    */
    readonly backend: string;
    /**
    * Specifies the URL values for the CRL Distribution Points field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_urls#crl_distribution_points PkiSecretBackendConfigUrls#crl_distribution_points}
    */
    readonly crlDistributionPoints?: string[];
    /**
    * Specifies that templating of AIA fields is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_urls#enable_templating PkiSecretBackendConfigUrls#enable_templating}
    */
    readonly enableTemplating?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_urls#id PkiSecretBackendConfigUrls#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the URL values for the Issuing Certificate field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_urls#issuing_certificates PkiSecretBackendConfigUrls#issuing_certificates}
    */
    readonly issuingCertificates?: string[];
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_urls#namespace PkiSecretBackendConfigUrls#namespace}
    */
    readonly namespace?: string;
    /**
    * Specifies the URL values for the OCSP Servers field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_urls#ocsp_servers PkiSecretBackendConfigUrls#ocsp_servers}
    */
    readonly ocspServers?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_urls vault_pki_secret_backend_config_urls}
*/
export declare class PkiSecretBackendConfigUrls extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_pki_secret_backend_config_urls";
    /**
    * Generates CDKTN code for importing a PkiSecretBackendConfigUrls resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PkiSecretBackendConfigUrls to import
    * @param importFromId The id of the existing PkiSecretBackendConfigUrls that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_urls#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PkiSecretBackendConfigUrls to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_urls vault_pki_secret_backend_config_urls} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PkiSecretBackendConfigUrlsConfig
    */
    constructor(scope: Construct, id: string, config: PkiSecretBackendConfigUrlsConfig);
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    private _crlDistributionPoints?;
    get crlDistributionPoints(): string[];
    set crlDistributionPoints(value: string[]);
    resetCrlDistributionPoints(): void;
    get crlDistributionPointsInput(): string[] | undefined;
    private _enableTemplating?;
    get enableTemplating(): boolean | cdktn.IResolvable;
    set enableTemplating(value: boolean | cdktn.IResolvable);
    resetEnableTemplating(): void;
    get enableTemplatingInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _issuingCertificates?;
    get issuingCertificates(): string[];
    set issuingCertificates(value: string[]);
    resetIssuingCertificates(): void;
    get issuingCertificatesInput(): string[] | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _ocspServers?;
    get ocspServers(): string[];
    set ocspServers(value: string[]);
    resetOcspServers(): void;
    get ocspServersInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

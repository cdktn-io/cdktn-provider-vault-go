/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IdentityOidcProviderConfig extends cdktn.TerraformMetaArguments {
    /**
    * The client IDs that are permitted to use the provider. If empty, no clients are allowed. If "*", all clients are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/identity_oidc_provider#allowed_client_ids IdentityOidcProvider#allowed_client_ids}
    */
    readonly allowedClientIds?: string[];
    /**
    * Set to true if the issuer endpoint uses HTTPS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/identity_oidc_provider#https_enabled IdentityOidcProvider#https_enabled}
    */
    readonly httpsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/identity_oidc_provider#id IdentityOidcProvider#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The host for the issuer. Can be either host or host:port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/identity_oidc_provider#issuer_host IdentityOidcProvider#issuer_host}
    */
    readonly issuerHost?: string;
    /**
    * The name of the provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/identity_oidc_provider#name IdentityOidcProvider#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/identity_oidc_provider#namespace IdentityOidcProvider#namespace}
    */
    readonly namespace?: string;
    /**
    * The scopes available for requesting on the provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/identity_oidc_provider#scopes_supported IdentityOidcProvider#scopes_supported}
    */
    readonly scopesSupported?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/identity_oidc_provider vault_identity_oidc_provider}
*/
export declare class IdentityOidcProvider extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_identity_oidc_provider";
    /**
    * Generates CDKTN code for importing a IdentityOidcProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IdentityOidcProvider to import
    * @param importFromId The id of the existing IdentityOidcProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/identity_oidc_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IdentityOidcProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/identity_oidc_provider vault_identity_oidc_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IdentityOidcProviderConfig
    */
    constructor(scope: Construct, id: string, config: IdentityOidcProviderConfig);
    private _allowedClientIds?;
    get allowedClientIds(): string[];
    set allowedClientIds(value: string[]);
    resetAllowedClientIds(): void;
    get allowedClientIdsInput(): string[] | undefined;
    private _httpsEnabled?;
    get httpsEnabled(): boolean | cdktn.IResolvable;
    set httpsEnabled(value: boolean | cdktn.IResolvable);
    resetHttpsEnabled(): void;
    get httpsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get issuer(): string;
    private _issuerHost?;
    get issuerHost(): string;
    set issuerHost(value: string);
    resetIssuerHost(): void;
    get issuerHostInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _scopesSupported?;
    get scopesSupported(): string[];
    set scopesSupported(value: string[]);
    resetScopesSupported(): void;
    get scopesSupportedInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

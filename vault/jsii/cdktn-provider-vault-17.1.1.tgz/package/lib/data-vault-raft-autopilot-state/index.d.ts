/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultRaftAutopilotStateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/raft_autopilot_state#id DataVaultRaftAutopilotState#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/raft_autopilot_state#namespace DataVaultRaftAutopilotState#namespace}
    */
    readonly namespace?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/raft_autopilot_state vault_raft_autopilot_state}
*/
export declare class DataVaultRaftAutopilotState extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_raft_autopilot_state";
    /**
    * Generates CDKTN code for importing a DataVaultRaftAutopilotState resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultRaftAutopilotState to import
    * @param importFromId The id of the existing DataVaultRaftAutopilotState that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/raft_autopilot_state#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultRaftAutopilotState to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/raft_autopilot_state vault_raft_autopilot_state} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultRaftAutopilotStateConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataVaultRaftAutopilotStateConfig);
    get failureTolerance(): number;
    get healthy(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get leader(): string;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get optimisticFailureTolerance(): number;
    private _redundancyZones;
    get redundancyZones(): cdktn.StringMap;
    get redundancyZonesJson(): string;
    private _servers;
    get servers(): cdktn.StringMap;
    get serversJson(): string;
    private _upgradeInfo;
    get upgradeInfo(): cdktn.StringMap;
    get upgradeInfoJson(): string;
    get voters(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultNamespacesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/namespaces#id DataVaultNamespaces#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/namespaces#namespace DataVaultNamespaces#namespace}
    */
    readonly namespace?: string;
    /**
    * True to fetch all child namespaces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/namespaces#recursive DataVaultNamespaces#recursive}
    */
    readonly recursive?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/namespaces vault_namespaces}
*/
export declare class DataVaultNamespaces extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_namespaces";
    /**
    * Generates CDKTN code for importing a DataVaultNamespaces resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultNamespaces to import
    * @param importFromId The id of the existing DataVaultNamespaces that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/namespaces#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultNamespaces to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/namespaces vault_namespaces} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultNamespacesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataVaultNamespacesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get paths(): string[];
    get pathsFq(): string[];
    private _recursive?;
    get recursive(): boolean | cdktn.IResolvable;
    set recursive(value: boolean | cdktn.IResolvable);
    resetRecursive(): void;
    get recursiveInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

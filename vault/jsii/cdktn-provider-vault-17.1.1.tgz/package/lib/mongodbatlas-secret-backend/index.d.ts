/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MongodbatlasSecretBackendConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_backend#id MongodbatlasSecretBackend#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Path where MongoDB Atlas secret backend is mounted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_backend#mount MongodbatlasSecretBackend#mount}
    */
    readonly mount: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_backend#namespace MongodbatlasSecretBackend#namespace}
    */
    readonly namespace?: string;
    /**
    * The Private Programmatic API Key used to connect with MongoDB Atlas API
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_backend#private_key MongodbatlasSecretBackend#private_key}
    */
    readonly privateKey?: string;
    /**
    * The Private Programmatic API Key used to connect with MongoDB Atlas API. This is a write-only field that is not stored in state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_backend#private_key_wo MongodbatlasSecretBackend#private_key_wo}
    */
    readonly privateKeyWo?: string;
    /**
    * Incrementing version counter for the private_key_wo field. Increment to force an update to the private key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_backend#private_key_wo_version MongodbatlasSecretBackend#private_key_wo_version}
    */
    readonly privateKeyWoVersion?: number;
    /**
    * The Public Programmatic API Key used to authenticate with the MongoDB Atlas API
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_backend#public_key MongodbatlasSecretBackend#public_key}
    */
    readonly publicKey: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_backend vault_mongodbatlas_secret_backend}
*/
export declare class MongodbatlasSecretBackend extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_mongodbatlas_secret_backend";
    /**
    * Generates CDKTN code for importing a MongodbatlasSecretBackend resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MongodbatlasSecretBackend to import
    * @param importFromId The id of the existing MongodbatlasSecretBackend that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_backend#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MongodbatlasSecretBackend to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_backend vault_mongodbatlas_secret_backend} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MongodbatlasSecretBackendConfig
    */
    constructor(scope: Construct, id: string, config: MongodbatlasSecretBackendConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get path(): string;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    resetPrivateKey(): void;
    get privateKeyInput(): string | undefined;
    private _privateKeyWo?;
    get privateKeyWo(): string;
    set privateKeyWo(value: string);
    resetPrivateKeyWo(): void;
    get privateKeyWoInput(): string | undefined;
    private _privateKeyWoVersion?;
    get privateKeyWoVersion(): number;
    set privateKeyWoVersion(value: number);
    resetPrivateKeyWoVersion(): void;
    get privateKeyWoVersionInput(): number | undefined;
    private _publicKey?;
    get publicKey(): string;
    set publicKey(value: string);
    get publicKeyInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

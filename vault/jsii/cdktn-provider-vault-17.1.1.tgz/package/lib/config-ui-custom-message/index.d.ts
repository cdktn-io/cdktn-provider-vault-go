/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConfigUiCustomMessageConfig extends cdktn.TerraformMetaArguments {
    /**
    * A flag indicating whether the custom message is displayed pre-login (false) or post-login (true)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/config_ui_custom_message#authenticated ConfigUiCustomMessage#authenticated}
    */
    readonly authenticated?: boolean | cdktn.IResolvable;
    /**
    * The ending time of the active period of the custom message. Can be omitted for non-expiring message
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/config_ui_custom_message#end_time ConfigUiCustomMessage#end_time}
    */
    readonly endTime?: string;
    /**
    * The base64-encoded content of the custom message
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/config_ui_custom_message#message_base64 ConfigUiCustomMessage#message_base64}
    */
    readonly messageBase64: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/config_ui_custom_message#namespace ConfigUiCustomMessage#namespace}
    */
    readonly namespace?: string;
    /**
    * A map containing additional options for the custom message
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/config_ui_custom_message#options ConfigUiCustomMessage#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * The starting time of the active period of the custom message
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/config_ui_custom_message#start_time ConfigUiCustomMessage#start_time}
    */
    readonly startTime: string;
    /**
    * The title of the custom message
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/config_ui_custom_message#title ConfigUiCustomMessage#title}
    */
    readonly title: string;
    /**
    * The display type of custom message. Allowed values are banner and modal
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/config_ui_custom_message#type ConfigUiCustomMessage#type}
    */
    readonly type?: string;
    /**
    * link block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/config_ui_custom_message#link ConfigUiCustomMessage#link}
    */
    readonly link?: ConfigUiCustomMessageLink;
}
export interface ConfigUiCustomMessageLink {
    /**
    * The URL of the hyperlink
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/config_ui_custom_message#href ConfigUiCustomMessage#href}
    */
    readonly href: string;
    /**
    * The title of the hyperlink
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/config_ui_custom_message#title ConfigUiCustomMessage#title}
    */
    readonly title: string;
}
export declare function configUiCustomMessageLinkToTerraform(struct?: ConfigUiCustomMessageLinkOutputReference | ConfigUiCustomMessageLink): any;
export declare function configUiCustomMessageLinkToHclTerraform(struct?: ConfigUiCustomMessageLinkOutputReference | ConfigUiCustomMessageLink): any;
export declare class ConfigUiCustomMessageLinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigUiCustomMessageLink | undefined;
    set internalValue(value: ConfigUiCustomMessageLink | undefined);
    private _href?;
    get href(): string;
    set href(value: string);
    get hrefInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/config_ui_custom_message vault_config_ui_custom_message}
*/
export declare class ConfigUiCustomMessage extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_config_ui_custom_message";
    /**
    * Generates CDKTN code for importing a ConfigUiCustomMessage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConfigUiCustomMessage to import
    * @param importFromId The id of the existing ConfigUiCustomMessage that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/config_ui_custom_message#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConfigUiCustomMessage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/config_ui_custom_message vault_config_ui_custom_message} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConfigUiCustomMessageConfig
    */
    constructor(scope: Construct, id: string, config: ConfigUiCustomMessageConfig);
    private _authenticated?;
    get authenticated(): boolean | cdktn.IResolvable;
    set authenticated(value: boolean | cdktn.IResolvable);
    resetAuthenticated(): void;
    get authenticatedInput(): boolean | cdktn.IResolvable | undefined;
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    resetEndTime(): void;
    get endTimeInput(): string | undefined;
    get id(): string;
    private _messageBase64?;
    get messageBase64(): string;
    set messageBase64(value: string);
    get messageBase64Input(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _link;
    get link(): ConfigUiCustomMessageLinkOutputReference;
    putLink(value: ConfigUiCustomMessageLink): void;
    resetLink(): void;
    get linkInput(): ConfigUiCustomMessageLink | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

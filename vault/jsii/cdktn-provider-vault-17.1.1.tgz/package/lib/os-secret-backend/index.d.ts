/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OsSecretBackendConfig extends cdktn.TerraformMetaArguments {
    /**
    * Maximum number of versions to keep for secrets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/os_secret_backend#max_versions OsSecretBackend#max_versions}
    */
    readonly maxVersions?: number;
    /**
    * Path where the OS secrets backend is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/os_secret_backend#mount OsSecretBackend#mount}
    */
    readonly mount: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/os_secret_backend#namespace OsSecretBackend#namespace}
    */
    readonly namespace?: string;
    /**
    * Trust SSH host keys on first use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/os_secret_backend#ssh_host_key_trust_on_first_use OsSecretBackend#ssh_host_key_trust_on_first_use}
    */
    readonly sshHostKeyTrustOnFirstUse?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/os_secret_backend vault_os_secret_backend}
*/
export declare class OsSecretBackend extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_os_secret_backend";
    /**
    * Generates CDKTN code for importing a OsSecretBackend resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OsSecretBackend to import
    * @param importFromId The id of the existing OsSecretBackend that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/os_secret_backend#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OsSecretBackend to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/os_secret_backend vault_os_secret_backend} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OsSecretBackendConfig
    */
    constructor(scope: Construct, id: string, config: OsSecretBackendConfig);
    private _maxVersions?;
    get maxVersions(): number;
    set maxVersions(value: number);
    resetMaxVersions(): void;
    get maxVersionsInput(): number | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _sshHostKeyTrustOnFirstUse?;
    get sshHostKeyTrustOnFirstUse(): boolean | cdktn.IResolvable;
    set sshHostKeyTrustOnFirstUse(value: boolean | cdktn.IResolvable);
    resetSshHostKeyTrustOnFirstUse(): void;
    get sshHostKeyTrustOnFirstUseInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

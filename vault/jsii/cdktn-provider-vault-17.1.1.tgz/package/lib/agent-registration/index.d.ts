/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AgentRegistrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of policy identifiers that define the authorization ceiling for this agent. Cannot include 'root' policy. Note: Vault automatically adds default policies (['default', 'default-ceiling']) unless no_default_ceiling_policy is true, but these are filtered out when reading the state to match your configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/agent_registration#ceiling_policies AgentRegistration#ceiling_policies}
    */
    readonly ceilingPolicies?: string[];
    /**
    * Detailed description of the agent's purpose.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/agent_registration#description AgentRegistration#description}
    */
    readonly description?: string;
    /**
    * Human-readable name for the agent registration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/agent_registration#display_name AgentRegistration#display_name}
    */
    readonly displayName: string;
    /**
    * Entity ID representing this agent. Each entity can only have one registration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/agent_registration#entity_id AgentRegistration#entity_id}
    */
    readonly entityId: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/agent_registration#namespace AgentRegistration#namespace}
    */
    readonly namespace?: string;
    /**
    * If true, opts out of automatically adding the default-ceiling policy to this agent registration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/agent_registration#no_default_ceiling_policy AgentRegistration#no_default_ceiling_policy}
    */
    readonly noDefaultCeilingPolicy?: boolean | cdktn.IResolvable;
    /**
    * When false, RAR (Rich Authorization Requests) is mandatory and authorization_details must be present in the token. When set to true, authorization_details in the JWT token are optional for this agent. This setting works in conjunction with the OAuth Resource Server profile's optional_authorization_details setting - RAR is optional if EITHER is true. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/agent_registration#optional_authorization_details AgentRegistration#optional_authorization_details}
    */
    readonly optionalAuthorizationDetails?: boolean | cdktn.IResolvable;
    /**
    * Owner of the agent registration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/agent_registration#owner AgentRegistration#owner}
    */
    readonly owner?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/agent_registration vault_agent_registration}
*/
export declare class AgentRegistration extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_agent_registration";
    /**
    * Generates CDKTN code for importing a AgentRegistration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AgentRegistration to import
    * @param importFromId The id of the existing AgentRegistration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/agent_registration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AgentRegistration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/agent_registration vault_agent_registration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AgentRegistrationConfig
    */
    constructor(scope: Construct, id: string, config: AgentRegistrationConfig);
    private _ceilingPolicies?;
    get ceilingPolicies(): string[];
    set ceilingPolicies(value: string[]);
    resetCeilingPolicies(): void;
    get ceilingPoliciesInput(): string[] | undefined;
    get creationTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _entityId?;
    get entityId(): string;
    set entityId(value: string);
    get entityIdInput(): string | undefined;
    get id(): string;
    get lastUpdatedTime(): string;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _noDefaultCeilingPolicy?;
    get noDefaultCeilingPolicy(): boolean | cdktn.IResolvable;
    set noDefaultCeilingPolicy(value: boolean | cdktn.IResolvable);
    resetNoDefaultCeilingPolicy(): void;
    get noDefaultCeilingPolicyInput(): boolean | cdktn.IResolvable | undefined;
    private _optionalAuthorizationDetails?;
    get optionalAuthorizationDetails(): boolean | cdktn.IResolvable;
    set optionalAuthorizationDetails(value: boolean | cdktn.IResolvable);
    resetOptionalAuthorizationDetails(): void;
    get optionalAuthorizationDetailsInput(): boolean | cdktn.IResolvable | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

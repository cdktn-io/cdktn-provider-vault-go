/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PkiSecretBackendRootCertConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of alternative names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#alt_names PkiSecretBackendRootCert#alt_names}
    */
    readonly altNames?: string[];
    /**
    * The PKI secret backend the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#backend PkiSecretBackendRootCert#backend}
    */
    readonly backend: string;
    /**
    * CN of root to create.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#common_name PkiSecretBackendRootCert#common_name}
    */
    readonly commonName: string;
    /**
    * The country.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#country PkiSecretBackendRootCert#country}
    */
    readonly country?: string;
    /**
    * Flag to exclude CN from SANs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#exclude_cn_from_sans PkiSecretBackendRootCert#exclude_cn_from_sans}
    */
    readonly excludeCnFromSans?: boolean | cdktn.IResolvable;
    /**
    * List of domains for which certificates are not allowed to be issued.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#excluded_dns_domains PkiSecretBackendRootCert#excluded_dns_domains}
    */
    readonly excludedDnsDomains?: string[];
    /**
    * List of email addresses for which certificates are not allowed to be issued.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#excluded_email_addresses PkiSecretBackendRootCert#excluded_email_addresses}
    */
    readonly excludedEmailAddresses?: string[];
    /**
    * List of IP ranges for which certificates are not allowed to be issued.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#excluded_ip_ranges PkiSecretBackendRootCert#excluded_ip_ranges}
    */
    readonly excludedIpRanges?: string[];
    /**
    * List of URI domains for which certificates are not allowed to be issued.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#excluded_uri_domains PkiSecretBackendRootCert#excluded_uri_domains}
    */
    readonly excludedUriDomains?: string[];
    /**
    * The format of data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#format PkiSecretBackendRootCert#format}
    */
    readonly format?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#id PkiSecretBackendRootCert#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * List of alternative IPs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#ip_sans PkiSecretBackendRootCert#ip_sans}
    */
    readonly ipSans?: string[];
    /**
    * Provides a name to the specified issuer. The name must be unique across all issuers and not be the reserved value 'default'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#issuer_name PkiSecretBackendRootCert#issuer_name}
    */
    readonly issuerName?: string;
    /**
    * The number of bits to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#key_bits PkiSecretBackendRootCert#key_bits}
    */
    readonly keyBits?: number;
    /**
    * When a new key is created with this request, optionally specifies the name for this.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#key_name PkiSecretBackendRootCert#key_name}
    */
    readonly keyName?: string;
    /**
    * Specifies the key to use for generating this request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#key_ref PkiSecretBackendRootCert#key_ref}
    */
    readonly keyRef?: string;
    /**
    * The desired key type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#key_type PkiSecretBackendRootCert#key_type}
    */
    readonly keyType?: string;
    /**
    * Specify the allowed key usage constraint on issued certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#key_usage PkiSecretBackendRootCert#key_usage}
    */
    readonly keyUsage?: string[];
    /**
    * The locality.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#locality PkiSecretBackendRootCert#locality}
    */
    readonly locality?: string;
    /**
    * The ID of the previously configured managed key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#managed_key_id PkiSecretBackendRootCert#managed_key_id}
    */
    readonly managedKeyId?: string;
    /**
    * The name of the previously configured managed key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#managed_key_name PkiSecretBackendRootCert#managed_key_name}
    */
    readonly managedKeyName?: string;
    /**
    * The maximum path length to encode in the generated certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#max_path_length PkiSecretBackendRootCert#max_path_length}
    */
    readonly maxPathLength?: number;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#namespace PkiSecretBackendRootCert#namespace}
    */
    readonly namespace?: string;
    /**
    * Set the Not After field of the certificate with specified date value. The value format should be given in UTC format YYYY-MM-ddTHH:MM:SSZ. Supports the Y10K end date for IEEE 802.1AR-2018 standard devices, 9999-12-31T23:59:59Z.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#not_after PkiSecretBackendRootCert#not_after}
    */
    readonly notAfter?: string;
    /**
    * Specifies the duration by which to backdate the NotBefore property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#not_before_duration PkiSecretBackendRootCert#not_before_duration}
    */
    readonly notBeforeDuration?: string;
    /**
    * The organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#organization PkiSecretBackendRootCert#organization}
    */
    readonly organization?: string;
    /**
    * List of other SANs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#other_sans PkiSecretBackendRootCert#other_sans}
    */
    readonly otherSans?: string[];
    /**
    * The organization unit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#ou PkiSecretBackendRootCert#ou}
    */
    readonly ou?: string;
    /**
    * List of domains for which certificates are allowed to be issued.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#permitted_dns_domains PkiSecretBackendRootCert#permitted_dns_domains}
    */
    readonly permittedDnsDomains?: string[];
    /**
    * List of email addresses for which certificates are allowed to be issued.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#permitted_email_addresses PkiSecretBackendRootCert#permitted_email_addresses}
    */
    readonly permittedEmailAddresses?: string[];
    /**
    * List of IP ranges for which certificates are allowed to be issued.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#permitted_ip_ranges PkiSecretBackendRootCert#permitted_ip_ranges}
    */
    readonly permittedIpRanges?: string[];
    /**
    * List of URI domains for which certificates are allowed to be issued.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#permitted_uri_domains PkiSecretBackendRootCert#permitted_uri_domains}
    */
    readonly permittedUriDomains?: string[];
    /**
    * The postal code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#postal_code PkiSecretBackendRootCert#postal_code}
    */
    readonly postalCode?: string;
    /**
    * The private key format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#private_key_format PkiSecretBackendRootCert#private_key_format}
    */
    readonly privateKeyFormat?: string;
    /**
    * The province.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#province PkiSecretBackendRootCert#province}
    */
    readonly province?: string;
    /**
    * The number of bits to use in the signature algorithm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#signature_bits PkiSecretBackendRootCert#signature_bits}
    */
    readonly signatureBits?: number;
    /**
    * The street address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#street_address PkiSecretBackendRootCert#street_address}
    */
    readonly streetAddress?: string;
    /**
    * Time to live.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#ttl PkiSecretBackendRootCert#ttl}
    */
    readonly ttl?: string;
    /**
    * Type of root to create. Must be either "existing", "exported", "internal" or "kms"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#type PkiSecretBackendRootCert#type}
    */
    readonly type: string;
    /**
    * List of alternative URIs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#uri_sans PkiSecretBackendRootCert#uri_sans}
    */
    readonly uriSans?: string[];
    /**
    * Whether to use PSS signatures when using a RSA key-type issuer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#use_pss PkiSecretBackendRootCert#use_pss}
    */
    readonly usePss?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert vault_pki_secret_backend_root_cert}
*/
export declare class PkiSecretBackendRootCert extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_pki_secret_backend_root_cert";
    /**
    * Generates CDKTN code for importing a PkiSecretBackendRootCert resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PkiSecretBackendRootCert to import
    * @param importFromId The id of the existing PkiSecretBackendRootCert that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PkiSecretBackendRootCert to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_root_cert vault_pki_secret_backend_root_cert} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PkiSecretBackendRootCertConfig
    */
    constructor(scope: Construct, id: string, config: PkiSecretBackendRootCertConfig);
    private _altNames?;
    get altNames(): string[];
    set altNames(value: string[]);
    resetAltNames(): void;
    get altNamesInput(): string[] | undefined;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    get certificate(): string;
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    get commonNameInput(): string | undefined;
    private _country?;
    get country(): string;
    set country(value: string);
    resetCountry(): void;
    get countryInput(): string | undefined;
    private _excludeCnFromSans?;
    get excludeCnFromSans(): boolean | cdktn.IResolvable;
    set excludeCnFromSans(value: boolean | cdktn.IResolvable);
    resetExcludeCnFromSans(): void;
    get excludeCnFromSansInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedDnsDomains?;
    get excludedDnsDomains(): string[];
    set excludedDnsDomains(value: string[]);
    resetExcludedDnsDomains(): void;
    get excludedDnsDomainsInput(): string[] | undefined;
    private _excludedEmailAddresses?;
    get excludedEmailAddresses(): string[];
    set excludedEmailAddresses(value: string[]);
    resetExcludedEmailAddresses(): void;
    get excludedEmailAddressesInput(): string[] | undefined;
    private _excludedIpRanges?;
    get excludedIpRanges(): string[];
    set excludedIpRanges(value: string[]);
    resetExcludedIpRanges(): void;
    get excludedIpRangesInput(): string[] | undefined;
    private _excludedUriDomains?;
    get excludedUriDomains(): string[];
    set excludedUriDomains(value: string[]);
    resetExcludedUriDomains(): void;
    get excludedUriDomainsInput(): string[] | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipSans?;
    get ipSans(): string[];
    set ipSans(value: string[]);
    resetIpSans(): void;
    get ipSansInput(): string[] | undefined;
    get issuerId(): string;
    private _issuerName?;
    get issuerName(): string;
    set issuerName(value: string);
    resetIssuerName(): void;
    get issuerNameInput(): string | undefined;
    get issuingCa(): string;
    private _keyBits?;
    get keyBits(): number;
    set keyBits(value: number);
    resetKeyBits(): void;
    get keyBitsInput(): number | undefined;
    get keyId(): string;
    private _keyName?;
    get keyName(): string;
    set keyName(value: string);
    resetKeyName(): void;
    get keyNameInput(): string | undefined;
    private _keyRef?;
    get keyRef(): string;
    set keyRef(value: string);
    resetKeyRef(): void;
    get keyRefInput(): string | undefined;
    private _keyType?;
    get keyType(): string;
    set keyType(value: string);
    resetKeyType(): void;
    get keyTypeInput(): string | undefined;
    private _keyUsage?;
    get keyUsage(): string[];
    set keyUsage(value: string[]);
    resetKeyUsage(): void;
    get keyUsageInput(): string[] | undefined;
    private _locality?;
    get locality(): string;
    set locality(value: string);
    resetLocality(): void;
    get localityInput(): string | undefined;
    private _managedKeyId?;
    get managedKeyId(): string;
    set managedKeyId(value: string);
    resetManagedKeyId(): void;
    get managedKeyIdInput(): string | undefined;
    private _managedKeyName?;
    get managedKeyName(): string;
    set managedKeyName(value: string);
    resetManagedKeyName(): void;
    get managedKeyNameInput(): string | undefined;
    private _maxPathLength?;
    get maxPathLength(): number;
    set maxPathLength(value: number);
    resetMaxPathLength(): void;
    get maxPathLengthInput(): number | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _notAfter?;
    get notAfter(): string;
    set notAfter(value: string);
    resetNotAfter(): void;
    get notAfterInput(): string | undefined;
    private _notBeforeDuration?;
    get notBeforeDuration(): string;
    set notBeforeDuration(value: string);
    resetNotBeforeDuration(): void;
    get notBeforeDurationInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _otherSans?;
    get otherSans(): string[];
    set otherSans(value: string[]);
    resetOtherSans(): void;
    get otherSansInput(): string[] | undefined;
    private _ou?;
    get ou(): string;
    set ou(value: string);
    resetOu(): void;
    get ouInput(): string | undefined;
    private _permittedDnsDomains?;
    get permittedDnsDomains(): string[];
    set permittedDnsDomains(value: string[]);
    resetPermittedDnsDomains(): void;
    get permittedDnsDomainsInput(): string[] | undefined;
    private _permittedEmailAddresses?;
    get permittedEmailAddresses(): string[];
    set permittedEmailAddresses(value: string[]);
    resetPermittedEmailAddresses(): void;
    get permittedEmailAddressesInput(): string[] | undefined;
    private _permittedIpRanges?;
    get permittedIpRanges(): string[];
    set permittedIpRanges(value: string[]);
    resetPermittedIpRanges(): void;
    get permittedIpRangesInput(): string[] | undefined;
    private _permittedUriDomains?;
    get permittedUriDomains(): string[];
    set permittedUriDomains(value: string[]);
    resetPermittedUriDomains(): void;
    get permittedUriDomainsInput(): string[] | undefined;
    private _postalCode?;
    get postalCode(): string;
    set postalCode(value: string);
    resetPostalCode(): void;
    get postalCodeInput(): string | undefined;
    private _privateKeyFormat?;
    get privateKeyFormat(): string;
    set privateKeyFormat(value: string);
    resetPrivateKeyFormat(): void;
    get privateKeyFormatInput(): string | undefined;
    private _province?;
    get province(): string;
    set province(value: string);
    resetProvince(): void;
    get provinceInput(): string | undefined;
    get serialNumber(): string;
    private _signatureBits?;
    get signatureBits(): number;
    set signatureBits(value: number);
    resetSignatureBits(): void;
    get signatureBitsInput(): number | undefined;
    private _streetAddress?;
    get streetAddress(): string;
    set streetAddress(value: string);
    resetStreetAddress(): void;
    get streetAddressInput(): string | undefined;
    private _ttl?;
    get ttl(): string;
    set ttl(value: string);
    resetTtl(): void;
    get ttlInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _uriSans?;
    get uriSans(): string[];
    set uriSans(value: string[]);
    resetUriSans(): void;
    get uriSansInput(): string[] | undefined;
    private _usePss?;
    get usePss(): boolean | cdktn.IResolvable;
    set usePss(value: boolean | cdktn.IResolvable);
    resetUsePss(): void;
    get usePssInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

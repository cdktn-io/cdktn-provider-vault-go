/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RotationPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Maximum retries per cycle for this rotation policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/rotation_policy#max_retries_per_cycle RotationPolicy#max_retries_per_cycle}
    */
    readonly maxRetriesPerCycle: number;
    /**
    * Maximum retry cycles for this rotation policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/rotation_policy#max_retry_cycles RotationPolicy#max_retry_cycles}
    */
    readonly maxRetryCycles: number;
    /**
    * Name of the rotation policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/rotation_policy#name RotationPolicy#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/rotation_policy#namespace RotationPolicy#namespace}
    */
    readonly namespace?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/rotation_policy vault_rotation_policy}
*/
export declare class RotationPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_rotation_policy";
    /**
    * Generates CDKTN code for importing a RotationPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RotationPolicy to import
    * @param importFromId The id of the existing RotationPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/rotation_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RotationPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/rotation_policy vault_rotation_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RotationPolicyConfig
    */
    constructor(scope: Construct, id: string, config: RotationPolicyConfig);
    private _maxRetriesPerCycle?;
    get maxRetriesPerCycle(): number;
    set maxRetriesPerCycle(value: number);
    get maxRetriesPerCycleInput(): number | undefined;
    private _maxRetryCycles?;
    get maxRetryCycles(): number;
    set maxRetryCycles(value: number);
    get maxRetryCyclesInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface KmipSecretListenerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Names of additional TLS CAs to use to verify client certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_listener#additional_client_cas KmipSecretListener#additional_client_cas}
    */
    readonly additionalClientCas?: string[];
    /**
    * Host:port address to listen on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_listener#address KmipSecretListener#address}
    */
    readonly address: string;
    /**
    * Use the legacy unnamed CA for verifying client certificates as well.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_listener#also_use_legacy_ca KmipSecretListener#also_use_legacy_ca}
    */
    readonly alsoUseLegacyCa?: boolean | cdktn.IResolvable;
    /**
    * Name of the CA to use to generate the server certificate and verify client certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_listener#ca KmipSecretListener#ca}
    */
    readonly ca: string;
    /**
    * Unique name for the listener.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_listener#name KmipSecretListener#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_listener#namespace KmipSecretListener#namespace}
    */
    readonly namespace?: string;
    /**
    * Path where KMIP backend is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_listener#path KmipSecretListener#path}
    */
    readonly path: string;
    /**
    * DNS SANs to include in listener certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_listener#server_hostnames KmipSecretListener#server_hostnames}
    */
    readonly serverHostnames?: string[];
    /**
    * IP SANs to include in listener certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_listener#server_ips KmipSecretListener#server_ips}
    */
    readonly serverIps?: string[];
    /**
    * TLS cipher suites to allow (does not apply to tls13+).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_listener#tls_cipher_suites KmipSecretListener#tls_cipher_suites}
    */
    readonly tlsCipherSuites?: string;
    /**
    * Maximum TLS version to accept (tls12 or tls13).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_listener#tls_max_version KmipSecretListener#tls_max_version}
    */
    readonly tlsMaxVersion?: string;
    /**
    * Minimum TLS version to accept (tls12 or tls13).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_listener#tls_min_version KmipSecretListener#tls_min_version}
    */
    readonly tlsMinVersion?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_listener vault_kmip_secret_listener}
*/
export declare class KmipSecretListener extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_kmip_secret_listener";
    /**
    * Generates CDKTN code for importing a KmipSecretListener resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KmipSecretListener to import
    * @param importFromId The id of the existing KmipSecretListener that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_listener#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KmipSecretListener to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_listener vault_kmip_secret_listener} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KmipSecretListenerConfig
    */
    constructor(scope: Construct, id: string, config: KmipSecretListenerConfig);
    private _additionalClientCas?;
    get additionalClientCas(): string[];
    set additionalClientCas(value: string[]);
    resetAdditionalClientCas(): void;
    get additionalClientCasInput(): string[] | undefined;
    private _address?;
    get address(): string;
    set address(value: string);
    get addressInput(): string | undefined;
    private _alsoUseLegacyCa?;
    get alsoUseLegacyCa(): boolean | cdktn.IResolvable;
    set alsoUseLegacyCa(value: boolean | cdktn.IResolvable);
    resetAlsoUseLegacyCa(): void;
    get alsoUseLegacyCaInput(): boolean | cdktn.IResolvable | undefined;
    private _ca?;
    get ca(): string;
    set ca(value: string);
    get caInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _serverHostnames?;
    get serverHostnames(): string[];
    set serverHostnames(value: string[]);
    resetServerHostnames(): void;
    get serverHostnamesInput(): string[] | undefined;
    private _serverIps?;
    get serverIps(): string[];
    set serverIps(value: string[]);
    resetServerIps(): void;
    get serverIpsInput(): string[] | undefined;
    private _tlsCipherSuites?;
    get tlsCipherSuites(): string;
    set tlsCipherSuites(value: string);
    resetTlsCipherSuites(): void;
    get tlsCipherSuitesInput(): string | undefined;
    private _tlsMaxVersion?;
    get tlsMaxVersion(): string;
    set tlsMaxVersion(value: string);
    resetTlsMaxVersion(): void;
    get tlsMaxVersionInput(): string | undefined;
    private _tlsMinVersion?;
    get tlsMinVersion(): string;
    set tlsMinVersion(value: string);
    resetTlsMinVersion(): void;
    get tlsMinVersionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

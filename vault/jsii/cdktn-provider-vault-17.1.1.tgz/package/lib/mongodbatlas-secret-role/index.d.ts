/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MongodbatlasSecretRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whitelist entry in CIDR notation to be added for the API key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_role#cidr_blocks MongodbatlasSecretRole#cidr_blocks}
    */
    readonly cidrBlocks?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_role#id MongodbatlasSecretRole#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * IP address to be added to the whitelist for the API key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_role#ip_addresses MongodbatlasSecretRole#ip_addresses}
    */
    readonly ipAddresses?: string[];
    /**
    * The maximum allowed lifetime of credentials issued using this role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_role#max_ttl MongodbatlasSecretRole#max_ttl}
    */
    readonly maxTtl?: string;
    /**
    * Path where MongoDB Atlas secret backend is mounted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_role#mount MongodbatlasSecretRole#mount}
    */
    readonly mount: string;
    /**
    * Name of the role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_role#name MongodbatlasSecretRole#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_role#namespace MongodbatlasSecretRole#namespace}
    */
    readonly namespace?: string;
    /**
    * ID for the organization to which the target API Key belongs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_role#organization_id MongodbatlasSecretRole#organization_id}
    */
    readonly organizationId?: string;
    /**
    * ID for the project to which the target API Key belongs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_role#project_id MongodbatlasSecretRole#project_id}
    */
    readonly projectId?: string;
    /**
    * Roles assigned when an org API key is assigned to a project API key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_role#project_roles MongodbatlasSecretRole#project_roles}
    */
    readonly projectRoles?: string[];
    /**
    * List of roles that the API Key needs to have
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_role#roles MongodbatlasSecretRole#roles}
    */
    readonly roles: string[];
    /**
    * Duration in seconds after which the issued credential should expire
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_role#ttl MongodbatlasSecretRole#ttl}
    */
    readonly ttl?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_role vault_mongodbatlas_secret_role}
*/
export declare class MongodbatlasSecretRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_mongodbatlas_secret_role";
    /**
    * Generates CDKTN code for importing a MongodbatlasSecretRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MongodbatlasSecretRole to import
    * @param importFromId The id of the existing MongodbatlasSecretRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MongodbatlasSecretRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/mongodbatlas_secret_role vault_mongodbatlas_secret_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MongodbatlasSecretRoleConfig
    */
    constructor(scope: Construct, id: string, config: MongodbatlasSecretRoleConfig);
    private _cidrBlocks?;
    get cidrBlocks(): string[];
    set cidrBlocks(value: string[]);
    resetCidrBlocks(): void;
    get cidrBlocksInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAddresses?;
    get ipAddresses(): string[];
    set ipAddresses(value: string[]);
    resetIpAddresses(): void;
    get ipAddressesInput(): string[] | undefined;
    private _maxTtl?;
    get maxTtl(): string;
    set maxTtl(value: string);
    resetMaxTtl(): void;
    get maxTtlInput(): string | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    resetOrganizationId(): void;
    get organizationIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _projectRoles?;
    get projectRoles(): string[];
    set projectRoles(value: string[]);
    resetProjectRoles(): void;
    get projectRolesInput(): string[] | undefined;
    private _roles?;
    get roles(): string[];
    set roles(value: string[]);
    get rolesInput(): string[] | undefined;
    private _ttl?;
    get ttl(): string;
    set ttl(value: string);
    resetTtl(): void;
    get ttlInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

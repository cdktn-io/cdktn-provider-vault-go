/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TransitSecretBackendKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * If set, enables taking backup of named key in the plaintext format. Once set, this cannot be disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#allow_plaintext_backup TransitSecretBackendKey#allow_plaintext_backup}
    */
    readonly allowPlaintextBackup?: boolean | cdktn.IResolvable;
    /**
    * Amount of seconds the key should live before being automatically rotated. A value of 0 disables automatic rotation for the key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#auto_rotate_period TransitSecretBackendKey#auto_rotate_period}
    */
    readonly autoRotatePeriod?: number;
    /**
    * The Transit secret backend the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#backend TransitSecretBackendKey#backend}
    */
    readonly backend: string;
    /**
    * Base64 encoded context for key derivation. Required if derived is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#context TransitSecretBackendKey#context}
    */
    readonly context?: string;
    /**
    * Whether or not to support convergent encryption, where the same plaintext creates the same ciphertext. This requires derived to be set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#convergent_encryption TransitSecretBackendKey#convergent_encryption}
    */
    readonly convergentEncryption?: boolean | cdktn.IResolvable;
    /**
    * Specifies if the key is allowed to be deleted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#deletion_allowed TransitSecretBackendKey#deletion_allowed}
    */
    readonly deletionAllowed?: boolean | cdktn.IResolvable;
    /**
    * Specifies if key derivation is to be used. If enabled, all encrypt/decrypt requests to this key must provide a context which is used for key derivation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#derived TransitSecretBackendKey#derived}
    */
    readonly derived?: boolean | cdktn.IResolvable;
    /**
    * Enables keys to be exportable. This allows for all the valid keys in the key ring to be exported. Once set, this cannot be disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#exportable TransitSecretBackendKey#exportable}
    */
    readonly exportable?: boolean | cdktn.IResolvable;
    /**
    * The elliptic curve algorithm to use for hybrid signatures. Supported key types are `ecdsa-p256`, `ecdsa-p384`, `ecdsa-p521`, and `ed25519`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#hybrid_key_type_ec TransitSecretBackendKey#hybrid_key_type_ec}
    */
    readonly hybridKeyTypeEc?: string;
    /**
    * The post-quantum algorithm to use for hybrid signatures. Currently, ML-DSA is the only supported key type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#hybrid_key_type_pqc TransitSecretBackendKey#hybrid_key_type_pqc}
    */
    readonly hybridKeyTypePqc?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#id TransitSecretBackendKey#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The key size in bytes for algorithms that allow variable key sizes. Currently only applicable to HMAC; this value must be between 32 and 512.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#key_size TransitSecretBackendKey#key_size}
    */
    readonly keySize?: number;
    /**
    * The UUID of the managed key to use when the key type is managed_key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#managed_key_id TransitSecretBackendKey#managed_key_id}
    */
    readonly managedKeyId?: string;
    /**
    * The name of the managed key to use when the key type is managed_key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#managed_key_name TransitSecretBackendKey#managed_key_name}
    */
    readonly managedKeyName?: string;
    /**
    * Minimum key version to use for decryption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#min_decryption_version TransitSecretBackendKey#min_decryption_version}
    */
    readonly minDecryptionVersion?: number;
    /**
    * Minimum key version to use for encryption
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#min_encryption_version TransitSecretBackendKey#min_encryption_version}
    */
    readonly minEncryptionVersion?: number;
    /**
    * Name of the encryption key to create.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#name TransitSecretBackendKey#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#namespace TransitSecretBackendKey#namespace}
    */
    readonly namespace?: string;
    /**
    * The parameter set to use for ML-DSA. Required for ML-DSA and hybrid keys.  Valid values for ML-DSA are `44`, `65`, and `87`. Valid values for SLH-DSA are `slh-dsa-sha2-128s`, `slh-dsa-shake-128s`, `slh-dsa-sha2-128f`, `slh-dsa-shake-128`, `slh-dsa-sha2-192s`, `slh-dsa-shake-192s`, `slh-dsa-sha2-192f`, `slh-dsa-shake-192f`, `slh-dsa-sha2-256s`, `slh-dsa-shake-256s`, `slh-dsa-sha2-256f`, and `slh-dsa-shake-256f`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#parameter_set TransitSecretBackendKey#parameter_set}
    */
    readonly parameterSet?: string;
    /**
    * Specifies the type of key to create. The currently-supported types are: `aes128-gcm96`, `aes256-gcm96` (default), `chacha20-poly1305`, `ed25519`, `ecdsa-p256`, `ecdsa-p384`, `ecdsa-p521`, `hmac`, `rsa-2048`, `rsa-3072`, `rsa-4096`, `managed_key`, `aes128-cmac`, `aes192-cmac`, `aes256-cmac`, `ml-dsa`, `hybrid`, and `slh-dsa`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#type TransitSecretBackendKey#type}
    */
    readonly type?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key vault_transit_secret_backend_key}
*/
export declare class TransitSecretBackendKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_transit_secret_backend_key";
    /**
    * Generates CDKTN code for importing a TransitSecretBackendKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TransitSecretBackendKey to import
    * @param importFromId The id of the existing TransitSecretBackendKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TransitSecretBackendKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/transit_secret_backend_key vault_transit_secret_backend_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TransitSecretBackendKeyConfig
    */
    constructor(scope: Construct, id: string, config: TransitSecretBackendKeyConfig);
    private _allowPlaintextBackup?;
    get allowPlaintextBackup(): boolean | cdktn.IResolvable;
    set allowPlaintextBackup(value: boolean | cdktn.IResolvable);
    resetAllowPlaintextBackup(): void;
    get allowPlaintextBackupInput(): boolean | cdktn.IResolvable | undefined;
    private _autoRotatePeriod?;
    get autoRotatePeriod(): number;
    set autoRotatePeriod(value: number);
    resetAutoRotatePeriod(): void;
    get autoRotatePeriodInput(): number | undefined;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    private _context?;
    get context(): string;
    set context(value: string);
    resetContext(): void;
    get contextInput(): string | undefined;
    private _convergentEncryption?;
    get convergentEncryption(): boolean | cdktn.IResolvable;
    set convergentEncryption(value: boolean | cdktn.IResolvable);
    resetConvergentEncryption(): void;
    get convergentEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _deletionAllowed?;
    get deletionAllowed(): boolean | cdktn.IResolvable;
    set deletionAllowed(value: boolean | cdktn.IResolvable);
    resetDeletionAllowed(): void;
    get deletionAllowedInput(): boolean | cdktn.IResolvable | undefined;
    private _derived?;
    get derived(): boolean | cdktn.IResolvable;
    set derived(value: boolean | cdktn.IResolvable);
    resetDerived(): void;
    get derivedInput(): boolean | cdktn.IResolvable | undefined;
    private _exportable?;
    get exportable(): boolean | cdktn.IResolvable;
    set exportable(value: boolean | cdktn.IResolvable);
    resetExportable(): void;
    get exportableInput(): boolean | cdktn.IResolvable | undefined;
    private _hybridKeyTypeEc?;
    get hybridKeyTypeEc(): string;
    set hybridKeyTypeEc(value: string);
    resetHybridKeyTypeEc(): void;
    get hybridKeyTypeEcInput(): string | undefined;
    private _hybridKeyTypePqc?;
    get hybridKeyTypePqc(): string;
    set hybridKeyTypePqc(value: string);
    resetHybridKeyTypePqc(): void;
    get hybridKeyTypePqcInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keySize?;
    get keySize(): number;
    set keySize(value: number);
    resetKeySize(): void;
    get keySizeInput(): number | undefined;
    private _keys;
    get keys(): cdktn.StringMapList;
    get latestVersion(): number;
    private _managedKeyId?;
    get managedKeyId(): string;
    set managedKeyId(value: string);
    resetManagedKeyId(): void;
    get managedKeyIdInput(): string | undefined;
    private _managedKeyName?;
    get managedKeyName(): string;
    set managedKeyName(value: string);
    resetManagedKeyName(): void;
    get managedKeyNameInput(): string | undefined;
    get minAvailableVersion(): number;
    private _minDecryptionVersion?;
    get minDecryptionVersion(): number;
    set minDecryptionVersion(value: number);
    resetMinDecryptionVersion(): void;
    get minDecryptionVersionInput(): number | undefined;
    private _minEncryptionVersion?;
    get minEncryptionVersion(): number;
    set minEncryptionVersion(value: number);
    resetMinEncryptionVersion(): void;
    get minEncryptionVersionInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _parameterSet?;
    get parameterSet(): string;
    set parameterSet(value: string);
    resetParameterSet(): void;
    get parameterSetInput(): string | undefined;
    get supportsDecryption(): cdktn.IResolvable;
    get supportsDerivation(): cdktn.IResolvable;
    get supportsEncryption(): cdktn.IResolvable;
    get supportsSigning(): cdktn.IResolvable;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OktaAuthBackendUserAConfig extends cdktn.TerraformMetaArguments {
    /**
    * Groups within the Okta auth backend to associate with this user
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/okta_auth_backend_user#groups OktaAuthBackendUserA#groups}
    */
    readonly groups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/okta_auth_backend_user#id OktaAuthBackendUserA#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/okta_auth_backend_user#namespace OktaAuthBackendUserA#namespace}
    */
    readonly namespace?: string;
    /**
    * Path to the Okta auth backend
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/okta_auth_backend_user#path OktaAuthBackendUserA#path}
    */
    readonly path: string;
    /**
    * Policies to associate with this user
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/okta_auth_backend_user#policies OktaAuthBackendUserA#policies}
    */
    readonly policies?: string[];
    /**
    * Name of the user within Okta
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/okta_auth_backend_user#username OktaAuthBackendUserA#username}
    */
    readonly username: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/okta_auth_backend_user vault_okta_auth_backend_user}
*/
export declare class OktaAuthBackendUserA extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_okta_auth_backend_user";
    /**
    * Generates CDKTN code for importing a OktaAuthBackendUserA resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OktaAuthBackendUserA to import
    * @param importFromId The id of the existing OktaAuthBackendUserA that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/okta_auth_backend_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OktaAuthBackendUserA to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/okta_auth_backend_user vault_okta_auth_backend_user} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OktaAuthBackendUserAConfig
    */
    constructor(scope: Construct, id: string, config: OktaAuthBackendUserAConfig);
    private _groups?;
    get groups(): string[];
    set groups(value: string[]);
    resetGroups(): void;
    get groupsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _policies?;
    get policies(): string[];
    set policies(value: string[]);
    resetPolicies(): void;
    get policiesInput(): string[] | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

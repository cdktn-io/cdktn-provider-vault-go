/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultPkiSecretBackendCertMetadataConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/pki_secret_backend_cert_metadata#id DataVaultPkiSecretBackendCertMetadata#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/pki_secret_backend_cert_metadata#namespace DataVaultPkiSecretBackendCertMetadata#namespace}
    */
    readonly namespace?: string;
    /**
    * Full path where PKI backend is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/pki_secret_backend_cert_metadata#path DataVaultPkiSecretBackendCertMetadata#path}
    */
    readonly path: string;
    /**
    * Specifies the serial of the certificate whose metadata to read.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/pki_secret_backend_cert_metadata#serial DataVaultPkiSecretBackendCertMetadata#serial}
    */
    readonly serial: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/pki_secret_backend_cert_metadata vault_pki_secret_backend_cert_metadata}
*/
export declare class DataVaultPkiSecretBackendCertMetadata extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_pki_secret_backend_cert_metadata";
    /**
    * Generates CDKTN code for importing a DataVaultPkiSecretBackendCertMetadata resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultPkiSecretBackendCertMetadata to import
    * @param importFromId The id of the existing DataVaultPkiSecretBackendCertMetadata that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/pki_secret_backend_cert_metadata#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultPkiSecretBackendCertMetadata to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/pki_secret_backend_cert_metadata vault_pki_secret_backend_cert_metadata} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultPkiSecretBackendCertMetadataConfig
    */
    constructor(scope: Construct, id: string, config: DataVaultPkiSecretBackendCertMetadataConfig);
    get certMetadata(): string;
    get expiration(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get issuerId(): string;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    get role(): string;
    private _serial?;
    get serial(): string;
    set serial(value: string);
    get serialInput(): string | undefined;
    get serialNumber(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface KmipSecretCaImportedConfig extends cdktn.TerraformMetaArguments {
    /**
    * CA certificate in PEM format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_ca_imported#ca_pem KmipSecretCaImported#ca_pem}
    */
    readonly caPem: string;
    /**
    * Name to identify the CA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_ca_imported#name KmipSecretCaImported#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_ca_imported#namespace KmipSecretCaImported#namespace}
    */
    readonly namespace?: string;
    /**
    * Path where KMIP backend is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_ca_imported#path KmipSecretCaImported#path}
    */
    readonly path: string;
    /**
    * The field in the certificate to use for the role (CN, O, OU, or UID). Must specify exactly one of role_name or role_field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_ca_imported#role_field KmipSecretCaImported#role_field}
    */
    readonly roleField?: string;
    /**
    * The role name to associate with this CA. Must specify exactly one of role_name or role_field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_ca_imported#role_name KmipSecretCaImported#role_name}
    */
    readonly roleName?: string;
    /**
    * The field in the certificate to use for the scope (CN, O, OU, or UID). Must specify exactly one of scope_name or scope_field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_ca_imported#scope_field KmipSecretCaImported#scope_field}
    */
    readonly scopeField?: string;
    /**
    * The scope name to associate with this CA. Must specify exactly one of scope_name or scope_field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_ca_imported#scope_name KmipSecretCaImported#scope_name}
    */
    readonly scopeName?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_ca_imported vault_kmip_secret_ca_imported}
*/
export declare class KmipSecretCaImported extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_kmip_secret_ca_imported";
    /**
    * Generates CDKTN code for importing a KmipSecretCaImported resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KmipSecretCaImported to import
    * @param importFromId The id of the existing KmipSecretCaImported that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_ca_imported#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KmipSecretCaImported to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/kmip_secret_ca_imported vault_kmip_secret_ca_imported} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KmipSecretCaImportedConfig
    */
    constructor(scope: Construct, id: string, config: KmipSecretCaImportedConfig);
    private _caPem?;
    get caPem(): string;
    set caPem(value: string);
    get caPemInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _roleField?;
    get roleField(): string;
    set roleField(value: string);
    resetRoleField(): void;
    get roleFieldInput(): string | undefined;
    private _roleName?;
    get roleName(): string;
    set roleName(value: string);
    resetRoleName(): void;
    get roleNameInput(): string | undefined;
    private _scopeField?;
    get scopeField(): string;
    set scopeField(value: string);
    resetScopeField(): void;
    get scopeFieldInput(): string | undefined;
    private _scopeName?;
    get scopeName(): string;
    set scopeName(value: string);
    resetScopeName(): void;
    get scopeNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

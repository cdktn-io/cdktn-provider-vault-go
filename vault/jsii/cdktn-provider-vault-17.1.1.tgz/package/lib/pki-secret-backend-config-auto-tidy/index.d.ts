/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PkiSecretBackendConfigAutoTidyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The amount of time that must pass after creation that an account with no orders is marked revoked, and the amount of time after being marked revoked or deactivated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#acme_account_safety_buffer PkiSecretBackendConfigAutoTidy#acme_account_safety_buffer}
    */
    readonly acmeAccountSafetyBuffer?: string;
    /**
    * The path of the PKI secret backend the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#backend PkiSecretBackendConfigAutoTidy#backend}
    */
    readonly backend: string;
    /**
    * Specifies whether automatic tidy is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#enabled PkiSecretBackendConfigAutoTidy#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#id PkiSecretBackendConfigAutoTidy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Interval at which to run an auto-tidy operation. This is the time between tidy invocations (after one finishes to the start of the next).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#interval_duration PkiSecretBackendConfigAutoTidy#interval_duration}
    */
    readonly intervalDuration?: string;
    /**
    * The amount of extra time that must have passed beyond issuer's expiration before it is removed from the backend storage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#issuer_safety_buffer PkiSecretBackendConfigAutoTidy#issuer_safety_buffer}
    */
    readonly issuerSafetyBuffer?: string;
    /**
    * This configures whether stored certificate are counted upon initialization of the backend, and whether during normal operation, a running count of certificates stored is maintained.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#maintain_stored_certificate_counts PkiSecretBackendConfigAutoTidy#maintain_stored_certificate_counts}
    */
    readonly maintainStoredCertificateCounts?: boolean | cdktn.IResolvable;
    /**
    * The maximum amount of time auto-tidy will be delayed after startup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#max_startup_backoff_duration PkiSecretBackendConfigAutoTidy#max_startup_backoff_duration}
    */
    readonly maxStartupBackoffDuration?: string;
    /**
    * The minimum amount of time auto-tidy will be delayed after startup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#min_startup_backoff_duration PkiSecretBackendConfigAutoTidy#min_startup_backoff_duration}
    */
    readonly minStartupBackoffDuration?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#namespace PkiSecretBackendConfigAutoTidy#namespace}
    */
    readonly namespace?: string;
    /**
    * The amount of time to wait between processing certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#pause_duration PkiSecretBackendConfigAutoTidy#pause_duration}
    */
    readonly pauseDuration?: string;
    /**
    * This configures whether the stored certificate count is published to the metrics consumer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#publish_stored_certificate_count_metrics PkiSecretBackendConfigAutoTidy#publish_stored_certificate_count_metrics}
    */
    readonly publishStoredCertificateCountMetrics?: boolean | cdktn.IResolvable;
    /**
    * The amount of time that must pass from the cross-cluster revocation request being initiated to when it will be slated for removal.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#revocation_queue_safety_buffer PkiSecretBackendConfigAutoTidy#revocation_queue_safety_buffer}
    */
    readonly revocationQueueSafetyBuffer?: string;
    /**
    * The amount of extra time that must have passed beyond certificate expiration before it is removed from the backend storage and/or revocation list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#safety_buffer PkiSecretBackendConfigAutoTidy#safety_buffer}
    */
    readonly safetyBuffer?: string;
    /**
    * Set to true to enable tidying ACME accounts, orders and authorizations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#tidy_acme PkiSecretBackendConfigAutoTidy#tidy_acme}
    */
    readonly tidyAcme?: boolean | cdktn.IResolvable;
    /**
    * Set to true to enable tidying up certificate metadata.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#tidy_cert_metadata PkiSecretBackendConfigAutoTidy#tidy_cert_metadata}
    */
    readonly tidyCertMetadata?: boolean | cdktn.IResolvable;
    /**
    * Set to true to enable tidying up the certificate store
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#tidy_cert_store PkiSecretBackendConfigAutoTidy#tidy_cert_store}
    */
    readonly tidyCertStore?: boolean | cdktn.IResolvable;
    /**
    * Set to true to enable tidying up the CMPv2 nonce store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#tidy_cmpv2_nonce_store PkiSecretBackendConfigAutoTidy#tidy_cmpv2_nonce_store}
    */
    readonly tidyCmpv2NonceStore?: boolean | cdktn.IResolvable;
    /**
    * Set to true to enable tidying up the cross-cluster revoked certificate store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#tidy_cross_cluster_revoked_certs PkiSecretBackendConfigAutoTidy#tidy_cross_cluster_revoked_certs}
    */
    readonly tidyCrossClusterRevokedCerts?: boolean | cdktn.IResolvable;
    /**
    * Set to true to automatically remove expired issuers past the issuer_safety_buffer. No keys will be removed as part of this operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#tidy_expired_issuers PkiSecretBackendConfigAutoTidy#tidy_expired_issuers}
    */
    readonly tidyExpiredIssuers?: boolean | cdktn.IResolvable;
    /**
    * Set to true to move the legacy ca_bundle from /config/ca_bundle to /config/ca_bundle.bak.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#tidy_move_legacy_ca_bundle PkiSecretBackendConfigAutoTidy#tidy_move_legacy_ca_bundle}
    */
    readonly tidyMoveLegacyCaBundle?: boolean | cdktn.IResolvable;
    /**
    * Set to true to remove stale revocation queue entries that haven't been confirmed by any active cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#tidy_revocation_queue PkiSecretBackendConfigAutoTidy#tidy_revocation_queue}
    */
    readonly tidyRevocationQueue?: boolean | cdktn.IResolvable;
    /**
    * Set to true to validate issuer associations on revocation entries. This helps increase the performance of CRL building and OCSP responses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#tidy_revoked_cert_issuer_associations PkiSecretBackendConfigAutoTidy#tidy_revoked_cert_issuer_associations}
    */
    readonly tidyRevokedCertIssuerAssociations?: boolean | cdktn.IResolvable;
    /**
    * Set to true to remove all invalid and expired certificates from storage. A revoked storage entry is considered invalid if the entry is empty, or the value within the entry is empty. If a certificate is removed due to expiry, the entry will also be removed from the CRL, and the CRL will be rotated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#tidy_revoked_certs PkiSecretBackendConfigAutoTidy#tidy_revoked_certs}
    */
    readonly tidyRevokedCerts?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy vault_pki_secret_backend_config_auto_tidy}
*/
export declare class PkiSecretBackendConfigAutoTidy extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_pki_secret_backend_config_auto_tidy";
    /**
    * Generates CDKTN code for importing a PkiSecretBackendConfigAutoTidy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PkiSecretBackendConfigAutoTidy to import
    * @param importFromId The id of the existing PkiSecretBackendConfigAutoTidy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PkiSecretBackendConfigAutoTidy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/pki_secret_backend_config_auto_tidy vault_pki_secret_backend_config_auto_tidy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PkiSecretBackendConfigAutoTidyConfig
    */
    constructor(scope: Construct, id: string, config: PkiSecretBackendConfigAutoTidyConfig);
    private _acmeAccountSafetyBuffer?;
    get acmeAccountSafetyBuffer(): string;
    set acmeAccountSafetyBuffer(value: string);
    resetAcmeAccountSafetyBuffer(): void;
    get acmeAccountSafetyBufferInput(): string | undefined;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _intervalDuration?;
    get intervalDuration(): string;
    set intervalDuration(value: string);
    resetIntervalDuration(): void;
    get intervalDurationInput(): string | undefined;
    private _issuerSafetyBuffer?;
    get issuerSafetyBuffer(): string;
    set issuerSafetyBuffer(value: string);
    resetIssuerSafetyBuffer(): void;
    get issuerSafetyBufferInput(): string | undefined;
    private _maintainStoredCertificateCounts?;
    get maintainStoredCertificateCounts(): boolean | cdktn.IResolvable;
    set maintainStoredCertificateCounts(value: boolean | cdktn.IResolvable);
    resetMaintainStoredCertificateCounts(): void;
    get maintainStoredCertificateCountsInput(): boolean | cdktn.IResolvable | undefined;
    private _maxStartupBackoffDuration?;
    get maxStartupBackoffDuration(): string;
    set maxStartupBackoffDuration(value: string);
    resetMaxStartupBackoffDuration(): void;
    get maxStartupBackoffDurationInput(): string | undefined;
    private _minStartupBackoffDuration?;
    get minStartupBackoffDuration(): string;
    set minStartupBackoffDuration(value: string);
    resetMinStartupBackoffDuration(): void;
    get minStartupBackoffDurationInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _pauseDuration?;
    get pauseDuration(): string;
    set pauseDuration(value: string);
    resetPauseDuration(): void;
    get pauseDurationInput(): string | undefined;
    private _publishStoredCertificateCountMetrics?;
    get publishStoredCertificateCountMetrics(): boolean | cdktn.IResolvable;
    set publishStoredCertificateCountMetrics(value: boolean | cdktn.IResolvable);
    resetPublishStoredCertificateCountMetrics(): void;
    get publishStoredCertificateCountMetricsInput(): boolean | cdktn.IResolvable | undefined;
    private _revocationQueueSafetyBuffer?;
    get revocationQueueSafetyBuffer(): string;
    set revocationQueueSafetyBuffer(value: string);
    resetRevocationQueueSafetyBuffer(): void;
    get revocationQueueSafetyBufferInput(): string | undefined;
    private _safetyBuffer?;
    get safetyBuffer(): string;
    set safetyBuffer(value: string);
    resetSafetyBuffer(): void;
    get safetyBufferInput(): string | undefined;
    private _tidyAcme?;
    get tidyAcme(): boolean | cdktn.IResolvable;
    set tidyAcme(value: boolean | cdktn.IResolvable);
    resetTidyAcme(): void;
    get tidyAcmeInput(): boolean | cdktn.IResolvable | undefined;
    private _tidyCertMetadata?;
    get tidyCertMetadata(): boolean | cdktn.IResolvable;
    set tidyCertMetadata(value: boolean | cdktn.IResolvable);
    resetTidyCertMetadata(): void;
    get tidyCertMetadataInput(): boolean | cdktn.IResolvable | undefined;
    private _tidyCertStore?;
    get tidyCertStore(): boolean | cdktn.IResolvable;
    set tidyCertStore(value: boolean | cdktn.IResolvable);
    resetTidyCertStore(): void;
    get tidyCertStoreInput(): boolean | cdktn.IResolvable | undefined;
    private _tidyCmpv2NonceStore?;
    get tidyCmpv2NonceStore(): boolean | cdktn.IResolvable;
    set tidyCmpv2NonceStore(value: boolean | cdktn.IResolvable);
    resetTidyCmpv2NonceStore(): void;
    get tidyCmpv2NonceStoreInput(): boolean | cdktn.IResolvable | undefined;
    private _tidyCrossClusterRevokedCerts?;
    get tidyCrossClusterRevokedCerts(): boolean | cdktn.IResolvable;
    set tidyCrossClusterRevokedCerts(value: boolean | cdktn.IResolvable);
    resetTidyCrossClusterRevokedCerts(): void;
    get tidyCrossClusterRevokedCertsInput(): boolean | cdktn.IResolvable | undefined;
    private _tidyExpiredIssuers?;
    get tidyExpiredIssuers(): boolean | cdktn.IResolvable;
    set tidyExpiredIssuers(value: boolean | cdktn.IResolvable);
    resetTidyExpiredIssuers(): void;
    get tidyExpiredIssuersInput(): boolean | cdktn.IResolvable | undefined;
    private _tidyMoveLegacyCaBundle?;
    get tidyMoveLegacyCaBundle(): boolean | cdktn.IResolvable;
    set tidyMoveLegacyCaBundle(value: boolean | cdktn.IResolvable);
    resetTidyMoveLegacyCaBundle(): void;
    get tidyMoveLegacyCaBundleInput(): boolean | cdktn.IResolvable | undefined;
    private _tidyRevocationQueue?;
    get tidyRevocationQueue(): boolean | cdktn.IResolvable;
    set tidyRevocationQueue(value: boolean | cdktn.IResolvable);
    resetTidyRevocationQueue(): void;
    get tidyRevocationQueueInput(): boolean | cdktn.IResolvable | undefined;
    private _tidyRevokedCertIssuerAssociations?;
    get tidyRevokedCertIssuerAssociations(): boolean | cdktn.IResolvable;
    set tidyRevokedCertIssuerAssociations(value: boolean | cdktn.IResolvable);
    resetTidyRevokedCertIssuerAssociations(): void;
    get tidyRevokedCertIssuerAssociationsInput(): boolean | cdktn.IResolvable | undefined;
    private _tidyRevokedCerts?;
    get tidyRevokedCerts(): boolean | cdktn.IResolvable;
    set tidyRevokedCerts(value: boolean | cdktn.IResolvable);
    resetTidyRevokedCerts(): void;
    get tidyRevokedCertsInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

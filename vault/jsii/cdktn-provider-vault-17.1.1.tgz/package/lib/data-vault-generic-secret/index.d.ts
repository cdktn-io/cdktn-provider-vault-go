/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultGenericSecretConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/generic_secret#id DataVaultGenericSecret#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/generic_secret#namespace DataVaultGenericSecret#namespace}
    */
    readonly namespace?: string;
    /**
    * Full path from which a secret will be read.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/generic_secret#path DataVaultGenericSecret#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/generic_secret#version DataVaultGenericSecret#version}
    */
    readonly version?: number;
    /**
    * If set to true, stores 'lease_start_time' in the TF state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/generic_secret#with_lease_start_time DataVaultGenericSecret#with_lease_start_time}
    */
    readonly withLeaseStartTime?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/generic_secret vault_generic_secret}
*/
export declare class DataVaultGenericSecret extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_generic_secret";
    /**
    * Generates CDKTN code for importing a DataVaultGenericSecret resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultGenericSecret to import
    * @param importFromId The id of the existing DataVaultGenericSecret that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/generic_secret#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultGenericSecret to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/generic_secret vault_generic_secret} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultGenericSecretConfig
    */
    constructor(scope: Construct, id: string, config: DataVaultGenericSecretConfig);
    private _data;
    get data(): cdktn.StringMap;
    get dataJson(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get leaseDuration(): number;
    get leaseId(): string;
    get leaseRenewable(): cdktn.IResolvable;
    get leaseStartTime(): string;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _version?;
    get version(): number;
    set version(value: number);
    resetVersion(): void;
    get versionInput(): number | undefined;
    private _withLeaseStartTime?;
    get withLeaseStartTime(): boolean | cdktn.IResolvable;
    set withLeaseStartTime(value: boolean | cdktn.IResolvable);
    resetWithLeaseStartTime(): void;
    get withLeaseStartTimeInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

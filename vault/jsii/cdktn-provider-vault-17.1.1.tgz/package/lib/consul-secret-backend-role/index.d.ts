/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConsulSecretBackendRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The path of the Consul Secret Backend the role belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/consul_secret_backend_role#backend ConsulSecretBackendRole#backend}
    */
    readonly backend?: string;
    /**
    * The Consul namespace that the token will be created in. Applicable for Vault 1.10+ and Consul 1.7+
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/consul_secret_backend_role#consul_namespace ConsulSecretBackendRole#consul_namespace}
    */
    readonly consulNamespace?: string;
    /**
    * List of Consul policies to associate with this role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/consul_secret_backend_role#consul_policies ConsulSecretBackendRole#consul_policies}
    */
    readonly consulPolicies?: string[];
    /**
    * Set of Consul roles to attach to the token. Applicable for Vault 1.10+ with Consul 1.5+
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/consul_secret_backend_role#consul_roles ConsulSecretBackendRole#consul_roles}
    */
    readonly consulRoles?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/consul_secret_backend_role#id ConsulSecretBackendRole#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Indicates that the token should not be replicated globally and instead be local to the current datacenter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/consul_secret_backend_role#local ConsulSecretBackendRole#local}
    */
    readonly local?: boolean | cdktn.IResolvable;
    /**
    * Maximum TTL for leases associated with this role, in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/consul_secret_backend_role#max_ttl ConsulSecretBackendRole#max_ttl}
    */
    readonly maxTtl?: number;
    /**
    * The name of an existing role against which to create this Consul credential
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/consul_secret_backend_role#name ConsulSecretBackendRole#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/consul_secret_backend_role#namespace ConsulSecretBackendRole#namespace}
    */
    readonly namespace?: string;
    /**
    * Set of Consul node identities to attach to
    * 				the token. Applicable for Vault 1.11+ with Consul 1.8+
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/consul_secret_backend_role#node_identities ConsulSecretBackendRole#node_identities}
    */
    readonly nodeIdentities?: string[];
    /**
    * The Consul admin partition that the token will be created in. Applicable for Vault 1.10+ and Consul 1.11+
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/consul_secret_backend_role#partition ConsulSecretBackendRole#partition}
    */
    readonly partition?: string;
    /**
    * List of Consul policies to associate with this role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/consul_secret_backend_role#policies ConsulSecretBackendRole#policies}
    */
    readonly policies?: string[];
    /**
    * Set of Consul service identities to attach to
    * 				the token. Applicable for Vault 1.11+ with Consul 1.5+
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/consul_secret_backend_role#service_identities ConsulSecretBackendRole#service_identities}
    */
    readonly serviceIdentities?: string[];
    /**
    * Specifies the TTL for this role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/consul_secret_backend_role#ttl ConsulSecretBackendRole#ttl}
    */
    readonly ttl?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/consul_secret_backend_role vault_consul_secret_backend_role}
*/
export declare class ConsulSecretBackendRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_consul_secret_backend_role";
    /**
    * Generates CDKTN code for importing a ConsulSecretBackendRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConsulSecretBackendRole to import
    * @param importFromId The id of the existing ConsulSecretBackendRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/consul_secret_backend_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConsulSecretBackendRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/consul_secret_backend_role vault_consul_secret_backend_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConsulSecretBackendRoleConfig
    */
    constructor(scope: Construct, id: string, config: ConsulSecretBackendRoleConfig);
    private _backend?;
    get backend(): string;
    set backend(value: string);
    resetBackend(): void;
    get backendInput(): string | undefined;
    private _consulNamespace?;
    get consulNamespace(): string;
    set consulNamespace(value: string);
    resetConsulNamespace(): void;
    get consulNamespaceInput(): string | undefined;
    private _consulPolicies?;
    get consulPolicies(): string[];
    set consulPolicies(value: string[]);
    resetConsulPolicies(): void;
    get consulPoliciesInput(): string[] | undefined;
    private _consulRoles?;
    get consulRoles(): string[];
    set consulRoles(value: string[]);
    resetConsulRoles(): void;
    get consulRolesInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _local?;
    get local(): boolean | cdktn.IResolvable;
    set local(value: boolean | cdktn.IResolvable);
    resetLocal(): void;
    get localInput(): boolean | cdktn.IResolvable | undefined;
    private _maxTtl?;
    get maxTtl(): number;
    set maxTtl(value: number);
    resetMaxTtl(): void;
    get maxTtlInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _nodeIdentities?;
    get nodeIdentities(): string[];
    set nodeIdentities(value: string[]);
    resetNodeIdentities(): void;
    get nodeIdentitiesInput(): string[] | undefined;
    private _partition?;
    get partition(): string;
    set partition(value: string);
    resetPartition(): void;
    get partitionInput(): string | undefined;
    private _policies?;
    get policies(): string[];
    set policies(value: string[]);
    resetPolicies(): void;
    get policiesInput(): string[] | undefined;
    private _serviceIdentities?;
    get serviceIdentities(): string[];
    set serviceIdentities(value: string[]);
    resetServiceIdentities(): void;
    get serviceIdentitiesInput(): string[] | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

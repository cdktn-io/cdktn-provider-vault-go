/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface KeymgmtReplicateKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies the name of the key to replicate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/keymgmt_replicate_key#key_name KeymgmtReplicateKey#key_name}
    */
    readonly keyName: string;
    /**
    * Specifies the name of the AWS KMS provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/keymgmt_replicate_key#kms_name KeymgmtReplicateKey#kms_name}
    */
    readonly kmsName: string;
    /**
    * Path of the Key Management secrets engine mount. Must match the `path` of a `vault_mount` resource with `type = "keymgmt"`. Use `vault_mount.keymgmt.path` here.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/keymgmt_replicate_key#mount KeymgmtReplicateKey#mount}
    */
    readonly mount: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/keymgmt_replicate_key#namespace KeymgmtReplicateKey#namespace}
    */
    readonly namespace?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/keymgmt_replicate_key vault_keymgmt_replicate_key}
*/
export declare class KeymgmtReplicateKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_keymgmt_replicate_key";
    /**
    * Generates CDKTN code for importing a KeymgmtReplicateKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KeymgmtReplicateKey to import
    * @param importFromId The id of the existing KeymgmtReplicateKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/keymgmt_replicate_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KeymgmtReplicateKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/keymgmt_replicate_key vault_keymgmt_replicate_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KeymgmtReplicateKeyConfig
    */
    constructor(scope: Construct, id: string, config: KeymgmtReplicateKeyConfig);
    private _keyName?;
    get keyName(): string;
    set keyName(value: string);
    get keyNameInput(): string | undefined;
    private _kmsName?;
    get kmsName(): string;
    set kmsName(value: string);
    get kmsNameInput(): string | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GenericEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * JSON-encoded data to write.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/generic_endpoint#data_json GenericEndpoint#data_json}
    */
    readonly dataJson: string;
    /**
    * Don't attempt to delete the path from Vault if true
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/generic_endpoint#disable_delete GenericEndpoint#disable_delete}
    */
    readonly disableDelete?: boolean | cdktn.IResolvable;
    /**
    * Don't attempt to read the path from Vault if true; drift won't be detected
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/generic_endpoint#disable_read GenericEndpoint#disable_read}
    */
    readonly disableRead?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/generic_endpoint#id GenericEndpoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * When reading, disregard fields not present in data_json
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/generic_endpoint#ignore_absent_fields GenericEndpoint#ignore_absent_fields}
    */
    readonly ignoreAbsentFields?: boolean | cdktn.IResolvable;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/generic_endpoint#namespace GenericEndpoint#namespace}
    */
    readonly namespace?: string;
    /**
    * Full path where to the endpoint that will be written
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/generic_endpoint#path GenericEndpoint#path}
    */
    readonly path: string;
    /**
    * Top-level fields returned by write to persist in state
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/generic_endpoint#write_fields GenericEndpoint#write_fields}
    */
    readonly writeFields?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/generic_endpoint vault_generic_endpoint}
*/
export declare class GenericEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_generic_endpoint";
    /**
    * Generates CDKTN code for importing a GenericEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GenericEndpoint to import
    * @param importFromId The id of the existing GenericEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/generic_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GenericEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/resources/generic_endpoint vault_generic_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GenericEndpointConfig
    */
    constructor(scope: Construct, id: string, config: GenericEndpointConfig);
    private _dataJson?;
    get dataJson(): string;
    set dataJson(value: string);
    get dataJsonInput(): string | undefined;
    private _disableDelete?;
    get disableDelete(): boolean | cdktn.IResolvable;
    set disableDelete(value: boolean | cdktn.IResolvable);
    resetDisableDelete(): void;
    get disableDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _disableRead?;
    get disableRead(): boolean | cdktn.IResolvable;
    set disableRead(value: boolean | cdktn.IResolvable);
    resetDisableRead(): void;
    get disableReadInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreAbsentFields?;
    get ignoreAbsentFields(): boolean | cdktn.IResolvable;
    set ignoreAbsentFields(value: boolean | cdktn.IResolvable);
    resetIgnoreAbsentFields(): void;
    get ignoreAbsentFieldsInput(): boolean | cdktn.IResolvable | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _writeData;
    get writeData(): cdktn.StringMap;
    get writeDataJson(): string;
    private _writeFields?;
    get writeFields(): string[];
    set writeFields(value: string[]);
    resetWriteFields(): void;
    get writeFieldsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

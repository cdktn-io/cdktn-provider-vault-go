/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultSshSecretBackendSignConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies the type of certificate to be created; either "user" or "host".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/ssh_secret_backend_sign#cert_type DataVaultSshSecretBackendSign#cert_type}
    */
    readonly certType?: string;
    /**
    * Specifies a map of the critical options that the certificate should be signed for. Defaults to none.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/ssh_secret_backend_sign#critical_options DataVaultSshSecretBackendSign#critical_options}
    */
    readonly criticalOptions?: {
        [key: string]: string;
    };
    /**
    * Specifies a map of the extensions that the certificate should be signed for. Defaults to none.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/ssh_secret_backend_sign#extensions DataVaultSshSecretBackendSign#extensions}
    */
    readonly extensions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/ssh_secret_backend_sign#id DataVaultSshSecretBackendSign#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the key id that the created certificate should have. If not specified, the display name of the token will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/ssh_secret_backend_sign#key_id DataVaultSshSecretBackendSign#key_id}
    */
    readonly keyId?: string;
    /**
    * Specifies the name of the role to sign.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/ssh_secret_backend_sign#name DataVaultSshSecretBackendSign#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/ssh_secret_backend_sign#namespace DataVaultSshSecretBackendSign#namespace}
    */
    readonly namespace?: string;
    /**
    * Full path where SSH backend is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/ssh_secret_backend_sign#path DataVaultSshSecretBackendSign#path}
    */
    readonly path: string;
    /**
    * Specifies the SSH public key that should be signed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/ssh_secret_backend_sign#public_key DataVaultSshSecretBackendSign#public_key}
    */
    readonly publicKey: string;
    /**
    * Specifies the Requested Time To Live. Cannot be greater than the role's max_ttl value. If not provided, the role's ttl value will be used. Note that the role values default to system values if not explicitly set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/ssh_secret_backend_sign#ttl DataVaultSshSecretBackendSign#ttl}
    */
    readonly ttl?: string;
    /**
    * Specifies valid principals, either usernames or hostnames, that the certificate should be signed for. Required unless the role has specified allow_empty_principals or a value has been set for either the default_user or default_user_template role parameters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/ssh_secret_backend_sign#valid_principals DataVaultSshSecretBackendSign#valid_principals}
    */
    readonly validPrincipals?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/ssh_secret_backend_sign vault_ssh_secret_backend_sign}
*/
export declare class DataVaultSshSecretBackendSign extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_ssh_secret_backend_sign";
    /**
    * Generates CDKTN code for importing a DataVaultSshSecretBackendSign resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultSshSecretBackendSign to import
    * @param importFromId The id of the existing DataVaultSshSecretBackendSign that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/ssh_secret_backend_sign#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultSshSecretBackendSign to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/data-sources/ssh_secret_backend_sign vault_ssh_secret_backend_sign} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultSshSecretBackendSignConfig
    */
    constructor(scope: Construct, id: string, config: DataVaultSshSecretBackendSignConfig);
    private _certType?;
    get certType(): string;
    set certType(value: string);
    resetCertType(): void;
    get certTypeInput(): string | undefined;
    private _criticalOptions?;
    get criticalOptions(): {
        [key: string]: string;
    };
    set criticalOptions(value: {
        [key: string]: string;
    });
    resetCriticalOptions(): void;
    get criticalOptionsInput(): {
        [key: string]: string;
    } | undefined;
    private _extensions?;
    get extensions(): {
        [key: string]: string;
    };
    set extensions(value: {
        [key: string]: string;
    });
    resetExtensions(): void;
    get extensionsInput(): {
        [key: string]: string;
    } | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyId?;
    get keyId(): string;
    set keyId(value: string);
    resetKeyId(): void;
    get keyIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _publicKey?;
    get publicKey(): string;
    set publicKey(value: string);
    get publicKeyInput(): string | undefined;
    get serialNumber(): string;
    get signedKey(): string;
    private _ttl?;
    get ttl(): string;
    set ttl(value: string);
    resetTtl(): void;
    get ttlInput(): string | undefined;
    private _validPrincipals?;
    get validPrincipals(): string;
    set validPrincipals(value: string);
    resetValidPrincipals(): void;
    get validPrincipalsInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

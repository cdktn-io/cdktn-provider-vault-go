/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultIdentityOidcOpenidConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/data-sources/identity_oidc_openid_config#id DataVaultIdentityOidcOpenidConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/data-sources/identity_oidc_openid_config#name DataVaultIdentityOidcOpenidConfig#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/data-sources/identity_oidc_openid_config#namespace DataVaultIdentityOidcOpenidConfig#namespace}
    */
    readonly namespace?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/data-sources/identity_oidc_openid_config vault_identity_oidc_openid_config}
*/
export declare class DataVaultIdentityOidcOpenidConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_identity_oidc_openid_config";
    /**
    * Generates CDKTN code for importing a DataVaultIdentityOidcOpenidConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultIdentityOidcOpenidConfig to import
    * @param importFromId The id of the existing DataVaultIdentityOidcOpenidConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/data-sources/identity_oidc_openid_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultIdentityOidcOpenidConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/data-sources/identity_oidc_openid_config vault_identity_oidc_openid_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultIdentityOidcOpenidConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataVaultIdentityOidcOpenidConfigConfig);
    get authorizationEndpoint(): string;
    get grantTypesSupported(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get idTokenSigningAlgValuesSupported(): string[];
    get issuer(): string;
    get jwksUri(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get requestUriParameterSupported(): cdktn.IResolvable;
    get responseTypesSupported(): string[];
    get scopesSupported(): string[];
    get subjectTypesSupported(): string[];
    get tokenEndpoint(): string;
    get tokenEndpointAuthMethodsSupported(): string[];
    get userinfoEndpoint(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NomadSecretBackendConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies the address of the Nomad instance, provided as "protocol://host:port" like "http://127.0.0.1:4646".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#address NomadSecretBackend#address}
    */
    readonly address?: string;
    /**
    * List of managed key registry entry names that the mount in question is allowed to access
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#allowed_managed_keys NomadSecretBackend#allowed_managed_keys}
    */
    readonly allowedManagedKeys?: string[];
    /**
    * List of headers to allow and pass from the request to the plugin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#allowed_response_headers NomadSecretBackend#allowed_response_headers}
    */
    readonly allowedResponseHeaders?: string[];
    /**
    * Specifies the list of keys that will not be HMAC'd by audit devices in the request data object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#audit_non_hmac_request_keys NomadSecretBackend#audit_non_hmac_request_keys}
    */
    readonly auditNonHmacRequestKeys?: string[];
    /**
    * Specifies the list of keys that will not be HMAC'd by audit devices in the response data object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#audit_non_hmac_response_keys NomadSecretBackend#audit_non_hmac_response_keys}
    */
    readonly auditNonHmacResponseKeys?: string[];
    /**
    * The mount path for the Nomad backend.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#backend NomadSecretBackend#backend}
    */
    readonly backend?: string;
    /**
    * CA certificate to use when verifying Nomad server certificate, must be x509 PEM encoded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#ca_cert NomadSecretBackend#ca_cert}
    */
    readonly caCert?: string;
    /**
    * Client certificate used for Nomad's TLS communication, must be x509 PEM encoded and if this is set you need to also set client_key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#client_cert NomadSecretBackend#client_cert}
    */
    readonly clientCert?: string;
    /**
    * Client key used for Nomad's TLS communication, must be x509 PEM encoded and if this is set you need to also set client_cert.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#client_key NomadSecretBackend#client_key}
    */
    readonly clientKey?: string;
    /**
    * Write-only client key used for Nomad's TLS communication, must be x509 PEM encoded and if this is set you need to also set client_cert.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#client_key_wo NomadSecretBackend#client_key_wo}
    */
    readonly clientKeyWo?: string;
    /**
    * Version counter for write-only client_key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#client_key_wo_version NomadSecretBackend#client_key_wo_version}
    */
    readonly clientKeyWoVersion?: number;
    /**
    * Default lease duration for secrets in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#default_lease_ttl_seconds NomadSecretBackend#default_lease_ttl_seconds}
    */
    readonly defaultLeaseTtlSeconds?: number;
    /**
    * List of headers to allow and pass from the request to the plugin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#delegated_auth_accessors NomadSecretBackend#delegated_auth_accessors}
    */
    readonly delegatedAuthAccessors?: string[];
    /**
    * Human-friendly description of the mount for the backend.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#description NomadSecretBackend#description}
    */
    readonly description?: string;
    /**
    * If set, opts out of mount migration on path updates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#disable_remount NomadSecretBackend#disable_remount}
    */
    readonly disableRemount?: boolean | cdktn.IResolvable;
    /**
    * Enable the secrets engine to access Vault's external entropy source
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#external_entropy_access NomadSecretBackend#external_entropy_access}
    */
    readonly externalEntropyAccess?: boolean | cdktn.IResolvable;
    /**
    * If set to true, disables caching.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#force_no_cache NomadSecretBackend#force_no_cache}
    */
    readonly forceNoCache?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#id NomadSecretBackend#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The key to use for signing plugin workload identity tokens
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#identity_token_key NomadSecretBackend#identity_token_key}
    */
    readonly identityTokenKey?: string;
    /**
    * Specifies whether to show this mount in the UI-specific listing endpoint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#listing_visibility NomadSecretBackend#listing_visibility}
    */
    readonly listingVisibility?: string;
    /**
    * Mark the secrets engine as local-only. Local engines are not replicated or removed by replication. Tolerance duration to use when checking the last rotation time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#local NomadSecretBackend#local}
    */
    readonly local?: boolean | cdktn.IResolvable;
    /**
    * Maximum possible lease duration for secrets in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#max_lease_ttl_seconds NomadSecretBackend#max_lease_ttl_seconds}
    */
    readonly maxLeaseTtlSeconds?: number;
    /**
    * Specifies the maximum length to use for the name of the Nomad token generated with Generate Credential. If omitted, 0 is used and ignored, defaulting to the max value allowed by the Nomad version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#max_token_name_length NomadSecretBackend#max_token_name_length}
    */
    readonly maxTokenNameLength?: number;
    /**
    * Maximum possible lease duration for secrets in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#max_ttl NomadSecretBackend#max_ttl}
    */
    readonly maxTtl?: number;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#namespace NomadSecretBackend#namespace}
    */
    readonly namespace?: string;
    /**
    * Specifies mount type specific options that are passed to the backend
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#options NomadSecretBackend#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * List of headers to allow and pass from the request to the plugin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#passthrough_request_headers NomadSecretBackend#passthrough_request_headers}
    */
    readonly passthroughRequestHeaders?: string[];
    /**
    * Specifies the semantic version of the plugin to use, e.g. 'v1.0.0'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#plugin_version NomadSecretBackend#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * Enable seal wrapping for the mount, causing values stored by the mount to be wrapped by the seal's encryption capability
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#seal_wrap NomadSecretBackend#seal_wrap}
    */
    readonly sealWrap?: boolean | cdktn.IResolvable;
    /**
    * Specifies the Nomad Management token to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#token NomadSecretBackend#token}
    */
    readonly token?: string;
    /**
    * Write-only Nomad Management token to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#token_wo NomadSecretBackend#token_wo}
    */
    readonly tokenWo?: string;
    /**
    * Version counter for write-only token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#token_wo_version NomadSecretBackend#token_wo_version}
    */
    readonly tokenWoVersion?: number;
    /**
    * Maximum possible lease duration for secrets in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#ttl NomadSecretBackend#ttl}
    */
    readonly ttl?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend vault_nomad_secret_backend}
*/
export declare class NomadSecretBackend extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_nomad_secret_backend";
    /**
    * Generates CDKTN code for importing a NomadSecretBackend resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NomadSecretBackend to import
    * @param importFromId The id of the existing NomadSecretBackend that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NomadSecretBackend to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/nomad_secret_backend vault_nomad_secret_backend} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NomadSecretBackendConfig = {}
    */
    constructor(scope: Construct, id: string, config?: NomadSecretBackendConfig);
    get accessor(): string;
    private _address?;
    get address(): string;
    set address(value: string);
    resetAddress(): void;
    get addressInput(): string | undefined;
    private _allowedManagedKeys?;
    get allowedManagedKeys(): string[];
    set allowedManagedKeys(value: string[]);
    resetAllowedManagedKeys(): void;
    get allowedManagedKeysInput(): string[] | undefined;
    private _allowedResponseHeaders?;
    get allowedResponseHeaders(): string[];
    set allowedResponseHeaders(value: string[]);
    resetAllowedResponseHeaders(): void;
    get allowedResponseHeadersInput(): string[] | undefined;
    private _auditNonHmacRequestKeys?;
    get auditNonHmacRequestKeys(): string[];
    set auditNonHmacRequestKeys(value: string[]);
    resetAuditNonHmacRequestKeys(): void;
    get auditNonHmacRequestKeysInput(): string[] | undefined;
    private _auditNonHmacResponseKeys?;
    get auditNonHmacResponseKeys(): string[];
    set auditNonHmacResponseKeys(value: string[]);
    resetAuditNonHmacResponseKeys(): void;
    get auditNonHmacResponseKeysInput(): string[] | undefined;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    resetBackend(): void;
    get backendInput(): string | undefined;
    private _caCert?;
    get caCert(): string;
    set caCert(value: string);
    resetCaCert(): void;
    get caCertInput(): string | undefined;
    private _clientCert?;
    get clientCert(): string;
    set clientCert(value: string);
    resetClientCert(): void;
    get clientCertInput(): string | undefined;
    private _clientKey?;
    get clientKey(): string;
    set clientKey(value: string);
    resetClientKey(): void;
    get clientKeyInput(): string | undefined;
    private _clientKeyWo?;
    get clientKeyWo(): string;
    set clientKeyWo(value: string);
    resetClientKeyWo(): void;
    get clientKeyWoInput(): string | undefined;
    private _clientKeyWoVersion?;
    get clientKeyWoVersion(): number;
    set clientKeyWoVersion(value: number);
    resetClientKeyWoVersion(): void;
    get clientKeyWoVersionInput(): number | undefined;
    private _defaultLeaseTtlSeconds?;
    get defaultLeaseTtlSeconds(): number;
    set defaultLeaseTtlSeconds(value: number);
    resetDefaultLeaseTtlSeconds(): void;
    get defaultLeaseTtlSecondsInput(): number | undefined;
    private _delegatedAuthAccessors?;
    get delegatedAuthAccessors(): string[];
    set delegatedAuthAccessors(value: string[]);
    resetDelegatedAuthAccessors(): void;
    get delegatedAuthAccessorsInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableRemount?;
    get disableRemount(): boolean | cdktn.IResolvable;
    set disableRemount(value: boolean | cdktn.IResolvable);
    resetDisableRemount(): void;
    get disableRemountInput(): boolean | cdktn.IResolvable | undefined;
    private _externalEntropyAccess?;
    get externalEntropyAccess(): boolean | cdktn.IResolvable;
    set externalEntropyAccess(value: boolean | cdktn.IResolvable);
    resetExternalEntropyAccess(): void;
    get externalEntropyAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _forceNoCache?;
    get forceNoCache(): boolean | cdktn.IResolvable;
    set forceNoCache(value: boolean | cdktn.IResolvable);
    resetForceNoCache(): void;
    get forceNoCacheInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityTokenKey?;
    get identityTokenKey(): string;
    set identityTokenKey(value: string);
    resetIdentityTokenKey(): void;
    get identityTokenKeyInput(): string | undefined;
    private _listingVisibility?;
    get listingVisibility(): string;
    set listingVisibility(value: string);
    resetListingVisibility(): void;
    get listingVisibilityInput(): string | undefined;
    private _local?;
    get local(): boolean | cdktn.IResolvable;
    set local(value: boolean | cdktn.IResolvable);
    resetLocal(): void;
    get localInput(): boolean | cdktn.IResolvable | undefined;
    private _maxLeaseTtlSeconds?;
    get maxLeaseTtlSeconds(): number;
    set maxLeaseTtlSeconds(value: number);
    resetMaxLeaseTtlSeconds(): void;
    get maxLeaseTtlSecondsInput(): number | undefined;
    private _maxTokenNameLength?;
    get maxTokenNameLength(): number;
    set maxTokenNameLength(value: number);
    resetMaxTokenNameLength(): void;
    get maxTokenNameLengthInput(): number | undefined;
    private _maxTtl?;
    get maxTtl(): number;
    set maxTtl(value: number);
    resetMaxTtl(): void;
    get maxTtlInput(): number | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _passthroughRequestHeaders?;
    get passthroughRequestHeaders(): string[];
    set passthroughRequestHeaders(value: string[]);
    resetPassthroughRequestHeaders(): void;
    get passthroughRequestHeadersInput(): string[] | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _sealWrap?;
    get sealWrap(): boolean | cdktn.IResolvable;
    set sealWrap(value: boolean | cdktn.IResolvable);
    resetSealWrap(): void;
    get sealWrapInput(): boolean | cdktn.IResolvable | undefined;
    private _token?;
    get token(): string;
    set token(value: string);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _tokenWo?;
    get tokenWo(): string;
    set tokenWo(value: string);
    resetTokenWo(): void;
    get tokenWoInput(): string | undefined;
    private _tokenWoVersion?;
    get tokenWoVersion(): number;
    set tokenWoVersion(value: number);
    resetTokenWoVersion(): void;
    get tokenWoVersionInput(): number | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

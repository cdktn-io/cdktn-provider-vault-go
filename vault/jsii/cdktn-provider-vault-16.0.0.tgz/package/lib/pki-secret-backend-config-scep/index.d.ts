/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PkiSecretBackendConfigScepConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of allowed digest algorithms for SCEP requests
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_config_scep#allowed_digest_algorithms PkiSecretBackendConfigScep#allowed_digest_algorithms}
    */
    readonly allowedDigestAlgorithms?: string[];
    /**
    * List of allowed encryption algorithms for SCEP requests
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_config_scep#allowed_encryption_algorithms PkiSecretBackendConfigScep#allowed_encryption_algorithms}
    */
    readonly allowedEncryptionAlgorithms?: string[];
    /**
    * The PKI secret backend the resource belongs to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_config_scep#backend PkiSecretBackendConfigScep#backend}
    */
    readonly backend: string;
    /**
    * Specifies the behavior for requests using the default SCEP label. Can be sign-verbatim or a role given by role:<role_name>
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_config_scep#default_path_policy PkiSecretBackendConfigScep#default_path_policy}
    */
    readonly defaultPathPolicy?: string;
    /**
    * Specifies whether SCEP is enabled
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_config_scep#enabled PkiSecretBackendConfigScep#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_config_scep#id PkiSecretBackendConfigScep#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The level of logging verbosity, affects only SCEP logs on this mount
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_config_scep#log_level PkiSecretBackendConfigScep#log_level}
    */
    readonly logLevel?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_config_scep#namespace PkiSecretBackendConfigScep#namespace}
    */
    readonly namespace?: string;
    /**
    * If true, only return the issuer CA, otherwise the entire CA certificate chain will be returned if available from the PKI mount
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_config_scep#restrict_ca_chain_to_issuer PkiSecretBackendConfigScep#restrict_ca_chain_to_issuer}
    */
    readonly restrictCaChainToIssuer?: boolean | cdktn.IResolvable;
    /**
    * authenticators block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_config_scep#authenticators PkiSecretBackendConfigScep#authenticators}
    */
    readonly authenticators?: PkiSecretBackendConfigScepAuthenticators;
    /**
    * external_validation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_config_scep#external_validation PkiSecretBackendConfigScep#external_validation}
    */
    readonly externalValidation?: PkiSecretBackendConfigScepExternalValidation[] | cdktn.IResolvable;
}
export interface PkiSecretBackendConfigScepAuthenticators {
    /**
    * The accessor and cert_role properties for cert auth backends
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_config_scep#cert PkiSecretBackendConfigScep#cert}
    */
    readonly cert?: {
        [key: string]: string;
    };
    /**
    * The accessor property for SCEP auth backends
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_config_scep#scep PkiSecretBackendConfigScep#scep}
    */
    readonly scep?: {
        [key: string]: string;
    };
}
export declare function pkiSecretBackendConfigScepAuthenticatorsToTerraform(struct?: PkiSecretBackendConfigScepAuthenticatorsOutputReference | PkiSecretBackendConfigScepAuthenticators): any;
export declare function pkiSecretBackendConfigScepAuthenticatorsToHclTerraform(struct?: PkiSecretBackendConfigScepAuthenticatorsOutputReference | PkiSecretBackendConfigScepAuthenticators): any;
export declare class PkiSecretBackendConfigScepAuthenticatorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PkiSecretBackendConfigScepAuthenticators | undefined;
    set internalValue(value: PkiSecretBackendConfigScepAuthenticators | undefined);
    private _cert?;
    get cert(): {
        [key: string]: string;
    };
    set cert(value: {
        [key: string]: string;
    });
    resetCert(): void;
    get certInput(): {
        [key: string]: string;
    } | undefined;
    private _scep?;
    get scep(): {
        [key: string]: string;
    };
    set scep(value: {
        [key: string]: string;
    });
    resetScep(): void;
    get scepInput(): {
        [key: string]: string;
    } | undefined;
}
export interface PkiSecretBackendConfigScepExternalValidation {
    /**
    * The credentials to enable Microsoft Intune validation of SCEP requests
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_config_scep#intune PkiSecretBackendConfigScep#intune}
    */
    readonly intune?: {
        [key: string]: string;
    };
}
export declare function pkiSecretBackendConfigScepExternalValidationToTerraform(struct?: PkiSecretBackendConfigScepExternalValidation | cdktn.IResolvable): any;
export declare function pkiSecretBackendConfigScepExternalValidationToHclTerraform(struct?: PkiSecretBackendConfigScepExternalValidation | cdktn.IResolvable): any;
export declare class PkiSecretBackendConfigScepExternalValidationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PkiSecretBackendConfigScepExternalValidation | cdktn.IResolvable | undefined;
    set internalValue(value: PkiSecretBackendConfigScepExternalValidation | cdktn.IResolvable | undefined);
    private _intune?;
    get intune(): {
        [key: string]: string;
    };
    set intune(value: {
        [key: string]: string;
    });
    resetIntune(): void;
    get intuneInput(): {
        [key: string]: string;
    } | undefined;
}
export declare class PkiSecretBackendConfigScepExternalValidationList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: PkiSecretBackendConfigScepExternalValidation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PkiSecretBackendConfigScepExternalValidationOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_config_scep vault_pki_secret_backend_config_scep}
*/
export declare class PkiSecretBackendConfigScep extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_pki_secret_backend_config_scep";
    /**
    * Generates CDKTN code for importing a PkiSecretBackendConfigScep resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PkiSecretBackendConfigScep to import
    * @param importFromId The id of the existing PkiSecretBackendConfigScep that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_config_scep#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PkiSecretBackendConfigScep to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_config_scep vault_pki_secret_backend_config_scep} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PkiSecretBackendConfigScepConfig
    */
    constructor(scope: Construct, id: string, config: PkiSecretBackendConfigScepConfig);
    private _allowedDigestAlgorithms?;
    get allowedDigestAlgorithms(): string[];
    set allowedDigestAlgorithms(value: string[]);
    resetAllowedDigestAlgorithms(): void;
    get allowedDigestAlgorithmsInput(): string[] | undefined;
    private _allowedEncryptionAlgorithms?;
    get allowedEncryptionAlgorithms(): string[];
    set allowedEncryptionAlgorithms(value: string[]);
    resetAllowedEncryptionAlgorithms(): void;
    get allowedEncryptionAlgorithmsInput(): string[] | undefined;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    private _defaultPathPolicy?;
    get defaultPathPolicy(): string;
    set defaultPathPolicy(value: string);
    resetDefaultPathPolicy(): void;
    get defaultPathPolicyInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdated(): string;
    private _logLevel?;
    get logLevel(): string;
    set logLevel(value: string);
    resetLogLevel(): void;
    get logLevelInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _restrictCaChainToIssuer?;
    get restrictCaChainToIssuer(): boolean | cdktn.IResolvable;
    set restrictCaChainToIssuer(value: boolean | cdktn.IResolvable);
    resetRestrictCaChainToIssuer(): void;
    get restrictCaChainToIssuerInput(): boolean | cdktn.IResolvable | undefined;
    private _authenticators;
    get authenticators(): PkiSecretBackendConfigScepAuthenticatorsOutputReference;
    putAuthenticators(value: PkiSecretBackendConfigScepAuthenticators): void;
    resetAuthenticators(): void;
    get authenticatorsInput(): PkiSecretBackendConfigScepAuthenticators | undefined;
    private _externalValidation;
    get externalValidation(): PkiSecretBackendConfigScepExternalValidationList;
    putExternalValidation(value: PkiSecretBackendConfigScepExternalValidation[] | cdktn.IResolvable): void;
    resetExternalValidation(): void;
    get externalValidationInput(): cdktn.IResolvable | PkiSecretBackendConfigScepExternalValidation[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SecretsSyncAwsDestinationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Access key id to authenticate against the AWS secrets manager.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/secrets_sync_aws_destination#access_key_id SecretsSyncAwsDestination#access_key_id}
    */
    readonly accessKeyId?: string;
    /**
    * Allowed IPv4 addresses for outbound connections from Vault to AWS Secrets Manager. Can also be set via an IP address range using CIDR notation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/secrets_sync_aws_destination#allowed_ipv4_addresses SecretsSyncAwsDestination#allowed_ipv4_addresses}
    */
    readonly allowedIpv4Addresses?: string[];
    /**
    * Allowed IPv6 addresses for outbound connections from Vault to AWS Secrets Manager. Can also be set via an IP address range using CIDR notation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/secrets_sync_aws_destination#allowed_ipv6_addresses SecretsSyncAwsDestination#allowed_ipv6_addresses}
    */
    readonly allowedIpv6Addresses?: string[];
    /**
    * Allowed ports for outbound connections from Vault to AWS Secrets Manager.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/secrets_sync_aws_destination#allowed_ports SecretsSyncAwsDestination#allowed_ports}
    */
    readonly allowedPorts?: number[];
    /**
    * Custom tags to set on the secret managed at the destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/secrets_sync_aws_destination#custom_tags SecretsSyncAwsDestination#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
    /**
    * Disable strict networking mode. When set to true, Vault will not enforce allowed IP addresses and ports.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/secrets_sync_aws_destination#disable_strict_networking SecretsSyncAwsDestination#disable_strict_networking}
    */
    readonly disableStrictNetworking?: boolean | cdktn.IResolvable;
    /**
    * Extra protection that must match the trust policy granting access to the AWS IAM role ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/secrets_sync_aws_destination#external_id SecretsSyncAwsDestination#external_id}
    */
    readonly externalId?: string;
    /**
    * Determines what level of information is synced as a distinct resource at the destination. Can be 'secret-path' or 'secret-key'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/secrets_sync_aws_destination#granularity SecretsSyncAwsDestination#granularity}
    */
    readonly granularity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/secrets_sync_aws_destination#id SecretsSyncAwsDestination#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Unique name of the AWS destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/secrets_sync_aws_destination#name SecretsSyncAwsDestination#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/secrets_sync_aws_destination#namespace SecretsSyncAwsDestination#namespace}
    */
    readonly namespace?: string;
    /**
    * Region where to manage the secrets manager entries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/secrets_sync_aws_destination#region SecretsSyncAwsDestination#region}
    */
    readonly region?: string;
    /**
    * Specifies a role to assume when connecting to AWS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/secrets_sync_aws_destination#role_arn SecretsSyncAwsDestination#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Secret access key to authenticate against the AWS secrets manager.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/secrets_sync_aws_destination#secret_access_key SecretsSyncAwsDestination#secret_access_key}
    */
    readonly secretAccessKey?: string;
    /**
    * Template describing how to generate external secret names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/secrets_sync_aws_destination#secret_name_template SecretsSyncAwsDestination#secret_name_template}
    */
    readonly secretNameTemplate?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/secrets_sync_aws_destination vault_secrets_sync_aws_destination}
*/
export declare class SecretsSyncAwsDestination extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_secrets_sync_aws_destination";
    /**
    * Generates CDKTN code for importing a SecretsSyncAwsDestination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecretsSyncAwsDestination to import
    * @param importFromId The id of the existing SecretsSyncAwsDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/secrets_sync_aws_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecretsSyncAwsDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/secrets_sync_aws_destination vault_secrets_sync_aws_destination} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecretsSyncAwsDestinationConfig
    */
    constructor(scope: Construct, id: string, config: SecretsSyncAwsDestinationConfig);
    private _accessKeyId?;
    get accessKeyId(): string;
    set accessKeyId(value: string);
    resetAccessKeyId(): void;
    get accessKeyIdInput(): string | undefined;
    private _allowedIpv4Addresses?;
    get allowedIpv4Addresses(): string[];
    set allowedIpv4Addresses(value: string[]);
    resetAllowedIpv4Addresses(): void;
    get allowedIpv4AddressesInput(): string[] | undefined;
    private _allowedIpv6Addresses?;
    get allowedIpv6Addresses(): string[];
    set allowedIpv6Addresses(value: string[]);
    resetAllowedIpv6Addresses(): void;
    get allowedIpv6AddressesInput(): string[] | undefined;
    private _allowedPorts?;
    get allowedPorts(): number[];
    set allowedPorts(value: number[]);
    resetAllowedPorts(): void;
    get allowedPortsInput(): number[] | undefined;
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _disableStrictNetworking?;
    get disableStrictNetworking(): boolean | cdktn.IResolvable;
    set disableStrictNetworking(value: boolean | cdktn.IResolvable);
    resetDisableStrictNetworking(): void;
    get disableStrictNetworkingInput(): boolean | cdktn.IResolvable | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _granularity?;
    get granularity(): string;
    set granularity(value: string);
    resetGranularity(): void;
    get granularityInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _secretAccessKey?;
    get secretAccessKey(): string;
    set secretAccessKey(value: string);
    resetSecretAccessKey(): void;
    get secretAccessKeyInput(): string | undefined;
    private _secretNameTemplate?;
    get secretNameTemplate(): string;
    set secretNameTemplate(value: string);
    resetSecretNameTemplate(): void;
    get secretNameTemplateInput(): string | undefined;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GcpSecretBackendConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of managed key registry entry names that the mount in question is allowed to access
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#allowed_managed_keys GcpSecretBackend#allowed_managed_keys}
    */
    readonly allowedManagedKeys?: string[];
    /**
    * List of headers to allow and pass from the request to the plugin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#allowed_response_headers GcpSecretBackend#allowed_response_headers}
    */
    readonly allowedResponseHeaders?: string[];
    /**
    * Specifies the list of keys that will not be HMAC'd by audit devices in the request data object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#audit_non_hmac_request_keys GcpSecretBackend#audit_non_hmac_request_keys}
    */
    readonly auditNonHmacRequestKeys?: string[];
    /**
    * Specifies the list of keys that will not be HMAC'd by audit devices in the response data object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#audit_non_hmac_response_keys GcpSecretBackend#audit_non_hmac_response_keys}
    */
    readonly auditNonHmacResponseKeys?: string[];
    /**
    * JSON-encoded credentials to use to connect to GCP
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#credentials GcpSecretBackend#credentials}
    */
    readonly credentials?: string;
    /**
    * Write-only JSON-encoded credentials to use to connect to GCP
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#credentials_wo GcpSecretBackend#credentials_wo}
    */
    readonly credentialsWo?: string;
    /**
    * Version counter for write-only JSON-encoded credentials
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#credentials_wo_version GcpSecretBackend#credentials_wo_version}
    */
    readonly credentialsWoVersion?: number;
    /**
    * Default lease duration for secrets in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#default_lease_ttl_seconds GcpSecretBackend#default_lease_ttl_seconds}
    */
    readonly defaultLeaseTtlSeconds?: number;
    /**
    * List of headers to allow and pass from the request to the plugin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#delegated_auth_accessors GcpSecretBackend#delegated_auth_accessors}
    */
    readonly delegatedAuthAccessors?: string[];
    /**
    * Human-friendly description of the mount for the backend.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#description GcpSecretBackend#description}
    */
    readonly description?: string;
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#disable_automated_rotation GcpSecretBackend#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * If set, opts out of mount migration on path updates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#disable_remount GcpSecretBackend#disable_remount}
    */
    readonly disableRemount?: boolean | cdktn.IResolvable;
    /**
    * Enable the secrets engine to access Vault's external entropy source
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#external_entropy_access GcpSecretBackend#external_entropy_access}
    */
    readonly externalEntropyAccess?: boolean | cdktn.IResolvable;
    /**
    * If set to true, disables caching.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#force_no_cache GcpSecretBackend#force_no_cache}
    */
    readonly forceNoCache?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#id GcpSecretBackend#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The audience claim value for plugin identity tokens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#identity_token_audience GcpSecretBackend#identity_token_audience}
    */
    readonly identityTokenAudience?: string;
    /**
    * The key to use for signing identity tokens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#identity_token_key GcpSecretBackend#identity_token_key}
    */
    readonly identityTokenKey?: string;
    /**
    * The TTL of generated tokens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#identity_token_ttl GcpSecretBackend#identity_token_ttl}
    */
    readonly identityTokenTtl?: number;
    /**
    * Specifies whether to show this mount in the UI-specific listing endpoint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#listing_visibility GcpSecretBackend#listing_visibility}
    */
    readonly listingVisibility?: string;
    /**
    * Local mount flag that can be explicitly set to true to enforce local mount in HA environment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#local GcpSecretBackend#local}
    */
    readonly local?: boolean | cdktn.IResolvable;
    /**
    * Maximum possible lease duration for secrets in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#max_lease_ttl_seconds GcpSecretBackend#max_lease_ttl_seconds}
    */
    readonly maxLeaseTtlSeconds?: number;
    /**
    * The maximum TTL for long-lived credentials (i.e. service account keys).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#max_ttl GcpSecretBackend#max_ttl}
    */
    readonly maxTtl?: number;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#namespace GcpSecretBackend#namespace}
    */
    readonly namespace?: string;
    /**
    * Specifies mount type specific options that are passed to the backend
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#options GcpSecretBackend#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * List of headers to allow and pass from the request to the plugin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#passthrough_request_headers GcpSecretBackend#passthrough_request_headers}
    */
    readonly passthroughRequestHeaders?: string[];
    /**
    * Path to mount the backend at.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#path GcpSecretBackend#path}
    */
    readonly path?: string;
    /**
    * Specifies the semantic version of the plugin to use, e.g. 'v1.0.0'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#plugin_version GcpSecretBackend#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#rotation_period GcpSecretBackend#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#rotation_schedule GcpSecretBackend#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#rotation_window GcpSecretBackend#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * Enable seal wrapping for the mount, causing values stored by the mount to be wrapped by the seal's encryption capability
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#seal_wrap GcpSecretBackend#seal_wrap}
    */
    readonly sealWrap?: boolean | cdktn.IResolvable;
    /**
    * Service Account to impersonate for plugin workload identity federation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#service_account_email GcpSecretBackend#service_account_email}
    */
    readonly serviceAccountEmail?: string;
    /**
    * The default TTL for long-lived credentials (i.e. service account keys).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#ttl GcpSecretBackend#ttl}
    */
    readonly ttl?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend vault_gcp_secret_backend}
*/
export declare class GcpSecretBackend extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_gcp_secret_backend";
    /**
    * Generates CDKTN code for importing a GcpSecretBackend resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GcpSecretBackend to import
    * @param importFromId The id of the existing GcpSecretBackend that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GcpSecretBackend to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/gcp_secret_backend vault_gcp_secret_backend} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GcpSecretBackendConfig = {}
    */
    constructor(scope: Construct, id: string, config?: GcpSecretBackendConfig);
    get accessor(): string;
    private _allowedManagedKeys?;
    get allowedManagedKeys(): string[];
    set allowedManagedKeys(value: string[]);
    resetAllowedManagedKeys(): void;
    get allowedManagedKeysInput(): string[] | undefined;
    private _allowedResponseHeaders?;
    get allowedResponseHeaders(): string[];
    set allowedResponseHeaders(value: string[]);
    resetAllowedResponseHeaders(): void;
    get allowedResponseHeadersInput(): string[] | undefined;
    private _auditNonHmacRequestKeys?;
    get auditNonHmacRequestKeys(): string[];
    set auditNonHmacRequestKeys(value: string[]);
    resetAuditNonHmacRequestKeys(): void;
    get auditNonHmacRequestKeysInput(): string[] | undefined;
    private _auditNonHmacResponseKeys?;
    get auditNonHmacResponseKeys(): string[];
    set auditNonHmacResponseKeys(value: string[]);
    resetAuditNonHmacResponseKeys(): void;
    get auditNonHmacResponseKeysInput(): string[] | undefined;
    private _credentials?;
    get credentials(): string;
    set credentials(value: string);
    resetCredentials(): void;
    get credentialsInput(): string | undefined;
    private _credentialsWo?;
    get credentialsWo(): string;
    set credentialsWo(value: string);
    resetCredentialsWo(): void;
    get credentialsWoInput(): string | undefined;
    private _credentialsWoVersion?;
    get credentialsWoVersion(): number;
    set credentialsWoVersion(value: number);
    resetCredentialsWoVersion(): void;
    get credentialsWoVersionInput(): number | undefined;
    private _defaultLeaseTtlSeconds?;
    get defaultLeaseTtlSeconds(): number;
    set defaultLeaseTtlSeconds(value: number);
    resetDefaultLeaseTtlSeconds(): void;
    get defaultLeaseTtlSecondsInput(): number | undefined;
    private _delegatedAuthAccessors?;
    get delegatedAuthAccessors(): string[];
    set delegatedAuthAccessors(value: string[]);
    resetDelegatedAuthAccessors(): void;
    get delegatedAuthAccessorsInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _disableRemount?;
    get disableRemount(): boolean | cdktn.IResolvable;
    set disableRemount(value: boolean | cdktn.IResolvable);
    resetDisableRemount(): void;
    get disableRemountInput(): boolean | cdktn.IResolvable | undefined;
    private _externalEntropyAccess?;
    get externalEntropyAccess(): boolean | cdktn.IResolvable;
    set externalEntropyAccess(value: boolean | cdktn.IResolvable);
    resetExternalEntropyAccess(): void;
    get externalEntropyAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _forceNoCache?;
    get forceNoCache(): boolean | cdktn.IResolvable;
    set forceNoCache(value: boolean | cdktn.IResolvable);
    resetForceNoCache(): void;
    get forceNoCacheInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityTokenAudience?;
    get identityTokenAudience(): string;
    set identityTokenAudience(value: string);
    resetIdentityTokenAudience(): void;
    get identityTokenAudienceInput(): string | undefined;
    private _identityTokenKey?;
    get identityTokenKey(): string;
    set identityTokenKey(value: string);
    resetIdentityTokenKey(): void;
    get identityTokenKeyInput(): string | undefined;
    private _identityTokenTtl?;
    get identityTokenTtl(): number;
    set identityTokenTtl(value: number);
    resetIdentityTokenTtl(): void;
    get identityTokenTtlInput(): number | undefined;
    private _listingVisibility?;
    get listingVisibility(): string;
    set listingVisibility(value: string);
    resetListingVisibility(): void;
    get listingVisibilityInput(): string | undefined;
    private _local?;
    get local(): boolean | cdktn.IResolvable;
    set local(value: boolean | cdktn.IResolvable);
    resetLocal(): void;
    get localInput(): boolean | cdktn.IResolvable | undefined;
    private _maxLeaseTtlSeconds?;
    get maxLeaseTtlSeconds(): number;
    set maxLeaseTtlSeconds(value: number);
    resetMaxLeaseTtlSeconds(): void;
    get maxLeaseTtlSecondsInput(): number | undefined;
    private _maxTtl?;
    get maxTtl(): number;
    set maxTtl(value: number);
    resetMaxTtl(): void;
    get maxTtlInput(): number | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _passthroughRequestHeaders?;
    get passthroughRequestHeaders(): string[];
    set passthroughRequestHeaders(value: string[]);
    resetPassthroughRequestHeaders(): void;
    get passthroughRequestHeadersInput(): string[] | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _sealWrap?;
    get sealWrap(): boolean | cdktn.IResolvable;
    set sealWrap(value: boolean | cdktn.IResolvable);
    resetSealWrap(): void;
    get sealWrapInput(): boolean | cdktn.IResolvable | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    resetServiceAccountEmail(): void;
    get serviceAccountEmailInput(): string | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

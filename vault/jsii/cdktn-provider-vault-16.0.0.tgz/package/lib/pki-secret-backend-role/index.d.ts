/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PkiSecretBackendRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Flag to allow any name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#allow_any_name PkiSecretBackendRole#allow_any_name}
    */
    readonly allowAnyName?: boolean | cdktn.IResolvable;
    /**
    * Flag to allow certificates matching the actual domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#allow_bare_domains PkiSecretBackendRole#allow_bare_domains}
    */
    readonly allowBareDomains?: boolean | cdktn.IResolvable;
    /**
    * Flag to allow names containing glob patterns.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#allow_glob_domains PkiSecretBackendRole#allow_glob_domains}
    */
    readonly allowGlobDomains?: boolean | cdktn.IResolvable;
    /**
    * Flag to allow IP SANs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#allow_ip_sans PkiSecretBackendRole#allow_ip_sans}
    */
    readonly allowIpSans?: boolean | cdktn.IResolvable;
    /**
    * Flag to allow certificates for localhost.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#allow_localhost PkiSecretBackendRole#allow_localhost}
    */
    readonly allowLocalhost?: boolean | cdktn.IResolvable;
    /**
    * Flag to allow certificates matching subdomains.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#allow_subdomains PkiSecretBackendRole#allow_subdomains}
    */
    readonly allowSubdomains?: boolean | cdktn.IResolvable;
    /**
    * Flag to allow wildcard certificates
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#allow_wildcard_certificates PkiSecretBackendRole#allow_wildcard_certificates}
    */
    readonly allowWildcardCertificates?: boolean | cdktn.IResolvable;
    /**
    * The domains of the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#allowed_domains PkiSecretBackendRole#allowed_domains}
    */
    readonly allowedDomains?: string[];
    /**
    * Flag to indicate that `allowed_domains` specifies a template expression (e.g. {{identity.entity.aliases.<mount accessor>.name}})
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#allowed_domains_template PkiSecretBackendRole#allowed_domains_template}
    */
    readonly allowedDomainsTemplate?: boolean | cdktn.IResolvable;
    /**
    * Defines allowed custom SANs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#allowed_other_sans PkiSecretBackendRole#allowed_other_sans}
    */
    readonly allowedOtherSans?: string[];
    /**
    * Defines allowed Subject serial numbers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#allowed_serial_numbers PkiSecretBackendRole#allowed_serial_numbers}
    */
    readonly allowedSerialNumbers?: string[];
    /**
    * Defines allowed URI SANs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#allowed_uri_sans PkiSecretBackendRole#allowed_uri_sans}
    */
    readonly allowedUriSans?: string[];
    /**
    * Flag to indicate that `allowed_uri_sans` specifies a template expression (e.g. {{identity.entity.aliases.<mount accessor>.name}})
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#allowed_uri_sans_template PkiSecretBackendRole#allowed_uri_sans_template}
    */
    readonly allowedUriSansTemplate?: boolean | cdktn.IResolvable;
    /**
    * The allowed User ID's.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#allowed_user_ids PkiSecretBackendRole#allowed_user_ids}
    */
    readonly allowedUserIds?: string[];
    /**
    * The path of the PKI secret backend the resource belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#backend PkiSecretBackendRole#backend}
    */
    readonly backend: string;
    /**
    * Flag to mark basic constraints valid when issuing non-CA certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#basic_constraints_valid_for_non_ca PkiSecretBackendRole#basic_constraints_valid_for_non_ca}
    */
    readonly basicConstraintsValidForNonCa?: boolean | cdktn.IResolvable;
    /**
    * Flag to specify certificates for client use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#client_flag PkiSecretBackendRole#client_flag}
    */
    readonly clientFlag?: boolean | cdktn.IResolvable;
    /**
    * Specify validations to run on the Common Name field of the certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#cn_validations PkiSecretBackendRole#cn_validations}
    */
    readonly cnValidations?: string[];
    /**
    * Flag to specify certificates for code signing use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#code_signing_flag PkiSecretBackendRole#code_signing_flag}
    */
    readonly codeSigningFlag?: boolean | cdktn.IResolvable;
    /**
    * The country of generated certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#country PkiSecretBackendRole#country}
    */
    readonly country?: string[];
    /**
    * Flag to specify certificates for email protection use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#email_protection_flag PkiSecretBackendRole#email_protection_flag}
    */
    readonly emailProtectionFlag?: boolean | cdktn.IResolvable;
    /**
    * Flag to allow only valid host names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#enforce_hostnames PkiSecretBackendRole#enforce_hostnames}
    */
    readonly enforceHostnames?: boolean | cdktn.IResolvable;
    /**
    * Specify the allowed extended key usage constraint on issued certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#ext_key_usage PkiSecretBackendRole#ext_key_usage}
    */
    readonly extKeyUsage?: string[];
    /**
    * A list of extended key usage OIDs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#ext_key_usage_oids PkiSecretBackendRole#ext_key_usage_oids}
    */
    readonly extKeyUsageOids?: string[];
    /**
    * Flag to generate leases with certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#generate_lease PkiSecretBackendRole#generate_lease}
    */
    readonly generateLease?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#id PkiSecretBackendRole#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the default issuer of this request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#issuer_ref PkiSecretBackendRole#issuer_ref}
    */
    readonly issuerRef?: string;
    /**
    * The number of bits of generated keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#key_bits PkiSecretBackendRole#key_bits}
    */
    readonly keyBits?: number;
    /**
    * The generated key type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#key_type PkiSecretBackendRole#key_type}
    */
    readonly keyType?: string;
    /**
    * Specify the allowed key usage constraint on issued certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#key_usage PkiSecretBackendRole#key_usage}
    */
    readonly keyUsage?: string[];
    /**
    * The locality of generated certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#locality PkiSecretBackendRole#locality}
    */
    readonly locality?: string[];
    /**
    * The maximum TTL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#max_ttl PkiSecretBackendRole#max_ttl}
    */
    readonly maxTtl?: string;
    /**
    * Unique name for the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#name PkiSecretBackendRole#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#namespace PkiSecretBackendRole#namespace}
    */
    readonly namespace?: string;
    /**
    * Flag to not store certificates in the storage backend.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#no_store PkiSecretBackendRole#no_store}
    */
    readonly noStore?: boolean | cdktn.IResolvable;
    /**
    * Allows metadata to be stored keyed on the certificate's serial number. The field is independent of no_store, allowing metadata storage regardless of whether certificates are stored. If true, metadata is not stored and an error is returned if the metadata field is specified on issuance APIs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#no_store_metadata PkiSecretBackendRole#no_store_metadata}
    */
    readonly noStoreMetadata?: boolean | cdktn.IResolvable;
    /**
    * Set the Not After field of the certificate with specified date value. The value format should be given in UTC format YYYY-MM-ddTHH:MM:SSZ. Supports the Y10K end date for IEEE 802.1AR-2018 standard devices, 9999-12-31T23:59:59Z.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#not_after PkiSecretBackendRole#not_after}
    */
    readonly notAfter?: string;
    /**
    * Specifies the duration by which to backdate the NotBefore property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#not_before_duration PkiSecretBackendRole#not_before_duration}
    */
    readonly notBeforeDuration?: string;
    /**
    * The organization of generated certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#organization PkiSecretBackendRole#organization}
    */
    readonly organization?: string[];
    /**
    * The organization unit of generated certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#ou PkiSecretBackendRole#ou}
    */
    readonly ou?: string[];
    /**
    * Specify the list of allowed policies OIDs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#policy_identifiers PkiSecretBackendRole#policy_identifiers}
    */
    readonly policyIdentifiers?: string[];
    /**
    * The postal code of generated certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#postal_code PkiSecretBackendRole#postal_code}
    */
    readonly postalCode?: string[];
    /**
    * The province of generated certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#province PkiSecretBackendRole#province}
    */
    readonly province?: string[];
    /**
    * Flag to force CN usage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#require_cn PkiSecretBackendRole#require_cn}
    */
    readonly requireCn?: boolean | cdktn.IResolvable;
    /**
    * Specifies the source of the subject serial number. Valid values are json-csr (default) or json. When set to json-csr, the subject serial number is taken from the serial_number parameter and falls back to the serial number in the CSR. When set to json, the subject serial number is taken from the serial_number parameter but will ignore any value in the CSR. For backwards compatibility an empty value for this field will default to the json-csr behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#serial_number_source PkiSecretBackendRole#serial_number_source}
    */
    readonly serialNumberSource?: string;
    /**
    * Flag to specify certificates for server use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#server_flag PkiSecretBackendRole#server_flag}
    */
    readonly serverFlag?: boolean | cdktn.IResolvable;
    /**
    * The number of bits to use in the signature algorithm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#signature_bits PkiSecretBackendRole#signature_bits}
    */
    readonly signatureBits?: number;
    /**
    * The street address of generated certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#street_address PkiSecretBackendRole#street_address}
    */
    readonly streetAddress?: string[];
    /**
    * The TTL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#ttl PkiSecretBackendRole#ttl}
    */
    readonly ttl?: string;
    /**
    * Flag to use the CN in the CSR.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#use_csr_common_name PkiSecretBackendRole#use_csr_common_name}
    */
    readonly useCsrCommonName?: boolean | cdktn.IResolvable;
    /**
    * Flag to use the SANs in the CSR.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#use_csr_sans PkiSecretBackendRole#use_csr_sans}
    */
    readonly useCsrSans?: boolean | cdktn.IResolvable;
    /**
    * Specifies whether or not to use PSS signatures over PKCS#1v1.5 signatures when a RSA-type issuer is used. Ignored for ECDSA/Ed25519 issuers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#use_pss PkiSecretBackendRole#use_pss}
    */
    readonly usePss?: boolean | cdktn.IResolvable;
    /**
    * policy_identifier block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#policy_identifier PkiSecretBackendRole#policy_identifier}
    */
    readonly policyIdentifier?: PkiSecretBackendRolePolicyIdentifier[] | cdktn.IResolvable;
}
export interface PkiSecretBackendRolePolicyIdentifier {
    /**
    * Optional CPS URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#cps PkiSecretBackendRole#cps}
    */
    readonly cps?: string;
    /**
    * Optional notice
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#notice PkiSecretBackendRole#notice}
    */
    readonly notice?: string;
    /**
    * OID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#oid PkiSecretBackendRole#oid}
    */
    readonly oid: string;
}
export declare function pkiSecretBackendRolePolicyIdentifierToTerraform(struct?: PkiSecretBackendRolePolicyIdentifier | cdktn.IResolvable): any;
export declare function pkiSecretBackendRolePolicyIdentifierToHclTerraform(struct?: PkiSecretBackendRolePolicyIdentifier | cdktn.IResolvable): any;
export declare class PkiSecretBackendRolePolicyIdentifierOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PkiSecretBackendRolePolicyIdentifier | cdktn.IResolvable | undefined;
    set internalValue(value: PkiSecretBackendRolePolicyIdentifier | cdktn.IResolvable | undefined);
    private _cps?;
    get cps(): string;
    set cps(value: string);
    resetCps(): void;
    get cpsInput(): string | undefined;
    private _notice?;
    get notice(): string;
    set notice(value: string);
    resetNotice(): void;
    get noticeInput(): string | undefined;
    private _oid?;
    get oid(): string;
    set oid(value: string);
    get oidInput(): string | undefined;
}
export declare class PkiSecretBackendRolePolicyIdentifierList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: PkiSecretBackendRolePolicyIdentifier[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PkiSecretBackendRolePolicyIdentifierOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role vault_pki_secret_backend_role}
*/
export declare class PkiSecretBackendRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_pki_secret_backend_role";
    /**
    * Generates CDKTN code for importing a PkiSecretBackendRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PkiSecretBackendRole to import
    * @param importFromId The id of the existing PkiSecretBackendRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PkiSecretBackendRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_role vault_pki_secret_backend_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PkiSecretBackendRoleConfig
    */
    constructor(scope: Construct, id: string, config: PkiSecretBackendRoleConfig);
    private _allowAnyName?;
    get allowAnyName(): boolean | cdktn.IResolvable;
    set allowAnyName(value: boolean | cdktn.IResolvable);
    resetAllowAnyName(): void;
    get allowAnyNameInput(): boolean | cdktn.IResolvable | undefined;
    private _allowBareDomains?;
    get allowBareDomains(): boolean | cdktn.IResolvable;
    set allowBareDomains(value: boolean | cdktn.IResolvable);
    resetAllowBareDomains(): void;
    get allowBareDomainsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowGlobDomains?;
    get allowGlobDomains(): boolean | cdktn.IResolvable;
    set allowGlobDomains(value: boolean | cdktn.IResolvable);
    resetAllowGlobDomains(): void;
    get allowGlobDomainsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowIpSans?;
    get allowIpSans(): boolean | cdktn.IResolvable;
    set allowIpSans(value: boolean | cdktn.IResolvable);
    resetAllowIpSans(): void;
    get allowIpSansInput(): boolean | cdktn.IResolvable | undefined;
    private _allowLocalhost?;
    get allowLocalhost(): boolean | cdktn.IResolvable;
    set allowLocalhost(value: boolean | cdktn.IResolvable);
    resetAllowLocalhost(): void;
    get allowLocalhostInput(): boolean | cdktn.IResolvable | undefined;
    private _allowSubdomains?;
    get allowSubdomains(): boolean | cdktn.IResolvable;
    set allowSubdomains(value: boolean | cdktn.IResolvable);
    resetAllowSubdomains(): void;
    get allowSubdomainsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowWildcardCertificates?;
    get allowWildcardCertificates(): boolean | cdktn.IResolvable;
    set allowWildcardCertificates(value: boolean | cdktn.IResolvable);
    resetAllowWildcardCertificates(): void;
    get allowWildcardCertificatesInput(): boolean | cdktn.IResolvable | undefined;
    private _allowedDomains?;
    get allowedDomains(): string[];
    set allowedDomains(value: string[]);
    resetAllowedDomains(): void;
    get allowedDomainsInput(): string[] | undefined;
    private _allowedDomainsTemplate?;
    get allowedDomainsTemplate(): boolean | cdktn.IResolvable;
    set allowedDomainsTemplate(value: boolean | cdktn.IResolvable);
    resetAllowedDomainsTemplate(): void;
    get allowedDomainsTemplateInput(): boolean | cdktn.IResolvable | undefined;
    private _allowedOtherSans?;
    get allowedOtherSans(): string[];
    set allowedOtherSans(value: string[]);
    resetAllowedOtherSans(): void;
    get allowedOtherSansInput(): string[] | undefined;
    private _allowedSerialNumbers?;
    get allowedSerialNumbers(): string[];
    set allowedSerialNumbers(value: string[]);
    resetAllowedSerialNumbers(): void;
    get allowedSerialNumbersInput(): string[] | undefined;
    private _allowedUriSans?;
    get allowedUriSans(): string[];
    set allowedUriSans(value: string[]);
    resetAllowedUriSans(): void;
    get allowedUriSansInput(): string[] | undefined;
    private _allowedUriSansTemplate?;
    get allowedUriSansTemplate(): boolean | cdktn.IResolvable;
    set allowedUriSansTemplate(value: boolean | cdktn.IResolvable);
    resetAllowedUriSansTemplate(): void;
    get allowedUriSansTemplateInput(): boolean | cdktn.IResolvable | undefined;
    private _allowedUserIds?;
    get allowedUserIds(): string[];
    set allowedUserIds(value: string[]);
    resetAllowedUserIds(): void;
    get allowedUserIdsInput(): string[] | undefined;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    private _basicConstraintsValidForNonCa?;
    get basicConstraintsValidForNonCa(): boolean | cdktn.IResolvable;
    set basicConstraintsValidForNonCa(value: boolean | cdktn.IResolvable);
    resetBasicConstraintsValidForNonCa(): void;
    get basicConstraintsValidForNonCaInput(): boolean | cdktn.IResolvable | undefined;
    private _clientFlag?;
    get clientFlag(): boolean | cdktn.IResolvable;
    set clientFlag(value: boolean | cdktn.IResolvable);
    resetClientFlag(): void;
    get clientFlagInput(): boolean | cdktn.IResolvable | undefined;
    private _cnValidations?;
    get cnValidations(): string[];
    set cnValidations(value: string[]);
    resetCnValidations(): void;
    get cnValidationsInput(): string[] | undefined;
    private _codeSigningFlag?;
    get codeSigningFlag(): boolean | cdktn.IResolvable;
    set codeSigningFlag(value: boolean | cdktn.IResolvable);
    resetCodeSigningFlag(): void;
    get codeSigningFlagInput(): boolean | cdktn.IResolvable | undefined;
    private _country?;
    get country(): string[];
    set country(value: string[]);
    resetCountry(): void;
    get countryInput(): string[] | undefined;
    private _emailProtectionFlag?;
    get emailProtectionFlag(): boolean | cdktn.IResolvable;
    set emailProtectionFlag(value: boolean | cdktn.IResolvable);
    resetEmailProtectionFlag(): void;
    get emailProtectionFlagInput(): boolean | cdktn.IResolvable | undefined;
    private _enforceHostnames?;
    get enforceHostnames(): boolean | cdktn.IResolvable;
    set enforceHostnames(value: boolean | cdktn.IResolvable);
    resetEnforceHostnames(): void;
    get enforceHostnamesInput(): boolean | cdktn.IResolvable | undefined;
    private _extKeyUsage?;
    get extKeyUsage(): string[];
    set extKeyUsage(value: string[]);
    resetExtKeyUsage(): void;
    get extKeyUsageInput(): string[] | undefined;
    private _extKeyUsageOids?;
    get extKeyUsageOids(): string[];
    set extKeyUsageOids(value: string[]);
    resetExtKeyUsageOids(): void;
    get extKeyUsageOidsInput(): string[] | undefined;
    private _generateLease?;
    get generateLease(): boolean | cdktn.IResolvable;
    set generateLease(value: boolean | cdktn.IResolvable);
    resetGenerateLease(): void;
    get generateLeaseInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _issuerRef?;
    get issuerRef(): string;
    set issuerRef(value: string);
    resetIssuerRef(): void;
    get issuerRefInput(): string | undefined;
    private _keyBits?;
    get keyBits(): number;
    set keyBits(value: number);
    resetKeyBits(): void;
    get keyBitsInput(): number | undefined;
    private _keyType?;
    get keyType(): string;
    set keyType(value: string);
    resetKeyType(): void;
    get keyTypeInput(): string | undefined;
    private _keyUsage?;
    get keyUsage(): string[];
    set keyUsage(value: string[]);
    resetKeyUsage(): void;
    get keyUsageInput(): string[] | undefined;
    private _locality?;
    get locality(): string[];
    set locality(value: string[]);
    resetLocality(): void;
    get localityInput(): string[] | undefined;
    private _maxTtl?;
    get maxTtl(): string;
    set maxTtl(value: string);
    resetMaxTtl(): void;
    get maxTtlInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _noStore?;
    get noStore(): boolean | cdktn.IResolvable;
    set noStore(value: boolean | cdktn.IResolvable);
    resetNoStore(): void;
    get noStoreInput(): boolean | cdktn.IResolvable | undefined;
    private _noStoreMetadata?;
    get noStoreMetadata(): boolean | cdktn.IResolvable;
    set noStoreMetadata(value: boolean | cdktn.IResolvable);
    resetNoStoreMetadata(): void;
    get noStoreMetadataInput(): boolean | cdktn.IResolvable | undefined;
    private _notAfter?;
    get notAfter(): string;
    set notAfter(value: string);
    resetNotAfter(): void;
    get notAfterInput(): string | undefined;
    private _notBeforeDuration?;
    get notBeforeDuration(): string;
    set notBeforeDuration(value: string);
    resetNotBeforeDuration(): void;
    get notBeforeDurationInput(): string | undefined;
    private _organization?;
    get organization(): string[];
    set organization(value: string[]);
    resetOrganization(): void;
    get organizationInput(): string[] | undefined;
    private _ou?;
    get ou(): string[];
    set ou(value: string[]);
    resetOu(): void;
    get ouInput(): string[] | undefined;
    private _policyIdentifiers?;
    get policyIdentifiers(): string[];
    set policyIdentifiers(value: string[]);
    resetPolicyIdentifiers(): void;
    get policyIdentifiersInput(): string[] | undefined;
    private _postalCode?;
    get postalCode(): string[];
    set postalCode(value: string[]);
    resetPostalCode(): void;
    get postalCodeInput(): string[] | undefined;
    private _province?;
    get province(): string[];
    set province(value: string[]);
    resetProvince(): void;
    get provinceInput(): string[] | undefined;
    private _requireCn?;
    get requireCn(): boolean | cdktn.IResolvable;
    set requireCn(value: boolean | cdktn.IResolvable);
    resetRequireCn(): void;
    get requireCnInput(): boolean | cdktn.IResolvable | undefined;
    private _serialNumberSource?;
    get serialNumberSource(): string;
    set serialNumberSource(value: string);
    resetSerialNumberSource(): void;
    get serialNumberSourceInput(): string | undefined;
    private _serverFlag?;
    get serverFlag(): boolean | cdktn.IResolvable;
    set serverFlag(value: boolean | cdktn.IResolvable);
    resetServerFlag(): void;
    get serverFlagInput(): boolean | cdktn.IResolvable | undefined;
    private _signatureBits?;
    get signatureBits(): number;
    set signatureBits(value: number);
    resetSignatureBits(): void;
    get signatureBitsInput(): number | undefined;
    private _streetAddress?;
    get streetAddress(): string[];
    set streetAddress(value: string[]);
    resetStreetAddress(): void;
    get streetAddressInput(): string[] | undefined;
    private _ttl?;
    get ttl(): string;
    set ttl(value: string);
    resetTtl(): void;
    get ttlInput(): string | undefined;
    private _useCsrCommonName?;
    get useCsrCommonName(): boolean | cdktn.IResolvable;
    set useCsrCommonName(value: boolean | cdktn.IResolvable);
    resetUseCsrCommonName(): void;
    get useCsrCommonNameInput(): boolean | cdktn.IResolvable | undefined;
    private _useCsrSans?;
    get useCsrSans(): boolean | cdktn.IResolvable;
    set useCsrSans(value: boolean | cdktn.IResolvable);
    resetUseCsrSans(): void;
    get useCsrSansInput(): boolean | cdktn.IResolvable | undefined;
    private _usePss?;
    get usePss(): boolean | cdktn.IResolvable;
    set usePss(value: boolean | cdktn.IResolvable);
    resetUsePss(): void;
    get usePssInput(): boolean | cdktn.IResolvable | undefined;
    private _policyIdentifier;
    get policyIdentifier(): PkiSecretBackendRolePolicyIdentifierList;
    putPolicyIdentifier(value: PkiSecretBackendRolePolicyIdentifier[] | cdktn.IResolvable): void;
    resetPolicyIdentifier(): void;
    get policyIdentifierInput(): cdktn.IResolvable | PkiSecretBackendRolePolicyIdentifier[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

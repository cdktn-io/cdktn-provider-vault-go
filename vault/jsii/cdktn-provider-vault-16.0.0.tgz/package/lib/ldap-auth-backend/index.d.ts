/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LdapAuthBackendConfig extends cdktn.TerraformMetaArguments {
    /**
    * The metadata to be tied to generated entity alias.
    *   This should be a list or map containing the metadata in key value pairs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#alias_metadata LdapAuthBackend#alias_metadata}
    */
    readonly aliasMetadata?: {
        [key: string]: string;
    };
    /**
    * Allows anonymous group searches.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#anonymous_group_search LdapAuthBackend#anonymous_group_search}
    */
    readonly anonymousGroupSearch?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#binddn LdapAuthBackend#binddn}
    */
    readonly binddn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#bindpass LdapAuthBackend#bindpass}
    */
    readonly bindpass?: string;
    /**
    * Write-only bind password to use for LDAP authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#bindpass_wo LdapAuthBackend#bindpass_wo}
    */
    readonly bindpassWo?: string;
    /**
    * Version counter for write-only bind password.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#bindpass_wo_version LdapAuthBackend#bindpass_wo_version}
    */
    readonly bindpassWoVersion?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#case_sensitive_names LdapAuthBackend#case_sensitive_names}
    */
    readonly caseSensitiveNames?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#certificate LdapAuthBackend#certificate}
    */
    readonly certificate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#client_tls_cert LdapAuthBackend#client_tls_cert}
    */
    readonly clientTlsCert?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#client_tls_key LdapAuthBackend#client_tls_key}
    */
    readonly clientTlsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#connection_timeout LdapAuthBackend#connection_timeout}
    */
    readonly connectionTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#deny_null_bind LdapAuthBackend#deny_null_bind}
    */
    readonly denyNullBind?: boolean | cdktn.IResolvable;
    /**
    * Specifies how aliases are dereferenced during LDAP searches. Valid values are 'never','searching','finding', and 'always'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#dereference_aliases LdapAuthBackend#dereference_aliases}
    */
    readonly dereferenceAliases?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#description LdapAuthBackend#description}
    */
    readonly description?: string;
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#disable_automated_rotation LdapAuthBackend#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * If set, opts out of mount migration on path updates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#disable_remount LdapAuthBackend#disable_remount}
    */
    readonly disableRemount?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#discoverdn LdapAuthBackend#discoverdn}
    */
    readonly discoverdn?: boolean | cdktn.IResolvable;
    /**
    * Enables login using the sAMAccountName attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#enable_samaccountname_login LdapAuthBackend#enable_samaccountname_login}
    */
    readonly enableSamaccountnameLogin?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#groupattr LdapAuthBackend#groupattr}
    */
    readonly groupattr?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#groupdn LdapAuthBackend#groupdn}
    */
    readonly groupdn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#groupfilter LdapAuthBackend#groupfilter}
    */
    readonly groupfilter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#id LdapAuthBackend#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#insecure_tls LdapAuthBackend#insecure_tls}
    */
    readonly insecureTls?: boolean | cdktn.IResolvable;
    /**
    * Specifies if the auth method is local only
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#local LdapAuthBackend#local}
    */
    readonly local?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#max_page_size LdapAuthBackend#max_page_size}
    */
    readonly maxPageSize?: number;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#namespace LdapAuthBackend#namespace}
    */
    readonly namespace?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#path LdapAuthBackend#path}
    */
    readonly path?: string;
    /**
    * The timeout(in sec) for requests to the LDAP server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#request_timeout LdapAuthBackend#request_timeout}
    */
    readonly requestTimeout?: number;
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#rotation_period LdapAuthBackend#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#rotation_schedule LdapAuthBackend#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#rotation_window LdapAuthBackend#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#starttls LdapAuthBackend#starttls}
    */
    readonly starttls?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#tls_max_version LdapAuthBackend#tls_max_version}
    */
    readonly tlsMaxVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#tls_min_version LdapAuthBackend#tls_min_version}
    */
    readonly tlsMinVersion?: string;
    /**
    * Specifies the blocks of IP addresses which are allowed to use the generated token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#token_bound_cidrs LdapAuthBackend#token_bound_cidrs}
    */
    readonly tokenBoundCidrs?: string[];
    /**
    * Generated Token's Explicit Maximum TTL in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#token_explicit_max_ttl LdapAuthBackend#token_explicit_max_ttl}
    */
    readonly tokenExplicitMaxTtl?: number;
    /**
    * The maximum lifetime of the generated token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#token_max_ttl LdapAuthBackend#token_max_ttl}
    */
    readonly tokenMaxTtl?: number;
    /**
    * If true, the 'default' policy will not automatically be added to generated tokens
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#token_no_default_policy LdapAuthBackend#token_no_default_policy}
    */
    readonly tokenNoDefaultPolicy?: boolean | cdktn.IResolvable;
    /**
    * The maximum number of times a token may be used, a value of zero means unlimited
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#token_num_uses LdapAuthBackend#token_num_uses}
    */
    readonly tokenNumUses?: number;
    /**
    * Generated Token's Period
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#token_period LdapAuthBackend#token_period}
    */
    readonly tokenPeriod?: number;
    /**
    * Generated Token's Policies
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#token_policies LdapAuthBackend#token_policies}
    */
    readonly tokenPolicies?: string[];
    /**
    * The initial ttl of the token to generate in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#token_ttl LdapAuthBackend#token_ttl}
    */
    readonly tokenTtl?: number;
    /**
    * The type of token to generate, service or batch
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#token_type LdapAuthBackend#token_type}
    */
    readonly tokenType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#tune LdapAuthBackend#tune}
    */
    readonly tune?: LdapAuthBackendTune[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#upndomain LdapAuthBackend#upndomain}
    */
    readonly upndomain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#url LdapAuthBackend#url}
    */
    readonly url: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#use_token_groups LdapAuthBackend#use_token_groups}
    */
    readonly useTokenGroups?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#userattr LdapAuthBackend#userattr}
    */
    readonly userattr?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#userdn LdapAuthBackend#userdn}
    */
    readonly userdn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#userfilter LdapAuthBackend#userfilter}
    */
    readonly userfilter?: string;
    /**
    * Force the auth method to use the username passed by the user as the alias name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#username_as_alias LdapAuthBackend#username_as_alias}
    */
    readonly usernameAsAlias?: boolean | cdktn.IResolvable;
}
export interface LdapAuthBackendTune {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#allowed_response_headers LdapAuthBackend#allowed_response_headers}
    */
    readonly allowedResponseHeaders?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#audit_non_hmac_request_keys LdapAuthBackend#audit_non_hmac_request_keys}
    */
    readonly auditNonHmacRequestKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#audit_non_hmac_response_keys LdapAuthBackend#audit_non_hmac_response_keys}
    */
    readonly auditNonHmacResponseKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#default_lease_ttl LdapAuthBackend#default_lease_ttl}
    */
    readonly defaultLeaseTtl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#listing_visibility LdapAuthBackend#listing_visibility}
    */
    readonly listingVisibility?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#max_lease_ttl LdapAuthBackend#max_lease_ttl}
    */
    readonly maxLeaseTtl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#passthrough_request_headers LdapAuthBackend#passthrough_request_headers}
    */
    readonly passthroughRequestHeaders?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#token_type LdapAuthBackend#token_type}
    */
    readonly tokenType?: string;
}
export declare function ldapAuthBackendTuneToTerraform(struct?: LdapAuthBackendTune | cdktn.IResolvable): any;
export declare function ldapAuthBackendTuneToHclTerraform(struct?: LdapAuthBackendTune | cdktn.IResolvable): any;
export declare class LdapAuthBackendTuneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LdapAuthBackendTune | cdktn.IResolvable | undefined;
    set internalValue(value: LdapAuthBackendTune | cdktn.IResolvable | undefined);
    private _allowedResponseHeaders?;
    get allowedResponseHeaders(): string[];
    set allowedResponseHeaders(value: string[]);
    resetAllowedResponseHeaders(): void;
    get allowedResponseHeadersInput(): string[] | undefined;
    private _auditNonHmacRequestKeys?;
    get auditNonHmacRequestKeys(): string[];
    set auditNonHmacRequestKeys(value: string[]);
    resetAuditNonHmacRequestKeys(): void;
    get auditNonHmacRequestKeysInput(): string[] | undefined;
    private _auditNonHmacResponseKeys?;
    get auditNonHmacResponseKeys(): string[];
    set auditNonHmacResponseKeys(value: string[]);
    resetAuditNonHmacResponseKeys(): void;
    get auditNonHmacResponseKeysInput(): string[] | undefined;
    private _defaultLeaseTtl?;
    get defaultLeaseTtl(): string;
    set defaultLeaseTtl(value: string);
    resetDefaultLeaseTtl(): void;
    get defaultLeaseTtlInput(): string | undefined;
    private _listingVisibility?;
    get listingVisibility(): string;
    set listingVisibility(value: string);
    resetListingVisibility(): void;
    get listingVisibilityInput(): string | undefined;
    private _maxLeaseTtl?;
    get maxLeaseTtl(): string;
    set maxLeaseTtl(value: string);
    resetMaxLeaseTtl(): void;
    get maxLeaseTtlInput(): string | undefined;
    private _passthroughRequestHeaders?;
    get passthroughRequestHeaders(): string[];
    set passthroughRequestHeaders(value: string[]);
    resetPassthroughRequestHeaders(): void;
    get passthroughRequestHeadersInput(): string[] | undefined;
    private _tokenType?;
    get tokenType(): string;
    set tokenType(value: string);
    resetTokenType(): void;
    get tokenTypeInput(): string | undefined;
}
export declare class LdapAuthBackendTuneList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: LdapAuthBackendTune[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LdapAuthBackendTuneOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend vault_ldap_auth_backend}
*/
export declare class LdapAuthBackend extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_ldap_auth_backend";
    /**
    * Generates CDKTN code for importing a LdapAuthBackend resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LdapAuthBackend to import
    * @param importFromId The id of the existing LdapAuthBackend that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LdapAuthBackend to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_auth_backend vault_ldap_auth_backend} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LdapAuthBackendConfig
    */
    constructor(scope: Construct, id: string, config: LdapAuthBackendConfig);
    get accessor(): string;
    private _aliasMetadata?;
    get aliasMetadata(): {
        [key: string]: string;
    };
    set aliasMetadata(value: {
        [key: string]: string;
    });
    resetAliasMetadata(): void;
    get aliasMetadataInput(): {
        [key: string]: string;
    } | undefined;
    private _anonymousGroupSearch?;
    get anonymousGroupSearch(): boolean | cdktn.IResolvable;
    set anonymousGroupSearch(value: boolean | cdktn.IResolvable);
    resetAnonymousGroupSearch(): void;
    get anonymousGroupSearchInput(): boolean | cdktn.IResolvable | undefined;
    private _binddn?;
    get binddn(): string;
    set binddn(value: string);
    resetBinddn(): void;
    get binddnInput(): string | undefined;
    private _bindpass?;
    get bindpass(): string;
    set bindpass(value: string);
    resetBindpass(): void;
    get bindpassInput(): string | undefined;
    private _bindpassWo?;
    get bindpassWo(): string;
    set bindpassWo(value: string);
    resetBindpassWo(): void;
    get bindpassWoInput(): string | undefined;
    private _bindpassWoVersion?;
    get bindpassWoVersion(): number;
    set bindpassWoVersion(value: number);
    resetBindpassWoVersion(): void;
    get bindpassWoVersionInput(): number | undefined;
    private _caseSensitiveNames?;
    get caseSensitiveNames(): boolean | cdktn.IResolvable;
    set caseSensitiveNames(value: boolean | cdktn.IResolvable);
    resetCaseSensitiveNames(): void;
    get caseSensitiveNamesInput(): boolean | cdktn.IResolvable | undefined;
    private _certificate?;
    get certificate(): string;
    set certificate(value: string);
    resetCertificate(): void;
    get certificateInput(): string | undefined;
    private _clientTlsCert?;
    get clientTlsCert(): string;
    set clientTlsCert(value: string);
    resetClientTlsCert(): void;
    get clientTlsCertInput(): string | undefined;
    private _clientTlsKey?;
    get clientTlsKey(): string;
    set clientTlsKey(value: string);
    resetClientTlsKey(): void;
    get clientTlsKeyInput(): string | undefined;
    private _connectionTimeout?;
    get connectionTimeout(): number;
    set connectionTimeout(value: number);
    resetConnectionTimeout(): void;
    get connectionTimeoutInput(): number | undefined;
    private _denyNullBind?;
    get denyNullBind(): boolean | cdktn.IResolvable;
    set denyNullBind(value: boolean | cdktn.IResolvable);
    resetDenyNullBind(): void;
    get denyNullBindInput(): boolean | cdktn.IResolvable | undefined;
    private _dereferenceAliases?;
    get dereferenceAliases(): string;
    set dereferenceAliases(value: string);
    resetDereferenceAliases(): void;
    get dereferenceAliasesInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _disableRemount?;
    get disableRemount(): boolean | cdktn.IResolvable;
    set disableRemount(value: boolean | cdktn.IResolvable);
    resetDisableRemount(): void;
    get disableRemountInput(): boolean | cdktn.IResolvable | undefined;
    private _discoverdn?;
    get discoverdn(): boolean | cdktn.IResolvable;
    set discoverdn(value: boolean | cdktn.IResolvable);
    resetDiscoverdn(): void;
    get discoverdnInput(): boolean | cdktn.IResolvable | undefined;
    private _enableSamaccountnameLogin?;
    get enableSamaccountnameLogin(): boolean | cdktn.IResolvable;
    set enableSamaccountnameLogin(value: boolean | cdktn.IResolvable);
    resetEnableSamaccountnameLogin(): void;
    get enableSamaccountnameLoginInput(): boolean | cdktn.IResolvable | undefined;
    private _groupattr?;
    get groupattr(): string;
    set groupattr(value: string);
    resetGroupattr(): void;
    get groupattrInput(): string | undefined;
    private _groupdn?;
    get groupdn(): string;
    set groupdn(value: string);
    resetGroupdn(): void;
    get groupdnInput(): string | undefined;
    private _groupfilter?;
    get groupfilter(): string;
    set groupfilter(value: string);
    resetGroupfilter(): void;
    get groupfilterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _insecureTls?;
    get insecureTls(): boolean | cdktn.IResolvable;
    set insecureTls(value: boolean | cdktn.IResolvable);
    resetInsecureTls(): void;
    get insecureTlsInput(): boolean | cdktn.IResolvable | undefined;
    private _local?;
    get local(): boolean | cdktn.IResolvable;
    set local(value: boolean | cdktn.IResolvable);
    resetLocal(): void;
    get localInput(): boolean | cdktn.IResolvable | undefined;
    private _maxPageSize?;
    get maxPageSize(): number;
    set maxPageSize(value: number);
    resetMaxPageSize(): void;
    get maxPageSizeInput(): number | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _requestTimeout?;
    get requestTimeout(): number;
    set requestTimeout(value: number);
    resetRequestTimeout(): void;
    get requestTimeoutInput(): number | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _starttls?;
    get starttls(): boolean | cdktn.IResolvable;
    set starttls(value: boolean | cdktn.IResolvable);
    resetStarttls(): void;
    get starttlsInput(): boolean | cdktn.IResolvable | undefined;
    private _tlsMaxVersion?;
    get tlsMaxVersion(): string;
    set tlsMaxVersion(value: string);
    resetTlsMaxVersion(): void;
    get tlsMaxVersionInput(): string | undefined;
    private _tlsMinVersion?;
    get tlsMinVersion(): string;
    set tlsMinVersion(value: string);
    resetTlsMinVersion(): void;
    get tlsMinVersionInput(): string | undefined;
    private _tokenBoundCidrs?;
    get tokenBoundCidrs(): string[];
    set tokenBoundCidrs(value: string[]);
    resetTokenBoundCidrs(): void;
    get tokenBoundCidrsInput(): string[] | undefined;
    private _tokenExplicitMaxTtl?;
    get tokenExplicitMaxTtl(): number;
    set tokenExplicitMaxTtl(value: number);
    resetTokenExplicitMaxTtl(): void;
    get tokenExplicitMaxTtlInput(): number | undefined;
    private _tokenMaxTtl?;
    get tokenMaxTtl(): number;
    set tokenMaxTtl(value: number);
    resetTokenMaxTtl(): void;
    get tokenMaxTtlInput(): number | undefined;
    private _tokenNoDefaultPolicy?;
    get tokenNoDefaultPolicy(): boolean | cdktn.IResolvable;
    set tokenNoDefaultPolicy(value: boolean | cdktn.IResolvable);
    resetTokenNoDefaultPolicy(): void;
    get tokenNoDefaultPolicyInput(): boolean | cdktn.IResolvable | undefined;
    private _tokenNumUses?;
    get tokenNumUses(): number;
    set tokenNumUses(value: number);
    resetTokenNumUses(): void;
    get tokenNumUsesInput(): number | undefined;
    private _tokenPeriod?;
    get tokenPeriod(): number;
    set tokenPeriod(value: number);
    resetTokenPeriod(): void;
    get tokenPeriodInput(): number | undefined;
    private _tokenPolicies?;
    get tokenPolicies(): string[];
    set tokenPolicies(value: string[]);
    resetTokenPolicies(): void;
    get tokenPoliciesInput(): string[] | undefined;
    private _tokenTtl?;
    get tokenTtl(): number;
    set tokenTtl(value: number);
    resetTokenTtl(): void;
    get tokenTtlInput(): number | undefined;
    private _tokenType?;
    get tokenType(): string;
    set tokenType(value: string);
    resetTokenType(): void;
    get tokenTypeInput(): string | undefined;
    private _tune;
    get tune(): LdapAuthBackendTuneList;
    putTune(value: LdapAuthBackendTune[] | cdktn.IResolvable): void;
    resetTune(): void;
    get tuneInput(): cdktn.IResolvable | LdapAuthBackendTune[] | undefined;
    private _upndomain?;
    get upndomain(): string;
    set upndomain(value: string);
    resetUpndomain(): void;
    get upndomainInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _useTokenGroups?;
    get useTokenGroups(): boolean | cdktn.IResolvable;
    set useTokenGroups(value: boolean | cdktn.IResolvable);
    resetUseTokenGroups(): void;
    get useTokenGroupsInput(): boolean | cdktn.IResolvable | undefined;
    private _userattr?;
    get userattr(): string;
    set userattr(value: string);
    resetUserattr(): void;
    get userattrInput(): string | undefined;
    private _userdn?;
    get userdn(): string;
    set userdn(value: string);
    resetUserdn(): void;
    get userdnInput(): string | undefined;
    private _userfilter?;
    get userfilter(): string;
    set userfilter(value: string);
    resetUserfilter(): void;
    get userfilterInput(): string | undefined;
    private _usernameAsAlias?;
    get usernameAsAlias(): boolean | cdktn.IResolvable;
    set usernameAsAlias(value: boolean | cdktn.IResolvable);
    resetUsernameAsAlias(): void;
    get usernameAsAliasInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AuditRequestHeaderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether this header's value should be HMAC'd in the audit logs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/audit_request_header#hmac AuditRequestHeader#hmac}
    */
    readonly hmac?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/audit_request_header#id AuditRequestHeader#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the request header to audit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/audit_request_header#name AuditRequestHeader#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/audit_request_header#namespace AuditRequestHeader#namespace}
    */
    readonly namespace?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/audit_request_header vault_audit_request_header}
*/
export declare class AuditRequestHeader extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_audit_request_header";
    /**
    * Generates CDKTN code for importing a AuditRequestHeader resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AuditRequestHeader to import
    * @param importFromId The id of the existing AuditRequestHeader that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/audit_request_header#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AuditRequestHeader to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/audit_request_header vault_audit_request_header} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AuditRequestHeaderConfig
    */
    constructor(scope: Construct, id: string, config: AuditRequestHeaderConfig);
    private _hmac?;
    get hmac(): boolean | cdktn.IResolvable;
    set hmac(value: boolean | cdktn.IResolvable);
    resetHmac(): void;
    get hmacInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultPkiSecretBackendConfigCmpv2Config extends cdktn.TerraformMetaArguments {
    /**
    * Path where PKI engine is mounted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/data-sources/pki_secret_backend_config_cmpv2#backend DataVaultPkiSecretBackendConfigCmpv2#backend}
    */
    readonly backend: string;
    /**
    * A comma-separated list of validations not to perform on CMPv2 messages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/data-sources/pki_secret_backend_config_cmpv2#disabled_validations DataVaultPkiSecretBackendConfigCmpv2#disabled_validations}
    */
    readonly disabledValidations?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/data-sources/pki_secret_backend_config_cmpv2#id DataVaultPkiSecretBackendConfigCmpv2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/data-sources/pki_secret_backend_config_cmpv2#namespace DataVaultPkiSecretBackendConfigCmpv2#namespace}
    */
    readonly namespace?: string;
}
export interface DataVaultPkiSecretBackendConfigCmpv2Authenticators {
}
export declare function dataVaultPkiSecretBackendConfigCmpv2AuthenticatorsToTerraform(struct?: DataVaultPkiSecretBackendConfigCmpv2Authenticators): any;
export declare function dataVaultPkiSecretBackendConfigCmpv2AuthenticatorsToHclTerraform(struct?: DataVaultPkiSecretBackendConfigCmpv2Authenticators): any;
export declare class DataVaultPkiSecretBackendConfigCmpv2AuthenticatorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataVaultPkiSecretBackendConfigCmpv2Authenticators | undefined;
    set internalValue(value: DataVaultPkiSecretBackendConfigCmpv2Authenticators | undefined);
    private _cert;
    get cert(): cdktn.StringMap;
}
export declare class DataVaultPkiSecretBackendConfigCmpv2AuthenticatorsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataVaultPkiSecretBackendConfigCmpv2AuthenticatorsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/data-sources/pki_secret_backend_config_cmpv2 vault_pki_secret_backend_config_cmpv2}
*/
export declare class DataVaultPkiSecretBackendConfigCmpv2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_pki_secret_backend_config_cmpv2";
    /**
    * Generates CDKTN code for importing a DataVaultPkiSecretBackendConfigCmpv2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultPkiSecretBackendConfigCmpv2 to import
    * @param importFromId The id of the existing DataVaultPkiSecretBackendConfigCmpv2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/data-sources/pki_secret_backend_config_cmpv2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultPkiSecretBackendConfigCmpv2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/data-sources/pki_secret_backend_config_cmpv2 vault_pki_secret_backend_config_cmpv2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultPkiSecretBackendConfigCmpv2Config
    */
    constructor(scope: Construct, id: string, config: DataVaultPkiSecretBackendConfigCmpv2Config);
    get auditFields(): string[];
    private _authenticators;
    get authenticators(): DataVaultPkiSecretBackendConfigCmpv2AuthenticatorsList;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    get defaultPathPolicy(): string;
    private _disabledValidations?;
    get disabledValidations(): string[];
    set disabledValidations(value: string[]);
    resetDisabledValidations(): void;
    get disabledValidationsInput(): string[] | undefined;
    get enableSentinelParsing(): cdktn.IResolvable;
    get enabled(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdated(): string;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MfaOktaConfig extends cdktn.TerraformMetaArguments {
    /**
    * Okta API key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/mfa_okta#api_token MfaOkta#api_token}
    */
    readonly apiToken: string;
    /**
    * If set, will be used as the base domain for API requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/mfa_okta#base_url MfaOkta#base_url}
    */
    readonly baseUrl?: string;
    /**
    * ID computed by Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/mfa_okta#id MfaOkta#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The mount to tie this method to for use in automatic mappings. The mapping will use the Name field of Aliases associated with this mount as the username in the mapping.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/mfa_okta#mount_accessor MfaOkta#mount_accessor}
    */
    readonly mountAccessor: string;
    /**
    * Name of the MFA method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/mfa_okta#name MfaOkta#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/mfa_okta#namespace MfaOkta#namespace}
    */
    readonly namespace?: string;
    /**
    * Name of the organization to be used in the Okta API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/mfa_okta#org_name MfaOkta#org_name}
    */
    readonly orgName: string;
    /**
    * If set to true, the username will only match the primary email for the account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/mfa_okta#primary_email MfaOkta#primary_email}
    */
    readonly primaryEmail?: boolean | cdktn.IResolvable;
    /**
    * A format string for mapping Identity names to MFA method names. Values to substitute should be placed in `{{}}`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/mfa_okta#username_format MfaOkta#username_format}
    */
    readonly usernameFormat?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/mfa_okta vault_mfa_okta}
*/
export declare class MfaOkta extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_mfa_okta";
    /**
    * Generates CDKTN code for importing a MfaOkta resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MfaOkta to import
    * @param importFromId The id of the existing MfaOkta that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/mfa_okta#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MfaOkta to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/mfa_okta vault_mfa_okta} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MfaOktaConfig
    */
    constructor(scope: Construct, id: string, config: MfaOktaConfig);
    private _apiToken?;
    get apiToken(): string;
    set apiToken(value: string);
    get apiTokenInput(): string | undefined;
    private _baseUrl?;
    get baseUrl(): string;
    set baseUrl(value: string);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _mountAccessor?;
    get mountAccessor(): string;
    set mountAccessor(value: string);
    get mountAccessorInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _orgName?;
    get orgName(): string;
    set orgName(value: string);
    get orgNameInput(): string | undefined;
    private _primaryEmail?;
    get primaryEmail(): boolean | cdktn.IResolvable;
    set primaryEmail(value: boolean | cdktn.IResolvable);
    resetPrimaryEmail(): void;
    get primaryEmailInput(): boolean | cdktn.IResolvable | undefined;
    private _usernameFormat?;
    get usernameFormat(): string;
    set usernameFormat(value: string);
    resetUsernameFormat(): void;
    get usernameFormatInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

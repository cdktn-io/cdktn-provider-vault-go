/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VaultProviderConfig {
    /**
    * If true, adds the value of the `address` argument to the Terraform process environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#add_address_to_env VaultProvider#add_address_to_env}
    */
    readonly addAddressToEnv?: string;
    /**
    * URL of the root of the target Vault server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#address VaultProvider#address}
    */
    readonly address?: string;
    /**
    * Path to directory containing CA certificate files to validate the server's certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#ca_cert_dir VaultProvider#ca_cert_dir}
    */
    readonly caCertDir?: string;
    /**
    * Path to a CA certificate file to validate the server's certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#ca_cert_file VaultProvider#ca_cert_file}
    */
    readonly caCertFile?: string;
    /**
    * Maximum TTL for secret leases requested by this provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#max_lease_ttl_seconds VaultProvider#max_lease_ttl_seconds}
    */
    readonly maxLeaseTtlSeconds?: number;
    /**
    * Maximum number of retries when a 5xx error code is encountered.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#max_retries VaultProvider#max_retries}
    */
    readonly maxRetries?: number;
    /**
    * Maximum number of retries for Client Controlled Consistency related operations
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#max_retries_ccc VaultProvider#max_retries_ccc}
    */
    readonly maxRetriesCcc?: number;
    /**
    * The namespace to use. Available only for Vault Enterprise.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#namespace VaultProvider#namespace}
    */
    readonly namespace?: string;
    /**
    * In the case where the Vault token is for a specific namespace and the provider namespace is not configured, use the token namespace as the root namespace for all resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#set_namespace_from_token VaultProvider#set_namespace_from_token}
    */
    readonly setNamespaceFromToken?: boolean | cdktn.IResolvable;
    /**
    * Set this to true to prevent the creation of ephemeral child token used by this provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#skip_child_token VaultProvider#skip_child_token}
    */
    readonly skipChildToken?: boolean | cdktn.IResolvable;
    /**
    * Skip the dynamic fetching of the Vault server version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#skip_get_vault_version VaultProvider#skip_get_vault_version}
    */
    readonly skipGetVaultVersion?: boolean | cdktn.IResolvable;
    /**
    * Set this to true only if the target Vault server is an insecure development instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#skip_tls_verify VaultProvider#skip_tls_verify}
    */
    readonly skipTlsVerify?: boolean | cdktn.IResolvable;
    /**
    * Name to use as the SNI host when connecting via TLS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#tls_server_name VaultProvider#tls_server_name}
    */
    readonly tlsServerName?: string;
    /**
    * Token to use to authenticate to Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#token VaultProvider#token}
    */
    readonly token?: string;
    /**
    * Token name to use for creating the Vault child token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#token_name VaultProvider#token_name}
    */
    readonly tokenName?: string;
    /**
    * Override the Vault server version, which is normally determined dynamically from the target Vault server
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#vault_version_override VaultProvider#vault_version_override}
    */
    readonly vaultVersionOverride?: string;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#alias VaultProvider#alias}
    */
    readonly alias?: string;
    /**
    * auth_login block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#auth_login VaultProvider#auth_login}
    */
    readonly authLogin?: VaultProviderAuthLogin[] | cdktn.IResolvable;
    /**
    * auth_login_aws block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#auth_login_aws VaultProvider#auth_login_aws}
    */
    readonly authLoginAws?: VaultProviderAuthLoginAws[] | cdktn.IResolvable;
    /**
    * auth_login_azure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#auth_login_azure VaultProvider#auth_login_azure}
    */
    readonly authLoginAzure?: VaultProviderAuthLoginAzure[] | cdktn.IResolvable;
    /**
    * auth_login_cert block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#auth_login_cert VaultProvider#auth_login_cert}
    */
    readonly authLoginCert?: VaultProviderAuthLoginCert[] | cdktn.IResolvable;
    /**
    * auth_login_gcp block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#auth_login_gcp VaultProvider#auth_login_gcp}
    */
    readonly authLoginGcp?: VaultProviderAuthLoginGcp[] | cdktn.IResolvable;
    /**
    * auth_login_jwt block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#auth_login_jwt VaultProvider#auth_login_jwt}
    */
    readonly authLoginJwt?: VaultProviderAuthLoginJwt[] | cdktn.IResolvable;
    /**
    * auth_login_kerberos block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#auth_login_kerberos VaultProvider#auth_login_kerberos}
    */
    readonly authLoginKerberos?: VaultProviderAuthLoginKerberos[] | cdktn.IResolvable;
    /**
    * auth_login_oci block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#auth_login_oci VaultProvider#auth_login_oci}
    */
    readonly authLoginOci?: VaultProviderAuthLoginOci[] | cdktn.IResolvable;
    /**
    * auth_login_oidc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#auth_login_oidc VaultProvider#auth_login_oidc}
    */
    readonly authLoginOidc?: VaultProviderAuthLoginOidc[] | cdktn.IResolvable;
    /**
    * auth_login_radius block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#auth_login_radius VaultProvider#auth_login_radius}
    */
    readonly authLoginRadius?: VaultProviderAuthLoginRadius[] | cdktn.IResolvable;
    /**
    * auth_login_token_file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#auth_login_token_file VaultProvider#auth_login_token_file}
    */
    readonly authLoginTokenFile?: VaultProviderAuthLoginTokenFile[] | cdktn.IResolvable;
    /**
    * auth_login_userpass block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#auth_login_userpass VaultProvider#auth_login_userpass}
    */
    readonly authLoginUserpass?: VaultProviderAuthLoginUserpass[] | cdktn.IResolvable;
    /**
    * client_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#client_auth VaultProvider#client_auth}
    */
    readonly clientAuth?: VaultProviderClientAuth[] | cdktn.IResolvable;
    /**
    * headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#headers VaultProvider#headers}
    */
    readonly headers?: VaultProviderHeaders[] | cdktn.IResolvable;
}
export interface VaultProviderAuthLogin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#method VaultProvider#method}
    */
    readonly method?: string;
    /**
    * The authentication engine's namespace. Conflicts with use_root_namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#namespace VaultProvider#namespace}
    */
    readonly namespace?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#parameters VaultProvider#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#path VaultProvider#path}
    */
    readonly path: string;
    /**
    * Authenticate to the root Vault namespace. Conflicts with namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#use_root_namespace VaultProvider#use_root_namespace}
    */
    readonly useRootNamespace?: boolean | cdktn.IResolvable;
}
export declare function vaultProviderAuthLoginToTerraform(struct?: VaultProviderAuthLogin | cdktn.IResolvable): any;
export declare function vaultProviderAuthLoginToHclTerraform(struct?: VaultProviderAuthLogin | cdktn.IResolvable): any;
export interface VaultProviderAuthLoginAws {
    /**
    * The AWS access key ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#aws_access_key_id VaultProvider#aws_access_key_id}
    */
    readonly awsAccessKeyId?: string;
    /**
    * The IAM endpoint URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#aws_iam_endpoint VaultProvider#aws_iam_endpoint}
    */
    readonly awsIamEndpoint?: string;
    /**
    * The name of the AWS profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#aws_profile VaultProvider#aws_profile}
    */
    readonly awsProfile?: string;
    /**
    * The AWS region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#aws_region VaultProvider#aws_region}
    */
    readonly awsRegion?: string;
    /**
    * The ARN of the AWS Role to assume.Used during STS AssumeRole
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#aws_role_arn VaultProvider#aws_role_arn}
    */
    readonly awsRoleArn?: string;
    /**
    * Specifies the name to attach to the AWS role session. Used during STS AssumeRole
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#aws_role_session_name VaultProvider#aws_role_session_name}
    */
    readonly awsRoleSessionName?: string;
    /**
    * The AWS secret access key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#aws_secret_access_key VaultProvider#aws_secret_access_key}
    */
    readonly awsSecretAccessKey?: string;
    /**
    * The AWS session token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#aws_session_token VaultProvider#aws_session_token}
    */
    readonly awsSessionToken?: string;
    /**
    * Path to the AWS shared credentials file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#aws_shared_credentials_file VaultProvider#aws_shared_credentials_file}
    */
    readonly awsSharedCredentialsFile?: string;
    /**
    * The STS endpoint URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#aws_sts_endpoint VaultProvider#aws_sts_endpoint}
    */
    readonly awsStsEndpoint?: string;
    /**
    * Path to the file containing an OAuth 2.0 access token or OpenID Connect ID token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#aws_web_identity_token_file VaultProvider#aws_web_identity_token_file}
    */
    readonly awsWebIdentityTokenFile?: string;
    /**
    * The Vault header value to include in the STS signing request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#header_value VaultProvider#header_value}
    */
    readonly headerValue?: string;
    /**
    * The path where the authentication engine is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#mount VaultProvider#mount}
    */
    readonly mount?: string;
    /**
    * The authentication engine's namespace. Conflicts with use_root_namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#namespace VaultProvider#namespace}
    */
    readonly namespace?: string;
    /**
    * The Vault role to use when logging into Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#role VaultProvider#role}
    */
    readonly role: string;
    /**
    * Authenticate to the root Vault namespace. Conflicts with namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#use_root_namespace VaultProvider#use_root_namespace}
    */
    readonly useRootNamespace?: boolean | cdktn.IResolvable;
}
export declare function vaultProviderAuthLoginAwsToTerraform(struct?: VaultProviderAuthLoginAws | cdktn.IResolvable): any;
export declare function vaultProviderAuthLoginAwsToHclTerraform(struct?: VaultProviderAuthLoginAws | cdktn.IResolvable): any;
export interface VaultProviderAuthLoginAzure {
    /**
    * The identity's client ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#client_id VaultProvider#client_id}
    */
    readonly clientId?: string;
    /**
    * A signed JSON Web Token. If not specified on will be created automatically
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#jwt VaultProvider#jwt}
    */
    readonly jwt?: string;
    /**
    * The path where the authentication engine is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#mount VaultProvider#mount}
    */
    readonly mount?: string;
    /**
    * The authentication engine's namespace. Conflicts with use_root_namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#namespace VaultProvider#namespace}
    */
    readonly namespace?: string;
    /**
    * The resource group for the machine that generated the MSI token. This information can be obtained through instance metadata.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#resource_group_name VaultProvider#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * Name of the login role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#role VaultProvider#role}
    */
    readonly role: string;
    /**
    * The scopes to include in the token request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#scope VaultProvider#scope}
    */
    readonly scope?: string;
    /**
    * The subscription ID for the machine that generated the MSI token. This information can be obtained through instance metadata.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#subscription_id VaultProvider#subscription_id}
    */
    readonly subscriptionId: string;
    /**
    * Provides the tenant ID to use in a multi-tenant authentication scenario.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#tenant_id VaultProvider#tenant_id}
    */
    readonly tenantId?: string;
    /**
    * Authenticate to the root Vault namespace. Conflicts with namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#use_root_namespace VaultProvider#use_root_namespace}
    */
    readonly useRootNamespace?: boolean | cdktn.IResolvable;
    /**
    * The virtual machine name for the machine that generated the MSI token. This information can be obtained through instance metadata.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#vm_name VaultProvider#vm_name}
    */
    readonly vmName?: string;
    /**
    * The virtual machine scale set name for the machine that generated the MSI token. This information can be obtained through instance metadata.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#vmss_name VaultProvider#vmss_name}
    */
    readonly vmssName?: string;
}
export declare function vaultProviderAuthLoginAzureToTerraform(struct?: VaultProviderAuthLoginAzure | cdktn.IResolvable): any;
export declare function vaultProviderAuthLoginAzureToHclTerraform(struct?: VaultProviderAuthLoginAzure | cdktn.IResolvable): any;
export interface VaultProviderAuthLoginCert {
    /**
    * Path to a file containing the client certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#cert_file VaultProvider#cert_file}
    */
    readonly certFile: string;
    /**
    * Path to a file containing the private key that the certificate was issued for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#key_file VaultProvider#key_file}
    */
    readonly keyFile: string;
    /**
    * The path where the authentication engine is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#mount VaultProvider#mount}
    */
    readonly mount?: string;
    /**
    * Name of the certificate's role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#name VaultProvider#name}
    */
    readonly name?: string;
    /**
    * The authentication engine's namespace. Conflicts with use_root_namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#namespace VaultProvider#namespace}
    */
    readonly namespace?: string;
    /**
    * Authenticate to the root Vault namespace. Conflicts with namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#use_root_namespace VaultProvider#use_root_namespace}
    */
    readonly useRootNamespace?: boolean | cdktn.IResolvable;
}
export declare function vaultProviderAuthLoginCertToTerraform(struct?: VaultProviderAuthLoginCert | cdktn.IResolvable): any;
export declare function vaultProviderAuthLoginCertToHclTerraform(struct?: VaultProviderAuthLoginCert | cdktn.IResolvable): any;
export interface VaultProviderAuthLoginGcp {
    /**
    * Path to the Google Cloud credentials file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#credentials VaultProvider#credentials}
    */
    readonly credentials?: string;
    /**
    * A signed JSON Web Token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#jwt VaultProvider#jwt}
    */
    readonly jwt?: string;
    /**
    * The path where the authentication engine is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#mount VaultProvider#mount}
    */
    readonly mount?: string;
    /**
    * The authentication engine's namespace. Conflicts with use_root_namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#namespace VaultProvider#namespace}
    */
    readonly namespace?: string;
    /**
    * Name of the login role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#role VaultProvider#role}
    */
    readonly role: string;
    /**
    * IAM service account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#service_account VaultProvider#service_account}
    */
    readonly serviceAccount?: string;
    /**
    * Authenticate to the root Vault namespace. Conflicts with namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#use_root_namespace VaultProvider#use_root_namespace}
    */
    readonly useRootNamespace?: boolean | cdktn.IResolvable;
}
export declare function vaultProviderAuthLoginGcpToTerraform(struct?: VaultProviderAuthLoginGcp | cdktn.IResolvable): any;
export declare function vaultProviderAuthLoginGcpToHclTerraform(struct?: VaultProviderAuthLoginGcp | cdktn.IResolvable): any;
export interface VaultProviderAuthLoginJwt {
    /**
    * A signed JSON Web Token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#jwt VaultProvider#jwt}
    */
    readonly jwt?: string;
    /**
    * The path where the authentication engine is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#mount VaultProvider#mount}
    */
    readonly mount?: string;
    /**
    * The authentication engine's namespace. Conflicts with use_root_namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#namespace VaultProvider#namespace}
    */
    readonly namespace?: string;
    /**
    * Name of the login role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#role VaultProvider#role}
    */
    readonly role: string;
    /**
    * Authenticate to the root Vault namespace. Conflicts with namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#use_root_namespace VaultProvider#use_root_namespace}
    */
    readonly useRootNamespace?: boolean | cdktn.IResolvable;
}
export declare function vaultProviderAuthLoginJwtToTerraform(struct?: VaultProviderAuthLoginJwt | cdktn.IResolvable): any;
export declare function vaultProviderAuthLoginJwtToHclTerraform(struct?: VaultProviderAuthLoginJwt | cdktn.IResolvable): any;
export interface VaultProviderAuthLoginKerberos {
    /**
    * Disable the Kerberos FAST negotiation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#disable_fast_negotiation VaultProvider#disable_fast_negotiation}
    */
    readonly disableFastNegotiation?: boolean | cdktn.IResolvable;
    /**
    * The Kerberos keytab file containing the entry of the login entity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#keytab_path VaultProvider#keytab_path}
    */
    readonly keytabPath?: string;
    /**
    * A valid Kerberos configuration file e.g. /etc/krb5.conf.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#krb5conf_path VaultProvider#krb5conf_path}
    */
    readonly krb5ConfPath?: string;
    /**
    * The path where the authentication engine is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#mount VaultProvider#mount}
    */
    readonly mount?: string;
    /**
    * The authentication engine's namespace. Conflicts with use_root_namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#namespace VaultProvider#namespace}
    */
    readonly namespace?: string;
    /**
    * The Kerberos server's authoritative authentication domain
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#realm VaultProvider#realm}
    */
    readonly realm?: string;
    /**
    * Strip the host from the username found in the keytab.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#remove_instance_name VaultProvider#remove_instance_name}
    */
    readonly removeInstanceName?: boolean | cdktn.IResolvable;
    /**
    * The service principle name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#service VaultProvider#service}
    */
    readonly service?: string;
    /**
    * Simple and Protected GSSAPI Negotiation Mechanism (SPNEGO) token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#token VaultProvider#token}
    */
    readonly token?: string;
    /**
    * Authenticate to the root Vault namespace. Conflicts with namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#use_root_namespace VaultProvider#use_root_namespace}
    */
    readonly useRootNamespace?: boolean | cdktn.IResolvable;
    /**
    * The username to login into Kerberos with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#username VaultProvider#username}
    */
    readonly username?: string;
}
export declare function vaultProviderAuthLoginKerberosToTerraform(struct?: VaultProviderAuthLoginKerberos | cdktn.IResolvable): any;
export declare function vaultProviderAuthLoginKerberosToHclTerraform(struct?: VaultProviderAuthLoginKerberos | cdktn.IResolvable): any;
export interface VaultProviderAuthLoginOci {
    /**
    * Authentication type to use when getting OCI credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#auth_type VaultProvider#auth_type}
    */
    readonly authType: string;
    /**
    * The path where the authentication engine is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#mount VaultProvider#mount}
    */
    readonly mount?: string;
    /**
    * The authentication engine's namespace. Conflicts with use_root_namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#namespace VaultProvider#namespace}
    */
    readonly namespace?: string;
    /**
    * Name of the login role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#role VaultProvider#role}
    */
    readonly role: string;
    /**
    * Authenticate to the root Vault namespace. Conflicts with namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#use_root_namespace VaultProvider#use_root_namespace}
    */
    readonly useRootNamespace?: boolean | cdktn.IResolvable;
}
export declare function vaultProviderAuthLoginOciToTerraform(struct?: VaultProviderAuthLoginOci | cdktn.IResolvable): any;
export declare function vaultProviderAuthLoginOciToHclTerraform(struct?: VaultProviderAuthLoginOci | cdktn.IResolvable): any;
export interface VaultProviderAuthLoginOidc {
    /**
    * The callback address. Must be a valid URI without the path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#callback_address VaultProvider#callback_address}
    */
    readonly callbackAddress?: string;
    /**
    * The callback listener's address. Must be a valid URI without the path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#callback_listener_address VaultProvider#callback_listener_address}
    */
    readonly callbackListenerAddress?: string;
    /**
    * The path where the authentication engine is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#mount VaultProvider#mount}
    */
    readonly mount?: string;
    /**
    * The authentication engine's namespace. Conflicts with use_root_namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#namespace VaultProvider#namespace}
    */
    readonly namespace?: string;
    /**
    * Name of the login role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#role VaultProvider#role}
    */
    readonly role: string;
    /**
    * Authenticate to the root Vault namespace. Conflicts with namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#use_root_namespace VaultProvider#use_root_namespace}
    */
    readonly useRootNamespace?: boolean | cdktn.IResolvable;
}
export declare function vaultProviderAuthLoginOidcToTerraform(struct?: VaultProviderAuthLoginOidc | cdktn.IResolvable): any;
export declare function vaultProviderAuthLoginOidcToHclTerraform(struct?: VaultProviderAuthLoginOidc | cdktn.IResolvable): any;
export interface VaultProviderAuthLoginRadius {
    /**
    * The path where the authentication engine is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#mount VaultProvider#mount}
    */
    readonly mount?: string;
    /**
    * The authentication engine's namespace. Conflicts with use_root_namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#namespace VaultProvider#namespace}
    */
    readonly namespace?: string;
    /**
    * The Radius password for username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#password VaultProvider#password}
    */
    readonly password?: string;
    /**
    * Authenticate to the root Vault namespace. Conflicts with namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#use_root_namespace VaultProvider#use_root_namespace}
    */
    readonly useRootNamespace?: boolean | cdktn.IResolvable;
    /**
    * The Radius username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#username VaultProvider#username}
    */
    readonly username?: string;
}
export declare function vaultProviderAuthLoginRadiusToTerraform(struct?: VaultProviderAuthLoginRadius | cdktn.IResolvable): any;
export declare function vaultProviderAuthLoginRadiusToHclTerraform(struct?: VaultProviderAuthLoginRadius | cdktn.IResolvable): any;
export interface VaultProviderAuthLoginTokenFile {
    /**
    * The name of a file containing a single line that is a valid Vault token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#filename VaultProvider#filename}
    */
    readonly filename?: string;
    /**
    * The authentication engine's namespace. Conflicts with use_root_namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#namespace VaultProvider#namespace}
    */
    readonly namespace?: string;
    /**
    * Authenticate to the root Vault namespace. Conflicts with namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#use_root_namespace VaultProvider#use_root_namespace}
    */
    readonly useRootNamespace?: boolean | cdktn.IResolvable;
}
export declare function vaultProviderAuthLoginTokenFileToTerraform(struct?: VaultProviderAuthLoginTokenFile | cdktn.IResolvable): any;
export declare function vaultProviderAuthLoginTokenFileToHclTerraform(struct?: VaultProviderAuthLoginTokenFile | cdktn.IResolvable): any;
export interface VaultProviderAuthLoginUserpass {
    /**
    * The path where the authentication engine is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#mount VaultProvider#mount}
    */
    readonly mount?: string;
    /**
    * The authentication engine's namespace. Conflicts with use_root_namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#namespace VaultProvider#namespace}
    */
    readonly namespace?: string;
    /**
    * Login with password
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#password VaultProvider#password}
    */
    readonly password?: string;
    /**
    * Login with password from a file
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#password_file VaultProvider#password_file}
    */
    readonly passwordFile?: string;
    /**
    * Authenticate to the root Vault namespace. Conflicts with namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#use_root_namespace VaultProvider#use_root_namespace}
    */
    readonly useRootNamespace?: boolean | cdktn.IResolvable;
    /**
    * Login with username
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#username VaultProvider#username}
    */
    readonly username?: string;
}
export declare function vaultProviderAuthLoginUserpassToTerraform(struct?: VaultProviderAuthLoginUserpass | cdktn.IResolvable): any;
export declare function vaultProviderAuthLoginUserpassToHclTerraform(struct?: VaultProviderAuthLoginUserpass | cdktn.IResolvable): any;
export interface VaultProviderClientAuth {
    /**
    * Path to a file containing the client certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#cert_file VaultProvider#cert_file}
    */
    readonly certFile: string;
    /**
    * Path to a file containing the private key that the certificate was issued for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#key_file VaultProvider#key_file}
    */
    readonly keyFile: string;
}
export declare function vaultProviderClientAuthToTerraform(struct?: VaultProviderClientAuth | cdktn.IResolvable): any;
export declare function vaultProviderClientAuthToHclTerraform(struct?: VaultProviderClientAuth | cdktn.IResolvable): any;
export interface VaultProviderHeaders {
    /**
    * The header name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#name VaultProvider#name}
    */
    readonly name: string;
    /**
    * The header value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#value VaultProvider#value}
    */
    readonly value: string;
}
export declare function vaultProviderHeadersToTerraform(struct?: VaultProviderHeaders | cdktn.IResolvable): any;
export declare function vaultProviderHeadersToHclTerraform(struct?: VaultProviderHeaders | cdktn.IResolvable): any;
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs vault}
*/
export declare class VaultProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "vault";
    /**
    * Generates CDKTN code for importing a VaultProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VaultProvider to import
    * @param importFromId The id of the existing VaultProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VaultProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs vault} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VaultProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: VaultProviderConfig);
    private _addAddressToEnv?;
    get addAddressToEnv(): string | undefined;
    set addAddressToEnv(value: string | undefined);
    resetAddAddressToEnv(): void;
    get addAddressToEnvInput(): string | undefined;
    private _address?;
    get address(): string | undefined;
    set address(value: string | undefined);
    resetAddress(): void;
    get addressInput(): string | undefined;
    private _caCertDir?;
    get caCertDir(): string | undefined;
    set caCertDir(value: string | undefined);
    resetCaCertDir(): void;
    get caCertDirInput(): string | undefined;
    private _caCertFile?;
    get caCertFile(): string | undefined;
    set caCertFile(value: string | undefined);
    resetCaCertFile(): void;
    get caCertFileInput(): string | undefined;
    private _maxLeaseTtlSeconds?;
    get maxLeaseTtlSeconds(): number | undefined;
    set maxLeaseTtlSeconds(value: number | undefined);
    resetMaxLeaseTtlSeconds(): void;
    get maxLeaseTtlSecondsInput(): number | undefined;
    private _maxRetries?;
    get maxRetries(): number | undefined;
    set maxRetries(value: number | undefined);
    resetMaxRetries(): void;
    get maxRetriesInput(): number | undefined;
    private _maxRetriesCcc?;
    get maxRetriesCcc(): number | undefined;
    set maxRetriesCcc(value: number | undefined);
    resetMaxRetriesCcc(): void;
    get maxRetriesCccInput(): number | undefined;
    private _namespace?;
    get namespace(): string | undefined;
    set namespace(value: string | undefined);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _setNamespaceFromToken?;
    get setNamespaceFromToken(): boolean | cdktn.IResolvable | undefined;
    set setNamespaceFromToken(value: boolean | cdktn.IResolvable | undefined);
    resetSetNamespaceFromToken(): void;
    get setNamespaceFromTokenInput(): boolean | cdktn.IResolvable | undefined;
    private _skipChildToken?;
    get skipChildToken(): boolean | cdktn.IResolvable | undefined;
    set skipChildToken(value: boolean | cdktn.IResolvable | undefined);
    resetSkipChildToken(): void;
    get skipChildTokenInput(): boolean | cdktn.IResolvable | undefined;
    private _skipGetVaultVersion?;
    get skipGetVaultVersion(): boolean | cdktn.IResolvable | undefined;
    set skipGetVaultVersion(value: boolean | cdktn.IResolvable | undefined);
    resetSkipGetVaultVersion(): void;
    get skipGetVaultVersionInput(): boolean | cdktn.IResolvable | undefined;
    private _skipTlsVerify?;
    get skipTlsVerify(): boolean | cdktn.IResolvable | undefined;
    set skipTlsVerify(value: boolean | cdktn.IResolvable | undefined);
    resetSkipTlsVerify(): void;
    get skipTlsVerifyInput(): boolean | cdktn.IResolvable | undefined;
    private _tlsServerName?;
    get tlsServerName(): string | undefined;
    set tlsServerName(value: string | undefined);
    resetTlsServerName(): void;
    get tlsServerNameInput(): string | undefined;
    private _token?;
    get token(): string | undefined;
    set token(value: string | undefined);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _tokenName?;
    get tokenName(): string | undefined;
    set tokenName(value: string | undefined);
    resetTokenName(): void;
    get tokenNameInput(): string | undefined;
    private _vaultVersionOverride?;
    get vaultVersionOverride(): string | undefined;
    set vaultVersionOverride(value: string | undefined);
    resetVaultVersionOverride(): void;
    get vaultVersionOverrideInput(): string | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _authLogin?;
    get authLogin(): VaultProviderAuthLogin[] | cdktn.IResolvable | undefined;
    set authLogin(value: VaultProviderAuthLogin[] | cdktn.IResolvable | undefined);
    resetAuthLogin(): void;
    get authLoginInput(): cdktn.IResolvable | VaultProviderAuthLogin[] | undefined;
    private _authLoginAws?;
    get authLoginAws(): VaultProviderAuthLoginAws[] | cdktn.IResolvable | undefined;
    set authLoginAws(value: VaultProviderAuthLoginAws[] | cdktn.IResolvable | undefined);
    resetAuthLoginAws(): void;
    get authLoginAwsInput(): cdktn.IResolvable | VaultProviderAuthLoginAws[] | undefined;
    private _authLoginAzure?;
    get authLoginAzure(): VaultProviderAuthLoginAzure[] | cdktn.IResolvable | undefined;
    set authLoginAzure(value: VaultProviderAuthLoginAzure[] | cdktn.IResolvable | undefined);
    resetAuthLoginAzure(): void;
    get authLoginAzureInput(): cdktn.IResolvable | VaultProviderAuthLoginAzure[] | undefined;
    private _authLoginCert?;
    get authLoginCert(): VaultProviderAuthLoginCert[] | cdktn.IResolvable | undefined;
    set authLoginCert(value: VaultProviderAuthLoginCert[] | cdktn.IResolvable | undefined);
    resetAuthLoginCert(): void;
    get authLoginCertInput(): cdktn.IResolvable | VaultProviderAuthLoginCert[] | undefined;
    private _authLoginGcp?;
    get authLoginGcp(): VaultProviderAuthLoginGcp[] | cdktn.IResolvable | undefined;
    set authLoginGcp(value: VaultProviderAuthLoginGcp[] | cdktn.IResolvable | undefined);
    resetAuthLoginGcp(): void;
    get authLoginGcpInput(): cdktn.IResolvable | VaultProviderAuthLoginGcp[] | undefined;
    private _authLoginJwt?;
    get authLoginJwt(): VaultProviderAuthLoginJwt[] | cdktn.IResolvable | undefined;
    set authLoginJwt(value: VaultProviderAuthLoginJwt[] | cdktn.IResolvable | undefined);
    resetAuthLoginJwt(): void;
    get authLoginJwtInput(): cdktn.IResolvable | VaultProviderAuthLoginJwt[] | undefined;
    private _authLoginKerberos?;
    get authLoginKerberos(): VaultProviderAuthLoginKerberos[] | cdktn.IResolvable | undefined;
    set authLoginKerberos(value: VaultProviderAuthLoginKerberos[] | cdktn.IResolvable | undefined);
    resetAuthLoginKerberos(): void;
    get authLoginKerberosInput(): cdktn.IResolvable | VaultProviderAuthLoginKerberos[] | undefined;
    private _authLoginOci?;
    get authLoginOci(): VaultProviderAuthLoginOci[] | cdktn.IResolvable | undefined;
    set authLoginOci(value: VaultProviderAuthLoginOci[] | cdktn.IResolvable | undefined);
    resetAuthLoginOci(): void;
    get authLoginOciInput(): cdktn.IResolvable | VaultProviderAuthLoginOci[] | undefined;
    private _authLoginOidc?;
    get authLoginOidc(): VaultProviderAuthLoginOidc[] | cdktn.IResolvable | undefined;
    set authLoginOidc(value: VaultProviderAuthLoginOidc[] | cdktn.IResolvable | undefined);
    resetAuthLoginOidc(): void;
    get authLoginOidcInput(): cdktn.IResolvable | VaultProviderAuthLoginOidc[] | undefined;
    private _authLoginRadius?;
    get authLoginRadius(): VaultProviderAuthLoginRadius[] | cdktn.IResolvable | undefined;
    set authLoginRadius(value: VaultProviderAuthLoginRadius[] | cdktn.IResolvable | undefined);
    resetAuthLoginRadius(): void;
    get authLoginRadiusInput(): cdktn.IResolvable | VaultProviderAuthLoginRadius[] | undefined;
    private _authLoginTokenFile?;
    get authLoginTokenFile(): VaultProviderAuthLoginTokenFile[] | cdktn.IResolvable | undefined;
    set authLoginTokenFile(value: VaultProviderAuthLoginTokenFile[] | cdktn.IResolvable | undefined);
    resetAuthLoginTokenFile(): void;
    get authLoginTokenFileInput(): cdktn.IResolvable | VaultProviderAuthLoginTokenFile[] | undefined;
    private _authLoginUserpass?;
    get authLoginUserpass(): VaultProviderAuthLoginUserpass[] | cdktn.IResolvable | undefined;
    set authLoginUserpass(value: VaultProviderAuthLoginUserpass[] | cdktn.IResolvable | undefined);
    resetAuthLoginUserpass(): void;
    get authLoginUserpassInput(): cdktn.IResolvable | VaultProviderAuthLoginUserpass[] | undefined;
    private _clientAuth?;
    get clientAuth(): VaultProviderClientAuth[] | cdktn.IResolvable | undefined;
    set clientAuth(value: VaultProviderClientAuth[] | cdktn.IResolvable | undefined);
    resetClientAuth(): void;
    get clientAuthInput(): cdktn.IResolvable | VaultProviderClientAuth[] | undefined;
    private _headers?;
    get headers(): VaultProviderHeaders[] | cdktn.IResolvable | undefined;
    set headers(value: VaultProviderHeaders[] | cdktn.IResolvable | undefined);
    resetHeaders(): void;
    get headersInput(): cdktn.IResolvable | VaultProviderHeaders[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PkiSecretBackendIssuerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Full path where PKI backend is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer#backend PkiSecretBackendIssuer#backend}
    */
    readonly backend: string;
    /**
    * Specifies the URL values for the CRL Distribution Points field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer#crl_distribution_points PkiSecretBackendIssuer#crl_distribution_points}
    */
    readonly crlDistributionPoints?: string[];
    /**
    * This determines whether this issuer is able to issue certificates where the chain of trust (including the issued certificate) contain critical extensions not processed by Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer#disable_critical_extension_checks PkiSecretBackendIssuer#disable_critical_extension_checks}
    */
    readonly disableCriticalExtensionChecks?: boolean | cdktn.IResolvable;
    /**
    * This determines whether this issuer is able to issue certificates where the chain of trust (including the final issued certificate) contains a link in which the subject of the issuing certificate does not match the named issuer of the certificate it signed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer#disable_name_checks PkiSecretBackendIssuer#disable_name_checks}
    */
    readonly disableNameChecks?: boolean | cdktn.IResolvable;
    /**
    * This determines whether this issuer is able to issue certificates where the chain of trust (including the final issued certificate) violates the name constraints critical extension of one of the issuer certificates in the chain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer#disable_name_constraint_checks PkiSecretBackendIssuer#disable_name_constraint_checks}
    */
    readonly disableNameConstraintChecks?: boolean | cdktn.IResolvable;
    /**
    * This determines whether this issuer is able to issue certificates where the chain of trust (including the final issued certificate) is longer than allowed by a certificate authority in that chain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer#disable_path_length_checks PkiSecretBackendIssuer#disable_path_length_checks}
    */
    readonly disablePathLengthChecks?: boolean | cdktn.IResolvable;
    /**
    * Specifies that the AIA URL values should be templated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer#enable_aia_url_templating PkiSecretBackendIssuer#enable_aia_url_templating}
    */
    readonly enableAiaUrlTemplating?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer#id PkiSecretBackendIssuer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Reference to an existing issuer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer#issuer_name PkiSecretBackendIssuer#issuer_name}
    */
    readonly issuerName?: string;
    /**
    * Reference to an existing issuer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer#issuer_ref PkiSecretBackendIssuer#issuer_ref}
    */
    readonly issuerRef: string;
    /**
    * Specifies the URL values for the Issuing Certificate field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer#issuing_certificates PkiSecretBackendIssuer#issuing_certificates}
    */
    readonly issuingCertificates?: string[];
    /**
    * Behavior of a leaf's 'NotAfter' field during issuance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer#leaf_not_after_behavior PkiSecretBackendIssuer#leaf_not_after_behavior}
    */
    readonly leafNotAfterBehavior?: string;
    /**
    * Chain of issuer references to build this issuer's computed CAChain field from, when non-empty.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer#manual_chain PkiSecretBackendIssuer#manual_chain}
    */
    readonly manualChain?: string[];
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer#namespace PkiSecretBackendIssuer#namespace}
    */
    readonly namespace?: string;
    /**
    * Specifies the URL values for the OCSP Servers field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer#ocsp_servers PkiSecretBackendIssuer#ocsp_servers}
    */
    readonly ocspServers?: string[];
    /**
    * Which signature algorithm to use when building CRLs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer#revocation_signature_algorithm PkiSecretBackendIssuer#revocation_signature_algorithm}
    */
    readonly revocationSignatureAlgorithm?: string;
    /**
    * Comma-separated list of allowed usages for this issuer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer#usage PkiSecretBackendIssuer#usage}
    */
    readonly usage?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer vault_pki_secret_backend_issuer}
*/
export declare class PkiSecretBackendIssuer extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_pki_secret_backend_issuer";
    /**
    * Generates CDKTN code for importing a PkiSecretBackendIssuer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PkiSecretBackendIssuer to import
    * @param importFromId The id of the existing PkiSecretBackendIssuer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PkiSecretBackendIssuer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/pki_secret_backend_issuer vault_pki_secret_backend_issuer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PkiSecretBackendIssuerConfig
    */
    constructor(scope: Construct, id: string, config: PkiSecretBackendIssuerConfig);
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    private _crlDistributionPoints?;
    get crlDistributionPoints(): string[];
    set crlDistributionPoints(value: string[]);
    resetCrlDistributionPoints(): void;
    get crlDistributionPointsInput(): string[] | undefined;
    private _disableCriticalExtensionChecks?;
    get disableCriticalExtensionChecks(): boolean | cdktn.IResolvable;
    set disableCriticalExtensionChecks(value: boolean | cdktn.IResolvable);
    resetDisableCriticalExtensionChecks(): void;
    get disableCriticalExtensionChecksInput(): boolean | cdktn.IResolvable | undefined;
    private _disableNameChecks?;
    get disableNameChecks(): boolean | cdktn.IResolvable;
    set disableNameChecks(value: boolean | cdktn.IResolvable);
    resetDisableNameChecks(): void;
    get disableNameChecksInput(): boolean | cdktn.IResolvable | undefined;
    private _disableNameConstraintChecks?;
    get disableNameConstraintChecks(): boolean | cdktn.IResolvable;
    set disableNameConstraintChecks(value: boolean | cdktn.IResolvable);
    resetDisableNameConstraintChecks(): void;
    get disableNameConstraintChecksInput(): boolean | cdktn.IResolvable | undefined;
    private _disablePathLengthChecks?;
    get disablePathLengthChecks(): boolean | cdktn.IResolvable;
    set disablePathLengthChecks(value: boolean | cdktn.IResolvable);
    resetDisablePathLengthChecks(): void;
    get disablePathLengthChecksInput(): boolean | cdktn.IResolvable | undefined;
    private _enableAiaUrlTemplating?;
    get enableAiaUrlTemplating(): boolean | cdktn.IResolvable;
    set enableAiaUrlTemplating(value: boolean | cdktn.IResolvable);
    resetEnableAiaUrlTemplating(): void;
    get enableAiaUrlTemplatingInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get issuerId(): string;
    private _issuerName?;
    get issuerName(): string;
    set issuerName(value: string);
    resetIssuerName(): void;
    get issuerNameInput(): string | undefined;
    private _issuerRef?;
    get issuerRef(): string;
    set issuerRef(value: string);
    get issuerRefInput(): string | undefined;
    private _issuingCertificates?;
    get issuingCertificates(): string[];
    set issuingCertificates(value: string[]);
    resetIssuingCertificates(): void;
    get issuingCertificatesInput(): string[] | undefined;
    private _leafNotAfterBehavior?;
    get leafNotAfterBehavior(): string;
    set leafNotAfterBehavior(value: string);
    resetLeafNotAfterBehavior(): void;
    get leafNotAfterBehaviorInput(): string | undefined;
    private _manualChain?;
    get manualChain(): string[];
    set manualChain(value: string[]);
    resetManualChain(): void;
    get manualChainInput(): string[] | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _ocspServers?;
    get ocspServers(): string[];
    set ocspServers(value: string[]);
    resetOcspServers(): void;
    get ocspServersInput(): string[] | undefined;
    private _revocationSignatureAlgorithm?;
    get revocationSignatureAlgorithm(): string;
    set revocationSignatureAlgorithm(value: string);
    resetRevocationSignatureAlgorithm(): void;
    get revocationSignatureAlgorithmInput(): string | undefined;
    private _usage?;
    get usage(): string;
    set usage(value: string);
    resetUsage(): void;
    get usageInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

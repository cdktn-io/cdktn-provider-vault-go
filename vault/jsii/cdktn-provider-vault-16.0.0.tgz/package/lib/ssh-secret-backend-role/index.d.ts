/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SshSecretBackendRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#algorithm_signer SshSecretBackendRole#algorithm_signer}
    */
    readonly algorithmSigner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#allow_bare_domains SshSecretBackendRole#allow_bare_domains}
    */
    readonly allowBareDomains?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#allow_empty_principals SshSecretBackendRole#allow_empty_principals}
    */
    readonly allowEmptyPrincipals?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#allow_host_certificates SshSecretBackendRole#allow_host_certificates}
    */
    readonly allowHostCertificates?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#allow_subdomains SshSecretBackendRole#allow_subdomains}
    */
    readonly allowSubdomains?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#allow_user_certificates SshSecretBackendRole#allow_user_certificates}
    */
    readonly allowUserCertificates?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#allow_user_key_ids SshSecretBackendRole#allow_user_key_ids}
    */
    readonly allowUserKeyIds?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#allowed_critical_options SshSecretBackendRole#allowed_critical_options}
    */
    readonly allowedCriticalOptions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#allowed_domains SshSecretBackendRole#allowed_domains}
    */
    readonly allowedDomains?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#allowed_domains_template SshSecretBackendRole#allowed_domains_template}
    */
    readonly allowedDomainsTemplate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#allowed_extensions SshSecretBackendRole#allowed_extensions}
    */
    readonly allowedExtensions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#allowed_users SshSecretBackendRole#allowed_users}
    */
    readonly allowedUsers?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#allowed_users_template SshSecretBackendRole#allowed_users_template}
    */
    readonly allowedUsersTemplate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#backend SshSecretBackendRole#backend}
    */
    readonly backend: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#cidr_list SshSecretBackendRole#cidr_list}
    */
    readonly cidrList?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#default_critical_options SshSecretBackendRole#default_critical_options}
    */
    readonly defaultCriticalOptions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#default_extensions SshSecretBackendRole#default_extensions}
    */
    readonly defaultExtensions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#default_user SshSecretBackendRole#default_user}
    */
    readonly defaultUser?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#default_user_template SshSecretBackendRole#default_user_template}
    */
    readonly defaultUserTemplate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#id SshSecretBackendRole#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#key_id_format SshSecretBackendRole#key_id_format}
    */
    readonly keyIdFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#key_type SshSecretBackendRole#key_type}
    */
    readonly keyType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#max_ttl SshSecretBackendRole#max_ttl}
    */
    readonly maxTtl?: string;
    /**
    * Unique name for the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#name SshSecretBackendRole#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#namespace SshSecretBackendRole#namespace}
    */
    readonly namespace?: string;
    /**
    * Specifies the duration by which to backdate the ValidAfter property. Uses duration format strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#not_before_duration SshSecretBackendRole#not_before_duration}
    */
    readonly notBeforeDuration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#ttl SshSecretBackendRole#ttl}
    */
    readonly ttl?: string;
    /**
    * allowed_user_key_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#allowed_user_key_config SshSecretBackendRole#allowed_user_key_config}
    */
    readonly allowedUserKeyConfig?: SshSecretBackendRoleAllowedUserKeyConfig[] | cdktn.IResolvable;
}
export interface SshSecretBackendRoleAllowedUserKeyConfig {
    /**
    * List of allowed key lengths, vault-1.10 and above
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#lengths SshSecretBackendRole#lengths}
    */
    readonly lengths: number[];
    /**
    * Key type, choices:
    * rsa, ecdsa, ec, dsa, ed25519, ssh-rsa, ssh-dss, ssh-ed25519, ecdsa-sha2-nistp256, ecdsa-sha2-nistp384, ecdsa-sha2-nistp521
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#type SshSecretBackendRole#type}
    */
    readonly type: string;
}
export declare function sshSecretBackendRoleAllowedUserKeyConfigToTerraform(struct?: SshSecretBackendRoleAllowedUserKeyConfig | cdktn.IResolvable): any;
export declare function sshSecretBackendRoleAllowedUserKeyConfigToHclTerraform(struct?: SshSecretBackendRoleAllowedUserKeyConfig | cdktn.IResolvable): any;
export declare class SshSecretBackendRoleAllowedUserKeyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SshSecretBackendRoleAllowedUserKeyConfig | cdktn.IResolvable | undefined;
    set internalValue(value: SshSecretBackendRoleAllowedUserKeyConfig | cdktn.IResolvable | undefined);
    private _lengths?;
    get lengths(): number[];
    set lengths(value: number[]);
    get lengthsInput(): number[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class SshSecretBackendRoleAllowedUserKeyConfigList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: SshSecretBackendRoleAllowedUserKeyConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SshSecretBackendRoleAllowedUserKeyConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role vault_ssh_secret_backend_role}
*/
export declare class SshSecretBackendRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_ssh_secret_backend_role";
    /**
    * Generates CDKTN code for importing a SshSecretBackendRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SshSecretBackendRole to import
    * @param importFromId The id of the existing SshSecretBackendRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SshSecretBackendRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ssh_secret_backend_role vault_ssh_secret_backend_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SshSecretBackendRoleConfig
    */
    constructor(scope: Construct, id: string, config: SshSecretBackendRoleConfig);
    private _algorithmSigner?;
    get algorithmSigner(): string;
    set algorithmSigner(value: string);
    resetAlgorithmSigner(): void;
    get algorithmSignerInput(): string | undefined;
    private _allowBareDomains?;
    get allowBareDomains(): boolean | cdktn.IResolvable;
    set allowBareDomains(value: boolean | cdktn.IResolvable);
    resetAllowBareDomains(): void;
    get allowBareDomainsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowEmptyPrincipals?;
    get allowEmptyPrincipals(): boolean | cdktn.IResolvable;
    set allowEmptyPrincipals(value: boolean | cdktn.IResolvable);
    resetAllowEmptyPrincipals(): void;
    get allowEmptyPrincipalsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowHostCertificates?;
    get allowHostCertificates(): boolean | cdktn.IResolvable;
    set allowHostCertificates(value: boolean | cdktn.IResolvable);
    resetAllowHostCertificates(): void;
    get allowHostCertificatesInput(): boolean | cdktn.IResolvable | undefined;
    private _allowSubdomains?;
    get allowSubdomains(): boolean | cdktn.IResolvable;
    set allowSubdomains(value: boolean | cdktn.IResolvable);
    resetAllowSubdomains(): void;
    get allowSubdomainsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowUserCertificates?;
    get allowUserCertificates(): boolean | cdktn.IResolvable;
    set allowUserCertificates(value: boolean | cdktn.IResolvable);
    resetAllowUserCertificates(): void;
    get allowUserCertificatesInput(): boolean | cdktn.IResolvable | undefined;
    private _allowUserKeyIds?;
    get allowUserKeyIds(): boolean | cdktn.IResolvable;
    set allowUserKeyIds(value: boolean | cdktn.IResolvable);
    resetAllowUserKeyIds(): void;
    get allowUserKeyIdsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowedCriticalOptions?;
    get allowedCriticalOptions(): string;
    set allowedCriticalOptions(value: string);
    resetAllowedCriticalOptions(): void;
    get allowedCriticalOptionsInput(): string | undefined;
    private _allowedDomains?;
    get allowedDomains(): string;
    set allowedDomains(value: string);
    resetAllowedDomains(): void;
    get allowedDomainsInput(): string | undefined;
    private _allowedDomainsTemplate?;
    get allowedDomainsTemplate(): boolean | cdktn.IResolvable;
    set allowedDomainsTemplate(value: boolean | cdktn.IResolvable);
    resetAllowedDomainsTemplate(): void;
    get allowedDomainsTemplateInput(): boolean | cdktn.IResolvable | undefined;
    private _allowedExtensions?;
    get allowedExtensions(): string;
    set allowedExtensions(value: string);
    resetAllowedExtensions(): void;
    get allowedExtensionsInput(): string | undefined;
    private _allowedUsers?;
    get allowedUsers(): string;
    set allowedUsers(value: string);
    resetAllowedUsers(): void;
    get allowedUsersInput(): string | undefined;
    private _allowedUsersTemplate?;
    get allowedUsersTemplate(): boolean | cdktn.IResolvable;
    set allowedUsersTemplate(value: boolean | cdktn.IResolvable);
    resetAllowedUsersTemplate(): void;
    get allowedUsersTemplateInput(): boolean | cdktn.IResolvable | undefined;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    private _cidrList?;
    get cidrList(): string;
    set cidrList(value: string);
    resetCidrList(): void;
    get cidrListInput(): string | undefined;
    private _defaultCriticalOptions?;
    get defaultCriticalOptions(): {
        [key: string]: string;
    };
    set defaultCriticalOptions(value: {
        [key: string]: string;
    });
    resetDefaultCriticalOptions(): void;
    get defaultCriticalOptionsInput(): {
        [key: string]: string;
    } | undefined;
    private _defaultExtensions?;
    get defaultExtensions(): {
        [key: string]: string;
    };
    set defaultExtensions(value: {
        [key: string]: string;
    });
    resetDefaultExtensions(): void;
    get defaultExtensionsInput(): {
        [key: string]: string;
    } | undefined;
    private _defaultUser?;
    get defaultUser(): string;
    set defaultUser(value: string);
    resetDefaultUser(): void;
    get defaultUserInput(): string | undefined;
    private _defaultUserTemplate?;
    get defaultUserTemplate(): boolean | cdktn.IResolvable;
    set defaultUserTemplate(value: boolean | cdktn.IResolvable);
    resetDefaultUserTemplate(): void;
    get defaultUserTemplateInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyIdFormat?;
    get keyIdFormat(): string;
    set keyIdFormat(value: string);
    resetKeyIdFormat(): void;
    get keyIdFormatInput(): string | undefined;
    private _keyType?;
    get keyType(): string;
    set keyType(value: string);
    get keyTypeInput(): string | undefined;
    private _maxTtl?;
    get maxTtl(): string;
    set maxTtl(value: string);
    resetMaxTtl(): void;
    get maxTtlInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _notBeforeDuration?;
    get notBeforeDuration(): string;
    set notBeforeDuration(value: string);
    resetNotBeforeDuration(): void;
    get notBeforeDurationInput(): string | undefined;
    private _ttl?;
    get ttl(): string;
    set ttl(value: string);
    resetTtl(): void;
    get ttlInput(): string | undefined;
    private _allowedUserKeyConfig;
    get allowedUserKeyConfig(): SshSecretBackendRoleAllowedUserKeyConfigList;
    putAllowedUserKeyConfig(value: SshSecretBackendRoleAllowedUserKeyConfig[] | cdktn.IResolvable): void;
    resetAllowedUserKeyConfig(): void;
    get allowedUserKeyConfigInput(): cdktn.IResolvable | SshSecretBackendRoleAllowedUserKeyConfig[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LdapSecretBackendConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of managed key registry entry names that the mount in question is allowed to access
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#allowed_managed_keys LdapSecretBackend#allowed_managed_keys}
    */
    readonly allowedManagedKeys?: string[];
    /**
    * List of headers to allow and pass from the request to the plugin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#allowed_response_headers LdapSecretBackend#allowed_response_headers}
    */
    readonly allowedResponseHeaders?: string[];
    /**
    * Specifies the list of keys that will not be HMAC'd by audit devices in the request data object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#audit_non_hmac_request_keys LdapSecretBackend#audit_non_hmac_request_keys}
    */
    readonly auditNonHmacRequestKeys?: string[];
    /**
    * Specifies the list of keys that will not be HMAC'd by audit devices in the response data object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#audit_non_hmac_response_keys LdapSecretBackend#audit_non_hmac_response_keys}
    */
    readonly auditNonHmacResponseKeys?: string[];
    /**
    * Distinguished name of object to bind when performing user and group search.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#binddn LdapSecretBackend#binddn}
    */
    readonly binddn: string;
    /**
    * LDAP password for searching for the user DN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#bindpass LdapSecretBackend#bindpass}
    */
    readonly bindpass?: string;
    /**
    * Write-only LDAP password for searching for the user DN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#bindpass_wo LdapSecretBackend#bindpass_wo}
    */
    readonly bindpassWo?: string;
    /**
    * Version counter for write-only bind password.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#bindpass_wo_version LdapSecretBackend#bindpass_wo_version}
    */
    readonly bindpassWoVersion?: number;
    /**
    * CA certificate to use when verifying LDAP server certificate, must be x509 PEM encoded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#certificate LdapSecretBackend#certificate}
    */
    readonly certificate?: string;
    /**
    * Client certificate to provide to the LDAP server, must be x509 PEM encoded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#client_tls_cert LdapSecretBackend#client_tls_cert}
    */
    readonly clientTlsCert?: string;
    /**
    * Client certificate key to provide to the LDAP server, must be x509 PEM encoded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#client_tls_key LdapSecretBackend#client_tls_key}
    */
    readonly clientTlsKey?: string;
    /**
    * Timeout, in seconds, when attempting to connect to the LDAP server before trying the next URL in the configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#connection_timeout LdapSecretBackend#connection_timeout}
    */
    readonly connectionTimeout?: number;
    /**
    * The type of credential to manage. Options include: 'password', 'phrase'. Defaults to 'password'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#credential_type LdapSecretBackend#credential_type}
    */
    readonly credentialType?: string;
    /**
    * Default lease duration for tokens and secrets in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#default_lease_ttl_seconds LdapSecretBackend#default_lease_ttl_seconds}
    */
    readonly defaultLeaseTtlSeconds?: number;
    /**
    * List of headers to allow and pass from the request to the plugin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#delegated_auth_accessors LdapSecretBackend#delegated_auth_accessors}
    */
    readonly delegatedAuthAccessors?: string[];
    /**
    * Human-friendly description of the mount
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#description LdapSecretBackend#description}
    */
    readonly description?: string;
    /**
    * Stops rotation of the root credential until set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#disable_automated_rotation LdapSecretBackend#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * If set, opts out of mount migration on path updates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#disable_remount LdapSecretBackend#disable_remount}
    */
    readonly disableRemount?: boolean | cdktn.IResolvable;
    /**
    * Enable the secrets engine to access Vault's external entropy source
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#external_entropy_access LdapSecretBackend#external_entropy_access}
    */
    readonly externalEntropyAccess?: boolean | cdktn.IResolvable;
    /**
    * If set to true, disables caching.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#force_no_cache LdapSecretBackend#force_no_cache}
    */
    readonly forceNoCache?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#id LdapSecretBackend#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The key to use for signing plugin workload identity tokens
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#identity_token_key LdapSecretBackend#identity_token_key}
    */
    readonly identityTokenKey?: string;
    /**
    * Skip LDAP server SSL Certificate verification - insecure and not recommended for production use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#insecure_tls LdapSecretBackend#insecure_tls}
    */
    readonly insecureTls?: boolean | cdktn.IResolvable;
    /**
    * Specifies whether to show this mount in the UI-specific listing endpoint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#listing_visibility LdapSecretBackend#listing_visibility}
    */
    readonly listingVisibility?: string;
    /**
    * Local mount flag that can be explicitly set to true to enforce local mount in HA environment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#local LdapSecretBackend#local}
    */
    readonly local?: boolean | cdktn.IResolvable;
    /**
    * Maximum possible lease duration for tokens and secrets in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#max_lease_ttl_seconds LdapSecretBackend#max_lease_ttl_seconds}
    */
    readonly maxLeaseTtlSeconds?: number;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#namespace LdapSecretBackend#namespace}
    */
    readonly namespace?: string;
    /**
    * Specifies mount type specific options that are passed to the backend
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#options LdapSecretBackend#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * List of headers to allow and pass from the request to the plugin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#passthrough_request_headers LdapSecretBackend#passthrough_request_headers}
    */
    readonly passthroughRequestHeaders?: string[];
    /**
    * Name of the password policy to use to generate passwords.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#password_policy LdapSecretBackend#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * The path where the LDAP secrets backend is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#path LdapSecretBackend#path}
    */
    readonly path?: string;
    /**
    * Specifies the semantic version of the plugin to use, e.g. 'v1.0.0'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#plugin_version LdapSecretBackend#plugin_version}
    */
    readonly pluginVersion?: string;
    /**
    * Timeout, in seconds, for the connection when making requests against the server before returning back an error.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#request_timeout LdapSecretBackend#request_timeout}
    */
    readonly requestTimeout?: number;
    /**
    * The period of time in seconds between each rotation of the root credential. Cannot be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#rotation_period LdapSecretBackend#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * The cron-style schedule for the root credential to be rotated on. Cannot be used with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#rotation_schedule LdapSecretBackend#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * The maximum amount of time in seconds Vault is allowed to complete a rotation once a scheduled rotation is triggered. Can only be used with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#rotation_window LdapSecretBackend#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * The LDAP schema to use when storing entry passwords. Valid schemas include openldap, ad, and racf.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#schema LdapSecretBackend#schema}
    */
    readonly schema?: string;
    /**
    * Enable seal wrapping for the mount, causing values stored by the mount to be wrapped by the seal's encryption capability
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#seal_wrap LdapSecretBackend#seal_wrap}
    */
    readonly sealWrap?: boolean | cdktn.IResolvable;
    /**
    * Skip rotation of static role secrets on import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#skip_static_role_import_rotation LdapSecretBackend#skip_static_role_import_rotation}
    */
    readonly skipStaticRoleImportRotation?: boolean | cdktn.IResolvable;
    /**
    * Issue a StartTLS command after establishing unencrypted connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#starttls LdapSecretBackend#starttls}
    */
    readonly starttls?: boolean | cdktn.IResolvable;
    /**
    * Enables userPrincipalDomain login with [username]@UPNDomain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#upndomain LdapSecretBackend#upndomain}
    */
    readonly upndomain?: string;
    /**
    * LDAP URL to connect to (default: ldap://127.0.0.1). Multiple URLs can be specified by concatenating them with commas; they will be tried in-order.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#url LdapSecretBackend#url}
    */
    readonly url?: string;
    /**
    * Attribute used for users (default: cn)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#userattr LdapSecretBackend#userattr}
    */
    readonly userattr?: string;
    /**
    * LDAP domain to use for users (eg: ou=People,dc=example,dc=org)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#userdn LdapSecretBackend#userdn}
    */
    readonly userdn?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend vault_ldap_secret_backend}
*/
export declare class LdapSecretBackend extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_ldap_secret_backend";
    /**
    * Generates CDKTN code for importing a LdapSecretBackend resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LdapSecretBackend to import
    * @param importFromId The id of the existing LdapSecretBackend that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LdapSecretBackend to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.7.0/docs/resources/ldap_secret_backend vault_ldap_secret_backend} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LdapSecretBackendConfig
    */
    constructor(scope: Construct, id: string, config: LdapSecretBackendConfig);
    get accessor(): string;
    private _allowedManagedKeys?;
    get allowedManagedKeys(): string[];
    set allowedManagedKeys(value: string[]);
    resetAllowedManagedKeys(): void;
    get allowedManagedKeysInput(): string[] | undefined;
    private _allowedResponseHeaders?;
    get allowedResponseHeaders(): string[];
    set allowedResponseHeaders(value: string[]);
    resetAllowedResponseHeaders(): void;
    get allowedResponseHeadersInput(): string[] | undefined;
    private _auditNonHmacRequestKeys?;
    get auditNonHmacRequestKeys(): string[];
    set auditNonHmacRequestKeys(value: string[]);
    resetAuditNonHmacRequestKeys(): void;
    get auditNonHmacRequestKeysInput(): string[] | undefined;
    private _auditNonHmacResponseKeys?;
    get auditNonHmacResponseKeys(): string[];
    set auditNonHmacResponseKeys(value: string[]);
    resetAuditNonHmacResponseKeys(): void;
    get auditNonHmacResponseKeysInput(): string[] | undefined;
    private _binddn?;
    get binddn(): string;
    set binddn(value: string);
    get binddnInput(): string | undefined;
    private _bindpass?;
    get bindpass(): string;
    set bindpass(value: string);
    resetBindpass(): void;
    get bindpassInput(): string | undefined;
    private _bindpassWo?;
    get bindpassWo(): string;
    set bindpassWo(value: string);
    resetBindpassWo(): void;
    get bindpassWoInput(): string | undefined;
    private _bindpassWoVersion?;
    get bindpassWoVersion(): number;
    set bindpassWoVersion(value: number);
    resetBindpassWoVersion(): void;
    get bindpassWoVersionInput(): number | undefined;
    private _certificate?;
    get certificate(): string;
    set certificate(value: string);
    resetCertificate(): void;
    get certificateInput(): string | undefined;
    private _clientTlsCert?;
    get clientTlsCert(): string;
    set clientTlsCert(value: string);
    resetClientTlsCert(): void;
    get clientTlsCertInput(): string | undefined;
    private _clientTlsKey?;
    get clientTlsKey(): string;
    set clientTlsKey(value: string);
    resetClientTlsKey(): void;
    get clientTlsKeyInput(): string | undefined;
    private _connectionTimeout?;
    get connectionTimeout(): number;
    set connectionTimeout(value: number);
    resetConnectionTimeout(): void;
    get connectionTimeoutInput(): number | undefined;
    private _credentialType?;
    get credentialType(): string;
    set credentialType(value: string);
    resetCredentialType(): void;
    get credentialTypeInput(): string | undefined;
    private _defaultLeaseTtlSeconds?;
    get defaultLeaseTtlSeconds(): number;
    set defaultLeaseTtlSeconds(value: number);
    resetDefaultLeaseTtlSeconds(): void;
    get defaultLeaseTtlSecondsInput(): number | undefined;
    private _delegatedAuthAccessors?;
    get delegatedAuthAccessors(): string[];
    set delegatedAuthAccessors(value: string[]);
    resetDelegatedAuthAccessors(): void;
    get delegatedAuthAccessorsInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _disableRemount?;
    get disableRemount(): boolean | cdktn.IResolvable;
    set disableRemount(value: boolean | cdktn.IResolvable);
    resetDisableRemount(): void;
    get disableRemountInput(): boolean | cdktn.IResolvable | undefined;
    private _externalEntropyAccess?;
    get externalEntropyAccess(): boolean | cdktn.IResolvable;
    set externalEntropyAccess(value: boolean | cdktn.IResolvable);
    resetExternalEntropyAccess(): void;
    get externalEntropyAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _forceNoCache?;
    get forceNoCache(): boolean | cdktn.IResolvable;
    set forceNoCache(value: boolean | cdktn.IResolvable);
    resetForceNoCache(): void;
    get forceNoCacheInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityTokenKey?;
    get identityTokenKey(): string;
    set identityTokenKey(value: string);
    resetIdentityTokenKey(): void;
    get identityTokenKeyInput(): string | undefined;
    private _insecureTls?;
    get insecureTls(): boolean | cdktn.IResolvable;
    set insecureTls(value: boolean | cdktn.IResolvable);
    resetInsecureTls(): void;
    get insecureTlsInput(): boolean | cdktn.IResolvable | undefined;
    private _listingVisibility?;
    get listingVisibility(): string;
    set listingVisibility(value: string);
    resetListingVisibility(): void;
    get listingVisibilityInput(): string | undefined;
    private _local?;
    get local(): boolean | cdktn.IResolvable;
    set local(value: boolean | cdktn.IResolvable);
    resetLocal(): void;
    get localInput(): boolean | cdktn.IResolvable | undefined;
    private _maxLeaseTtlSeconds?;
    get maxLeaseTtlSeconds(): number;
    set maxLeaseTtlSeconds(value: number);
    resetMaxLeaseTtlSeconds(): void;
    get maxLeaseTtlSecondsInput(): number | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _passthroughRequestHeaders?;
    get passthroughRequestHeaders(): string[];
    set passthroughRequestHeaders(value: string[]);
    resetPassthroughRequestHeaders(): void;
    get passthroughRequestHeadersInput(): string[] | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _pluginVersion?;
    get pluginVersion(): string;
    set pluginVersion(value: string);
    resetPluginVersion(): void;
    get pluginVersionInput(): string | undefined;
    private _requestTimeout?;
    get requestTimeout(): number;
    set requestTimeout(value: number);
    resetRequestTimeout(): void;
    get requestTimeoutInput(): number | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _sealWrap?;
    get sealWrap(): boolean | cdktn.IResolvable;
    set sealWrap(value: boolean | cdktn.IResolvable);
    resetSealWrap(): void;
    get sealWrapInput(): boolean | cdktn.IResolvable | undefined;
    private _skipStaticRoleImportRotation?;
    get skipStaticRoleImportRotation(): boolean | cdktn.IResolvable;
    set skipStaticRoleImportRotation(value: boolean | cdktn.IResolvable);
    resetSkipStaticRoleImportRotation(): void;
    get skipStaticRoleImportRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _starttls?;
    get starttls(): boolean | cdktn.IResolvable;
    set starttls(value: boolean | cdktn.IResolvable);
    resetStarttls(): void;
    get starttlsInput(): boolean | cdktn.IResolvable | undefined;
    private _upndomain?;
    get upndomain(): string;
    set upndomain(value: string);
    resetUpndomain(): void;
    get upndomainInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _userattr?;
    get userattr(): string;
    set userattr(value: string);
    resetUserattr(): void;
    get userattrInput(): string | undefined;
    private _userdn?;
    get userdn(): string;
    set userdn(value: string);
    resetUserdn(): void;
    get userdnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

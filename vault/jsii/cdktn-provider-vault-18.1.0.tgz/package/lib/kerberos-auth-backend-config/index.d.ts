/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface KerberosAuthBackendConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Adds group aliases during authentication. Default: false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.11.0/docs/resources/kerberos_auth_backend_config#add_group_aliases KerberosAuthBackendConfig#add_group_aliases}
    */
    readonly addGroupAliases?: boolean | cdktn.IResolvable;
    /**
    * Base64-encoded keytab file content (write-only). Must contain an entry matching service_account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.11.0/docs/resources/kerberos_auth_backend_config#keytab_wo KerberosAuthBackendConfig#keytab_wo}
    */
    readonly keytabWo: string;
    /**
    * Version identifier for keytab updates. Increment this value to trigger a keytab update.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.11.0/docs/resources/kerberos_auth_backend_config#keytab_wo_version KerberosAuthBackendConfig#keytab_wo_version}
    */
    readonly keytabWoVersion: number;
    /**
    * Path where the Kerberos auth method is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.11.0/docs/resources/kerberos_auth_backend_config#mount KerberosAuthBackendConfig#mount}
    */
    readonly mount: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.11.0/docs/resources/kerberos_auth_backend_config#namespace KerberosAuthBackendConfig#namespace}
    */
    readonly namespace?: string;
    /**
    * Removes instance names from Kerberos service principal names. Default: false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.11.0/docs/resources/kerberos_auth_backend_config#remove_instance_name KerberosAuthBackendConfig#remove_instance_name}
    */
    readonly removeInstanceName?: boolean | cdktn.IResolvable;
    /**
    * The Kerberos service account associated with the keytab entry (e.g., 'vault_svc').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.11.0/docs/resources/kerberos_auth_backend_config#service_account KerberosAuthBackendConfig#service_account}
    */
    readonly serviceAccount: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.11.0/docs/resources/kerberos_auth_backend_config vault_kerberos_auth_backend_config}
*/
export declare class KerberosAuthBackendConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_kerberos_auth_backend_config";
    /**
    * Generates CDKTN code for importing a KerberosAuthBackendConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KerberosAuthBackendConfig to import
    * @param importFromId The id of the existing KerberosAuthBackendConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.11.0/docs/resources/kerberos_auth_backend_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KerberosAuthBackendConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.11.0/docs/resources/kerberos_auth_backend_config vault_kerberos_auth_backend_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KerberosAuthBackendConfigConfig
    */
    constructor(scope: Construct, id: string, config: KerberosAuthBackendConfigConfig);
    private _addGroupAliases?;
    get addGroupAliases(): boolean | cdktn.IResolvable;
    set addGroupAliases(value: boolean | cdktn.IResolvable);
    resetAddGroupAliases(): void;
    get addGroupAliasesInput(): boolean | cdktn.IResolvable | undefined;
    private _keytabWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get keytabWo(): string;
    set keytabWo(value: string);
    get keytabWoInput(): string | undefined;
    private _keytabWoVersion?;
    get keytabWoVersion(): number;
    set keytabWoVersion(value: number);
    get keytabWoVersionInput(): number | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _removeInstanceName?;
    get removeInstanceName(): boolean | cdktn.IResolvable;
    set removeInstanceName(value: boolean | cdktn.IResolvable);
    resetRemoveInstanceName(): void;
    get removeInstanceNameInput(): boolean | cdktn.IResolvable | undefined;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    get serviceAccountInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

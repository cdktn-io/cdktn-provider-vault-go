/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EphemeralVaultRadiusAuthLoginConfig extends cdktn.TerraformEphemeralMetaArguments {
    /**
    * Unique name of the auth backend to login to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.11.0/docs/ephemeral-resources/radius_auth_login#mount EphemeralVaultRadiusAuthLogin#mount}
    */
    readonly mount: string;
    /**
    * Terraform ID of the mount resource. Used to defer the provisioning of the ephemeral resource till the apply stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.11.0/docs/ephemeral-resources/radius_auth_login#mount_id EphemeralVaultRadiusAuthLogin#mount_id}
    */
    readonly mountId?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.11.0/docs/ephemeral-resources/radius_auth_login#namespace EphemeralVaultRadiusAuthLogin#namespace}
    */
    readonly namespace?: string;
    /**
    * RADIUS password for the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.11.0/docs/ephemeral-resources/radius_auth_login#password EphemeralVaultRadiusAuthLogin#password}
    */
    readonly password: string;
    /**
    * RADIUS username to authenticate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.11.0/docs/ephemeral-resources/radius_auth_login#username EphemeralVaultRadiusAuthLogin#username}
    */
    readonly username: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.11.0/docs/ephemeral-resources/radius_auth_login vault_radius_auth_login}
*/
export declare class EphemeralVaultRadiusAuthLogin extends cdktn.TerraformEphemeralResource {
    static readonly tfResourceType = "vault_radius_auth_login";
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.11.0/docs/ephemeral-resources/radius_auth_login vault_radius_auth_login} Ephemeral Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EphemeralVaultRadiusAuthLoginConfig
    */
    constructor(scope: Construct, id: string, config: EphemeralVaultRadiusAuthLoginConfig);
    get accessor(): string;
    get clientToken(): string;
    private _data;
    get data(): cdktn.StringMap;
    get entityId(): string;
    get identityPolicies(): string[];
    get leaseDuration(): number;
    get leaseId(): string;
    private _metadata;
    get metadata(): cdktn.StringMap;
    get mfaRequirement(): string;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _mountId?;
    get mountId(): string;
    set mountId(value: string);
    resetMountId(): void;
    get mountIdInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get orphan(): cdktn.IResolvable;
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    get policies(): string[];
    get renewable(): cdktn.IResolvable;
    get tokenPolicies(): string[];
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    get warnings(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

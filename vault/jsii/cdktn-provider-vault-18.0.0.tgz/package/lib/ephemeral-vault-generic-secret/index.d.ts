/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EphemeralVaultGenericSecretConfig extends cdktn.TerraformEphemeralMetaArguments {
    /**
    * Terraform ID of the mount resource. Used to defer the provisioning of the ephemeral resource till the apply stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/ephemeral-resources/generic_secret#mount_id EphemeralVaultGenericSecret#mount_id}
    */
    readonly mountId?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/ephemeral-resources/generic_secret#namespace EphemeralVaultGenericSecret#namespace}
    */
    readonly namespace?: string;
    /**
    * Full path from which a secret will be read.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/ephemeral-resources/generic_secret#path EphemeralVaultGenericSecret#path}
    */
    readonly path: string;
    /**
    * Version of the secret to retrieve. Use -1 for latest version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/ephemeral-resources/generic_secret#version EphemeralVaultGenericSecret#version}
    */
    readonly version?: number;
    /**
    * If set to true, stores 'lease_start_time' in the result.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/ephemeral-resources/generic_secret#with_lease_start_time EphemeralVaultGenericSecret#with_lease_start_time}
    */
    readonly withLeaseStartTime?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/ephemeral-resources/generic_secret vault_generic_secret}
*/
export declare class EphemeralVaultGenericSecret extends cdktn.TerraformEphemeralResource {
    static readonly tfResourceType = "vault_generic_secret";
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/ephemeral-resources/generic_secret vault_generic_secret} Ephemeral Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EphemeralVaultGenericSecretConfig
    */
    constructor(scope: Construct, id: string, config: EphemeralVaultGenericSecretConfig);
    private _data;
    get data(): cdktn.StringMap;
    get dataJson(): string;
    get leaseDuration(): number;
    get leaseId(): string;
    get leaseRenewable(): cdktn.IResolvable;
    get leaseStartTime(): string;
    private _mountId?;
    get mountId(): string;
    set mountId(value: string);
    resetMountId(): void;
    get mountIdInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _version?;
    get version(): number;
    set version(value: number);
    resetVersion(): void;
    get versionInput(): number | undefined;
    private _withLeaseStartTime?;
    get withLeaseStartTime(): boolean | cdktn.IResolvable;
    set withLeaseStartTime(value: boolean | cdktn.IResolvable);
    resetWithLeaseStartTime(): void;
    get withLeaseStartTimeInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EphemeralVaultCfAuthLoginConfig extends cdktn.TerraformEphemeralMetaArguments {
    /**
    * The full body of the file available at the path denoted by `CF_INSTANCE_CERT`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/ephemeral-resources/cf_auth_login#cf_instance_cert EphemeralVaultCfAuthLogin#cf_instance_cert}
    */
    readonly cfInstanceCert: string;
    /**
    * Mount path for the CF auth engine in Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/ephemeral-resources/cf_auth_login#mount EphemeralVaultCfAuthLogin#mount}
    */
    readonly mount?: string;
    /**
    * Terraform ID of the mount resource. Used to defer the provisioning of the ephemeral resource till the apply stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/ephemeral-resources/cf_auth_login#mount_id EphemeralVaultCfAuthLogin#mount_id}
    */
    readonly mountId?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/ephemeral-resources/cf_auth_login#namespace EphemeralVaultCfAuthLogin#namespace}
    */
    readonly namespace?: string;
    /**
    * Name of the CF auth role to log in with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/ephemeral-resources/cf_auth_login#role EphemeralVaultCfAuthLogin#role}
    */
    readonly role: string;
    /**
    * The RSA-PSS/SHA256 signature generated using `CF_INSTANCE_KEY` over the concatenation of signing_time, cf_instance_cert, and role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/ephemeral-resources/cf_auth_login#signature EphemeralVaultCfAuthLogin#signature}
    */
    readonly signature: string;
    /**
    * The date and time used to construct the signature (e.g. `2006-01-02T15:04:05Z`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/ephemeral-resources/cf_auth_login#signing_time EphemeralVaultCfAuthLogin#signing_time}
    */
    readonly signingTime: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/ephemeral-resources/cf_auth_login vault_cf_auth_login}
*/
export declare class EphemeralVaultCfAuthLogin extends cdktn.TerraformEphemeralResource {
    static readonly tfResourceType = "vault_cf_auth_login";
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.1/docs/ephemeral-resources/cf_auth_login vault_cf_auth_login} Ephemeral Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EphemeralVaultCfAuthLoginConfig
    */
    constructor(scope: Construct, id: string, config: EphemeralVaultCfAuthLoginConfig);
    get accessor(): string;
    private _cfInstanceCert?;
    get cfInstanceCert(): string;
    set cfInstanceCert(value: string);
    get cfInstanceCertInput(): string | undefined;
    get clientToken(): string;
    get leaseDuration(): number;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    resetMount(): void;
    get mountInput(): string | undefined;
    private _mountId?;
    get mountId(): string;
    set mountId(value: string);
    resetMountId(): void;
    get mountIdInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get policies(): string[];
    get renewable(): cdktn.IResolvable;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _signature?;
    get signature(): string;
    set signature(value: string);
    get signatureInput(): string | undefined;
    private _signingTime?;
    get signingTime(): string;
    set signingTime(value: string);
    get signingTimeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

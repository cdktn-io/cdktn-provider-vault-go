/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TransitSecretBackendImportedKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * If set, enables taking backup of named key in plaintext format. Once enabled, cannot be disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#allow_plaintext_backup TransitSecretBackendImportedKey#allow_plaintext_backup}
    */
    readonly allowPlaintextBackup?: boolean | cdktn.IResolvable;
    /**
    * If set, the imported key can be rotated within Vault by using the rotate endpoint. Once the key is rotated in Vault, it no longer accepts imported key material. Changing this field replaces this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#allow_rotation TransitSecretBackendImportedKey#allow_rotation}
    */
    readonly allowRotation?: boolean | cdktn.IResolvable;
    /**
    * The period in seconds at which this key should be rotated automatically. Set to 0 to disable; otherwise it must be at least one hour (3600).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#auto_rotate_period TransitSecretBackendImportedKey#auto_rotate_period}
    */
    readonly autoRotatePeriod?: number;
    /**
    * A base64-encoded string containing the wrapped ephemeral AES key and the encrypted key material (write-only). Required with `ciphertext_wo_version`. Vault requires either this or `public_key` for the initial import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#ciphertext_wo TransitSecretBackendImportedKey#ciphertext_wo}
    */
    readonly ciphertextWo?: string;
    /**
    * Version identifier for `ciphertext_wo`. Increment it to import a new ciphertext as a new key version. Required with `ciphertext_wo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#ciphertext_wo_version TransitSecretBackendImportedKey#ciphertext_wo_version}
    */
    readonly ciphertextWoVersion?: number;
    /**
    * A base64-encoded string providing a context for key derivation. Required if `derived` is true. Changing this field replaces this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#context TransitSecretBackendImportedKey#context}
    */
    readonly context?: string;
    /**
    * Specifies if the key is allowed to be deleted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#deletion_allowed TransitSecretBackendImportedKey#deletion_allowed}
    */
    readonly deletionAllowed?: boolean | cdktn.IResolvable;
    /**
    * Specifies if key derivation is to be used. Changing this field replaces this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#derived TransitSecretBackendImportedKey#derived}
    */
    readonly derived?: boolean | cdktn.IResolvable;
    /**
    * Enables keys to be exportable. Once enabled, cannot be disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#exportable TransitSecretBackendImportedKey#exportable}
    */
    readonly exportable?: boolean | cdktn.IResolvable;
    /**
    * The hash function used for the RSA-OAEP step of creating the ciphertext (`SHA1`, `SHA224`, `SHA256`, `SHA384`, `SHA512`). Vault uses `SHA256` if not set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#hash_function TransitSecretBackendImportedKey#hash_function}
    */
    readonly hashFunction?: string;
    /**
    * Changes the key type of the new key version when importing key material into an existing key. Sent as `type` to Vault's import key version endpoint, so it has no effect on the initial import. Reported by `latest_version_type`. Requires Vault Enterprise 2.2.0 or later.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#import_version_type TransitSecretBackendImportedKey#import_version_type}
    */
    readonly importVersionType?: string;
    /**
    * Minimum key version to use for decryption. Vault always sets this to at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#min_decryption_version TransitSecretBackendImportedKey#min_decryption_version}
    */
    readonly minDecryptionVersion?: number;
    /**
    * Minimum key version to use for encryption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#min_encryption_version TransitSecretBackendImportedKey#min_encryption_version}
    */
    readonly minEncryptionVersion?: number;
    /**
    * Path where the Transit secret backend is mounted. Changing this field replaces this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#mount TransitSecretBackendImportedKey#mount}
    */
    readonly mount: string;
    /**
    * Name of the encryption key to create. Changing this field replaces this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#name TransitSecretBackendImportedKey#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#namespace TransitSecretBackendImportedKey#namespace}
    */
    readonly namespace?: string;
    /**
    * A plaintext PEM public key to be imported. Vault requires either this or `ciphertext_wo` for the initial import. Changing it imports the new public key as a new key version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#public_key TransitSecretBackendImportedKey#public_key}
    */
    readonly publicKey?: string;
    /**
    * Specifies the type of key to create (e.g. `aes128-gcm96`, `aes256-gcm96`, `chacha20-poly1305`, `ed25519`, `ecdsa-p256`, `ecdsa-p384`, `ecdsa-p521`, `rsa-2048`, `rsa-3072`, `rsa-4096`, `hmac`, `aes128-cmac`, `aes192-cmac`, `aes256-cmac`). Changing this field replaces this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#type TransitSecretBackendImportedKey#type}
    */
    readonly type: string;
    /**
    * Specifies the existing key version to update when importing key material to an already-imported key. If omitted, Vault creates a new version, except when the latest version contains only a public key and the request supplies its matching private key; in that case Vault adds the private key to the existing, latest version. Ignored when the key is first imported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#version TransitSecretBackendImportedKey#version}
    */
    readonly version?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key vault_transit_secret_backend_imported_key}
*/
export declare class TransitSecretBackendImportedKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_transit_secret_backend_imported_key";
    /**
    * Generates CDKTN code for importing a TransitSecretBackendImportedKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TransitSecretBackendImportedKey to import
    * @param importFromId The id of the existing TransitSecretBackendImportedKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TransitSecretBackendImportedKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transit_secret_backend_imported_key vault_transit_secret_backend_imported_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TransitSecretBackendImportedKeyConfig
    */
    constructor(scope: Construct, id: string, config: TransitSecretBackendImportedKeyConfig);
    private _allowPlaintextBackup?;
    get allowPlaintextBackup(): boolean | cdktn.IResolvable;
    set allowPlaintextBackup(value: boolean | cdktn.IResolvable);
    resetAllowPlaintextBackup(): void;
    get allowPlaintextBackupInput(): boolean | cdktn.IResolvable | undefined;
    private _allowRotation?;
    get allowRotation(): boolean | cdktn.IResolvable;
    set allowRotation(value: boolean | cdktn.IResolvable);
    resetAllowRotation(): void;
    get allowRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _autoRotatePeriod?;
    get autoRotatePeriod(): number;
    set autoRotatePeriod(value: number);
    resetAutoRotatePeriod(): void;
    get autoRotatePeriodInput(): number | undefined;
    private _ciphertextWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get ciphertextWo(): string;
    set ciphertextWo(value: string);
    resetCiphertextWo(): void;
    get ciphertextWoInput(): string | undefined;
    private _ciphertextWoVersion?;
    get ciphertextWoVersion(): number;
    set ciphertextWoVersion(value: number);
    resetCiphertextWoVersion(): void;
    get ciphertextWoVersionInput(): number | undefined;
    private _context?;
    get context(): string;
    set context(value: string);
    resetContext(): void;
    get contextInput(): string | undefined;
    private _deletionAllowed?;
    get deletionAllowed(): boolean | cdktn.IResolvable;
    set deletionAllowed(value: boolean | cdktn.IResolvable);
    resetDeletionAllowed(): void;
    get deletionAllowedInput(): boolean | cdktn.IResolvable | undefined;
    private _derived?;
    get derived(): boolean | cdktn.IResolvable;
    set derived(value: boolean | cdktn.IResolvable);
    resetDerived(): void;
    get derivedInput(): boolean | cdktn.IResolvable | undefined;
    private _exportable?;
    get exportable(): boolean | cdktn.IResolvable;
    set exportable(value: boolean | cdktn.IResolvable);
    resetExportable(): void;
    get exportableInput(): boolean | cdktn.IResolvable | undefined;
    private _hashFunction?;
    get hashFunction(): string;
    set hashFunction(value: string);
    resetHashFunction(): void;
    get hashFunctionInput(): string | undefined;
    private _importVersionType?;
    get importVersionType(): string;
    set importVersionType(value: string);
    resetImportVersionType(): void;
    get importVersionTypeInput(): string | undefined;
    get importedKey(): cdktn.IResolvable;
    get importedKeyAllowRotation(): cdktn.IResolvable;
    private _keys;
    get keys(): cdktn.StringMap;
    get latestVersion(): number;
    get latestVersionType(): string;
    get minAvailableVersion(): number;
    private _minDecryptionVersion?;
    get minDecryptionVersion(): number;
    set minDecryptionVersion(value: number);
    resetMinDecryptionVersion(): void;
    get minDecryptionVersionInput(): number | undefined;
    private _minEncryptionVersion?;
    get minEncryptionVersion(): number;
    set minEncryptionVersion(value: number);
    resetMinEncryptionVersion(): void;
    get minEncryptionVersionInput(): number | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _publicKey?;
    get publicKey(): string;
    set publicKey(value: string);
    resetPublicKey(): void;
    get publicKeyInput(): string | undefined;
    get supportsDecryption(): cdktn.IResolvable;
    get supportsDerivation(): cdktn.IResolvable;
    get supportsEncryption(): cdktn.IResolvable;
    get supportsSigning(): cdktn.IResolvable;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _version?;
    get version(): number;
    set version(value: number);
    resetVersion(): void;
    get versionInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

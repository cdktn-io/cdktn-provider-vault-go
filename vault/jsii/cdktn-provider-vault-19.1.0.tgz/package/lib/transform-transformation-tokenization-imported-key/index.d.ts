/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TransformTransformationTokenizationImportedKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * If set to `true`, the imported key can be rotated within Vault. Once the key is rotated in Vault, it no longer accepts imported key material. Vault only applies this when the key is imported, so changing this field replaces this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transform_transformation_tokenization_imported_key#allow_rotation TransformTransformationTokenizationImportedKey#allow_rotation}
    */
    readonly allowRotation?: boolean | cdktn.IResolvable;
    /**
    * The list of roles allowed to perform this transformation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transform_transformation_tokenization_imported_key#allowed_roles TransformTransformationTokenizationImportedKey#allowed_roles}
    */
    readonly allowedRoles?: string[];
    /**
    * The period in seconds at which the key is rotated automatically. Set to 0 to disable; otherwise it must be at least one hour (3600).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transform_transformation_tokenization_imported_key#auto_rotate_period TransformTransformationTokenizationImportedKey#auto_rotate_period}
    */
    readonly autoRotatePeriod?: number;
    /**
    * A base64-encoded string containing the wrapped ephemeral AES key and the encrypted 256-bit AES key material (write-only). Required with `ciphertext_wo_version`. Required to create the transformation, but may be omitted for a transformation adopted with `terraform import`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transform_transformation_tokenization_imported_key#ciphertext_wo TransformTransformationTokenizationImportedKey#ciphertext_wo}
    */
    readonly ciphertextWo?: string;
    /**
    * Version identifier for `ciphertext_wo`. Increment it to import a new ciphertext as a new key version. Required with `ciphertext_wo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transform_transformation_tokenization_imported_key#ciphertext_wo_version TransformTransformationTokenizationImportedKey#ciphertext_wo_version}
    */
    readonly ciphertextWoVersion?: number;
    /**
    * If true, this transformation can be deleted. Deletion is blocked while this is false, so it must be applied as `true` before the resource can be destroyed. Vault's import endpoint does not accept this parameter, so it is applied in an update immediately after the key is imported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transform_transformation_tokenization_imported_key#deletion_allowed TransformTransformationTokenizationImportedKey#deletion_allowed}
    */
    readonly deletionAllowed?: boolean | cdktn.IResolvable;
    /**
    * The hash function used for the RSA-OAEP step of creating the ciphertext (`SHA1`, `SHA224`, `SHA256`, `SHA384`, `SHA512`). Vault uses `SHA256` if not set. Vault does not return this value, so it is not verified against the transformation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transform_transformation_tokenization_imported_key#hash_function TransformTransformationTokenizationImportedKey#hash_function}
    */
    readonly hashFunction?: string;
    /**
    * The mapping mode for stored tokenization values (`default` or `exportable`). Vault does not allow this field to be changed after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transform_transformation_tokenization_imported_key#mapping_mode TransformTransformationTokenizationImportedKey#mapping_mode}
    */
    readonly mappingMode?: string;
    /**
    * The maximum TTL of a token, in seconds. `0` means tokens have no expiration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transform_transformation_tokenization_imported_key#max_ttl TransformTransformationTokenizationImportedKey#max_ttl}
    */
    readonly maxTtl?: number;
    /**
    * Minimum key version to use for decryption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transform_transformation_tokenization_imported_key#min_decryption_version TransformTransformationTokenizationImportedKey#min_decryption_version}
    */
    readonly minDecryptionVersion?: number;
    /**
    * Path where the Transform secret backend is mounted. Changing this field replaces this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transform_transformation_tokenization_imported_key#mount TransformTransformationTokenizationImportedKey#mount}
    */
    readonly mount: string;
    /**
    * Name of the transformation to create. Changing this field replaces this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transform_transformation_tokenization_imported_key#name TransformTransformationTokenizationImportedKey#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transform_transformation_tokenization_imported_key#namespace TransformTransformationTokenizationImportedKey#namespace}
    */
    readonly namespace?: string;
    /**
    * The stores that contain tokenized state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transform_transformation_tokenization_imported_key#stores TransformTransformationTokenizationImportedKey#stores}
    */
    readonly stores?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transform_transformation_tokenization_imported_key vault_transform_transformation_tokenization_imported_key}
*/
export declare class TransformTransformationTokenizationImportedKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_transform_transformation_tokenization_imported_key";
    /**
    * Generates CDKTN code for importing a TransformTransformationTokenizationImportedKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TransformTransformationTokenizationImportedKey to import
    * @param importFromId The id of the existing TransformTransformationTokenizationImportedKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transform_transformation_tokenization_imported_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TransformTransformationTokenizationImportedKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/resources/transform_transformation_tokenization_imported_key vault_transform_transformation_tokenization_imported_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TransformTransformationTokenizationImportedKeyConfig
    */
    constructor(scope: Construct, id: string, config: TransformTransformationTokenizationImportedKeyConfig);
    private _allowRotation?;
    get allowRotation(): boolean | cdktn.IResolvable;
    set allowRotation(value: boolean | cdktn.IResolvable);
    resetAllowRotation(): void;
    get allowRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _allowedRoles?;
    get allowedRoles(): string[];
    set allowedRoles(value: string[]);
    resetAllowedRoles(): void;
    get allowedRolesInput(): string[] | undefined;
    private _autoRotatePeriod?;
    get autoRotatePeriod(): number;
    set autoRotatePeriod(value: number);
    resetAutoRotatePeriod(): void;
    get autoRotatePeriodInput(): number | undefined;
    private _ciphertextWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get ciphertextWo(): string;
    set ciphertextWo(value: string);
    resetCiphertextWo(): void;
    get ciphertextWoInput(): string | undefined;
    private _ciphertextWoVersion?;
    get ciphertextWoVersion(): number;
    set ciphertextWoVersion(value: number);
    resetCiphertextWoVersion(): void;
    get ciphertextWoVersionInput(): number | undefined;
    private _deletionAllowed?;
    get deletionAllowed(): boolean | cdktn.IResolvable;
    set deletionAllowed(value: boolean | cdktn.IResolvable);
    resetDeletionAllowed(): void;
    get deletionAllowedInput(): boolean | cdktn.IResolvable | undefined;
    private _hashFunction?;
    get hashFunction(): string;
    set hashFunction(value: string);
    resetHashFunction(): void;
    get hashFunctionInput(): string | undefined;
    get latestVersion(): number;
    private _mappingMode?;
    get mappingMode(): string;
    set mappingMode(value: string);
    resetMappingMode(): void;
    get mappingModeInput(): string | undefined;
    private _maxTtl?;
    get maxTtl(): number;
    set maxTtl(value: number);
    resetMaxTtl(): void;
    get maxTtlInput(): number | undefined;
    get minAvailableVersion(): number;
    private _minDecryptionVersion?;
    get minDecryptionVersion(): number;
    set minDecryptionVersion(value: number);
    resetMinDecryptionVersion(): void;
    get minDecryptionVersionInput(): number | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _stores?;
    get stores(): string[];
    set stores(value: string[]);
    resetStores(): void;
    get storesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

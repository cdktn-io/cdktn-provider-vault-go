/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultPkiExternalCaSecretBackendOrderChallengeConfig extends cdktn.TerraformMetaArguments {
    /**
    * The type of ACME challenge to retrieve. Valid values are `http-01`, `dns-01`, `tls-alpn-01`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/data-sources/pki_external_ca_secret_backend_order_challenge#challenge_type DataVaultPkiExternalCaSecretBackendOrderChallenge#challenge_type}
    */
    readonly challengeType: string;
    /**
    * The identifier (domain name) for which to retrieve the challenge.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/data-sources/pki_external_ca_secret_backend_order_challenge#identifier DataVaultPkiExternalCaSecretBackendOrderChallenge#identifier}
    */
    readonly identifier: string;
    /**
    * The path where the PKI External CA secret backend is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/data-sources/pki_external_ca_secret_backend_order_challenge#mount DataVaultPkiExternalCaSecretBackendOrderChallenge#mount}
    */
    readonly mount: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/data-sources/pki_external_ca_secret_backend_order_challenge#namespace DataVaultPkiExternalCaSecretBackendOrderChallenge#namespace}
    */
    readonly namespace?: string;
    /**
    * The unique identifier for the ACME order.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/data-sources/pki_external_ca_secret_backend_order_challenge#order_id DataVaultPkiExternalCaSecretBackendOrderChallenge#order_id}
    */
    readonly orderId: string;
    /**
    * Name of the role associated with the order.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/data-sources/pki_external_ca_secret_backend_order_challenge#role_name DataVaultPkiExternalCaSecretBackendOrderChallenge#role_name}
    */
    readonly roleName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/data-sources/pki_external_ca_secret_backend_order_challenge#timeouts DataVaultPkiExternalCaSecretBackendOrderChallenge#timeouts}
    */
    readonly timeouts?: DataVaultPkiExternalCaSecretBackendOrderChallengeTimeouts;
}
export interface DataVaultPkiExternalCaSecretBackendOrderChallengeTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/data-sources/pki_external_ca_secret_backend_order_challenge#read DataVaultPkiExternalCaSecretBackendOrderChallenge#read}
    */
    readonly read?: string;
}
export declare function dataVaultPkiExternalCaSecretBackendOrderChallengeTimeoutsToTerraform(struct?: DataVaultPkiExternalCaSecretBackendOrderChallengeTimeouts | cdktn.IResolvable): any;
export declare function dataVaultPkiExternalCaSecretBackendOrderChallengeTimeoutsToHclTerraform(struct?: DataVaultPkiExternalCaSecretBackendOrderChallengeTimeouts | cdktn.IResolvable): any;
export declare class DataVaultPkiExternalCaSecretBackendOrderChallengeTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataVaultPkiExternalCaSecretBackendOrderChallengeTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataVaultPkiExternalCaSecretBackendOrderChallengeTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/data-sources/pki_external_ca_secret_backend_order_challenge vault_pki_external_ca_secret_backend_order_challenge}
*/
export declare class DataVaultPkiExternalCaSecretBackendOrderChallenge extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_pki_external_ca_secret_backend_order_challenge";
    /**
    * Generates CDKTN code for importing a DataVaultPkiExternalCaSecretBackendOrderChallenge resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultPkiExternalCaSecretBackendOrderChallenge to import
    * @param importFromId The id of the existing DataVaultPkiExternalCaSecretBackendOrderChallenge that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/data-sources/pki_external_ca_secret_backend_order_challenge#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultPkiExternalCaSecretBackendOrderChallenge to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.14.0/docs/data-sources/pki_external_ca_secret_backend_order_challenge vault_pki_external_ca_secret_backend_order_challenge} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultPkiExternalCaSecretBackendOrderChallengeConfig
    */
    constructor(scope: Construct, id: string, config: DataVaultPkiExternalCaSecretBackendOrderChallengeConfig);
    private _challengeType?;
    get challengeType(): string;
    set challengeType(value: string);
    get challengeTypeInput(): string | undefined;
    get expires(): string;
    get id(): string;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    get keyAuthorization(): string;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _orderId?;
    get orderId(): string;
    set orderId(value: string);
    get orderIdInput(): string | undefined;
    private _roleName?;
    get roleName(): string;
    set roleName(value: string);
    get roleNameInput(): string | undefined;
    get status(): string;
    get token(): string;
    private _timeouts;
    get timeouts(): DataVaultPkiExternalCaSecretBackendOrderChallengeTimeoutsOutputReference;
    putTimeouts(value: DataVaultPkiExternalCaSecretBackendOrderChallengeTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataVaultPkiExternalCaSecretBackendOrderChallengeTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

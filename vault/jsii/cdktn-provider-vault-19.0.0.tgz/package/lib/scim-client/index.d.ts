/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ScimClientConfig extends cdktn.TerraformMetaArguments {
    /**
    * Entity ID authorized to call SCIM protocol endpoints on behalf of this client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/scim_client#access_grant_principal ScimClient#access_grant_principal}
    */
    readonly accessGrantPrincipal: string;
    /**
    * Auth mount accessor used to create entity aliases for SCIM users. Immutable after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/scim_client#alias_mount_accessor ScimClient#alias_mount_accessor}
    */
    readonly aliasMountAccessor?: string;
    /**
    * Whether to allow adoption of existing Vault groups by SCIM-provisioned groups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/scim_client#allow_group_adoption ScimClient#allow_group_adoption}
    */
    readonly allowGroupAdoption?: boolean | cdktn.IResolvable;
    /**
    * Whether to allow adoption of existing Vault entities by SCIM users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/scim_client#allow_user_adoption ScimClient#allow_user_adoption}
    */
    readonly allowUserAdoption?: boolean | cdktn.IResolvable;
    /**
    * Additional mount accessors whose aliases may be managed by this SCIM client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/scim_client#allowed_extra_alias_mount_accessors ScimClient#allowed_extra_alias_mount_accessors}
    */
    readonly allowedExtraAliasMountAccessors?: string[];
    /**
    * The name of the SCIM client. Must be lowercase, because Vault lowercases client names when it stores them. May contain only letters, digits, '_', '-' and '.', and must start and end with a letter, digit or '_'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/scim_client#client_name ScimClient#client_name}
    */
    readonly clientName: string;
    /**
    * The Vault SCIM extension schema version used for this client. Must be "2.0" or "2.2". Leave unset to use Vault's default for new clients ("2.2").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/scim_client#default_schema_version ScimClient#default_schema_version}
    */
    readonly defaultSchemaVersion?: string;
    /**
    * Controls how linked entities/groups/aliases are handled when this resource is destroyed. `orphan_child_resources` detaches managed resources without deleting them; `delete_child_resources` deletes all managed resources along with the client. Leave unset for a plain delete (fails if the client still owns linked resources). Only consulted at destroy time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/scim_client#deletion_policy ScimClient#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/scim_client#id ScimClient#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Maximum number of active tokens for this SCIM client. Must be a positive non-zero value. Leave unset to use Vault's default (2).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/scim_client#max_active_tokens ScimClient#max_active_tokens}
    */
    readonly maxActiveTokens?: number;
    /**
    * Maximum TTL (in seconds) for tokens issued to this SCIM client. Zero means the cluster default is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/scim_client#max_token_ttl ScimClient#max_token_ttl}
    */
    readonly maxTokenTtl?: number;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/scim_client#namespace ScimClient#namespace}
    */
    readonly namespace?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/scim_client#timeouts ScimClient#timeouts}
    */
    readonly timeouts?: ScimClientTimeouts;
}
export interface ScimClientTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/scim_client#delete ScimClient#delete}
    */
    readonly delete?: string;
}
export declare function scimClientTimeoutsToTerraform(struct?: ScimClientTimeouts | cdktn.IResolvable): any;
export declare function scimClientTimeoutsToHclTerraform(struct?: ScimClientTimeouts | cdktn.IResolvable): any;
export declare class ScimClientTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ScimClientTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ScimClientTimeouts | cdktn.IResolvable | undefined);
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/scim_client vault_scim_client}
*/
export declare class ScimClient extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_scim_client";
    /**
    * Generates CDKTN code for importing a ScimClient resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ScimClient to import
    * @param importFromId The id of the existing ScimClient that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/scim_client#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ScimClient to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/scim_client vault_scim_client} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ScimClientConfig
    */
    constructor(scope: Construct, id: string, config: ScimClientConfig);
    private _accessGrantPrincipal?;
    get accessGrantPrincipal(): string;
    set accessGrantPrincipal(value: string);
    get accessGrantPrincipalInput(): string | undefined;
    private _aliasMountAccessor?;
    get aliasMountAccessor(): string;
    set aliasMountAccessor(value: string);
    resetAliasMountAccessor(): void;
    get aliasMountAccessorInput(): string | undefined;
    private _allowGroupAdoption?;
    get allowGroupAdoption(): boolean | cdktn.IResolvable;
    set allowGroupAdoption(value: boolean | cdktn.IResolvable);
    resetAllowGroupAdoption(): void;
    get allowGroupAdoptionInput(): boolean | cdktn.IResolvable | undefined;
    private _allowUserAdoption?;
    get allowUserAdoption(): boolean | cdktn.IResolvable;
    set allowUserAdoption(value: boolean | cdktn.IResolvable);
    resetAllowUserAdoption(): void;
    get allowUserAdoptionInput(): boolean | cdktn.IResolvable | undefined;
    private _allowedExtraAliasMountAccessors?;
    get allowedExtraAliasMountAccessors(): string[];
    set allowedExtraAliasMountAccessors(value: string[]);
    resetAllowedExtraAliasMountAccessors(): void;
    get allowedExtraAliasMountAccessorsInput(): string[] | undefined;
    get clientId(): string;
    private _clientName?;
    get clientName(): string;
    set clientName(value: string);
    get clientNameInput(): string | undefined;
    private _defaultSchemaVersion?;
    get defaultSchemaVersion(): string;
    set defaultSchemaVersion(value: string);
    resetDefaultSchemaVersion(): void;
    get defaultSchemaVersionInput(): string | undefined;
    get deleting(): cdktn.IResolvable;
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxActiveTokens?;
    get maxActiveTokens(): number;
    set maxActiveTokens(value: number);
    resetMaxActiveTokens(): void;
    get maxActiveTokensInput(): number | undefined;
    private _maxTokenTtl?;
    get maxTokenTtl(): number;
    set maxTokenTtl(value: number);
    resetMaxTokenTtl(): void;
    get maxTokenTtlInput(): number | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _timeouts;
    get timeouts(): ScimClientTimeoutsOutputReference;
    putTimeouts(value: ScimClientTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ScimClientTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EphemeralVaultTokenConfig extends cdktn.TerraformEphemeralMetaArguments {
    /**
    * The display name of the token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/token#display_name EphemeralVaultToken#display_name}
    */
    readonly displayName?: string;
    /**
    * Name of the entity alias to associate with during token creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/token#entity_alias EphemeralVaultToken#entity_alias}
    */
    readonly entityAlias?: string;
    /**
    * The explicit max TTL of the token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/token#explicit_max_ttl EphemeralVaultToken#explicit_max_ttl}
    */
    readonly explicitMaxTtl?: string;
    /**
    * The ID of the client token. This is an input field, not a resource identifier. Can only be specified by a root token. The ID provided may not contain a '.' character and should not start with the 's.' prefix.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/token#id EphemeralVaultToken#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Metadata to be associated with the token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/token#metadata EphemeralVaultToken#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
    * Terraform ID of the mount resource. Used to defer the provisioning of the ephemeral resource till the apply stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/token#mount_id EphemeralVaultToken#mount_id}
    */
    readonly mountId?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/token#namespace EphemeralVaultToken#namespace}
    */
    readonly namespace?: string;
    /**
    * Flag to disable the default policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/token#no_default_policy EphemeralVaultToken#no_default_policy}
    */
    readonly noDefaultPolicy?: boolean | cdktn.IResolvable;
    /**
    * Flag to create a token without parent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/token#no_parent EphemeralVaultToken#no_parent}
    */
    readonly noParent?: boolean | cdktn.IResolvable;
    /**
    * The number of allowed uses of the token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/token#num_uses EphemeralVaultToken#num_uses}
    */
    readonly numUses?: number;
    /**
    * The period of the token for periodic tokens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/token#period EphemeralVaultToken#period}
    */
    readonly period?: string;
    /**
    * List of policies to attach to the token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/token#policies EphemeralVaultToken#policies}
    */
    readonly policies?: string[];
    /**
    * Flag to allow the token to be renewed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/token#renewable EphemeralVaultToken#renewable}
    */
    readonly renewable?: boolean | cdktn.IResolvable;
    /**
    * The token role name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/token#role_name EphemeralVaultToken#role_name}
    */
    readonly roleName?: string;
    /**
    * The TTL period of the token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/token#ttl EphemeralVaultToken#ttl}
    */
    readonly ttl?: string;
    /**
    * The token type. Can be 'batch' or 'service'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/token#type EphemeralVaultToken#type}
    */
    readonly type?: string;
    /**
    * The TTL period of the wrapped token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/token#wrapping_ttl EphemeralVaultToken#wrapping_ttl}
    */
    readonly wrappingTtl?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/token vault_token}
*/
export declare class EphemeralVaultToken extends cdktn.TerraformEphemeralResource {
    static readonly tfResourceType = "vault_token";
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/token vault_token} Ephemeral Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EphemeralVaultTokenConfig = {}
    */
    constructor(scope: Construct, id: string, config?: EphemeralVaultTokenConfig);
    get accessor(): string;
    get clientToken(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _entityAlias?;
    get entityAlias(): string;
    set entityAlias(value: string);
    resetEntityAlias(): void;
    get entityAliasInput(): string | undefined;
    get entityId(): string;
    private _explicitMaxTtl?;
    get explicitMaxTtl(): string;
    set explicitMaxTtl(value: string);
    resetExplicitMaxTtl(): void;
    get explicitMaxTtlInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get leaseDuration(): number;
    get leaseId(): string;
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
    private _mountId?;
    get mountId(): string;
    set mountId(value: string);
    resetMountId(): void;
    get mountIdInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _noDefaultPolicy?;
    get noDefaultPolicy(): boolean | cdktn.IResolvable;
    set noDefaultPolicy(value: boolean | cdktn.IResolvable);
    resetNoDefaultPolicy(): void;
    get noDefaultPolicyInput(): boolean | cdktn.IResolvable | undefined;
    private _noParent?;
    get noParent(): boolean | cdktn.IResolvable;
    set noParent(value: boolean | cdktn.IResolvable);
    resetNoParent(): void;
    get noParentInput(): boolean | cdktn.IResolvable | undefined;
    private _numUses?;
    get numUses(): number;
    set numUses(value: number);
    resetNumUses(): void;
    get numUsesInput(): number | undefined;
    get orphan(): cdktn.IResolvable;
    private _period?;
    get period(): string;
    set period(value: string);
    resetPeriod(): void;
    get periodInput(): string | undefined;
    private _policies?;
    get policies(): string[];
    set policies(value: string[]);
    resetPolicies(): void;
    get policiesInput(): string[] | undefined;
    private _renewable?;
    get renewable(): boolean | cdktn.IResolvable;
    set renewable(value: boolean | cdktn.IResolvable);
    resetRenewable(): void;
    get renewableInput(): boolean | cdktn.IResolvable | undefined;
    private _roleName?;
    get roleName(): string;
    set roleName(value: string);
    resetRoleName(): void;
    get roleNameInput(): string | undefined;
    get tokenPolicies(): string[];
    private _ttl?;
    get ttl(): string;
    set ttl(value: string);
    resetTtl(): void;
    get ttlInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get wrappedToken(): string;
    get wrappingAccessor(): string;
    private _wrappingTtl?;
    get wrappingTtl(): string;
    set wrappingTtl(value: string);
    resetWrappingTtl(): void;
    get wrappingTtlInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EphemeralVaultKerberosAuthBackendLoginConfig extends cdktn.TerraformEphemeralMetaArguments {
    /**
    * Disable FAST negotiation. Default: false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kerberos_auth_backend_login#disable_fast_negotiation EphemeralVaultKerberosAuthBackendLogin#disable_fast_negotiation}
    */
    readonly disableFastNegotiation?: boolean | cdktn.IResolvable;
    /**
    * Path to the keytab file for authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kerberos_auth_backend_login#keytab_path EphemeralVaultKerberosAuthBackendLogin#keytab_path}
    */
    readonly keytabPath: string;
    /**
    * Path to the krb5.conf configuration file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kerberos_auth_backend_login#krb5conf_path EphemeralVaultKerberosAuthBackendLogin#krb5conf_path}
    */
    readonly krb5ConfPath: string;
    /**
    * Path where the Kerberos auth method is mounted. Defaults to 'kerberos'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kerberos_auth_backend_login#mount EphemeralVaultKerberosAuthBackendLogin#mount}
    */
    readonly mount: string;
    /**
    * Terraform ID of the mount resource. Used to defer the provisioning of the ephemeral resource till the apply stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kerberos_auth_backend_login#mount_id EphemeralVaultKerberosAuthBackendLogin#mount_id}
    */
    readonly mountId?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kerberos_auth_backend_login#namespace EphemeralVaultKerberosAuthBackendLogin#namespace}
    */
    readonly namespace?: string;
    /**
    * Kerberos realm name. Must match the UPNDomain in LDAP config.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kerberos_auth_backend_login#realm EphemeralVaultKerberosAuthBackendLogin#realm}
    */
    readonly realm: string;
    /**
    * Remove instance name from principal. Default: false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kerberos_auth_backend_login#remove_instance_name EphemeralVaultKerberosAuthBackendLogin#remove_instance_name}
    */
    readonly removeInstanceName?: boolean | cdktn.IResolvable;
    /**
    * Service principal name for obtaining a service ticket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kerberos_auth_backend_login#service EphemeralVaultKerberosAuthBackendLogin#service}
    */
    readonly service: string;
    /**
    * Username for the keytab entry. Must match a service account in LDAP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kerberos_auth_backend_login#username EphemeralVaultKerberosAuthBackendLogin#username}
    */
    readonly username: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kerberos_auth_backend_login vault_kerberos_auth_backend_login}
*/
export declare class EphemeralVaultKerberosAuthBackendLogin extends cdktn.TerraformEphemeralResource {
    static readonly tfResourceType = "vault_kerberos_auth_backend_login";
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kerberos_auth_backend_login vault_kerberos_auth_backend_login} Ephemeral Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EphemeralVaultKerberosAuthBackendLoginConfig
    */
    constructor(scope: Construct, id: string, config: EphemeralVaultKerberosAuthBackendLoginConfig);
    get accessor(): string;
    get clientToken(): string;
    private _disableFastNegotiation?;
    get disableFastNegotiation(): boolean | cdktn.IResolvable;
    set disableFastNegotiation(value: boolean | cdktn.IResolvable);
    resetDisableFastNegotiation(): void;
    get disableFastNegotiationInput(): boolean | cdktn.IResolvable | undefined;
    get entityId(): string;
    get identityPolicies(): string[];
    private _keytabPath?;
    get keytabPath(): string;
    set keytabPath(value: string);
    get keytabPathInput(): string | undefined;
    private _krb5ConfPath?;
    get krb5ConfPath(): string;
    set krb5ConfPath(value: string);
    get krb5ConfPathInput(): string | undefined;
    get leaseDuration(): number;
    private _metadata;
    get metadata(): cdktn.StringMap;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _mountId?;
    get mountId(): string;
    set mountId(value: string);
    resetMountId(): void;
    get mountIdInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get orphan(): cdktn.IResolvable;
    get policies(): string[];
    private _realm?;
    get realm(): string;
    set realm(value: string);
    get realmInput(): string | undefined;
    private _removeInstanceName?;
    get removeInstanceName(): boolean | cdktn.IResolvable;
    set removeInstanceName(value: boolean | cdktn.IResolvable);
    resetRemoveInstanceName(): void;
    get removeInstanceNameInput(): boolean | cdktn.IResolvable | undefined;
    get renewable(): cdktn.IResolvable;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    get tokenPolicies(): string[];
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

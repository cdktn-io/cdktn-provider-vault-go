/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TpmAuthBackendConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * How long each CA is valid once it becomes active, in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/tpm_auth_backend_config#ca_lifetime TpmAuthBackendConfig#ca_lifetime}
    */
    readonly caLifetime?: number;
    /**
    * How long before hard expiry the active CA stops signing new certificates, in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/tpm_auth_backend_config#ca_soft_expiry TpmAuthBackendConfig#ca_soft_expiry}
    */
    readonly caSoftExpiry?: number;
    /**
    * Default lifetime for issued client certificates when the role does not specify `cert_ttl`, in seconds. When unset or `0`, the effective TTL falls back to CA soft expiry. Vault always caps the actual certificate lifetime by the remaining validity of the signing CA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/tpm_auth_backend_config#default_cert_ttl TpmAuthBackendConfig#default_cert_ttl}
    */
    readonly defaultCertTtl?: number;
    /**
    * Path of the enabled TPM auth backend mount to configure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/tpm_auth_backend_config#mount TpmAuthBackendConfig#mount}
    */
    readonly mount: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/tpm_auth_backend_config#namespace TpmAuthBackendConfig#namespace}
    */
    readonly namespace?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/tpm_auth_backend_config vault_tpm_auth_backend_config}
*/
export declare class TpmAuthBackendConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_tpm_auth_backend_config";
    /**
    * Generates CDKTN code for importing a TpmAuthBackendConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TpmAuthBackendConfig to import
    * @param importFromId The id of the existing TpmAuthBackendConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/tpm_auth_backend_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TpmAuthBackendConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/tpm_auth_backend_config vault_tpm_auth_backend_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TpmAuthBackendConfigConfig
    */
    constructor(scope: Construct, id: string, config: TpmAuthBackendConfigConfig);
    private _caLifetime?;
    get caLifetime(): number;
    set caLifetime(value: number);
    resetCaLifetime(): void;
    get caLifetimeInput(): number | undefined;
    private _caSoftExpiry?;
    get caSoftExpiry(): number;
    set caSoftExpiry(value: number);
    resetCaSoftExpiry(): void;
    get caSoftExpiryInput(): number | undefined;
    private _defaultCertTtl?;
    get defaultCertTtl(): number;
    set defaultCertTtl(value: number);
    resetDefaultCertTtl(): void;
    get defaultCertTtlInput(): number | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface KerberosAuthBackendLdapConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * A map of string to string that will be set as metadata on the identity alias
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#alias_metadata KerberosAuthBackendLdapConfig#alias_metadata}
    */
    readonly aliasMetadata?: {
        [key: string]: string;
    };
    /**
    * Use anonymous binds when performing LDAP group searches. Default: false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#anonymous_group_search KerberosAuthBackendLdapConfig#anonymous_group_search}
    */
    readonly anonymousGroupSearch?: boolean | cdktn.IResolvable;
    /**
    * Distinguished name of object to bind for search (e.g., 'cn=vault,ou=Users,dc=example,dc=com').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#binddn KerberosAuthBackendLdapConfig#binddn}
    */
    readonly binddn?: string;
    /**
    * LDAP password for searching for the user DN (write-only). Must be used together with bindpass_wo_version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#bindpass_wo KerberosAuthBackendLdapConfig#bindpass_wo}
    */
    readonly bindpassWo?: string;
    /**
    * Version identifier for bindpass updates. Change to trigger password update. Must be used together with bindpass_wo.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#bindpass_wo_version KerberosAuthBackendLdapConfig#bindpass_wo_version}
    */
    readonly bindpassWoVersion?: number;
    /**
    * If true, usernames and group names are case sensitive. Default: false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#case_sensitive_names KerberosAuthBackendLdapConfig#case_sensitive_names}
    */
    readonly caseSensitiveNames?: boolean | cdktn.IResolvable;
    /**
    * CA certificate to use when verifying LDAP server certificate, must be x509 PEM encoded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#certificate KerberosAuthBackendLdapConfig#certificate}
    */
    readonly certificate?: string;
    /**
    * Client certificate to provide to the LDAP server, must be x509 PEM encoded (write-only). Must be used together with client_tls_cert_wo_version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#client_tls_cert_wo KerberosAuthBackendLdapConfig#client_tls_cert_wo}
    */
    readonly clientTlsCertWo?: string;
    /**
    * Version identifier for client TLS certificate updates. Change to trigger certificate update. Must be used together with client_tls_cert_wo.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#client_tls_cert_wo_version KerberosAuthBackendLdapConfig#client_tls_cert_wo_version}
    */
    readonly clientTlsCertWoVersion?: number;
    /**
    * Client certificate key to provide to the LDAP server, must be x509 PEM encoded (write-only). Must be used together with client_tls_key_wo_version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#client_tls_key_wo KerberosAuthBackendLdapConfig#client_tls_key_wo}
    */
    readonly clientTlsKeyWo?: string;
    /**
    * Version identifier for client TLS key updates. Must be used together with client_tls_key_wo.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#client_tls_key_wo_version KerberosAuthBackendLdapConfig#client_tls_key_wo_version}
    */
    readonly clientTlsKeyWoVersion?: number;
    /**
    * Timeout, in seconds, when attempting to connect to the LDAP server. Default: 30.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#connection_timeout KerberosAuthBackendLdapConfig#connection_timeout}
    */
    readonly connectionTimeout?: number;
    /**
    * Denies an unauthenticated LDAP bind request if the user's password is empty. Default: true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#deny_null_bind KerberosAuthBackendLdapConfig#deny_null_bind}
    */
    readonly denyNullBind?: boolean | cdktn.IResolvable;
    /**
    * When aliases should be dereferenced on search operations. Accepted values are 'never', 'finding', 'searching', 'always'. Default: 'never'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#dereference_aliases KerberosAuthBackendLdapConfig#dereference_aliases}
    */
    readonly dereferenceAliases?: string;
    /**
    * Use anonymous bind to discover bind DN of a user. Default: false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#discoverdn KerberosAuthBackendLdapConfig#discoverdn}
    */
    readonly discoverdn?: boolean | cdktn.IResolvable;
    /**
    * If true, matching sAMAccountName attribute values will be allowed to login when upndomain is defined. Default: false. **Note:** Requires Vault 1.19.0+
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#enable_samaccountname_login KerberosAuthBackendLdapConfig#enable_samaccountname_login}
    */
    readonly enableSamaccountnameLogin?: boolean | cdktn.IResolvable;
    /**
    * LDAP attribute to follow for group membership. Default: 'cn'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#groupattr KerberosAuthBackendLdapConfig#groupattr}
    */
    readonly groupattr?: string;
    /**
    * LDAP search base to use for group membership search (e.g., ou=Groups,dc=example,dc=org).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#groupdn KerberosAuthBackendLdapConfig#groupdn}
    */
    readonly groupdn?: string;
    /**
    * Go template for querying group membership of user. Default: '(|(memberUid={{.Username}})(member={{.UserDN}})(uniqueMember={{.UserDN}}))'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#groupfilter KerberosAuthBackendLdapConfig#groupfilter}
    */
    readonly groupfilter?: string;
    /**
    * Skip TLS certificate verification. Not recommended for production. Default: false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#insecure_tls KerberosAuthBackendLdapConfig#insecure_tls}
    */
    readonly insecureTls?: boolean | cdktn.IResolvable;
    /**
    * If set to a value greater than 0, the LDAP backend will use the LDAP server's paged search control. Default: 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#max_page_size KerberosAuthBackendLdapConfig#max_page_size}
    */
    readonly maxPageSize?: number;
    /**
    * Path where the Kerberos auth method is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#mount KerberosAuthBackendLdapConfig#mount}
    */
    readonly mount: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#namespace KerberosAuthBackendLdapConfig#namespace}
    */
    readonly namespace?: string;
    /**
    * Timeout, in seconds, for the connection when making requests against the server. Default: 90.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#request_timeout KerberosAuthBackendLdapConfig#request_timeout}
    */
    readonly requestTimeout?: number;
    /**
    * Issue a StartTLS command after establishing an unencrypted connection. Default: false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#starttls KerberosAuthBackendLdapConfig#starttls}
    */
    readonly starttls?: boolean | cdktn.IResolvable;
    /**
    * Maximum TLS version to use. Accepted values are 'tls10', 'tls11', 'tls12' or 'tls13'. Default: 'tls12'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#tls_max_version KerberosAuthBackendLdapConfig#tls_max_version}
    */
    readonly tlsMaxVersion?: string;
    /**
    * Minimum TLS version to use. Accepted values are 'tls10', 'tls11', 'tls12' or 'tls13'. Default: 'tls12'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#tls_min_version KerberosAuthBackendLdapConfig#tls_min_version}
    */
    readonly tlsMinVersion?: string;
    /**
    * Specifies the blocks of IP addresses which are allowed to use the generated token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#token_bound_cidrs KerberosAuthBackendLdapConfig#token_bound_cidrs}
    */
    readonly tokenBoundCidrs?: string[];
    /**
    * Generated Token's Explicit Maximum TTL in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#token_explicit_max_ttl KerberosAuthBackendLdapConfig#token_explicit_max_ttl}
    */
    readonly tokenExplicitMaxTtl?: number;
    /**
    * The maximum lifetime of the generated token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#token_max_ttl KerberosAuthBackendLdapConfig#token_max_ttl}
    */
    readonly tokenMaxTtl?: number;
    /**
    * If true, the 'default' policy will not automatically be added to generated tokens
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#token_no_default_policy KerberosAuthBackendLdapConfig#token_no_default_policy}
    */
    readonly tokenNoDefaultPolicy?: boolean | cdktn.IResolvable;
    /**
    * The maximum number of times a token may be used, a value of zero means unlimited
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#token_num_uses KerberosAuthBackendLdapConfig#token_num_uses}
    */
    readonly tokenNumUses?: number;
    /**
    * Generated Token's Period
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#token_period KerberosAuthBackendLdapConfig#token_period}
    */
    readonly tokenPeriod?: number;
    /**
    * Generated Token's Policies
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#token_policies KerberosAuthBackendLdapConfig#token_policies}
    */
    readonly tokenPolicies?: string[];
    /**
    * The initial ttl of the token to generate in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#token_ttl KerberosAuthBackendLdapConfig#token_ttl}
    */
    readonly tokenTtl?: number;
    /**
    * The type of token to generate, service or batch
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#token_type KerberosAuthBackendLdapConfig#token_type}
    */
    readonly tokenType?: string;
    /**
    * Enables userPrincipalDomain login with [username]@UPNDomain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#upndomain KerberosAuthBackendLdapConfig#upndomain}
    */
    readonly upndomain?: string;
    /**
    * LDAP URL to connect. Multiple URLs can be specified by concatenating them with commas. Default: ldap://127.0.0.1
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#url KerberosAuthBackendLdapConfig#url}
    */
    readonly url?: string;
    /**
    * If true, use the Active Directory tokenGroups constructed attribute. Default: false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#use_token_groups KerberosAuthBackendLdapConfig#use_token_groups}
    */
    readonly useTokenGroups?: boolean | cdktn.IResolvable;
    /**
    * Attribute used as username. Common values: 'samaccountname', 'uid'. Default: 'cn'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#userattr KerberosAuthBackendLdapConfig#userattr}
    */
    readonly userattr?: string;
    /**
    * LDAP domain to use for users (e.g., ou=People,dc=example,dc=org).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#userdn KerberosAuthBackendLdapConfig#userdn}
    */
    readonly userdn?: string;
    /**
    * Go template for LDAP user search filter. Default: '({{.UserAttr}}={{.Username}})'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#userfilter KerberosAuthBackendLdapConfig#userfilter}
    */
    readonly userfilter?: string;
    /**
    * Use username as alias name. Default: false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#username_as_alias KerberosAuthBackendLdapConfig#username_as_alias}
    */
    readonly usernameAsAlias?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config vault_kerberos_auth_backend_ldap_config}
*/
export declare class KerberosAuthBackendLdapConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_kerberos_auth_backend_ldap_config";
    /**
    * Generates CDKTN code for importing a KerberosAuthBackendLdapConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KerberosAuthBackendLdapConfig to import
    * @param importFromId The id of the existing KerberosAuthBackendLdapConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KerberosAuthBackendLdapConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_ldap_config vault_kerberos_auth_backend_ldap_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KerberosAuthBackendLdapConfigConfig
    */
    constructor(scope: Construct, id: string, config: KerberosAuthBackendLdapConfigConfig);
    private _aliasMetadata?;
    get aliasMetadata(): {
        [key: string]: string;
    };
    set aliasMetadata(value: {
        [key: string]: string;
    });
    resetAliasMetadata(): void;
    get aliasMetadataInput(): {
        [key: string]: string;
    } | undefined;
    private _anonymousGroupSearch?;
    get anonymousGroupSearch(): boolean | cdktn.IResolvable;
    set anonymousGroupSearch(value: boolean | cdktn.IResolvable);
    resetAnonymousGroupSearch(): void;
    get anonymousGroupSearchInput(): boolean | cdktn.IResolvable | undefined;
    private _binddn?;
    get binddn(): string;
    set binddn(value: string);
    resetBinddn(): void;
    get binddnInput(): string | undefined;
    private _bindpassWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get bindpassWo(): string;
    set bindpassWo(value: string);
    resetBindpassWo(): void;
    get bindpassWoInput(): string | undefined;
    private _bindpassWoVersion?;
    get bindpassWoVersion(): number;
    set bindpassWoVersion(value: number);
    resetBindpassWoVersion(): void;
    get bindpassWoVersionInput(): number | undefined;
    private _caseSensitiveNames?;
    get caseSensitiveNames(): boolean | cdktn.IResolvable;
    set caseSensitiveNames(value: boolean | cdktn.IResolvable);
    resetCaseSensitiveNames(): void;
    get caseSensitiveNamesInput(): boolean | cdktn.IResolvable | undefined;
    private _certificate?;
    get certificate(): string;
    set certificate(value: string);
    resetCertificate(): void;
    get certificateInput(): string | undefined;
    private _clientTlsCertWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get clientTlsCertWo(): string;
    set clientTlsCertWo(value: string);
    resetClientTlsCertWo(): void;
    get clientTlsCertWoInput(): string | undefined;
    private _clientTlsCertWoVersion?;
    get clientTlsCertWoVersion(): number;
    set clientTlsCertWoVersion(value: number);
    resetClientTlsCertWoVersion(): void;
    get clientTlsCertWoVersionInput(): number | undefined;
    private _clientTlsKeyWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get clientTlsKeyWo(): string;
    set clientTlsKeyWo(value: string);
    resetClientTlsKeyWo(): void;
    get clientTlsKeyWoInput(): string | undefined;
    private _clientTlsKeyWoVersion?;
    get clientTlsKeyWoVersion(): number;
    set clientTlsKeyWoVersion(value: number);
    resetClientTlsKeyWoVersion(): void;
    get clientTlsKeyWoVersionInput(): number | undefined;
    private _connectionTimeout?;
    get connectionTimeout(): number;
    set connectionTimeout(value: number);
    resetConnectionTimeout(): void;
    get connectionTimeoutInput(): number | undefined;
    private _denyNullBind?;
    get denyNullBind(): boolean | cdktn.IResolvable;
    set denyNullBind(value: boolean | cdktn.IResolvable);
    resetDenyNullBind(): void;
    get denyNullBindInput(): boolean | cdktn.IResolvable | undefined;
    private _dereferenceAliases?;
    get dereferenceAliases(): string;
    set dereferenceAliases(value: string);
    resetDereferenceAliases(): void;
    get dereferenceAliasesInput(): string | undefined;
    private _discoverdn?;
    get discoverdn(): boolean | cdktn.IResolvable;
    set discoverdn(value: boolean | cdktn.IResolvable);
    resetDiscoverdn(): void;
    get discoverdnInput(): boolean | cdktn.IResolvable | undefined;
    private _enableSamaccountnameLogin?;
    get enableSamaccountnameLogin(): boolean | cdktn.IResolvable;
    set enableSamaccountnameLogin(value: boolean | cdktn.IResolvable);
    resetEnableSamaccountnameLogin(): void;
    get enableSamaccountnameLoginInput(): boolean | cdktn.IResolvable | undefined;
    private _groupattr?;
    get groupattr(): string;
    set groupattr(value: string);
    resetGroupattr(): void;
    get groupattrInput(): string | undefined;
    private _groupdn?;
    get groupdn(): string;
    set groupdn(value: string);
    resetGroupdn(): void;
    get groupdnInput(): string | undefined;
    private _groupfilter?;
    get groupfilter(): string;
    set groupfilter(value: string);
    resetGroupfilter(): void;
    get groupfilterInput(): string | undefined;
    private _insecureTls?;
    get insecureTls(): boolean | cdktn.IResolvable;
    set insecureTls(value: boolean | cdktn.IResolvable);
    resetInsecureTls(): void;
    get insecureTlsInput(): boolean | cdktn.IResolvable | undefined;
    private _maxPageSize?;
    get maxPageSize(): number;
    set maxPageSize(value: number);
    resetMaxPageSize(): void;
    get maxPageSizeInput(): number | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _requestTimeout?;
    get requestTimeout(): number;
    set requestTimeout(value: number);
    resetRequestTimeout(): void;
    get requestTimeoutInput(): number | undefined;
    private _starttls?;
    get starttls(): boolean | cdktn.IResolvable;
    set starttls(value: boolean | cdktn.IResolvable);
    resetStarttls(): void;
    get starttlsInput(): boolean | cdktn.IResolvable | undefined;
    private _tlsMaxVersion?;
    get tlsMaxVersion(): string;
    set tlsMaxVersion(value: string);
    resetTlsMaxVersion(): void;
    get tlsMaxVersionInput(): string | undefined;
    private _tlsMinVersion?;
    get tlsMinVersion(): string;
    set tlsMinVersion(value: string);
    resetTlsMinVersion(): void;
    get tlsMinVersionInput(): string | undefined;
    private _tokenBoundCidrs?;
    get tokenBoundCidrs(): string[];
    set tokenBoundCidrs(value: string[]);
    resetTokenBoundCidrs(): void;
    get tokenBoundCidrsInput(): string[] | undefined;
    private _tokenExplicitMaxTtl?;
    get tokenExplicitMaxTtl(): number;
    set tokenExplicitMaxTtl(value: number);
    resetTokenExplicitMaxTtl(): void;
    get tokenExplicitMaxTtlInput(): number | undefined;
    private _tokenMaxTtl?;
    get tokenMaxTtl(): number;
    set tokenMaxTtl(value: number);
    resetTokenMaxTtl(): void;
    get tokenMaxTtlInput(): number | undefined;
    private _tokenNoDefaultPolicy?;
    get tokenNoDefaultPolicy(): boolean | cdktn.IResolvable;
    set tokenNoDefaultPolicy(value: boolean | cdktn.IResolvable);
    resetTokenNoDefaultPolicy(): void;
    get tokenNoDefaultPolicyInput(): boolean | cdktn.IResolvable | undefined;
    private _tokenNumUses?;
    get tokenNumUses(): number;
    set tokenNumUses(value: number);
    resetTokenNumUses(): void;
    get tokenNumUsesInput(): number | undefined;
    private _tokenPeriod?;
    get tokenPeriod(): number;
    set tokenPeriod(value: number);
    resetTokenPeriod(): void;
    get tokenPeriodInput(): number | undefined;
    private _tokenPolicies?;
    get tokenPolicies(): string[];
    set tokenPolicies(value: string[]);
    resetTokenPolicies(): void;
    get tokenPoliciesInput(): string[] | undefined;
    private _tokenTtl?;
    get tokenTtl(): number;
    set tokenTtl(value: number);
    resetTokenTtl(): void;
    get tokenTtlInput(): number | undefined;
    private _tokenType?;
    get tokenType(): string;
    set tokenType(value: string);
    resetTokenType(): void;
    get tokenTypeInput(): string | undefined;
    private _upndomain?;
    get upndomain(): string;
    set upndomain(value: string);
    resetUpndomain(): void;
    get upndomainInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _useTokenGroups?;
    get useTokenGroups(): boolean | cdktn.IResolvable;
    set useTokenGroups(value: boolean | cdktn.IResolvable);
    resetUseTokenGroups(): void;
    get useTokenGroupsInput(): boolean | cdktn.IResolvable | undefined;
    private _userattr?;
    get userattr(): string;
    set userattr(value: string);
    resetUserattr(): void;
    get userattrInput(): string | undefined;
    private _userdn?;
    get userdn(): string;
    set userdn(value: string);
    resetUserdn(): void;
    get userdnInput(): string | undefined;
    private _userfilter?;
    get userfilter(): string;
    set userfilter(value: string);
    resetUserfilter(): void;
    get userfilterInput(): string | undefined;
    private _usernameAsAlias?;
    get usernameAsAlias(): boolean | cdktn.IResolvable;
    set usernameAsAlias(value: boolean | cdktn.IResolvable);
    resetUsernameAsAlias(): void;
    get usernameAsAliasInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

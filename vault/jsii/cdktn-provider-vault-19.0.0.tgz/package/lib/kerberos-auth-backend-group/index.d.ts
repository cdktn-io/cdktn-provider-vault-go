/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface KerberosAuthBackendGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Path where the Kerberos auth method is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_group#mount KerberosAuthBackendGroup#mount}
    */
    readonly mount: string;
    /**
    * The name of the LDAP group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_group#name KerberosAuthBackendGroup#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_group#namespace KerberosAuthBackendGroup#namespace}
    */
    readonly namespace?: string;
    /**
    * Set of Vault policies to associate with this group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_group#policies KerberosAuthBackendGroup#policies}
    */
    readonly policies?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_group vault_kerberos_auth_backend_group}
*/
export declare class KerberosAuthBackendGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_kerberos_auth_backend_group";
    /**
    * Generates CDKTN code for importing a KerberosAuthBackendGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KerberosAuthBackendGroup to import
    * @param importFromId The id of the existing KerberosAuthBackendGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KerberosAuthBackendGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/resources/kerberos_auth_backend_group vault_kerberos_auth_backend_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KerberosAuthBackendGroupConfig
    */
    constructor(scope: Construct, id: string, config: KerberosAuthBackendGroupConfig);
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _policies?;
    get policies(): string[];
    set policies(value: string[]);
    resetPolicies(): void;
    get policiesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EphemeralVaultKubernetesServiceAccountTokenConfig extends cdktn.TerraformEphemeralMetaArguments {
    /**
    * The Kubernetes secret backend to generate service account tokens from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kubernetes_service_account_token#backend EphemeralVaultKubernetesServiceAccountToken#backend}
    */
    readonly backend: string;
    /**
    * If true, generate a ClusterRoleBinding to grant permissions across the whole cluster instead of within a namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kubernetes_service_account_token#cluster_role_binding EphemeralVaultKubernetesServiceAccountToken#cluster_role_binding}
    */
    readonly clusterRoleBinding?: boolean | cdktn.IResolvable;
    /**
    * The name of the Kubernetes namespace in which to generate the credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kubernetes_service_account_token#kubernetes_namespace EphemeralVaultKubernetesServiceAccountToken#kubernetes_namespace}
    */
    readonly kubernetesNamespace: string;
    /**
    * Terraform ID of the mount resource. Used to defer the provisioning of the ephemeral resource till the apply stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kubernetes_service_account_token#mount_id EphemeralVaultKubernetesServiceAccountToken#mount_id}
    */
    readonly mountId?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kubernetes_service_account_token#namespace EphemeralVaultKubernetesServiceAccountToken#namespace}
    */
    readonly namespace?: string;
    /**
    * The name of the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kubernetes_service_account_token#role EphemeralVaultKubernetesServiceAccountToken#role}
    */
    readonly role: string;
    /**
    * The TTL of the generated Kubernetes service account token, specified in seconds or as a Go duration format string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kubernetes_service_account_token#ttl EphemeralVaultKubernetesServiceAccountToken#ttl}
    */
    readonly ttl?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kubernetes_service_account_token vault_kubernetes_service_account_token}
*/
export declare class EphemeralVaultKubernetesServiceAccountToken extends cdktn.TerraformEphemeralResource {
    static readonly tfResourceType = "vault_kubernetes_service_account_token";
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/kubernetes_service_account_token vault_kubernetes_service_account_token} Ephemeral Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EphemeralVaultKubernetesServiceAccountTokenConfig
    */
    constructor(scope: Construct, id: string, config: EphemeralVaultKubernetesServiceAccountTokenConfig);
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    private _clusterRoleBinding?;
    get clusterRoleBinding(): boolean | cdktn.IResolvable;
    set clusterRoleBinding(value: boolean | cdktn.IResolvable);
    resetClusterRoleBinding(): void;
    get clusterRoleBindingInput(): boolean | cdktn.IResolvable | undefined;
    private _kubernetesNamespace?;
    get kubernetesNamespace(): string;
    set kubernetesNamespace(value: string);
    get kubernetesNamespaceInput(): string | undefined;
    get leaseDuration(): number;
    get leaseId(): string;
    get leaseRenewable(): cdktn.IResolvable;
    private _mountId?;
    get mountId(): string;
    set mountId(value: string);
    resetMountId(): void;
    get mountIdInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    get serviceAccountName(): string;
    get serviceAccountNamespace(): string;
    get serviceAccountToken(): string;
    private _ttl?;
    get ttl(): string;
    set ttl(value: string);
    resetTtl(): void;
    get ttlInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EphemeralVaultAzureAccessCredentialsConfig extends cdktn.TerraformEphemeralMetaArguments {
    /**
    * Azure Secret Backend to read credentials from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/azure_access_credentials#backend EphemeralVaultAzureAccessCredentials#backend}
    */
    readonly backend: string;
    /**
    * The Azure environment to use during credential validation. Defaults to the Azure Public Cloud. Some possible values: AzurePublicCloud, AzureUSGovernmentCloud.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/azure_access_credentials#environment EphemeralVaultAzureAccessCredentials#environment}
    */
    readonly environment?: string;
    /**
    * If 'validate_creds' is true, the number of seconds after which to give up validating credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/azure_access_credentials#max_cred_validation_seconds EphemeralVaultAzureAccessCredentials#max_cred_validation_seconds}
    */
    readonly maxCredValidationSeconds?: number;
    /**
    * Terraform ID of the mount resource. Used to defer the provisioning of the ephemeral resource till the apply stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/azure_access_credentials#mount_id EphemeralVaultAzureAccessCredentials#mount_id}
    */
    readonly mountId?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/azure_access_credentials#namespace EphemeralVaultAzureAccessCredentials#namespace}
    */
    readonly namespace?: string;
    /**
    * If 'validate_creds' is true, the number of seconds to wait between each test of generated credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/azure_access_credentials#num_seconds_between_tests EphemeralVaultAzureAccessCredentials#num_seconds_between_tests}
    */
    readonly numSecondsBetweenTests?: number;
    /**
    * If 'validate_creds' is true, the number of sequential successes required to validate generated credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/azure_access_credentials#num_sequential_successes EphemeralVaultAzureAccessCredentials#num_sequential_successes}
    */
    readonly numSequentialSuccesses?: number;
    /**
    * Input metadata to send with the request to Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/azure_access_credentials#request_metadata EphemeralVaultAzureAccessCredentials#request_metadata}
    */
    readonly requestMetadata?: {
        [key: string]: string;
    };
    /**
    * Azure Secret Role to read credentials from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/azure_access_credentials#role EphemeralVaultAzureAccessCredentials#role}
    */
    readonly role: string;
    /**
    * The subscription ID to use during credential validation. Defaults to the subscription ID configured in the Vault backend.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/azure_access_credentials#subscription_id EphemeralVaultAzureAccessCredentials#subscription_id}
    */
    readonly subscriptionId?: string;
    /**
    * The tenant ID to use during credential validation. Defaults to the tenant ID configured in the Vault backend.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/azure_access_credentials#tenant_id EphemeralVaultAzureAccessCredentials#tenant_id}
    */
    readonly tenantId?: string;
    /**
    * Whether generated credentials should be validated before being returned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/azure_access_credentials#validate_creds EphemeralVaultAzureAccessCredentials#validate_creds}
    */
    readonly validateCreds?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/azure_access_credentials vault_azure_access_credentials}
*/
export declare class EphemeralVaultAzureAccessCredentials extends cdktn.TerraformEphemeralResource {
    static readonly tfResourceType = "vault_azure_access_credentials";
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/ephemeral-resources/azure_access_credentials vault_azure_access_credentials} Ephemeral Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EphemeralVaultAzureAccessCredentialsConfig
    */
    constructor(scope: Construct, id: string, config: EphemeralVaultAzureAccessCredentialsConfig);
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    get clientId(): string;
    get clientSecret(): string;
    private _environment?;
    get environment(): string;
    set environment(value: string);
    resetEnvironment(): void;
    get environmentInput(): string | undefined;
    get leaseDuration(): number;
    get leaseId(): string;
    get leaseRenewable(): cdktn.IResolvable;
    get leaseStartTime(): string;
    private _maxCredValidationSeconds?;
    get maxCredValidationSeconds(): number;
    set maxCredValidationSeconds(value: number);
    resetMaxCredValidationSeconds(): void;
    get maxCredValidationSecondsInput(): number | undefined;
    private _metadata;
    get metadata(): cdktn.StringMap;
    private _mountId?;
    get mountId(): string;
    set mountId(value: string);
    resetMountId(): void;
    get mountIdInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _numSecondsBetweenTests?;
    get numSecondsBetweenTests(): number;
    set numSecondsBetweenTests(value: number);
    resetNumSecondsBetweenTests(): void;
    get numSecondsBetweenTestsInput(): number | undefined;
    private _numSequentialSuccesses?;
    get numSequentialSuccesses(): number;
    set numSequentialSuccesses(value: number);
    resetNumSequentialSuccesses(): void;
    get numSequentialSuccessesInput(): number | undefined;
    private _requestMetadata?;
    get requestMetadata(): {
        [key: string]: string;
    };
    set requestMetadata(value: {
        [key: string]: string;
    });
    resetRequestMetadata(): void;
    get requestMetadataInput(): {
        [key: string]: string;
    } | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _subscriptionId?;
    get subscriptionId(): string;
    set subscriptionId(value: string);
    resetSubscriptionId(): void;
    get subscriptionIdInput(): string | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    resetTenantId(): void;
    get tenantIdInput(): string | undefined;
    private _validateCreds?;
    get validateCreds(): boolean | cdktn.IResolvable;
    set validateCreds(value: boolean | cdktn.IResolvable);
    resetValidateCreds(): void;
    get validateCredsInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultGcpkmsVerifyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Base64-encoded digest to verify.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/data-sources/gcpkms_verify#digest DataVaultGcpkmsVerify#digest}
    */
    readonly digest: string;
    /**
    * Name of the Vault key to use for verification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/data-sources/gcpkms_verify#key_name DataVaultGcpkmsVerify#key_name}
    */
    readonly keyName: string;
    /**
    * Version of the key to use for verification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/data-sources/gcpkms_verify#key_version DataVaultGcpkmsVerify#key_version}
    */
    readonly keyVersion: number;
    /**
    * Path where the GCP KMS secrets engine is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/data-sources/gcpkms_verify#mount DataVaultGcpkmsVerify#mount}
    */
    readonly mount: string;
    /**
    * Target namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/data-sources/gcpkms_verify#namespace DataVaultGcpkmsVerify#namespace}
    */
    readonly namespace?: string;
    /**
    * Base64-encoded signature to verify.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/data-sources/gcpkms_verify#signature DataVaultGcpkmsVerify#signature}
    */
    readonly signature: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/data-sources/gcpkms_verify vault_gcpkms_verify}
*/
export declare class DataVaultGcpkmsVerify extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_gcpkms_verify";
    /**
    * Generates CDKTN code for importing a DataVaultGcpkmsVerify resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultGcpkmsVerify to import
    * @param importFromId The id of the existing DataVaultGcpkmsVerify that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/data-sources/gcpkms_verify#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultGcpkmsVerify to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.13.0/docs/data-sources/gcpkms_verify vault_gcpkms_verify} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultGcpkmsVerifyConfig
    */
    constructor(scope: Construct, id: string, config: DataVaultGcpkmsVerifyConfig);
    private _digest?;
    get digest(): string;
    set digest(value: string);
    get digestInput(): string | undefined;
    private _keyName?;
    get keyName(): string;
    set keyName(value: string);
    get keyNameInput(): string | undefined;
    private _keyVersion?;
    get keyVersion(): number;
    set keyVersion(value: number);
    get keyVersionInput(): number | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _signature?;
    get signature(): string;
    set signature(value: string);
    get signatureInput(): string | undefined;
    get valid(): cdktn.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

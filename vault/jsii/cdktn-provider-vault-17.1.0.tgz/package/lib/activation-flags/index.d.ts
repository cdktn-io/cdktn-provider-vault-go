/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ActivationFlagsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Exact feature key to activate with PUT /sys/activation-flags/:feature/activate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/activation_flags#feature ActivationFlags#feature}
    */
    readonly feature: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/activation_flags vault_activation_flags}
*/
export declare class ActivationFlags extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_activation_flags";
    /**
    * Generates CDKTN code for importing a ActivationFlags resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ActivationFlags to import
    * @param importFromId The id of the existing ActivationFlags that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/activation_flags#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ActivationFlags to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/activation_flags vault_activation_flags} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ActivationFlagsConfig
    */
    constructor(scope: Construct, id: string, config: ActivationFlagsConfig);
    private _feature?;
    get feature(): string;
    set feature(value: string);
    get featureInput(): string | undefined;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RaftAutopilotConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies whether to remove dead server nodes periodically or when a new server joins. This requires that min-quorum is also set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/raft_autopilot#cleanup_dead_servers RaftAutopilot#cleanup_dead_servers}
    */
    readonly cleanupDeadServers?: boolean | cdktn.IResolvable;
    /**
    * Limit the amount of time a server can go without leader contact before being considered failed. This only takes effect when cleanup_dead_servers is set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/raft_autopilot#dead_server_last_contact_threshold RaftAutopilot#dead_server_last_contact_threshold}
    */
    readonly deadServerLastContactThreshold?: string;
    /**
    * Disables automatically upgrading Vault using autopilot. (Enterprise-only)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/raft_autopilot#disable_upgrade_migration RaftAutopilot#disable_upgrade_migration}
    */
    readonly disableUpgradeMigration?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/raft_autopilot#id RaftAutopilot#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Limit the amount of time a server can go without leader contact before being considered unhealthy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/raft_autopilot#last_contact_threshold RaftAutopilot#last_contact_threshold}
    */
    readonly lastContactThreshold?: string;
    /**
    * Maximum number of log entries in the Raft log that a server can be behind its leader before being considered unhealthy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/raft_autopilot#max_trailing_logs RaftAutopilot#max_trailing_logs}
    */
    readonly maxTrailingLogs?: number;
    /**
    * Minimum number of servers allowed in a cluster before autopilot can prune dead servers. This should at least be 3. Applicable only for voting nodes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/raft_autopilot#min_quorum RaftAutopilot#min_quorum}
    */
    readonly minQuorum?: number;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/raft_autopilot#namespace RaftAutopilot#namespace}
    */
    readonly namespace?: string;
    /**
    * Minimum amount of time a server must be stable in the 'healthy' state before being added to the cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/raft_autopilot#server_stabilization_time RaftAutopilot#server_stabilization_time}
    */
    readonly serverStabilizationTime?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/raft_autopilot vault_raft_autopilot}
*/
export declare class RaftAutopilot extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_raft_autopilot";
    /**
    * Generates CDKTN code for importing a RaftAutopilot resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RaftAutopilot to import
    * @param importFromId The id of the existing RaftAutopilot that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/raft_autopilot#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RaftAutopilot to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/raft_autopilot vault_raft_autopilot} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RaftAutopilotConfig = {}
    */
    constructor(scope: Construct, id: string, config?: RaftAutopilotConfig);
    private _cleanupDeadServers?;
    get cleanupDeadServers(): boolean | cdktn.IResolvable;
    set cleanupDeadServers(value: boolean | cdktn.IResolvable);
    resetCleanupDeadServers(): void;
    get cleanupDeadServersInput(): boolean | cdktn.IResolvable | undefined;
    private _deadServerLastContactThreshold?;
    get deadServerLastContactThreshold(): string;
    set deadServerLastContactThreshold(value: string);
    resetDeadServerLastContactThreshold(): void;
    get deadServerLastContactThresholdInput(): string | undefined;
    private _disableUpgradeMigration?;
    get disableUpgradeMigration(): boolean | cdktn.IResolvable;
    set disableUpgradeMigration(value: boolean | cdktn.IResolvable);
    resetDisableUpgradeMigration(): void;
    get disableUpgradeMigrationInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lastContactThreshold?;
    get lastContactThreshold(): string;
    set lastContactThreshold(value: string);
    resetLastContactThreshold(): void;
    get lastContactThresholdInput(): string | undefined;
    private _maxTrailingLogs?;
    get maxTrailingLogs(): number;
    set maxTrailingLogs(value: number);
    resetMaxTrailingLogs(): void;
    get maxTrailingLogsInput(): number | undefined;
    private _minQuorum?;
    get minQuorum(): number;
    set minQuorum(value: number);
    resetMinQuorum(): void;
    get minQuorumInput(): number | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _serverStabilizationTime?;
    get serverStabilizationTime(): string;
    set serverStabilizationTime(value: string);
    resetServerStabilizationTime(): void;
    get serverStabilizationTimeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OsSecretBackendAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Custom metadata for the account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/os_secret_backend_account#custom_metadata OsSecretBackendAccount#custom_metadata}
    */
    readonly customMetadata?: {
        [key: string]: string;
    };
    /**
    * Disable automated password rotation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/os_secret_backend_account#disable_automated_rotation OsSecretBackendAccount#disable_automated_rotation}
    */
    readonly disableAutomatedRotation?: boolean | cdktn.IResolvable;
    /**
    * Name of the host this account belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/os_secret_backend_account#host OsSecretBackendAccount#host}
    */
    readonly host: string;
    /**
    * Path where the OS secrets backend is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/os_secret_backend_account#mount OsSecretBackendAccount#mount}
    */
    readonly mount: string;
    /**
    * Name of the account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/os_secret_backend_account#name OsSecretBackendAccount#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/os_secret_backend_account#namespace OsSecretBackendAccount#namespace}
    */
    readonly namespace?: string;
    /**
    * Reference to a parent account for rotation management.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/os_secret_backend_account#parent_account_ref OsSecretBackendAccount#parent_account_ref}
    */
    readonly parentAccountRef?: string;
    /**
    * Name of the password policy to use for password generation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/os_secret_backend_account#password_policy OsSecretBackendAccount#password_policy}
    */
    readonly passwordPolicy?: string;
    /**
    * Password for the account. This is write-only, will not be read back from Vault,
    * 	and can only be set during resource creation. To update the password after creation, use the Vault CLI
    * 	or API to call the reset endpoint directly.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/os_secret_backend_account#password_wo OsSecretBackendAccount#password_wo}
    */
    readonly passwordWo: string;
    /**
    * How often to rotate passwords, in seconds. Mutually exclusive with rotation_schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/os_secret_backend_account#rotation_period OsSecretBackendAccount#rotation_period}
    */
    readonly rotationPeriod?: number;
    /**
    * Cron schedule for password rotation. Mutually exclusive with rotation_period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/os_secret_backend_account#rotation_schedule OsSecretBackendAccount#rotation_schedule}
    */
    readonly rotationSchedule?: string;
    /**
    * Window of time for password rotation, in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/os_secret_backend_account#rotation_window OsSecretBackendAccount#rotation_window}
    */
    readonly rotationWindow?: number;
    /**
    * Username for the account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/os_secret_backend_account#username OsSecretBackendAccount#username}
    */
    readonly username: string;
    /**
    * Verify the connection to the host with the provided credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/os_secret_backend_account#verify_connection OsSecretBackendAccount#verify_connection}
    */
    readonly verifyConnection?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/os_secret_backend_account vault_os_secret_backend_account}
*/
export declare class OsSecretBackendAccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_os_secret_backend_account";
    /**
    * Generates CDKTN code for importing a OsSecretBackendAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OsSecretBackendAccount to import
    * @param importFromId The id of the existing OsSecretBackendAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/os_secret_backend_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OsSecretBackendAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/os_secret_backend_account vault_os_secret_backend_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OsSecretBackendAccountConfig
    */
    constructor(scope: Construct, id: string, config: OsSecretBackendAccountConfig);
    private _customMetadata?;
    get customMetadata(): {
        [key: string]: string;
    };
    set customMetadata(value: {
        [key: string]: string;
    });
    resetCustomMetadata(): void;
    get customMetadataInput(): {
        [key: string]: string;
    } | undefined;
    private _disableAutomatedRotation?;
    get disableAutomatedRotation(): boolean | cdktn.IResolvable;
    set disableAutomatedRotation(value: boolean | cdktn.IResolvable);
    resetDisableAutomatedRotation(): void;
    get disableAutomatedRotationInput(): boolean | cdktn.IResolvable | undefined;
    private _host?;
    get host(): string;
    set host(value: string);
    get hostInput(): string | undefined;
    get lastVaultRotation(): string;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get nextVaultRotation(): string;
    private _parentAccountRef?;
    get parentAccountRef(): string;
    set parentAccountRef(value: string);
    resetParentAccountRef(): void;
    get parentAccountRefInput(): string | undefined;
    private _passwordPolicy?;
    get passwordPolicy(): string;
    set passwordPolicy(value: string);
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): string | undefined;
    private _passwordWo?;
    get passwordWo(): string;
    set passwordWo(value: string);
    get passwordWoInput(): string | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    resetRotationPeriod(): void;
    get rotationPeriodInput(): number | undefined;
    private _rotationSchedule?;
    get rotationSchedule(): string;
    set rotationSchedule(value: string);
    resetRotationSchedule(): void;
    get rotationScheduleInput(): string | undefined;
    private _rotationWindow?;
    get rotationWindow(): number;
    set rotationWindow(value: number);
    resetRotationWindow(): void;
    get rotationWindowInput(): number | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    private _verifyConnection?;
    get verifyConnection(): boolean | cdktn.IResolvable;
    set verifyConnection(value: boolean | cdktn.IResolvable);
    resetVerifyConnection(): void;
    get verifyConnectionInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

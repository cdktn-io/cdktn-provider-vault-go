/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConfigUiDefaultAuthConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of backup authentication methods. Uses `ListAttribute` with `ElementType: StringType` to preserve order of backup methods. Each must be a valid auth type. Vault presents these in the "Sign in with other methods" tab. **Note:** Removing this field from configuration will clear it in Vault by sending an empty array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/config_ui_default_auth#backup_auth_types ConfigUiDefaultAuth#backup_auth_types}
    */
    readonly backupAuthTypes?: string[];
    /**
    * The default authentication method. Uses `OneOf` validator to ensure only valid auth methods are accepted: github, jwt, ldap, oidc, okta, radius, saml, token, userpass.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/config_ui_default_auth#default_auth_type ConfigUiDefaultAuth#default_auth_type}
    */
    readonly defaultAuthType: string;
    /**
    * If true, child namespaces will not inherit default_auth_type and backup_auth_types from this configuration. **Note:** Removing this field from configuration will reset it to `false` in Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/config_ui_default_auth#disable_inheritance ConfigUiDefaultAuth#disable_inheritance}
    */
    readonly disableInheritance?: boolean | cdktn.IResolvable;
    /**
    * Unique identifier for the configuration. Can contain letters, numbers, underscores, and dashes. Uses `RequiresReplace()` plan modifier - changing this forces resource recreation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/config_ui_default_auth#name ConfigUiDefaultAuth#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/config_ui_default_auth#namespace ConfigUiDefaultAuth#namespace}
    */
    readonly namespace?: string;
    /**
    * Target namespace for the configuration. Empty string or omitted applies to root namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/config_ui_default_auth#namespace_path ConfigUiDefaultAuth#namespace_path}
    */
    readonly namespacePath?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/config_ui_default_auth vault_config_ui_default_auth}
*/
export declare class ConfigUiDefaultAuth extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_config_ui_default_auth";
    /**
    * Generates CDKTN code for importing a ConfigUiDefaultAuth resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConfigUiDefaultAuth to import
    * @param importFromId The id of the existing ConfigUiDefaultAuth that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/config_ui_default_auth#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConfigUiDefaultAuth to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/config_ui_default_auth vault_config_ui_default_auth} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConfigUiDefaultAuthConfig
    */
    constructor(scope: Construct, id: string, config: ConfigUiDefaultAuthConfig);
    private _backupAuthTypes?;
    get backupAuthTypes(): string[];
    set backupAuthTypes(value: string[]);
    resetBackupAuthTypes(): void;
    get backupAuthTypesInput(): string[] | undefined;
    private _defaultAuthType?;
    get defaultAuthType(): string;
    set defaultAuthType(value: string);
    get defaultAuthTypeInput(): string | undefined;
    private _disableInheritance?;
    get disableInheritance(): boolean | cdktn.IResolvable;
    set disableInheritance(value: boolean | cdktn.IResolvable);
    resetDisableInheritance(): void;
    get disableInheritanceInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _namespacePath?;
    get namespacePath(): string;
    set namespacePath(value: string);
    resetNamespacePath(): void;
    get namespacePathInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

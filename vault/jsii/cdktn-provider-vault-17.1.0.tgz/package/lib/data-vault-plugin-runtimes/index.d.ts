/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultPluginRuntimesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/plugin_runtimes#namespace DataVaultPluginRuntimes#namespace}
    */
    readonly namespace?: string;
    /**
    * Specifies the plugin runtime type to list. Currently only `container` is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/plugin_runtimes#type DataVaultPluginRuntimes#type}
    */
    readonly type?: string;
}
export interface DataVaultPluginRuntimesRuntimes {
}
export declare function dataVaultPluginRuntimesRuntimesToTerraform(struct?: DataVaultPluginRuntimesRuntimes): any;
export declare function dataVaultPluginRuntimesRuntimesToHclTerraform(struct?: DataVaultPluginRuntimesRuntimes): any;
export declare class DataVaultPluginRuntimesRuntimesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataVaultPluginRuntimesRuntimes | undefined;
    set internalValue(value: DataVaultPluginRuntimesRuntimes | undefined);
    get cgroupParent(): string;
    get cpuNanos(): number;
    get memoryBytes(): number;
    get name(): string;
    get ociRuntime(): string;
    get rootless(): cdktn.IResolvable;
    get type(): string;
}
export declare class DataVaultPluginRuntimesRuntimesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataVaultPluginRuntimesRuntimesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/plugin_runtimes vault_plugin_runtimes}
*/
export declare class DataVaultPluginRuntimes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_plugin_runtimes";
    /**
    * Generates CDKTN code for importing a DataVaultPluginRuntimes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultPluginRuntimes to import
    * @param importFromId The id of the existing DataVaultPluginRuntimes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/plugin_runtimes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultPluginRuntimes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/plugin_runtimes vault_plugin_runtimes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultPluginRuntimesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataVaultPluginRuntimesConfig);
    get id(): string;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _runtimes;
    get runtimes(): DataVaultPluginRuntimesRuntimesList;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface KvSecretV2Config extends cdktn.TerraformMetaArguments {
    /**
    * This flag is required if cas_required is set to true on either the secret or the engine's config. In order for a write to be successful, cas must be set to the current version of the secret.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/kv_secret_v2#cas KvSecretV2#cas}
    */
    readonly cas?: number;
    /**
    * JSON-encoded secret data to write.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/kv_secret_v2#data_json KvSecretV2#data_json}
    */
    readonly dataJson?: string;
    /**
    * Write-Only JSON-encoded secret data to write.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/kv_secret_v2#data_json_wo KvSecretV2#data_json_wo}
    */
    readonly dataJsonWo?: string;
    /**
    * Version counter for write-only secret data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/kv_secret_v2#data_json_wo_version KvSecretV2#data_json_wo_version}
    */
    readonly dataJsonWoVersion?: number;
    /**
    * If set to true, permanently deletes all versions for the specified key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/kv_secret_v2#delete_all_versions KvSecretV2#delete_all_versions}
    */
    readonly deleteAllVersions?: boolean | cdktn.IResolvable;
    /**
    * If set to true, disables reading secret from Vault; note: drift won't be detected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/kv_secret_v2#disable_read KvSecretV2#disable_read}
    */
    readonly disableRead?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/kv_secret_v2#id KvSecretV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Path where KV-V2 engine is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/kv_secret_v2#mount KvSecretV2#mount}
    */
    readonly mount: string;
    /**
    * Full name of the secret. For a nested secret, the name is the nested path excluding the mount and data prefix. For example, for a secret at 'kvv2/data/foo/bar/baz', the name is 'foo/bar/baz'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/kv_secret_v2#name KvSecretV2#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/kv_secret_v2#namespace KvSecretV2#namespace}
    */
    readonly namespace?: string;
    /**
    * An object that holds option settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/kv_secret_v2#options KvSecretV2#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * custom_metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/kv_secret_v2#custom_metadata KvSecretV2#custom_metadata}
    */
    readonly customMetadata?: KvSecretV2CustomMetadata;
}
export interface KvSecretV2CustomMetadata {
    /**
    * If true, all keys will require the cas parameter to be set on all write requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/kv_secret_v2#cas_required KvSecretV2#cas_required}
    */
    readonly casRequired?: boolean | cdktn.IResolvable;
    /**
    * A map of arbitrary string to string valued user-provided metadata meant to describe the secret.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/kv_secret_v2#data KvSecretV2#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * If set, specifies the length of time before a version is deleted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/kv_secret_v2#delete_version_after KvSecretV2#delete_version_after}
    */
    readonly deleteVersionAfter?: number;
    /**
    * The number of versions to keep per key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/kv_secret_v2#max_versions KvSecretV2#max_versions}
    */
    readonly maxVersions?: number;
}
export declare function kvSecretV2CustomMetadataToTerraform(struct?: KvSecretV2CustomMetadataOutputReference | KvSecretV2CustomMetadata): any;
export declare function kvSecretV2CustomMetadataToHclTerraform(struct?: KvSecretV2CustomMetadataOutputReference | KvSecretV2CustomMetadata): any;
export declare class KvSecretV2CustomMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KvSecretV2CustomMetadata | undefined;
    set internalValue(value: KvSecretV2CustomMetadata | undefined);
    private _casRequired?;
    get casRequired(): boolean | cdktn.IResolvable;
    set casRequired(value: boolean | cdktn.IResolvable);
    resetCasRequired(): void;
    get casRequiredInput(): boolean | cdktn.IResolvable | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _deleteVersionAfter?;
    get deleteVersionAfter(): number;
    set deleteVersionAfter(value: number);
    resetDeleteVersionAfter(): void;
    get deleteVersionAfterInput(): number | undefined;
    private _maxVersions?;
    get maxVersions(): number;
    set maxVersions(value: number);
    resetMaxVersions(): void;
    get maxVersionsInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/kv_secret_v2 vault_kv_secret_v2}
*/
export declare class KvSecretV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_kv_secret_v2";
    /**
    * Generates CDKTN code for importing a KvSecretV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KvSecretV2 to import
    * @param importFromId The id of the existing KvSecretV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/kv_secret_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KvSecretV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/kv_secret_v2 vault_kv_secret_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KvSecretV2Config
    */
    constructor(scope: Construct, id: string, config: KvSecretV2Config);
    private _cas?;
    get cas(): number;
    set cas(value: number);
    resetCas(): void;
    get casInput(): number | undefined;
    private _data;
    get data(): cdktn.StringMap;
    private _dataJson?;
    get dataJson(): string;
    set dataJson(value: string);
    resetDataJson(): void;
    get dataJsonInput(): string | undefined;
    private _dataJsonWo?;
    get dataJsonWo(): string;
    set dataJsonWo(value: string);
    resetDataJsonWo(): void;
    get dataJsonWoInput(): string | undefined;
    private _dataJsonWoVersion?;
    get dataJsonWoVersion(): number;
    set dataJsonWoVersion(value: number);
    resetDataJsonWoVersion(): void;
    get dataJsonWoVersionInput(): number | undefined;
    private _deleteAllVersions?;
    get deleteAllVersions(): boolean | cdktn.IResolvable;
    set deleteAllVersions(value: boolean | cdktn.IResolvable);
    resetDeleteAllVersions(): void;
    get deleteAllVersionsInput(): boolean | cdktn.IResolvable | undefined;
    private _disableRead?;
    get disableRead(): boolean | cdktn.IResolvable;
    set disableRead(value: boolean | cdktn.IResolvable);
    resetDisableRead(): void;
    get disableReadInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): cdktn.StringMap;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    get path(): string;
    private _customMetadata;
    get customMetadata(): KvSecretV2CustomMetadataOutputReference;
    putCustomMetadata(value: KvSecretV2CustomMetadata): void;
    resetCustomMetadata(): void;
    get customMetadataInput(): KvSecretV2CustomMetadata | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

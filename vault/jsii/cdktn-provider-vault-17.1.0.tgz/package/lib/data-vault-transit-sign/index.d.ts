/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultTransitSignConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a list of items for processing. When this parameter is set, any supplied 'input' or 'context' parameters will be ignored. Responses are returned in the 'batch_results' array component of the 'data' element of the response. Any batch output will preserve the order of the batch input. If the input data value of an item is invalid, the corresponding item in the 'batch_results' will have the key 'error' with a value describing the error.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign#batch_input DataVaultTransitSign#batch_input}
    */
    readonly batchInput?: {
        [key: string]: string;
    }[] | cdktn.IResolvable;
    /**
    * The results returned from Vault if using batch_input
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign#batch_results DataVaultTransitSign#batch_results}
    */
    readonly batchResults?: {
        [key: string]: string;
    }[] | cdktn.IResolvable;
    /**
    * Base64 encoded context for key derivation. Required if key derivation is enabled; currently only available with ed25519 keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign#context DataVaultTransitSign#context}
    */
    readonly context?: string;
    /**
    * Specifies the hash algorithm to use for supporting key types (notably, not including ed25519 which specifies its own hash algorithm).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign#hash_algorithm DataVaultTransitSign#hash_algorithm}
    */
    readonly hashAlgorithm?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign#id DataVaultTransitSign#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the base64 encoded input data. One of input or batch_input must be supplied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign#input DataVaultTransitSign#input}
    */
    readonly input?: string;
    /**
    * The version of the key to use
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign#key_version DataVaultTransitSign#key_version}
    */
    readonly keyVersion?: number;
    /**
    * Specifies the way in which the signature should be marshaled. This currently only applies to ECDSA keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign#marshaling_algorithm DataVaultTransitSign#marshaling_algorithm}
    */
    readonly marshalingAlgorithm?: string;
    /**
    * Name of the signing key to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign#name DataVaultTransitSign#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign#namespace DataVaultTransitSign#namespace}
    */
    readonly namespace?: string;
    /**
    * The Transit secret backend the key belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign#path DataVaultTransitSign#path}
    */
    readonly path: string;
    /**
    * Set to true when the input is already hashed. If the key type is rsa-2048, rsa-3072 or rsa-4096, then the algorithm used to hash the input should be indicated by the hash_algorithm parameter. Just as the value to sign should be the base64-encoded representation of the exact binary data you want signed, when set, input is expected to be base64-encoded binary hashed data, not hex-formatted. (As an example, on the command line, you could generate a suitable input via openssl dgst -sha256 -binary | base64.)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign#prehashed DataVaultTransitSign#prehashed}
    */
    readonly prehashed?: boolean | cdktn.IResolvable;
    /**
    * A user-supplied string that will be present in the reference field on the corresponding batch_results item in the response, to assist in understanding which result corresponds to a particular input. Only valid on batch requests when using ‘batch_input’ below.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign#reference DataVaultTransitSign#reference}
    */
    readonly reference?: string;
    /**
    * The salt length used to sign. This currently only applies to the RSA PSS signature scheme.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign#salt_length DataVaultTransitSign#salt_length}
    */
    readonly saltLength?: string;
    /**
    * The signature returned from Vault if using input
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign#signature DataVaultTransitSign#signature}
    */
    readonly signature?: string;
    /**
    * When using a RSA key, specifies the RSA signature algorithm to use for signing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign#signature_algorithm DataVaultTransitSign#signature_algorithm}
    */
    readonly signatureAlgorithm?: string;
    /**
    * Base64 encoded context for Ed25519ctx and Ed25519ph signatures.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign#signature_context DataVaultTransitSign#signature_context}
    */
    readonly signatureContext?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign vault_transit_sign}
*/
export declare class DataVaultTransitSign extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_transit_sign";
    /**
    * Generates CDKTN code for importing a DataVaultTransitSign resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultTransitSign to import
    * @param importFromId The id of the existing DataVaultTransitSign that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultTransitSign to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/transit_sign vault_transit_sign} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultTransitSignConfig
    */
    constructor(scope: Construct, id: string, config: DataVaultTransitSignConfig);
    private _batchInput?;
    get batchInput(): {
        [key: string]: string;
    }[] | cdktn.IResolvable;
    set batchInput(value: {
        [key: string]: string;
    }[] | cdktn.IResolvable);
    resetBatchInput(): void;
    get batchInputInput(): cdktn.IResolvable | {
        [key: string]: string;
    }[] | undefined;
    private _batchResults?;
    get batchResults(): {
        [key: string]: string;
    }[] | cdktn.IResolvable;
    set batchResults(value: {
        [key: string]: string;
    }[] | cdktn.IResolvable);
    resetBatchResults(): void;
    get batchResultsInput(): cdktn.IResolvable | {
        [key: string]: string;
    }[] | undefined;
    private _context?;
    get context(): string;
    set context(value: string);
    resetContext(): void;
    get contextInput(): string | undefined;
    private _hashAlgorithm?;
    get hashAlgorithm(): string;
    set hashAlgorithm(value: string);
    resetHashAlgorithm(): void;
    get hashAlgorithmInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _input?;
    get input(): string;
    set input(value: string);
    resetInput(): void;
    get inputInput(): string | undefined;
    private _keyVersion?;
    get keyVersion(): number;
    set keyVersion(value: number);
    resetKeyVersion(): void;
    get keyVersionInput(): number | undefined;
    private _marshalingAlgorithm?;
    get marshalingAlgorithm(): string;
    set marshalingAlgorithm(value: string);
    resetMarshalingAlgorithm(): void;
    get marshalingAlgorithmInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _prehashed?;
    get prehashed(): boolean | cdktn.IResolvable;
    set prehashed(value: boolean | cdktn.IResolvable);
    resetPrehashed(): void;
    get prehashedInput(): boolean | cdktn.IResolvable | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
    private _saltLength?;
    get saltLength(): string;
    set saltLength(value: string);
    resetSaltLength(): void;
    get saltLengthInput(): string | undefined;
    private _signature?;
    get signature(): string;
    set signature(value: string);
    resetSignature(): void;
    get signatureInput(): string | undefined;
    private _signatureAlgorithm?;
    get signatureAlgorithm(): string;
    set signatureAlgorithm(value: string);
    resetSignatureAlgorithm(): void;
    get signatureAlgorithmInput(): string | undefined;
    private _signatureContext?;
    get signatureContext(): string;
    set signatureContext(value: string);
    resetSignatureContext(): void;
    get signatureContextInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

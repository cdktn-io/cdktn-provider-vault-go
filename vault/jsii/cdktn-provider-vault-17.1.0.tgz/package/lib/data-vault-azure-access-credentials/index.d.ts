/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultAzureAccessCredentialsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Azure Secret Backend to read credentials from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/azure_access_credentials#backend DataVaultAzureAccessCredentials#backend}
    */
    readonly backend: string;
    /**
    * The Azure environment to use during credential validation.
    * Defaults to the Azure Public Cloud.
    * Some possible values: AzurePublicCloud, AzureUSGovernmentCloud
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/azure_access_credentials#environment DataVaultAzureAccessCredentials#environment}
    */
    readonly environment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/azure_access_credentials#id DataVaultAzureAccessCredentials#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * If 'validate_creds' is true, the number of seconds after which to give up validating credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/azure_access_credentials#max_cred_validation_seconds DataVaultAzureAccessCredentials#max_cred_validation_seconds}
    */
    readonly maxCredValidationSeconds?: number;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/azure_access_credentials#namespace DataVaultAzureAccessCredentials#namespace}
    */
    readonly namespace?: string;
    /**
    * If 'validate_creds' is true, the number of seconds to wait between each test of generated credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/azure_access_credentials#num_seconds_between_tests DataVaultAzureAccessCredentials#num_seconds_between_tests}
    */
    readonly numSecondsBetweenTests?: number;
    /**
    * If 'validate_creds' is true, the number of sequential successes required to validate generated credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/azure_access_credentials#num_sequential_successes DataVaultAzureAccessCredentials#num_sequential_successes}
    */
    readonly numSequentialSuccesses?: number;
    /**
    * Azure Secret Role to read credentials from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/azure_access_credentials#role DataVaultAzureAccessCredentials#role}
    */
    readonly role: string;
    /**
    * The subscription ID to use during credential validation. Defaults to the subscription ID configured in the Vault backend
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/azure_access_credentials#subscription_id DataVaultAzureAccessCredentials#subscription_id}
    */
    readonly subscriptionId?: string;
    /**
    * The tenant ID to use during credential validation. Defaults to the tenant ID configured in the Vault backend
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/azure_access_credentials#tenant_id DataVaultAzureAccessCredentials#tenant_id}
    */
    readonly tenantId?: string;
    /**
    * Whether generated credentials should be validated before being returned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/azure_access_credentials#validate_creds DataVaultAzureAccessCredentials#validate_creds}
    */
    readonly validateCreds?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/azure_access_credentials vault_azure_access_credentials}
*/
export declare class DataVaultAzureAccessCredentials extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_azure_access_credentials";
    /**
    * Generates CDKTN code for importing a DataVaultAzureAccessCredentials resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultAzureAccessCredentials to import
    * @param importFromId The id of the existing DataVaultAzureAccessCredentials that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/azure_access_credentials#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultAzureAccessCredentials to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/azure_access_credentials vault_azure_access_credentials} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultAzureAccessCredentialsConfig
    */
    constructor(scope: Construct, id: string, config: DataVaultAzureAccessCredentialsConfig);
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    get clientId(): string;
    get clientSecret(): string;
    private _environment?;
    get environment(): string;
    set environment(value: string);
    resetEnvironment(): void;
    get environmentInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get leaseDuration(): number;
    get leaseId(): string;
    get leaseRenewable(): cdktn.IResolvable;
    get leaseStartTime(): string;
    private _maxCredValidationSeconds?;
    get maxCredValidationSeconds(): number;
    set maxCredValidationSeconds(value: number);
    resetMaxCredValidationSeconds(): void;
    get maxCredValidationSecondsInput(): number | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _numSecondsBetweenTests?;
    get numSecondsBetweenTests(): number;
    set numSecondsBetweenTests(value: number);
    resetNumSecondsBetweenTests(): void;
    get numSecondsBetweenTestsInput(): number | undefined;
    private _numSequentialSuccesses?;
    get numSequentialSuccesses(): number;
    set numSequentialSuccesses(value: number);
    resetNumSequentialSuccesses(): void;
    get numSequentialSuccessesInput(): number | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _subscriptionId?;
    get subscriptionId(): string;
    set subscriptionId(value: string);
    resetSubscriptionId(): void;
    get subscriptionIdInput(): string | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    resetTenantId(): void;
    get tenantIdInput(): string | undefined;
    private _validateCreds?;
    get validateCreds(): boolean | cdktn.IResolvable;
    set validateCreds(value: boolean | cdktn.IResolvable);
    resetValidateCreds(): void;
    get validateCredsInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OauthResourceServerConfigProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of allowed audiences (aud claim) to validate in JWTs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile#audiences OauthResourceServerConfigProfile#audiences}
    */
    readonly audiences?: string[];
    /**
    * Leeway for clock skew in seconds when validating time-based claims. Defaults to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile#clock_skew_leeway OauthResourceServerConfigProfile#clock_skew_leeway}
    */
    readonly clockSkewLeeway?: number;
    /**
    * Whether this profile is enabled for JWT validation. Disabled profiles are ignored. Defaults to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile#enabled OauthResourceServerConfigProfile#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The issuer ID (iss claim) to validate against in incoming JWTs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile#issuer_id OauthResourceServerConfigProfile#issuer_id}
    */
    readonly issuerId: string;
    /**
    * Optional CA certificate (PEM format) for JWKS URI TLS validation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile#jwks_ca_pem OauthResourceServerConfigProfile#jwks_ca_pem}
    */
    readonly jwksCaPem?: string;
    /**
    * The JWKS URI to fetch public keys from. Required when use_jwks=true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile#jwks_uri OauthResourceServerConfigProfile#jwks_uri}
    */
    readonly jwksUri?: string;
    /**
    * The JWT type: 'access_token' or 'transaction_token'. Defaults to 'access_token'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile#jwt_type OauthResourceServerConfigProfile#jwt_type}
    */
    readonly jwtType?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile#namespace OauthResourceServerConfigProfile#namespace}
    */
    readonly namespace?: string;
    /**
    * If true, JWT-authenticated tokens omit the default policy unless added elsewhere. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile#no_default_policy OauthResourceServerConfigProfile#no_default_policy}
    */
    readonly noDefaultPolicy?: boolean | cdktn.IResolvable;
    /**
    * When false, RAR (Rich Authorization Requests) is mandatory and authorization_details must be present in the token. When set to true, authorization_details in the JWT token are optional. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile#optional_authorization_details OauthResourceServerConfigProfile#optional_authorization_details}
    */
    readonly optionalAuthorizationDetails?: boolean | cdktn.IResolvable;
    /**
    * The name of the OAuth Resource Server Configuration profile. Must be unique within the namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile#profile_name OauthResourceServerConfigProfile#profile_name}
    */
    readonly profileName: string;
    /**
    * List of supported signing algorithms (e.g., RS256, ES256). Defaults to all supported algorithms.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile#supported_algorithms OauthResourceServerConfigProfile#supported_algorithms}
    */
    readonly supportedAlgorithms?: string[];
    /**
    * If true, use JWKS URI for key validation; if false, use static public keys. Defaults to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile#use_jwks OauthResourceServerConfigProfile#use_jwks}
    */
    readonly useJwks?: boolean | cdktn.IResolvable;
    /**
    * The claim to use as the user identifier. Defaults to 'sub'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile#user_claim OauthResourceServerConfigProfile#user_claim}
    */
    readonly userClaim?: string;
    /**
    * public_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile#public_keys OauthResourceServerConfigProfile#public_keys}
    */
    readonly publicKeys?: OauthResourceServerConfigProfilePublicKeys[] | cdktn.IResolvable;
}
export interface OauthResourceServerConfigProfilePublicKeys {
    /**
    * The key ID (kid) for this public key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile#key_id OauthResourceServerConfigProfile#key_id}
    */
    readonly keyId: string;
    /**
    * The PEM-encoded public key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile#pem OauthResourceServerConfigProfile#pem}
    */
    readonly pem: string;
}
export declare function oauthResourceServerConfigProfilePublicKeysToTerraform(struct?: OauthResourceServerConfigProfilePublicKeys | cdktn.IResolvable): any;
export declare function oauthResourceServerConfigProfilePublicKeysToHclTerraform(struct?: OauthResourceServerConfigProfilePublicKeys | cdktn.IResolvable): any;
export declare class OauthResourceServerConfigProfilePublicKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OauthResourceServerConfigProfilePublicKeys | cdktn.IResolvable | undefined;
    set internalValue(value: OauthResourceServerConfigProfilePublicKeys | cdktn.IResolvable | undefined);
    private _keyId?;
    get keyId(): string;
    set keyId(value: string);
    get keyIdInput(): string | undefined;
    private _pem?;
    get pem(): string;
    set pem(value: string);
    get pemInput(): string | undefined;
}
export declare class OauthResourceServerConfigProfilePublicKeysList extends cdktn.ComplexList {
    internalValue?: OauthResourceServerConfigProfilePublicKeys[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OauthResourceServerConfigProfilePublicKeysOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile vault_oauth_resource_server_config_profile}
*/
export declare class OauthResourceServerConfigProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_oauth_resource_server_config_profile";
    /**
    * Generates CDKTN code for importing a OauthResourceServerConfigProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OauthResourceServerConfigProfile to import
    * @param importFromId The id of the existing OauthResourceServerConfigProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OauthResourceServerConfigProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/oauth_resource_server_config_profile vault_oauth_resource_server_config_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OauthResourceServerConfigProfileConfig
    */
    constructor(scope: Construct, id: string, config: OauthResourceServerConfigProfileConfig);
    private _audiences?;
    get audiences(): string[];
    set audiences(value: string[]);
    resetAudiences(): void;
    get audiencesInput(): string[] | undefined;
    private _clockSkewLeeway?;
    get clockSkewLeeway(): number;
    set clockSkewLeeway(value: number);
    resetClockSkewLeeway(): void;
    get clockSkewLeewayInput(): number | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _issuerId?;
    get issuerId(): string;
    set issuerId(value: string);
    get issuerIdInput(): string | undefined;
    private _jwksCaPem?;
    get jwksCaPem(): string;
    set jwksCaPem(value: string);
    resetJwksCaPem(): void;
    get jwksCaPemInput(): string | undefined;
    private _jwksUri?;
    get jwksUri(): string;
    set jwksUri(value: string);
    resetJwksUri(): void;
    get jwksUriInput(): string | undefined;
    private _jwtType?;
    get jwtType(): string;
    set jwtType(value: string);
    resetJwtType(): void;
    get jwtTypeInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _noDefaultPolicy?;
    get noDefaultPolicy(): boolean | cdktn.IResolvable;
    set noDefaultPolicy(value: boolean | cdktn.IResolvable);
    resetNoDefaultPolicy(): void;
    get noDefaultPolicyInput(): boolean | cdktn.IResolvable | undefined;
    private _optionalAuthorizationDetails?;
    get optionalAuthorizationDetails(): boolean | cdktn.IResolvable;
    set optionalAuthorizationDetails(value: boolean | cdktn.IResolvable);
    resetOptionalAuthorizationDetails(): void;
    get optionalAuthorizationDetailsInput(): boolean | cdktn.IResolvable | undefined;
    private _profileName?;
    get profileName(): string;
    set profileName(value: string);
    get profileNameInput(): string | undefined;
    private _supportedAlgorithms?;
    get supportedAlgorithms(): string[];
    set supportedAlgorithms(value: string[]);
    resetSupportedAlgorithms(): void;
    get supportedAlgorithmsInput(): string[] | undefined;
    private _useJwks?;
    get useJwks(): boolean | cdktn.IResolvable;
    set useJwks(value: boolean | cdktn.IResolvable);
    resetUseJwks(): void;
    get useJwksInput(): boolean | cdktn.IResolvable | undefined;
    private _userClaim?;
    get userClaim(): string;
    set userClaim(value: string);
    resetUserClaim(): void;
    get userClaimInput(): string | undefined;
    private _publicKeys;
    get publicKeys(): OauthResourceServerConfigProfilePublicKeysList;
    putPublicKeys(value: OauthResourceServerConfigProfilePublicKeys[] | cdktn.IResolvable): void;
    resetPublicKeys(): void;
    get publicKeysInput(): cdktn.IResolvable | OauthResourceServerConfigProfilePublicKeys[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

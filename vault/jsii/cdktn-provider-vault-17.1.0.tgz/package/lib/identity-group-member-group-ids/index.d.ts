/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IdentityGroupMemberGroupIdsConfig extends cdktn.TerraformMetaArguments {
    /**
    * If set to true, allows the resource to manage member group ids
    * exclusively. Beware of race conditions when disabling exclusive management
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group_member_group_ids#exclusive IdentityGroupMemberGroupIds#exclusive}
    */
    readonly exclusive?: boolean | cdktn.IResolvable;
    /**
    * ID of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group_member_group_ids#group_id IdentityGroupMemberGroupIds#group_id}
    */
    readonly groupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group_member_group_ids#id IdentityGroupMemberGroupIds#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Group IDs to be assigned as group members.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group_member_group_ids#member_group_ids IdentityGroupMemberGroupIds#member_group_ids}
    */
    readonly memberGroupIds?: string[];
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group_member_group_ids#namespace IdentityGroupMemberGroupIds#namespace}
    */
    readonly namespace?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group_member_group_ids vault_identity_group_member_group_ids}
*/
export declare class IdentityGroupMemberGroupIds extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_identity_group_member_group_ids";
    /**
    * Generates CDKTN code for importing a IdentityGroupMemberGroupIds resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IdentityGroupMemberGroupIds to import
    * @param importFromId The id of the existing IdentityGroupMemberGroupIds that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group_member_group_ids#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IdentityGroupMemberGroupIds to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group_member_group_ids vault_identity_group_member_group_ids} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IdentityGroupMemberGroupIdsConfig
    */
    constructor(scope: Construct, id: string, config: IdentityGroupMemberGroupIdsConfig);
    private _exclusive?;
    get exclusive(): boolean | cdktn.IResolvable;
    set exclusive(value: boolean | cdktn.IResolvable);
    resetExclusive(): void;
    get exclusiveInput(): boolean | cdktn.IResolvable | undefined;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    get groupIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _memberGroupIds?;
    get memberGroupIds(): string[];
    set memberGroupIds(value: string[]);
    resetMemberGroupIds(): void;
    get memberGroupIdsInput(): string[] | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

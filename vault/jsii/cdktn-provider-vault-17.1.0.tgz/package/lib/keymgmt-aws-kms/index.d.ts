/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface KeymgmtAwsKmsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The credentials to use for authentication with AWS KMS. Supplying values for this parameter is optional, as credentials may also be specified as environment variables. Credentials provided to this parameter will take precedence over credentials provided via environment variables.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/keymgmt_aws_kms#credentials_wo KeymgmtAwsKms#credentials_wo}
    */
    readonly credentialsWo?: {
        [key: string]: string;
    };
    /**
    * Version counter for the write-only `credentials_wo` field. Since write-only values are not stored in state, Terraform cannot detect when credentials change. Increment this value whenever you update `credentials_wo` to ensure the new credentials are sent to Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/keymgmt_aws_kms#credentials_wo_version KeymgmtAwsKms#credentials_wo_version}
    */
    readonly credentialsWoVersion?: number;
    /**
    * Refers to the name of an AWS region. Cannot be changed after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/keymgmt_aws_kms#key_collection KeymgmtAwsKms#key_collection}
    */
    readonly keyCollection: string;
    /**
    * Path of the Key Management secrets engine mount. Must match the `path` of a `vault_mount` resource with `type = "keymgmt"`. Use `vault_mount.keymgmt.path` here.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/keymgmt_aws_kms#mount KeymgmtAwsKms#mount}
    */
    readonly mount: string;
    /**
    * Specifies the name of the AWS KMS provider. Cannot be changed after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/keymgmt_aws_kms#name KeymgmtAwsKms#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/keymgmt_aws_kms#namespace KeymgmtAwsKms#namespace}
    */
    readonly namespace?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/keymgmt_aws_kms vault_keymgmt_aws_kms}
*/
export declare class KeymgmtAwsKms extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_keymgmt_aws_kms";
    /**
    * Generates CDKTN code for importing a KeymgmtAwsKms resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KeymgmtAwsKms to import
    * @param importFromId The id of the existing KeymgmtAwsKms that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/keymgmt_aws_kms#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KeymgmtAwsKms to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/keymgmt_aws_kms vault_keymgmt_aws_kms} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KeymgmtAwsKmsConfig
    */
    constructor(scope: Construct, id: string, config: KeymgmtAwsKmsConfig);
    private _credentialsWo?;
    get credentialsWo(): {
        [key: string]: string;
    };
    set credentialsWo(value: {
        [key: string]: string;
    });
    resetCredentialsWo(): void;
    get credentialsWoInput(): {
        [key: string]: string;
    } | undefined;
    private _credentialsWoVersion?;
    get credentialsWoVersion(): number;
    set credentialsWoVersion(value: number);
    resetCredentialsWoVersion(): void;
    get credentialsWoVersionInput(): number | undefined;
    private _keyCollection?;
    get keyCollection(): string;
    set keyCollection(value: string);
    get keyCollectionInput(): string | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

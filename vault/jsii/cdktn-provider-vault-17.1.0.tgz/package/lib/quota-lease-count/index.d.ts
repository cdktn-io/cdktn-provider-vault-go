/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface QuotaLeaseCountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/quota_lease_count#id QuotaLeaseCount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * If set to true on a quota where path is set to a namespace, the same quota will be cumulatively applied to all child namespace. The inheritable parameter cannot be set to true if the path does not specify a namespace. Only the quotas associated with the root namespace are inheritable by default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/quota_lease_count#inheritable QuotaLeaseCount#inheritable}
    */
    readonly inheritable?: boolean | cdktn.IResolvable;
    /**
    * The maximum number of leases to be allowed by the quota rule. The max_leases must be positive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/quota_lease_count#max_leases QuotaLeaseCount#max_leases}
    */
    readonly maxLeases: number;
    /**
    * The name of the quota.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/quota_lease_count#name QuotaLeaseCount#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/quota_lease_count#namespace QuotaLeaseCount#namespace}
    */
    readonly namespace?: string;
    /**
    * Path of the mount or namespace to apply the quota. A blank path configures a global lease count quota.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/quota_lease_count#path QuotaLeaseCount#path}
    */
    readonly path?: string;
    /**
    * If set on a quota where path is set to an auth mount with a concept of roles (such as /auth/approle/), this will make the quota restrict login requests to that mount that are made with the specified role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/quota_lease_count#role QuotaLeaseCount#role}
    */
    readonly role?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/quota_lease_count vault_quota_lease_count}
*/
export declare class QuotaLeaseCount extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_quota_lease_count";
    /**
    * Generates CDKTN code for importing a QuotaLeaseCount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the QuotaLeaseCount to import
    * @param importFromId The id of the existing QuotaLeaseCount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/quota_lease_count#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the QuotaLeaseCount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/quota_lease_count vault_quota_lease_count} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options QuotaLeaseCountConfig
    */
    constructor(scope: Construct, id: string, config: QuotaLeaseCountConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inheritable?;
    get inheritable(): boolean | cdktn.IResolvable;
    set inheritable(value: boolean | cdktn.IResolvable);
    resetInheritable(): void;
    get inheritableInput(): boolean | cdktn.IResolvable | undefined;
    private _maxLeases?;
    get maxLeases(): number;
    set maxLeases(value: number);
    get maxLeasesInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

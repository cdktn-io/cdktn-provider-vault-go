/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CfAuthBackendRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * A map of string to string that will be set as metadata on the identity alias
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role#alias_metadata CfAuthBackendRole#alias_metadata}
    */
    readonly aliasMetadata?: {
        [key: string]: string;
    };
    /**
    * An optional set of application IDs an instance must be a member of to qualify for this role. To clear this constraint, omit the field entirely rather than setting it to an empty list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role#bound_application_ids CfAuthBackendRole#bound_application_ids}
    */
    readonly boundApplicationIds?: string[];
    /**
    * An optional set of instance IDs an instance must be a member of to qualify for this role. To clear this constraint, omit the field entirely rather than setting it to an empty list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role#bound_instance_ids CfAuthBackendRole#bound_instance_ids}
    */
    readonly boundInstanceIds?: string[];
    /**
    * An optional set of organization IDs an instance must be a member of to qualify for this role. To clear this constraint, omit the field entirely rather than setting it to an empty list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role#bound_organization_ids CfAuthBackendRole#bound_organization_ids}
    */
    readonly boundOrganizationIds?: string[];
    /**
    * An optional set of space IDs an instance must be a member of to qualify for this role. To clear this constraint, omit the field entirely rather than setting it to an empty list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role#bound_space_ids CfAuthBackendRole#bound_space_ids}
    */
    readonly boundSpaceIds?: string[];
    /**
    * If set to `true`, disables the default behavior that logging in must be performed from an acceptable IP address described by the presented certificate. Defaults to `false`. To reset to the default, omit this field from config rather than setting it to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role#disable_ip_matching CfAuthBackendRole#disable_ip_matching}
    */
    readonly disableIpMatching?: boolean | cdktn.IResolvable;
    /**
    * Mount path for the CF auth engine in Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role#mount CfAuthBackendRole#mount}
    */
    readonly mount: string;
    /**
    * Name of the CF auth role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role#name CfAuthBackendRole#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role#namespace CfAuthBackendRole#namespace}
    */
    readonly namespace?: string;
    /**
    * Specifies the blocks of IP addresses which are allowed to use the generated token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role#token_bound_cidrs CfAuthBackendRole#token_bound_cidrs}
    */
    readonly tokenBoundCidrs?: string[];
    /**
    * Generated Token's Explicit Maximum TTL in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role#token_explicit_max_ttl CfAuthBackendRole#token_explicit_max_ttl}
    */
    readonly tokenExplicitMaxTtl?: number;
    /**
    * The maximum lifetime of the generated token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role#token_max_ttl CfAuthBackendRole#token_max_ttl}
    */
    readonly tokenMaxTtl?: number;
    /**
    * If true, the 'default' policy will not automatically be added to generated tokens
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role#token_no_default_policy CfAuthBackendRole#token_no_default_policy}
    */
    readonly tokenNoDefaultPolicy?: boolean | cdktn.IResolvable;
    /**
    * The maximum number of times a token may be used, a value of zero means unlimited
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role#token_num_uses CfAuthBackendRole#token_num_uses}
    */
    readonly tokenNumUses?: number;
    /**
    * Generated Token's Period
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role#token_period CfAuthBackendRole#token_period}
    */
    readonly tokenPeriod?: number;
    /**
    * Generated Token's Policies
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role#token_policies CfAuthBackendRole#token_policies}
    */
    readonly tokenPolicies?: string[];
    /**
    * The initial ttl of the token to generate in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role#token_ttl CfAuthBackendRole#token_ttl}
    */
    readonly tokenTtl?: number;
    /**
    * The type of token to generate, service or batch
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role#token_type CfAuthBackendRole#token_type}
    */
    readonly tokenType?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role vault_cf_auth_backend_role}
*/
export declare class CfAuthBackendRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_cf_auth_backend_role";
    /**
    * Generates CDKTN code for importing a CfAuthBackendRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CfAuthBackendRole to import
    * @param importFromId The id of the existing CfAuthBackendRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CfAuthBackendRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cf_auth_backend_role vault_cf_auth_backend_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CfAuthBackendRoleConfig
    */
    constructor(scope: Construct, id: string, config: CfAuthBackendRoleConfig);
    private _aliasMetadata?;
    get aliasMetadata(): {
        [key: string]: string;
    };
    set aliasMetadata(value: {
        [key: string]: string;
    });
    resetAliasMetadata(): void;
    get aliasMetadataInput(): {
        [key: string]: string;
    } | undefined;
    private _boundApplicationIds?;
    get boundApplicationIds(): string[];
    set boundApplicationIds(value: string[]);
    resetBoundApplicationIds(): void;
    get boundApplicationIdsInput(): string[] | undefined;
    private _boundInstanceIds?;
    get boundInstanceIds(): string[];
    set boundInstanceIds(value: string[]);
    resetBoundInstanceIds(): void;
    get boundInstanceIdsInput(): string[] | undefined;
    private _boundOrganizationIds?;
    get boundOrganizationIds(): string[];
    set boundOrganizationIds(value: string[]);
    resetBoundOrganizationIds(): void;
    get boundOrganizationIdsInput(): string[] | undefined;
    private _boundSpaceIds?;
    get boundSpaceIds(): string[];
    set boundSpaceIds(value: string[]);
    resetBoundSpaceIds(): void;
    get boundSpaceIdsInput(): string[] | undefined;
    private _disableIpMatching?;
    get disableIpMatching(): boolean | cdktn.IResolvable;
    set disableIpMatching(value: boolean | cdktn.IResolvable);
    resetDisableIpMatching(): void;
    get disableIpMatchingInput(): boolean | cdktn.IResolvable | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _tokenBoundCidrs?;
    get tokenBoundCidrs(): string[];
    set tokenBoundCidrs(value: string[]);
    resetTokenBoundCidrs(): void;
    get tokenBoundCidrsInput(): string[] | undefined;
    private _tokenExplicitMaxTtl?;
    get tokenExplicitMaxTtl(): number;
    set tokenExplicitMaxTtl(value: number);
    resetTokenExplicitMaxTtl(): void;
    get tokenExplicitMaxTtlInput(): number | undefined;
    private _tokenMaxTtl?;
    get tokenMaxTtl(): number;
    set tokenMaxTtl(value: number);
    resetTokenMaxTtl(): void;
    get tokenMaxTtlInput(): number | undefined;
    private _tokenNoDefaultPolicy?;
    get tokenNoDefaultPolicy(): boolean | cdktn.IResolvable;
    set tokenNoDefaultPolicy(value: boolean | cdktn.IResolvable);
    resetTokenNoDefaultPolicy(): void;
    get tokenNoDefaultPolicyInput(): boolean | cdktn.IResolvable | undefined;
    private _tokenNumUses?;
    get tokenNumUses(): number;
    set tokenNumUses(value: number);
    resetTokenNumUses(): void;
    get tokenNumUsesInput(): number | undefined;
    private _tokenPeriod?;
    get tokenPeriod(): number;
    set tokenPeriod(value: number);
    resetTokenPeriod(): void;
    get tokenPeriodInput(): number | undefined;
    private _tokenPolicies?;
    get tokenPolicies(): string[];
    set tokenPolicies(value: string[]);
    resetTokenPolicies(): void;
    get tokenPoliciesInput(): string[] | undefined;
    private _tokenTtl?;
    get tokenTtl(): number;
    set tokenTtl(value: number);
    resetTokenTtl(): void;
    get tokenTtlInput(): number | undefined;
    private _tokenType?;
    get tokenType(): string;
    set tokenType(value: string);
    resetTokenType(): void;
    get tokenTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

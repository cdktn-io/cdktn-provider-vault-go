/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SecretsSyncGcpDestinationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Allowed IPv4 addresses for outbound network connectivity in CIDR notation. If not set, all IPv4 addresses are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#allowed_ipv4_addresses SecretsSyncGcpDestination#allowed_ipv4_addresses}
    */
    readonly allowedIpv4Addresses?: string[];
    /**
    * Allowed IPv6 addresses for outbound network connectivity in CIDR notation. If not set, all IPv6 addresses are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#allowed_ipv6_addresses SecretsSyncGcpDestination#allowed_ipv6_addresses}
    */
    readonly allowedIpv6Addresses?: string[];
    /**
    * Allowed ports for outbound network connectivity. If not set, all ports are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#allowed_ports SecretsSyncGcpDestination#allowed_ports}
    */
    readonly allowedPorts?: number[];
    /**
    * JSON-encoded credentials to use to connect to GCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#credentials SecretsSyncGcpDestination#credentials}
    */
    readonly credentials?: string;
    /**
    * Custom tags to set on the secret managed at the destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#custom_tags SecretsSyncGcpDestination#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
    /**
    * Disable strict networking requirements.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#disable_strict_networking SecretsSyncGcpDestination#disable_strict_networking}
    */
    readonly disableStrictNetworking?: boolean | cdktn.IResolvable;
    /**
    * Global KMS key for encryption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#global_kms_key SecretsSyncGcpDestination#global_kms_key}
    */
    readonly globalKmsKey?: string;
    /**
    * Determines what level of information is synced as a distinct resource at the destination. Can be 'secret-path' or 'secret-key'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#granularity SecretsSyncGcpDestination#granularity}
    */
    readonly granularity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#id SecretsSyncGcpDestination#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The audience claim value for identity tokens. This is a write-only field and will not be read back from Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#identity_token_audience_wo SecretsSyncGcpDestination#identity_token_audience_wo}
    */
    readonly identityTokenAudienceWo?: string;
    /**
    * A version counter for the write-only identity_token_audience_wo field. Incrementing this value will trigger an update.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#identity_token_audience_wo_version SecretsSyncGcpDestination#identity_token_audience_wo_version}
    */
    readonly identityTokenAudienceWoVersion?: number;
    /**
    * The key to use for signing identity tokens. This is a write-only field and will not be read back from Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#identity_token_key_wo SecretsSyncGcpDestination#identity_token_key_wo}
    */
    readonly identityTokenKeyWo?: string;
    /**
    * A version counter for the write-only identity_token_key_wo field. Incrementing this value will trigger an update.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#identity_token_key_wo_version SecretsSyncGcpDestination#identity_token_key_wo_version}
    */
    readonly identityTokenKeyWoVersion?: number;
    /**
    * The TTL of generated tokens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#identity_token_ttl SecretsSyncGcpDestination#identity_token_ttl}
    */
    readonly identityTokenTtl?: number;
    /**
    * Locational KMS keys for encryption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#locational_kms_keys SecretsSyncGcpDestination#locational_kms_keys}
    */
    readonly locationalKmsKeys?: {
        [key: string]: string;
    };
    /**
    * Unique name of the GCP destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#name SecretsSyncGcpDestination#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#namespace SecretsSyncGcpDestination#namespace}
    */
    readonly namespace?: string;
    /**
    * The target project to manage secrets in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#project_id SecretsSyncGcpDestination#project_id}
    */
    readonly projectId?: string;
    /**
    * Replication locations for secrets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#replication_locations SecretsSyncGcpDestination#replication_locations}
    */
    readonly replicationLocations?: string[];
    /**
    * Template describing how to generate external secret names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#secret_name_template SecretsSyncGcpDestination#secret_name_template}
    */
    readonly secretNameTemplate?: string;
    /**
    * Service Account to impersonate for workload identity federation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#service_account_email SecretsSyncGcpDestination#service_account_email}
    */
    readonly serviceAccountEmail?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination vault_secrets_sync_gcp_destination}
*/
export declare class SecretsSyncGcpDestination extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_secrets_sync_gcp_destination";
    /**
    * Generates CDKTN code for importing a SecretsSyncGcpDestination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecretsSyncGcpDestination to import
    * @param importFromId The id of the existing SecretsSyncGcpDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecretsSyncGcpDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/secrets_sync_gcp_destination vault_secrets_sync_gcp_destination} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecretsSyncGcpDestinationConfig
    */
    constructor(scope: Construct, id: string, config: SecretsSyncGcpDestinationConfig);
    private _allowedIpv4Addresses?;
    get allowedIpv4Addresses(): string[];
    set allowedIpv4Addresses(value: string[]);
    resetAllowedIpv4Addresses(): void;
    get allowedIpv4AddressesInput(): string[] | undefined;
    private _allowedIpv6Addresses?;
    get allowedIpv6Addresses(): string[];
    set allowedIpv6Addresses(value: string[]);
    resetAllowedIpv6Addresses(): void;
    get allowedIpv6AddressesInput(): string[] | undefined;
    private _allowedPorts?;
    get allowedPorts(): number[];
    set allowedPorts(value: number[]);
    resetAllowedPorts(): void;
    get allowedPortsInput(): number[] | undefined;
    private _credentials?;
    get credentials(): string;
    set credentials(value: string);
    resetCredentials(): void;
    get credentialsInput(): string | undefined;
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _disableStrictNetworking?;
    get disableStrictNetworking(): boolean | cdktn.IResolvable;
    set disableStrictNetworking(value: boolean | cdktn.IResolvable);
    resetDisableStrictNetworking(): void;
    get disableStrictNetworkingInput(): boolean | cdktn.IResolvable | undefined;
    private _globalKmsKey?;
    get globalKmsKey(): string;
    set globalKmsKey(value: string);
    resetGlobalKmsKey(): void;
    get globalKmsKeyInput(): string | undefined;
    private _granularity?;
    get granularity(): string;
    set granularity(value: string);
    resetGranularity(): void;
    get granularityInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityTokenAudienceWo?;
    get identityTokenAudienceWo(): string;
    set identityTokenAudienceWo(value: string);
    resetIdentityTokenAudienceWo(): void;
    get identityTokenAudienceWoInput(): string | undefined;
    private _identityTokenAudienceWoVersion?;
    get identityTokenAudienceWoVersion(): number;
    set identityTokenAudienceWoVersion(value: number);
    resetIdentityTokenAudienceWoVersion(): void;
    get identityTokenAudienceWoVersionInput(): number | undefined;
    private _identityTokenKeyWo?;
    get identityTokenKeyWo(): string;
    set identityTokenKeyWo(value: string);
    resetIdentityTokenKeyWo(): void;
    get identityTokenKeyWoInput(): string | undefined;
    private _identityTokenKeyWoVersion?;
    get identityTokenKeyWoVersion(): number;
    set identityTokenKeyWoVersion(value: number);
    resetIdentityTokenKeyWoVersion(): void;
    get identityTokenKeyWoVersionInput(): number | undefined;
    private _identityTokenTtl?;
    get identityTokenTtl(): number;
    set identityTokenTtl(value: number);
    resetIdentityTokenTtl(): void;
    get identityTokenTtlInput(): number | undefined;
    private _locationalKmsKeys?;
    get locationalKmsKeys(): {
        [key: string]: string;
    };
    set locationalKmsKeys(value: {
        [key: string]: string;
    });
    resetLocationalKmsKeys(): void;
    get locationalKmsKeysInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _replicationLocations?;
    get replicationLocations(): string[];
    set replicationLocations(value: string[]);
    resetReplicationLocations(): void;
    get replicationLocationsInput(): string[] | undefined;
    private _secretNameTemplate?;
    get secretNameTemplate(): string;
    set secretNameTemplate(value: string);
    resetSecretNameTemplate(): void;
    get secretNameTemplateInput(): string | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    resetServiceAccountEmail(): void;
    get serviceAccountEmailInput(): string | undefined;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

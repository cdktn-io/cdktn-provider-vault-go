/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseSecretBackendRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The path of the Database Secret Backend the role belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/database_secret_backend_role#backend DatabaseSecretBackendRole#backend}
    */
    readonly backend: string;
    /**
    * Database statements to execute to create and configure a user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/database_secret_backend_role#creation_statements DatabaseSecretBackendRole#creation_statements}
    */
    readonly creationStatements: string[];
    /**
    * Specifies the configuration for the given credential_type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/database_secret_backend_role#credential_config DatabaseSecretBackendRole#credential_config}
    */
    readonly credentialConfig?: {
        [key: string]: string;
    };
    /**
    * Specifies the type of credential that will be generated for the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/database_secret_backend_role#credential_type DatabaseSecretBackendRole#credential_type}
    */
    readonly credentialType?: string;
    /**
    * Database connection to use for this role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/database_secret_backend_role#db_name DatabaseSecretBackendRole#db_name}
    */
    readonly dbName: string;
    /**
    * Default TTL for leases associated with this role, in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/database_secret_backend_role#default_ttl DatabaseSecretBackendRole#default_ttl}
    */
    readonly defaultTtl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/database_secret_backend_role#id DatabaseSecretBackendRole#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Maximum TTL for leases associated with this role, in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/database_secret_backend_role#max_ttl DatabaseSecretBackendRole#max_ttl}
    */
    readonly maxTtl?: number;
    /**
    * Unique name for the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/database_secret_backend_role#name DatabaseSecretBackendRole#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/database_secret_backend_role#namespace DatabaseSecretBackendRole#namespace}
    */
    readonly namespace?: string;
    /**
    * Database statements to execute to renew a user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/database_secret_backend_role#renew_statements DatabaseSecretBackendRole#renew_statements}
    */
    readonly renewStatements?: string[];
    /**
    * Database statements to execute to revoke a user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/database_secret_backend_role#revocation_statements DatabaseSecretBackendRole#revocation_statements}
    */
    readonly revocationStatements?: string[];
    /**
    * Database statements to execute to rollback a create operation in the event of an error.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/database_secret_backend_role#rollback_statements DatabaseSecretBackendRole#rollback_statements}
    */
    readonly rollbackStatements?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/database_secret_backend_role vault_database_secret_backend_role}
*/
export declare class DatabaseSecretBackendRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_database_secret_backend_role";
    /**
    * Generates CDKTN code for importing a DatabaseSecretBackendRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseSecretBackendRole to import
    * @param importFromId The id of the existing DatabaseSecretBackendRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/database_secret_backend_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseSecretBackendRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/database_secret_backend_role vault_database_secret_backend_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseSecretBackendRoleConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseSecretBackendRoleConfig);
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    private _creationStatements?;
    get creationStatements(): string[];
    set creationStatements(value: string[]);
    get creationStatementsInput(): string[] | undefined;
    private _credentialConfig?;
    get credentialConfig(): {
        [key: string]: string;
    };
    set credentialConfig(value: {
        [key: string]: string;
    });
    resetCredentialConfig(): void;
    get credentialConfigInput(): {
        [key: string]: string;
    } | undefined;
    private _credentialType?;
    get credentialType(): string;
    set credentialType(value: string);
    resetCredentialType(): void;
    get credentialTypeInput(): string | undefined;
    private _dbName?;
    get dbName(): string;
    set dbName(value: string);
    get dbNameInput(): string | undefined;
    private _defaultTtl?;
    get defaultTtl(): number;
    set defaultTtl(value: number);
    resetDefaultTtl(): void;
    get defaultTtlInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxTtl?;
    get maxTtl(): number;
    set maxTtl(value: number);
    resetMaxTtl(): void;
    get maxTtlInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _renewStatements?;
    get renewStatements(): string[];
    set renewStatements(value: string[]);
    resetRenewStatements(): void;
    get renewStatementsInput(): string[] | undefined;
    private _revocationStatements?;
    get revocationStatements(): string[];
    set revocationStatements(value: string[]);
    resetRevocationStatements(): void;
    get revocationStatementsInput(): string[] | undefined;
    private _rollbackStatements?;
    get rollbackStatements(): string[];
    set rollbackStatements(value: string[]);
    resetRollbackStatements(): void;
    get rollbackStatementsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GenericSecretConfig extends cdktn.TerraformMetaArguments {
    /**
    * JSON-encoded secret data to write.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/generic_secret#data_json GenericSecret#data_json}
    */
    readonly dataJson: string;
    /**
    * Only applicable for kv-v2 stores. If set, permanently deletes all versions for the specified key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/generic_secret#delete_all_versions GenericSecret#delete_all_versions}
    */
    readonly deleteAllVersions?: boolean | cdktn.IResolvable;
    /**
    * Don't attempt to read the token from Vault if true; drift won't be detected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/generic_secret#disable_read GenericSecret#disable_read}
    */
    readonly disableRead?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/generic_secret#id GenericSecret#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/generic_secret#namespace GenericSecret#namespace}
    */
    readonly namespace?: string;
    /**
    * Full path where the generic secret will be written.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/generic_secret#path GenericSecret#path}
    */
    readonly path: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/generic_secret vault_generic_secret}
*/
export declare class GenericSecret extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_generic_secret";
    /**
    * Generates CDKTN code for importing a GenericSecret resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GenericSecret to import
    * @param importFromId The id of the existing GenericSecret that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/generic_secret#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GenericSecret to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/generic_secret vault_generic_secret} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GenericSecretConfig
    */
    constructor(scope: Construct, id: string, config: GenericSecretConfig);
    private _data;
    get data(): cdktn.StringMap;
    private _dataJson?;
    get dataJson(): string;
    set dataJson(value: string);
    get dataJsonInput(): string | undefined;
    private _deleteAllVersions?;
    get deleteAllVersions(): boolean | cdktn.IResolvable;
    set deleteAllVersions(value: boolean | cdktn.IResolvable);
    resetDeleteAllVersions(): void;
    get deleteAllVersionsInput(): boolean | cdktn.IResolvable | undefined;
    private _disableRead?;
    get disableRead(): boolean | cdktn.IResolvable;
    set disableRead(value: boolean | cdktn.IResolvable);
    resetDisableRead(): void;
    get disableReadInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

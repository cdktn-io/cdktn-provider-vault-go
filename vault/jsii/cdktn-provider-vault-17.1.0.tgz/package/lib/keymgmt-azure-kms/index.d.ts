/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface KeymgmtAzureKmsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The credentials to use for authentication with Azure Key Vault. Supplying values for this parameter is optional, as credentials may also be specified as environment variables. Environment variables will take precedence over credentials provided via this parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/keymgmt_azure_kms#credentials_wo KeymgmtAzureKms#credentials_wo}
    */
    readonly credentialsWo?: {
        [key: string]: string;
    };
    /**
    * Version counter for the write-only `credentials_wo` field. Since write-only values are not stored in state, Terraform cannot detect when credentials change. Increment this value whenever you update `credentials_wo` to ensure the new credentials are sent to Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/keymgmt_azure_kms#credentials_wo_version KeymgmtAzureKms#credentials_wo_version}
    */
    readonly credentialsWoVersion?: number;
    /**
    * Refers to the name of an existing Azure Key Vault instance. Cannot be changed after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/keymgmt_azure_kms#key_collection KeymgmtAzureKms#key_collection}
    */
    readonly keyCollection: string;
    /**
    * Path of the Key Management secrets engine mount. Must match the `path` of a `vault_mount` resource with `type = "keymgmt"`. Use `vault_mount.keymgmt.path` here.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/keymgmt_azure_kms#mount KeymgmtAzureKms#mount}
    */
    readonly mount: string;
    /**
    * Specifies the name of the Azure Key Vault provider. Cannot be changed after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/keymgmt_azure_kms#name KeymgmtAzureKms#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/keymgmt_azure_kms#namespace KeymgmtAzureKms#namespace}
    */
    readonly namespace?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/keymgmt_azure_kms vault_keymgmt_azure_kms}
*/
export declare class KeymgmtAzureKms extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_keymgmt_azure_kms";
    /**
    * Generates CDKTN code for importing a KeymgmtAzureKms resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KeymgmtAzureKms to import
    * @param importFromId The id of the existing KeymgmtAzureKms that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/keymgmt_azure_kms#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KeymgmtAzureKms to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/keymgmt_azure_kms vault_keymgmt_azure_kms} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KeymgmtAzureKmsConfig
    */
    constructor(scope: Construct, id: string, config: KeymgmtAzureKmsConfig);
    private _credentialsWo?;
    get credentialsWo(): {
        [key: string]: string;
    };
    set credentialsWo(value: {
        [key: string]: string;
    });
    resetCredentialsWo(): void;
    get credentialsWoInput(): {
        [key: string]: string;
    } | undefined;
    private _credentialsWoVersion?;
    get credentialsWoVersion(): number;
    set credentialsWoVersion(value: number);
    resetCredentialsWoVersion(): void;
    get credentialsWoVersionInput(): number | undefined;
    private _keyCollection?;
    get keyCollection(): string;
    set keyCollection(value: string);
    get keyCollectionInput(): string | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

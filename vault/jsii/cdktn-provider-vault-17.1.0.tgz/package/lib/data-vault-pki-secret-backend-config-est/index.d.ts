/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultPkiSecretBackendConfigEstConfig extends cdktn.TerraformMetaArguments {
    /**
    * Path where PKI engine is mounted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/pki_secret_backend_config_est#backend DataVaultPkiSecretBackendConfigEst#backend}
    */
    readonly backend: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/pki_secret_backend_config_est#id DataVaultPkiSecretBackendConfigEst#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/pki_secret_backend_config_est#namespace DataVaultPkiSecretBackendConfigEst#namespace}
    */
    readonly namespace?: string;
}
export interface DataVaultPkiSecretBackendConfigEstAuthenticators {
}
export declare function dataVaultPkiSecretBackendConfigEstAuthenticatorsToTerraform(struct?: DataVaultPkiSecretBackendConfigEstAuthenticators): any;
export declare function dataVaultPkiSecretBackendConfigEstAuthenticatorsToHclTerraform(struct?: DataVaultPkiSecretBackendConfigEstAuthenticators): any;
export declare class DataVaultPkiSecretBackendConfigEstAuthenticatorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataVaultPkiSecretBackendConfigEstAuthenticators | undefined;
    set internalValue(value: DataVaultPkiSecretBackendConfigEstAuthenticators | undefined);
    private _cert;
    get cert(): cdktn.StringMap;
    private _userpass;
    get userpass(): cdktn.StringMap;
}
export declare class DataVaultPkiSecretBackendConfigEstAuthenticatorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataVaultPkiSecretBackendConfigEstAuthenticatorsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/pki_secret_backend_config_est vault_pki_secret_backend_config_est}
*/
export declare class DataVaultPkiSecretBackendConfigEst extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_pki_secret_backend_config_est";
    /**
    * Generates CDKTN code for importing a DataVaultPkiSecretBackendConfigEst resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultPkiSecretBackendConfigEst to import
    * @param importFromId The id of the existing DataVaultPkiSecretBackendConfigEst that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/pki_secret_backend_config_est#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultPkiSecretBackendConfigEst to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/pki_secret_backend_config_est vault_pki_secret_backend_config_est} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultPkiSecretBackendConfigEstConfig
    */
    constructor(scope: Construct, id: string, config: DataVaultPkiSecretBackendConfigEstConfig);
    get auditFields(): string[];
    private _authenticators;
    get authenticators(): DataVaultPkiSecretBackendConfigEstAuthenticatorsList;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    get backendInput(): string | undefined;
    get defaultMount(): cdktn.IResolvable;
    get defaultPathPolicy(): string;
    get enableSentinelParsing(): cdktn.IResolvable;
    get enabled(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labelToPathPolicy;
    get labelToPathPolicy(): cdktn.StringMap;
    get lastUpdated(): string;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

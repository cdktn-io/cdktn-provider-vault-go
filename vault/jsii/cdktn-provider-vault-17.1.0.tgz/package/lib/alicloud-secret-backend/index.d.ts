/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AlicloudSecretBackendConfig extends cdktn.TerraformMetaArguments {
    /**
    * The AliCloud Access Key ID to use when generating new credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/alicloud_secret_backend#access_key AlicloudSecretBackend#access_key}
    */
    readonly accessKey: string;
    /**
    * Path of the AliCloud secrets engine mount. Must match the `path` of a `vault_mount` resource with `type = "alicloud"`. Use `vault_mount.alicloud.path` here.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/alicloud_secret_backend#mount AlicloudSecretBackend#mount}
    */
    readonly mount: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/alicloud_secret_backend#namespace AlicloudSecretBackend#namespace}
    */
    readonly namespace?: string;
    /**
    * Write-only AliCloud Secret Access Key. This value will never be read back from Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/alicloud_secret_backend#secret_key_wo AlicloudSecretBackend#secret_key_wo}
    */
    readonly secretKeyWo: string;
    /**
    * A version counter for the write-only `secret_key_wo` field. Incrementing this value will trigger an update to the secret key in Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/alicloud_secret_backend#secret_key_wo_version AlicloudSecretBackend#secret_key_wo_version}
    */
    readonly secretKeyWoVersion: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/alicloud_secret_backend vault_alicloud_secret_backend}
*/
export declare class AlicloudSecretBackend extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_alicloud_secret_backend";
    /**
    * Generates CDKTN code for importing a AlicloudSecretBackend resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlicloudSecretBackend to import
    * @param importFromId The id of the existing AlicloudSecretBackend that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/alicloud_secret_backend#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlicloudSecretBackend to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/alicloud_secret_backend vault_alicloud_secret_backend} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlicloudSecretBackendConfig
    */
    constructor(scope: Construct, id: string, config: AlicloudSecretBackendConfig);
    private _accessKey?;
    get accessKey(): string;
    set accessKey(value: string);
    get accessKeyInput(): string | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _secretKeyWo?;
    get secretKeyWo(): string;
    set secretKeyWo(value: string);
    get secretKeyWoInput(): string | undefined;
    private _secretKeyWoVersion?;
    get secretKeyWoVersion(): number;
    set secretKeyWoVersion(value: number);
    get secretKeyWoVersionInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConfigControlGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * The maximum ttl for a control group wrapping token. This can be provided in seconds or duration (for example, 2h).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/config_control_group#max_ttl ConfigControlGroup#max_ttl}
    */
    readonly maxTtl: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/config_control_group#namespace ConfigControlGroup#namespace}
    */
    readonly namespace?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/config_control_group vault_config_control_group}
*/
export declare class ConfigControlGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_config_control_group";
    /**
    * Generates CDKTN code for importing a ConfigControlGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConfigControlGroup to import
    * @param importFromId The id of the existing ConfigControlGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/config_control_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConfigControlGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/config_control_group vault_config_control_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConfigControlGroupConfig
    */
    constructor(scope: Construct, id: string, config: ConfigControlGroupConfig);
    get id(): string;
    private _maxTtl?;
    get maxTtl(): string;
    set maxTtl(value: string);
    get maxTtlInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

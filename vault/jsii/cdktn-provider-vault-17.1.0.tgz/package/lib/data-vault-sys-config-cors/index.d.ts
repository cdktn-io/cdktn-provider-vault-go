/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataVaultSysConfigCorsConfig extends cdktn.TerraformMetaArguments {
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/sys_config_cors vault_sys_config_cors}
*/
export declare class DataVaultSysConfigCors extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "vault_sys_config_cors";
    /**
    * Generates CDKTN code for importing a DataVaultSysConfigCors resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVaultSysConfigCors to import
    * @param importFromId The id of the existing DataVaultSysConfigCors that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/sys_config_cors#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVaultSysConfigCors to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/data-sources/sys_config_cors vault_sys_config_cors} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVaultSysConfigCorsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataVaultSysConfigCorsConfig);
    get allowedHeaders(): string[];
    get allowedOrigins(): string[];
    get enabled(): cdktn.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

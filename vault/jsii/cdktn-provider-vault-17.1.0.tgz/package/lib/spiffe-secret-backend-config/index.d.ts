/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SpiffeSecretBackendConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Refresh hint to use in trust bundles.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/spiffe_secret_backend_config#bundle_refresh_hint SpiffeSecretBackendConfig#bundle_refresh_hint}
    */
    readonly bundleRefreshHint?: string;
    /**
    * Base URL to use for JWT iss claim.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/spiffe_secret_backend_config#jwt_issuer_url SpiffeSecretBackendConfig#jwt_issuer_url}
    */
    readonly jwtIssuerUrl?: string;
    /**
    * If true, SPIFFE IDs in JWT SVIDs must not exceed 255 bytes, the limit for the sub claim in OIDC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/spiffe_secret_backend_config#jwt_oidc_compatibility_mode SpiffeSecretBackendConfig#jwt_oidc_compatibility_mode}
    */
    readonly jwtOidcCompatibilityMode?: boolean | cdktn.IResolvable;
    /**
    * Signing algorithm to use for JWTs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/spiffe_secret_backend_config#jwt_signing_algorithm SpiffeSecretBackendConfig#jwt_signing_algorithm}
    */
    readonly jwtSigningAlgorithm?: string;
    /**
    * How long a signing key will live for once it starts being used to sign.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/spiffe_secret_backend_config#key_lifetime SpiffeSecretBackendConfig#key_lifetime}
    */
    readonly keyLifetime?: string;
    /**
    * Mount path for the SPIFFE secrets engine in Vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/spiffe_secret_backend_config#mount SpiffeSecretBackendConfig#mount}
    */
    readonly mount: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/spiffe_secret_backend_config#namespace SpiffeSecretBackendConfig#namespace}
    */
    readonly namespace?: string;
    /**
    * The SPIFFE trust domain for this backend.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/spiffe_secret_backend_config#trust_domain SpiffeSecretBackendConfig#trust_domain}
    */
    readonly trustDomain: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/spiffe_secret_backend_config vault_spiffe_secret_backend_config}
*/
export declare class SpiffeSecretBackendConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_spiffe_secret_backend_config";
    /**
    * Generates CDKTN code for importing a SpiffeSecretBackendConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SpiffeSecretBackendConfig to import
    * @param importFromId The id of the existing SpiffeSecretBackendConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/spiffe_secret_backend_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SpiffeSecretBackendConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/spiffe_secret_backend_config vault_spiffe_secret_backend_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SpiffeSecretBackendConfigConfig
    */
    constructor(scope: Construct, id: string, config: SpiffeSecretBackendConfigConfig);
    private _bundleRefreshHint?;
    get bundleRefreshHint(): string;
    set bundleRefreshHint(value: string);
    resetBundleRefreshHint(): void;
    get bundleRefreshHintInput(): string | undefined;
    private _jwtIssuerUrl?;
    get jwtIssuerUrl(): string;
    set jwtIssuerUrl(value: string);
    resetJwtIssuerUrl(): void;
    get jwtIssuerUrlInput(): string | undefined;
    private _jwtOidcCompatibilityMode?;
    get jwtOidcCompatibilityMode(): boolean | cdktn.IResolvable;
    set jwtOidcCompatibilityMode(value: boolean | cdktn.IResolvable);
    resetJwtOidcCompatibilityMode(): void;
    get jwtOidcCompatibilityModeInput(): boolean | cdktn.IResolvable | undefined;
    private _jwtSigningAlgorithm?;
    get jwtSigningAlgorithm(): string;
    set jwtSigningAlgorithm(value: string);
    resetJwtSigningAlgorithm(): void;
    get jwtSigningAlgorithmInput(): string | undefined;
    private _keyLifetime?;
    get keyLifetime(): string;
    set keyLifetime(value: string);
    resetKeyLifetime(): void;
    get keyLifetimeInput(): string | undefined;
    private _mount?;
    get mount(): string;
    set mount(value: string);
    get mountInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _trustDomain?;
    get trustDomain(): string;
    set trustDomain(value: string);
    get trustDomainInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

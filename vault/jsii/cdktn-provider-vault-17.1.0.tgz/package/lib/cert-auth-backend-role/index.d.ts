/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CertAuthBackendRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The metadata to be tied to generated entity alias.
    *   This should be a list or map containing the metadata in key value pairs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#alias_metadata CertAuthBackendRole#alias_metadata}
    */
    readonly aliasMetadata?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#allowed_common_names CertAuthBackendRole#allowed_common_names}
    */
    readonly allowedCommonNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#allowed_dns_sans CertAuthBackendRole#allowed_dns_sans}
    */
    readonly allowedDnsSans?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#allowed_email_sans CertAuthBackendRole#allowed_email_sans}
    */
    readonly allowedEmailSans?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#allowed_names CertAuthBackendRole#allowed_names}
    */
    readonly allowedNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#allowed_organizational_units CertAuthBackendRole#allowed_organizational_units}
    */
    readonly allowedOrganizationalUnits?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#allowed_uri_sans CertAuthBackendRole#allowed_uri_sans}
    */
    readonly allowedUriSans?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#backend CertAuthBackendRole#backend}
    */
    readonly backend?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#certificate CertAuthBackendRole#certificate}
    */
    readonly certificate: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#display_name CertAuthBackendRole#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#id CertAuthBackendRole#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#name CertAuthBackendRole#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#namespace CertAuthBackendRole#namespace}
    */
    readonly namespace?: string;
    /**
    * Any additional CA certificates needed to verify OCSP responses. Provided as base64 encoded PEM data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#ocsp_ca_certificates CertAuthBackendRole#ocsp_ca_certificates}
    */
    readonly ocspCaCertificates?: string;
    /**
    * If enabled, validate certificates' revocation status using OCSP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#ocsp_enabled CertAuthBackendRole#ocsp_enabled}
    */
    readonly ocspEnabled?: boolean | cdktn.IResolvable;
    /**
    * If true and an OCSP response cannot be fetched or is of an unknown status, the login will proceed as if the certificate has not been revoked.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#ocsp_fail_open CertAuthBackendRole#ocsp_fail_open}
    */
    readonly ocspFailOpen?: boolean | cdktn.IResolvable;
    /**
    * The number of retries to attempt when connecting to an OCSP server. Defaults to 4 retries. Must be a non-negative value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#ocsp_max_retries CertAuthBackendRole#ocsp_max_retries}
    */
    readonly ocspMaxRetries?: number;
    /**
    * If set to true, rather than accepting the first successful OCSP response, query all servers and consider the certificate valid only if all servers agree.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#ocsp_query_all_servers CertAuthBackendRole#ocsp_query_all_servers}
    */
    readonly ocspQueryAllServers?: boolean | cdktn.IResolvable;
    /**
    * A comma-separated list of OCSP server addresses. If unset, the OCSP server is determined from the AuthorityInformationAccess extension on the certificate being inspected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#ocsp_servers_override CertAuthBackendRole#ocsp_servers_override}
    */
    readonly ocspServersOverride?: string[];
    /**
    * The maximum age in seconds of the 'thisUpdate' field in an OCSP response before it is considered too old. Defaults to 0 (disabled). Must be a non-negative value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#ocsp_this_update_max_age CertAuthBackendRole#ocsp_this_update_max_age}
    */
    readonly ocspThisUpdateMaxAge?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#required_extensions CertAuthBackendRole#required_extensions}
    */
    readonly requiredExtensions?: string[];
    /**
    * Specifies the blocks of IP addresses which are allowed to use the generated token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#token_bound_cidrs CertAuthBackendRole#token_bound_cidrs}
    */
    readonly tokenBoundCidrs?: string[];
    /**
    * Generated Token's Explicit Maximum TTL in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#token_explicit_max_ttl CertAuthBackendRole#token_explicit_max_ttl}
    */
    readonly tokenExplicitMaxTtl?: number;
    /**
    * The maximum lifetime of the generated token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#token_max_ttl CertAuthBackendRole#token_max_ttl}
    */
    readonly tokenMaxTtl?: number;
    /**
    * If true, the 'default' policy will not automatically be added to generated tokens
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#token_no_default_policy CertAuthBackendRole#token_no_default_policy}
    */
    readonly tokenNoDefaultPolicy?: boolean | cdktn.IResolvable;
    /**
    * The maximum number of times a token may be used, a value of zero means unlimited
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#token_num_uses CertAuthBackendRole#token_num_uses}
    */
    readonly tokenNumUses?: number;
    /**
    * Generated Token's Period
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#token_period CertAuthBackendRole#token_period}
    */
    readonly tokenPeriod?: number;
    /**
    * Generated Token's Policies
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#token_policies CertAuthBackendRole#token_policies}
    */
    readonly tokenPolicies?: string[];
    /**
    * The initial ttl of the token to generate in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#token_ttl CertAuthBackendRole#token_ttl}
    */
    readonly tokenTtl?: number;
    /**
    * The type of token to generate, service or batch
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#token_type CertAuthBackendRole#token_type}
    */
    readonly tokenType?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role vault_cert_auth_backend_role}
*/
export declare class CertAuthBackendRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_cert_auth_backend_role";
    /**
    * Generates CDKTN code for importing a CertAuthBackendRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CertAuthBackendRole to import
    * @param importFromId The id of the existing CertAuthBackendRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CertAuthBackendRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/cert_auth_backend_role vault_cert_auth_backend_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CertAuthBackendRoleConfig
    */
    constructor(scope: Construct, id: string, config: CertAuthBackendRoleConfig);
    private _aliasMetadata?;
    get aliasMetadata(): {
        [key: string]: string;
    };
    set aliasMetadata(value: {
        [key: string]: string;
    });
    resetAliasMetadata(): void;
    get aliasMetadataInput(): {
        [key: string]: string;
    } | undefined;
    private _allowedCommonNames?;
    get allowedCommonNames(): string[];
    set allowedCommonNames(value: string[]);
    resetAllowedCommonNames(): void;
    get allowedCommonNamesInput(): string[] | undefined;
    private _allowedDnsSans?;
    get allowedDnsSans(): string[];
    set allowedDnsSans(value: string[]);
    resetAllowedDnsSans(): void;
    get allowedDnsSansInput(): string[] | undefined;
    private _allowedEmailSans?;
    get allowedEmailSans(): string[];
    set allowedEmailSans(value: string[]);
    resetAllowedEmailSans(): void;
    get allowedEmailSansInput(): string[] | undefined;
    private _allowedNames?;
    get allowedNames(): string[];
    set allowedNames(value: string[]);
    resetAllowedNames(): void;
    get allowedNamesInput(): string[] | undefined;
    private _allowedOrganizationalUnits?;
    get allowedOrganizationalUnits(): string[];
    set allowedOrganizationalUnits(value: string[]);
    resetAllowedOrganizationalUnits(): void;
    get allowedOrganizationalUnitsInput(): string[] | undefined;
    private _allowedUriSans?;
    get allowedUriSans(): string[];
    set allowedUriSans(value: string[]);
    resetAllowedUriSans(): void;
    get allowedUriSansInput(): string[] | undefined;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    resetBackend(): void;
    get backendInput(): string | undefined;
    private _certificate?;
    get certificate(): string;
    set certificate(value: string);
    get certificateInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _ocspCaCertificates?;
    get ocspCaCertificates(): string;
    set ocspCaCertificates(value: string);
    resetOcspCaCertificates(): void;
    get ocspCaCertificatesInput(): string | undefined;
    private _ocspEnabled?;
    get ocspEnabled(): boolean | cdktn.IResolvable;
    set ocspEnabled(value: boolean | cdktn.IResolvable);
    resetOcspEnabled(): void;
    get ocspEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _ocspFailOpen?;
    get ocspFailOpen(): boolean | cdktn.IResolvable;
    set ocspFailOpen(value: boolean | cdktn.IResolvable);
    resetOcspFailOpen(): void;
    get ocspFailOpenInput(): boolean | cdktn.IResolvable | undefined;
    private _ocspMaxRetries?;
    get ocspMaxRetries(): number;
    set ocspMaxRetries(value: number);
    resetOcspMaxRetries(): void;
    get ocspMaxRetriesInput(): number | undefined;
    private _ocspQueryAllServers?;
    get ocspQueryAllServers(): boolean | cdktn.IResolvable;
    set ocspQueryAllServers(value: boolean | cdktn.IResolvable);
    resetOcspQueryAllServers(): void;
    get ocspQueryAllServersInput(): boolean | cdktn.IResolvable | undefined;
    private _ocspServersOverride?;
    get ocspServersOverride(): string[];
    set ocspServersOverride(value: string[]);
    resetOcspServersOverride(): void;
    get ocspServersOverrideInput(): string[] | undefined;
    private _ocspThisUpdateMaxAge?;
    get ocspThisUpdateMaxAge(): number;
    set ocspThisUpdateMaxAge(value: number);
    resetOcspThisUpdateMaxAge(): void;
    get ocspThisUpdateMaxAgeInput(): number | undefined;
    private _requiredExtensions?;
    get requiredExtensions(): string[];
    set requiredExtensions(value: string[]);
    resetRequiredExtensions(): void;
    get requiredExtensionsInput(): string[] | undefined;
    private _tokenBoundCidrs?;
    get tokenBoundCidrs(): string[];
    set tokenBoundCidrs(value: string[]);
    resetTokenBoundCidrs(): void;
    get tokenBoundCidrsInput(): string[] | undefined;
    private _tokenExplicitMaxTtl?;
    get tokenExplicitMaxTtl(): number;
    set tokenExplicitMaxTtl(value: number);
    resetTokenExplicitMaxTtl(): void;
    get tokenExplicitMaxTtlInput(): number | undefined;
    private _tokenMaxTtl?;
    get tokenMaxTtl(): number;
    set tokenMaxTtl(value: number);
    resetTokenMaxTtl(): void;
    get tokenMaxTtlInput(): number | undefined;
    private _tokenNoDefaultPolicy?;
    get tokenNoDefaultPolicy(): boolean | cdktn.IResolvable;
    set tokenNoDefaultPolicy(value: boolean | cdktn.IResolvable);
    resetTokenNoDefaultPolicy(): void;
    get tokenNoDefaultPolicyInput(): boolean | cdktn.IResolvable | undefined;
    private _tokenNumUses?;
    get tokenNumUses(): number;
    set tokenNumUses(value: number);
    resetTokenNumUses(): void;
    get tokenNumUsesInput(): number | undefined;
    private _tokenPeriod?;
    get tokenPeriod(): number;
    set tokenPeriod(value: number);
    resetTokenPeriod(): void;
    get tokenPeriodInput(): number | undefined;
    private _tokenPolicies?;
    get tokenPolicies(): string[];
    set tokenPolicies(value: string[]);
    resetTokenPolicies(): void;
    get tokenPoliciesInput(): string[] | undefined;
    private _tokenTtl?;
    get tokenTtl(): number;
    set tokenTtl(value: number);
    resetTokenTtl(): void;
    get tokenTtlInput(): number | undefined;
    private _tokenType?;
    get tokenType(): string;
    set tokenType(value: string);
    resetTokenType(): void;
    get tokenTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

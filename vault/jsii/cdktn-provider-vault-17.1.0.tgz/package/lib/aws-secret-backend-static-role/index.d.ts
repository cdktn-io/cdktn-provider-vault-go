/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSecretBackendStaticRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ARN of the role to assume when managing the static role. This is required for cross-account role management.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/aws_secret_backend_static_role#assume_role_arn AwsSecretBackendStaticRole#assume_role_arn}
    */
    readonly assumeRoleArn?: string;
    /**
    * Session name to use when assuming the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/aws_secret_backend_static_role#assume_role_session_name AwsSecretBackendStaticRole#assume_role_session_name}
    */
    readonly assumeRoleSessionName?: string;
    /**
    * The path where the AWS secrets backend is mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/aws_secret_backend_static_role#backend AwsSecretBackendStaticRole#backend}
    */
    readonly backend?: string;
    /**
    * External ID to use when assuming the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/aws_secret_backend_static_role#external_id AwsSecretBackendStaticRole#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/aws_secret_backend_static_role#id AwsSecretBackendStaticRole#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/aws_secret_backend_static_role#name AwsSecretBackendStaticRole#name}
    */
    readonly name: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/aws_secret_backend_static_role#namespace AwsSecretBackendStaticRole#namespace}
    */
    readonly namespace?: string;
    /**
    * How often Vault should rotate the password of the user entry.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/aws_secret_backend_static_role#rotation_period AwsSecretBackendStaticRole#rotation_period}
    */
    readonly rotationPeriod: number;
    /**
    * The username of the existing AWS IAM user to manage password rotation for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/aws_secret_backend_static_role#username AwsSecretBackendStaticRole#username}
    */
    readonly username: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/aws_secret_backend_static_role vault_aws_secret_backend_static_role}
*/
export declare class AwsSecretBackendStaticRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_aws_secret_backend_static_role";
    /**
    * Generates CDKTN code for importing a AwsSecretBackendStaticRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSecretBackendStaticRole to import
    * @param importFromId The id of the existing AwsSecretBackendStaticRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/aws_secret_backend_static_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSecretBackendStaticRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/aws_secret_backend_static_role vault_aws_secret_backend_static_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSecretBackendStaticRoleConfig
    */
    constructor(scope: Construct, id: string, config: AwsSecretBackendStaticRoleConfig);
    private _assumeRoleArn?;
    get assumeRoleArn(): string;
    set assumeRoleArn(value: string);
    resetAssumeRoleArn(): void;
    get assumeRoleArnInput(): string | undefined;
    private _assumeRoleSessionName?;
    get assumeRoleSessionName(): string;
    set assumeRoleSessionName(value: string);
    resetAssumeRoleSessionName(): void;
    get assumeRoleSessionNameInput(): string | undefined;
    private _backend?;
    get backend(): string;
    set backend(value: string);
    resetBackend(): void;
    get backendInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _rotationPeriod?;
    get rotationPeriod(): number;
    set rotationPeriod(value: number);
    get rotationPeriodInput(): number | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}

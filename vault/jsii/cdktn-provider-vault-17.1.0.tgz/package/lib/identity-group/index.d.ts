/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IdentityGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Manage member entities externally through `vault_identity_group_member_entity_ids`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group#external_member_entity_ids IdentityGroup#external_member_entity_ids}
    */
    readonly externalMemberEntityIds?: boolean | cdktn.IResolvable;
    /**
    * Manage member groups externally through `vault_identity_group_member_group_ids`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group#external_member_group_ids IdentityGroup#external_member_group_ids}
    */
    readonly externalMemberGroupIds?: boolean | cdktn.IResolvable;
    /**
    * Manage policies externally through `vault_identity_group_policies`, allows using group ID in assigned policies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group#external_policies IdentityGroup#external_policies}
    */
    readonly externalPolicies?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group#id IdentityGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Entity IDs to be assigned as group members.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group#member_entity_ids IdentityGroup#member_entity_ids}
    */
    readonly memberEntityIds?: string[];
    /**
    * Group IDs to be assigned as group members.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group#member_group_ids IdentityGroup#member_group_ids}
    */
    readonly memberGroupIds?: string[];
    /**
    * Metadata to be associated with the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group#metadata IdentityGroup#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
    * Name of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group#name IdentityGroup#name}
    */
    readonly name?: string;
    /**
    * Target namespace. (requires Enterprise)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group#namespace IdentityGroup#namespace}
    */
    readonly namespace?: string;
    /**
    * Policies to be tied to the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group#policies IdentityGroup#policies}
    */
    readonly policies?: string[];
    /**
    * Type of the group, internal or external. Defaults to internal.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group#type IdentityGroup#type}
    */
    readonly type?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group vault_identity_group}
*/
export declare class IdentityGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "vault_identity_group";
    /**
    * Generates CDKTN code for importing a IdentityGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IdentityGroup to import
    * @param importFromId The id of the existing IdentityGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IdentityGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.10.0/docs/resources/identity_group vault_identity_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IdentityGroupConfig = {}
    */
    constructor(scope: Construct, id: string, config?: IdentityGroupConfig);
    private _externalMemberEntityIds?;
    get externalMemberEntityIds(): boolean | cdktn.IResolvable;
    set externalMemberEntityIds(value: boolean | cdktn.IResolvable);
    resetExternalMemberEntityIds(): void;
    get externalMemberEntityIdsInput(): boolean | cdktn.IResolvable | undefined;
    private _externalMemberGroupIds?;
    get externalMemberGroupIds(): boolean | cdktn.IResolvable;
    set externalMemberGroupIds(value: boolean | cdktn.IResolvable);
    resetExternalMemberGroupIds(): void;
    get externalMemberGroupIdsInput(): boolean | cdktn.IResolvable | undefined;
    private _externalPolicies?;
    get externalPolicies(): boolean | cdktn.IResolvable;
    set externalPolicies(value: boolean | cdktn.IResolvable);
    resetExternalPolicies(): void;
    get externalPoliciesInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _memberEntityIds?;
    get memberEntityIds(): string[];
    set memberEntityIds(value: string[]);
    resetMemberEntityIds(): void;
    get memberEntityIdsInput(): string[] | undefined;
    private _memberGroupIds?;
    get memberGroupIds(): string[];
    set memberGroupIds(value: string[]);
    resetMemberGroupIds(): void;
    get memberGroupIdsInput(): string[] | undefined;
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _policies?;
    get policies(): string[];
    set policies(value: string[]);
    resetPolicies(): void;
    get policiesInput(): string[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
